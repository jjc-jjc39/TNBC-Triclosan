# ==============================================================================
# TNBC_Triclosan
# Step 3 - GSE95554 real Triclosan exposure validation
# Script 12D v5 FINAL
#
# Purpose:
#   Continue strictly from the accepted Script 12C rat gene-level expression
#   bundle. Audit current rat-to-human ortholog relationships before creating
#   any human-ortholog expression matrix or performing exposure comparisons.
#
# Primary ortholog source:
#   NCBI Gene FTP DATA/gene_orthologs.gz.
#
# Supporting current GeneID/symbol sources:
#   NCBI Gene FTP species-specific gene_info files for:
#     - Rattus norvegicus, tax_id 10116
#     - Homo sapiens, tax_id 9606
#
# Mapping policy in this script:
#   - Rat genes enter by the single NCBI GeneID preserved in Script 12C.
#   - Rat-human ortholog pairs are accepted regardless of which species appears
#     in the first two columns of gene_orthologs.
#   - Exact rat/human GeneID pairs are deduplicated.
#   - Every rat gene is classified as:
#       NO_CURRENT_NCBI_RAT_RECORD
#       NO_HUMAN_ORTHOLOG
#       ONE_HUMAN_ORTHOLOG
#       MULTIPLE_HUMAN_ORTHOLOGS
#   - Every human ortholog is classified by how many assayed rat genes map to it,
#     allowing explicit identification of many-rat-to-one-human relationships.
#
# This script DOES:
#   - verify accepted Script 12C report, manifest, fixed MD5 and matrix;
#   - download NCBI ortholog and species gene_info files with bounded retries;
#   - preserve downloaded source files and MD5s;
#   - build complete rat-to-human mapping and relationship audits;
#   - audit the locked 24-human-gene signature, including whether each human
#     gene has zero, one or multiple assayed rat orthologs;
#   - save an RDS audit bundle, CSV tables, manifests, report and sessionInfo.
#
# This script DOES NOT:
#   - alter or aggregate the 19,098 x 50 rat expression matrix;
#   - create a human-ortholog expression matrix;
#   - automatically combine Abcb1a and Abcb1b into ABCB1;
#   - choose one ortholog from a one-to-many relationship;
#   - perform DEG, PCA, GSVA, GSEA or TCS-versus-OIL testing;
#   - use expression variation or biological results to select mappings.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
previous_error_option <- getOption("error")
options(stringsAsFactors = FALSE, warn = 1)
# Clear any inherited recover/browser error handler from the interactive
# R session so a future failure returns a normal error instead of Browse[].
options(error = NULL)
options(timeout = max(1800L, getOption("timeout")))
Sys.setenv(TZ = "Asia/Singapore")

SCRIPT_BUILD_ID <- "Script12D_v5_FINAL_20260711"

cat("============================================================\n")
cat("RUNNING: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat("NCBI Gene ortholog audit: ENABLED\n")
cat("Tax-ID filtering and malformed-row sanitization: ENABLED\n")
cat("Deterministic duplicate GeneID resolution: ENABLED\n")
cat("Single-row-safe completeness scoring: ENABLED\n")
cat("Schema-safe audit-table binding: ENABLED\n")
cat("Zero-row-safe ortholog direction handling: ENABLED\n")
cat("Synthetic boundary self-tests before live data: ENABLED\n")
cat("Direct expanded-pair construction without string re-parsing: ENABLED\n")
cat("Human-ortholog expression aggregation: DISABLED\n")
cat("ABCB1 paralog combination: DISABLED\n")
cat("Differential expression and pathway analysis: DISABLED\n")
cat("============================================================\n")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step3_GSE95554_real_exposure_validation"
)

input_root <- file.path(
  step_root,
  "02_gene_level_expression"
)
final_root <- file.path(
  step_root,
  "03_rat_human_ortholog_audit"
)

input_bundle_file <- file.path(
  input_root,
  "objects",
  "GSE95554_gene_level_expression_COMPLETE_bundle.rds"
)
input_matrix_file <- file.path(
  input_root,
  "objects",
  "GSE95554_gene_level_expression_matrix.rds"
)
input_manifest_file <- file.path(
  input_root,
  "audit",
  "Script12C_output_manifest_with_MD5.csv"
)
input_report_file <- file.path(
  input_root,
  "logs",
  "Script12C_COMPLETE_report.txt"
)
input_integrity_file <- file.path(
  input_root,
  "audit",
  "GSE95554_gene_level_expression_integrity_summary.csv"
)
input_gene_audit_file <- file.path(
  input_root,
  "audit",
  "GSE95554_gene_level_aggregation_audit.csv"
)

required_inputs <- c(
  input_bundle_file,
  input_matrix_file,
  input_manifest_file,
  input_report_file,
  input_integrity_file,
  input_gene_audit_file
)

missing_inputs <- required_inputs[
  !file.exists(required_inputs)
]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 12D cannot start because required accepted Script 12C files ",
      "are missing:\n",
      paste0(
        "- ",
        missing_inputs,
        collapse = "\n"
      )
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop(
    paste0(
      "Step 3 directory does not exist:\n",
      step_root
    ),
    call. = FALSE
  )
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(
      final_root,
      all.files = TRUE
    ),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(
      final_root,
      recursive = TRUE,
      force = TRUE
    )
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 12D will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive that directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(
  Sys.time(),
  "%Y%m%d_%H%M%S"
)

stage_root <- file.path(
  step_root,
  paste0(
    ".Script12D_staging_",
    stamp,
    "_",
    Sys.getpid()
  )
)
stage_download_dir <- file.path(
  stage_root,
  "downloads"
)
stage_object_dir <- file.path(
  stage_root,
  "objects"
)
stage_audit_dir <- file.path(
  stage_root,
  "audit"
)
stage_log_dir <- file.path(
  stage_root,
  "logs"
)

for (directory_i in c(
  stage_download_dir,
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)) {
  dir.create(
    directory_i,
    recursive = TRUE,
    showWarnings = FALSE
  )
}

if (!all(dir.exists(c(
  stage_download_dir,
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop(
    "Unable to create Script 12D staging directories.",
    call. = FALSE
  )
}

committed <- FALSE

on.exit({
  options(error = previous_error_option)

  if (!committed && dir.exists(stage_root)) {
    unlink(
      stage_root,
      recursive = TRUE,
      force = TRUE
    )
  }
}, add = TRUE)

# ------------------------------
# 1. General helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) {
    stop(
      message,
      call. = FALSE
    )
  }
}

md5_one <- function(path) {
  unname(
    tools::md5sum(path)
  )
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(
    report_file,
    warn = FALSE,
    encoding = "UTF-8"
  )

  any(
    grepl(
      fixed_text,
      lines,
      fixed = TRUE
    )
  )
}

manifest_expected_md5 <- function(
  manifest_file,
  target_file
) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c(
      "file_name",
      "size_bytes",
      "md5"
    ) %in% colnames(manifest)),
    paste0(
      "Malformed manifest:\n",
      manifest_file
    )
  )

  row_index <- which(
    manifest$file_name ==
      basename(target_file)
  )

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file),
      "."
    )
  )

  tolower(
    trimws(
      as.character(
        manifest$md5[row_index]
      )
    )
  )
}

make_manifest <- function(paths) {
  assert_true(
    length(paths) >= 1L,
    "Cannot create an empty manifest."
  )

  info <- file.info(paths)

  data.frame(
    file_name = basename(paths),
    absolute_path = vapply(
      paths,
      function(path_i) {
        normalizePath(
          path_i,
          winslash = "/",
          mustWork = FALSE
        )
      },
      character(1)
    ),
    size_bytes = as.numeric(
      info$size
    ),
    md5 = vapply(
      paths,
      md5_one,
      character(1)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

clean_text <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  trimws(x)
}

safe_integer_character <- function(x, field_name) {
  x <- clean_text(x)

  assert_true(
    all(
      grepl(
        "^[0-9]+$",
        x
      )
    ),
    paste0(
      "Field ",
      field_name,
      " contains a blank or non-numeric GeneID."
    )
  )

  x
}

split_semicolon_values <- function(x) {
  x <- clean_text(x)

  if (!nzchar(x)) {
    return(character(0))
  }

  result <- clean_text(
    unlist(
      strsplit(
        x,
        split = ";",
        fixed = TRUE
      ),
      use.names = FALSE
    )
  )

  sort(
    unique(
      result[nzchar(result)]
    )
  )
}

collapse_unique <- function(x) {
  x <- sort(
    unique(
      clean_text(x)
    )
  )
  x <- x[nzchar(x)]

  if (length(x) == 0L) {
    ""
  } else {
    paste(
      x,
      collapse = ";"
    )
  }
}

capture_warnings <- function(expression) {
  warning_messages <- character(0)

  value <- withCallingHandlers(
    expression,
    warning = function(w) {
      warning_messages <<- c(
        warning_messages,
        conditionMessage(w)
      )
      invokeRestart("muffleWarning")
    }
  )

  list(
    value = value,
    warnings = unique(warning_messages)
  )
}

collapse_messages <- function(x) {
  x <- unique(
    trimws(
      as.character(x)
    )
  )
  x <- x[
    !is.na(x) &
      nzchar(x)
  ]

  if (length(x) == 0L) {
    ""
  } else {
    paste(
      x,
      collapse = " | "
    )
  }
}

rbind_fill_base <- function(...) {
  tables <- list(...)

  tables <- tables[
    !vapply(
      tables,
      is.null,
      logical(1)
    )
  ]

  assert_true(
    length(tables) >= 1L,
    "rbind_fill_base received no data frames."
  )

  assert_true(
    all(
      vapply(
        tables,
        is.data.frame,
        logical(1)
      )
    ),
    "rbind_fill_base accepts data frames only."
  )

  all_columns <- unique(
    unlist(
      lapply(
        tables,
        colnames
      ),
      use.names = FALSE
    )
  )

  normalized <- lapply(
    tables,
    function(table_i) {
      missing_columns <- setdiff(
        all_columns,
        colnames(table_i)
      )

      if (length(missing_columns) > 0L) {
        for (column_i in missing_columns) {
          table_i[[column_i]] <- rep(
            NA,
            times = nrow(table_i)
          )
        }
      }

      table_i[
        ,
        all_columns,
        drop = FALSE
      ]
    }
  )

  result <- do.call(
    rbind,
    normalized
  )
  rownames(result) <- NULL
  result
}

make_directional_pair_frame <- function(
  source_table,
  rat_gene_column,
  human_gene_column,
  orientation_label
) {
  assert_true(
    is.data.frame(source_table),
    "Directional ortholog source must be a data frame."
  )

  assert_true(
    rat_gene_column %in%
      colnames(source_table) &&
      human_gene_column %in%
        colnames(source_table),
    paste0(
      "Directional ortholog source is missing required columns: ",
      rat_gene_column,
      " and/or ",
      human_gene_column,
      "."
    )
  )

  row_number <- nrow(
    source_table
  )

  rat_gene_ids_i <- clean_text(
    source_table[[
      rat_gene_column
    ]]
  )
  human_gene_ids_i <- clean_text(
    source_table[[
      human_gene_column
    ]]
  )

  assert_true(
    length(rat_gene_ids_i) ==
      row_number &&
      length(human_gene_ids_i) ==
        row_number,
    paste0(
      "Directional ortholog source columns have inconsistent lengths for ",
      orientation_label,
      "."
    )
  )

  # rep(..., times = 0L) returns character(0), so an absent orientation is
  # represented by a valid zero-row data frame rather than a 0-versus-1 error.
  result <- data.frame(
    rat_gene_id =
      rat_gene_ids_i,
    human_gene_id =
      human_gene_ids_i,
    source_orientation = rep(
      orientation_label,
      times = row_number
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    nrow(result) ==
      row_number &&
      identical(
        colnames(result),
        c(
          "rat_gene_id",
          "human_gene_id",
          "source_orientation"
        )
      ),
    paste0(
      "Directional pair construction failed for ",
      orientation_label,
      "."
    )
  )

  result
}

download_with_retries <- function(
  url,
  destination,
  minimum_size_bytes,
  maximum_attempts = 3L
) {
  audit_rows <- vector(
    "list",
    maximum_attempts
  )

  success <- FALSE
  final_error <- ""
  attempts_used <- 0L

  for (attempt_i in seq_len(maximum_attempts)) {
    attempts_used <- attempt_i
    warning_messages <- character(0)
    error_message <- ""
    start_time <- format(
      Sys.time(),
      "%Y-%m-%d %H:%M:%S %Z"
    )

    if (file.exists(destination)) {
      unlink(
        destination,
        force = TRUE
      )
    }

    result_i <- tryCatch(
      withCallingHandlers(
        utils::download.file(
          url = url,
          destfile = destination,
          mode = "wb",
          quiet = FALSE,
          method = "auto"
        ),
        warning = function(w) {
          warning_messages <<- c(
            warning_messages,
            conditionMessage(w)
          )
          invokeRestart("muffleWarning")
        }
      ),
      error = function(e) {
        error_message <<- conditionMessage(e)
        NA_integer_
      }
    )

    exists_i <- file.exists(destination)
    size_i <- if (exists_i) {
      as.numeric(
        file.info(destination)$size
      )
    } else {
      0
    }

    success_i <- exists_i &&
      is.finite(size_i) &&
      size_i >= minimum_size_bytes &&
      (
        is.numeric(result_i) ||
          is.integer(result_i)
      ) &&
      length(result_i) == 1L &&
      !is.na(result_i) &&
      result_i == 0L

    audit_rows[[attempt_i]] <- data.frame(
      source_url = url,
      destination_file = basename(destination),
      attempt = attempt_i,
      start_time = start_time,
      end_time = format(
        Sys.time(),
        "%Y-%m-%d %H:%M:%S %Z"
      ),
      download_return_code = if (
        length(result_i) == 1L &&
          !is.na(result_i)
      ) {
        as.character(result_i)
      } else {
        ""
      },
      file_exists = exists_i,
      size_bytes = size_i,
      minimum_expected_size_bytes =
        minimum_size_bytes,
      succeeded = success_i,
      warning_messages =
        collapse_messages(
          warning_messages
        ),
      error_message = error_message,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )

    if (success_i) {
      success <- TRUE
      break
    }

    final_error <- if (nzchar(error_message)) {
      error_message
    } else {
      paste0(
        "Downloaded file was absent or smaller than ",
        minimum_size_bytes,
        " bytes."
      )
    }

    if (attempt_i < maximum_attempts) {
      Sys.sleep(
        2L * attempt_i
      )
    }
  }

  audit <- do.call(
    rbind,
    audit_rows[
      seq_len(attempts_used)
    ]
  )
  rownames(audit) <- NULL

  assert_true(
    success,
    paste0(
      "Unable to download the required NCBI source after ",
      maximum_attempts,
      " attempts:\n",
      url,
      "\nLast error: ",
      final_error
    )
  )

  list(
    file = destination,
    audit = audit
  )
}

read_ncbi_gzip_table <- function(
  file,
  expected_columns,
  table_name
) {
  connection <- gzfile(
    file,
    open = "rt"
  )

  on.exit(
    close(connection),
    add = TRUE
  )

  result <- capture_warnings(
    utils::read.delim(
      connection,
      header = TRUE,
      sep = "\t",
      quote = "",
      comment.char = "",
      stringsAsFactors = FALSE,
      check.names = FALSE,
      colClasses = "character"
    )
  )

  table_i <- result$value

  assert_true(
    is.data.frame(table_i) &&
      nrow(table_i) >= 1L,
    paste0(
      table_name,
      " was empty or malformed."
    )
  )

  normalized_names <- sub(
    "^#",
    "",
    colnames(table_i)
  )
  colnames(table_i) <- normalized_names

  assert_true(
    all(
      expected_columns %in%
        colnames(table_i)
    ),
    paste0(
      table_name,
      " is missing required columns: ",
      paste(
        setdiff(
          expected_columns,
          colnames(table_i)
        ),
        collapse = ", "
      ),
      "\nObserved columns: ",
      paste(
        colnames(table_i),
        collapse = ", "
      )
    )
  )

  list(
    table = table_i,
    warnings = result$warnings
  )
}

sanitize_gene_info_table <- function(
  table_i,
  target_tax_id,
  table_name,
  minimum_retained_rows = 1000L
) {
  required_columns <- c(
    "tax_id",
    "GeneID",
    "Symbol",
    "Synonyms",
    "description",
    "type_of_gene"
  )

  assert_true(
    is.data.frame(table_i) &&
      all(
        required_columns %in%
          colnames(table_i)
      ),
    paste0(
      table_name,
      " is missing required columns before sanitization."
    )
  )

  raw_row_number <- nrow(table_i)
  source_row_number_original <- seq_len(
    raw_row_number
  )

  for (column_i in colnames(table_i)) {
    table_i[[column_i]] <- clean_text(
      table_i[[column_i]]
    )
  }

  # Keep the source-row index numeric. It is used only as the final deterministic
  # tie-breaker and must not be ordered lexicographically as character text.
  table_i$source_row_number <- source_row_number_original

  valid_tax_id <- grepl(
    "^[0-9]+$",
    table_i$tax_id
  )
  valid_gene_id <- grepl(
    "^[0-9]+$",
    table_i$GeneID
  )
  target_tax_id_row <-
    valid_tax_id &
    table_i$tax_id == target_tax_id

  candidate <- table_i[
    target_tax_id_row &
      valid_gene_id,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(candidate) >=
      minimum_retained_rows,
    paste0(
      table_name,
      " contains only ",
      nrow(candidate),
      " valid rows for target tax_id ",
      target_tax_id,
      " before duplicate resolution; expected at least ",
      minimum_retained_rows,
      "."
    )
  )

  assert_true(
    ncol(candidate) >= 2L,
    paste0(
      table_name,
      " target-species candidate table has fewer than two columns."
    )
  )

  target_rows_before_geneid_filter <- sum(
    target_tax_id_row
  )
  invalid_geneid_target_rows <- sum(
    target_tax_id_row &
      !valid_gene_id
  )

  # Remove rows that are exact duplicates across all original source fields.
  original_columns <- setdiff(
    colnames(candidate),
    "source_row_number"
  )

  assert_true(
    length(original_columns) >= 1L,
    paste0(
      table_name,
      " has no original source columns available for duplicate resolution."
    )
  )

  exact_duplicate_mask <- duplicated(
    candidate[
      ,
      original_columns,
      drop = FALSE
    ]
  )
  exact_duplicate_row_number <- sum(
    exact_duplicate_mask
  )

  candidate <- candidate[
    !exact_duplicate_mask,
    ,
    drop = FALSE
  ]

  geneid_groups <- split(
    seq_len(
      nrow(candidate)
    ),
    candidate$GeneID,
    drop = TRUE
  )

  assert_true(
    length(geneid_groups) >=
      minimum_retained_rows &&
      all(
        lengths(
          geneid_groups
        ) >= 1L
      ),
    paste0(
      table_name,
      " produced an invalid GeneID grouping structure."
    )
  )

  duplicated_geneid_groups <- geneid_groups[
    lengths(geneid_groups) > 1L
  ]

  duplicate_audit_rows <- list()
  selected_rows <- integer(
    length(geneid_groups)
  )
  selected_index <- 0L

  for (gene_id_i in names(geneid_groups)) {
    selected_index <- selected_index + 1L
    row_indices <- geneid_groups[[gene_id_i]]

    candidate_subset <- candidate[
      row_indices,
      original_columns,
      drop = FALSE
    ]

    assert_true(
      nrow(candidate_subset) ==
        length(row_indices) &&
        ncol(candidate_subset) ==
          length(original_columns),
      paste0(
        table_name,
        " internal duplicate-resolution subset has invalid dimensions for ",
        "GeneID ",
        gene_id_i,
        "."
      )
    )

    # as.matrix() preserves a two-dimensional object even when the GeneID has
    # only one candidate row. This avoids vapply() simplifying a 1-row result
    # to a vector and causing rowSums() to fail.
    candidate_character_matrix <- as.matrix(
      candidate_subset
    )

    if (
      is.null(
        dim(
          candidate_character_matrix
        )
      )
    ) {
      candidate_character_matrix <- matrix(
        candidate_character_matrix,
        nrow = length(row_indices),
        ncol = length(original_columns)
      )
    }

    nonblank_matrix <- matrix(
      nzchar(
        clean_text(
          candidate_character_matrix
        )
      ),
      nrow = nrow(
        candidate_character_matrix
      ),
      ncol = ncol(
        candidate_character_matrix
      ),
      dimnames = dimnames(
        candidate_character_matrix
      )
    )

    completeness_score <- rowSums(
      nonblank_matrix,
      na.rm = TRUE
    )

    assert_true(
      length(completeness_score) ==
        length(row_indices) &&
        all(
          is.finite(
            completeness_score
          )
        ),
      paste0(
        table_name,
        " completeness scoring failed for GeneID ",
        gene_id_i,
        "."
      )
    )

    symbol_available <- nzchar(
      candidate$Symbol[
        row_indices
      ]
    )
    description_available <- nzchar(
      candidate$description[
        row_indices
      ]
    )
    type_available <- nzchar(
      candidate$type_of_gene[
        row_indices
      ]
    )

    assert_true(
      length(symbol_available) ==
        length(row_indices) &&
        length(description_available) ==
          length(row_indices) &&
        length(type_available) ==
          length(row_indices),
      paste0(
        table_name,
        " duplicate-resolution ranking vectors are misaligned for GeneID ",
        gene_id_i,
        "."
      )
    )

    ranking <- order(
      -as.integer(symbol_available),
      -as.integer(description_available),
      -as.integer(type_available),
      -as.numeric(completeness_score),
      candidate$source_row_number[
        row_indices
      ],
      na.last = TRUE,
      method = "radix"
    )

    assert_true(
      length(ranking) ==
        length(row_indices) &&
        all(
          ranking %in%
            seq_along(
              row_indices
            )
        ),
      paste0(
        table_name,
        " duplicate-resolution ranking failed for GeneID ",
        gene_id_i,
        "."
      )
    )

    chosen_row <- row_indices[
      ranking[1]
    ]

    assert_true(
      length(chosen_row) == 1L &&
        is.finite(chosen_row) &&
        chosen_row >= 1L &&
        chosen_row <= nrow(candidate),
      paste0(
        table_name,
        " selected an invalid source row for GeneID ",
        gene_id_i,
        "."
      )
    )
    selected_rows[
      selected_index
    ] <- chosen_row

    if (length(row_indices) > 1L) {
      duplicate_audit_rows[[
        length(
          duplicate_audit_rows
        ) + 1L
      ]] <- data.frame(
        source_table = table_name,
        GeneID = gene_id_i,
        candidate_row_number =
          length(row_indices),
        candidate_source_rows = paste(
          candidate$source_row_number[
            row_indices
          ],
          collapse = ";"
        ),
        selected_source_row =
          candidate$source_row_number[
            chosen_row
          ],
        selected_symbol =
          candidate$Symbol[
            chosen_row
          ],
        resolution_rule = paste0(
          "PREFER_NONBLANK_SYMBOL_DESCRIPTION_TYPE;",
          "THEN_MAX_COMPLETENESS;",
          "THEN_EARLIEST_SOURCE_ROW"
        ),
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
  }

  retained <- candidate[
    selected_rows,
    ,
    drop = FALSE
  ]

  retained <- retained[
    order(
      suppressWarnings(
        as.numeric(
          retained$GeneID
        )
      ),
      retained$GeneID
    ),
    ,
    drop = FALSE
  ]

  rownames(retained) <- NULL

  assert_true(
    nrow(retained) >=
      minimum_retained_rows,
    paste0(
      table_name,
      " retained only ",
      nrow(retained),
      " target-species rows after sanitization; expected at least ",
      minimum_retained_rows,
      "."
    )
  )

  assert_true(
    all(
      retained$tax_id ==
        target_tax_id
    ) &&
      all(
        grepl(
          "^[0-9]+$",
          retained$GeneID
        )
      ) &&
      anyDuplicated(
        retained$GeneID
      ) == 0L,
    paste0(
      table_name,
      " failed post-sanitization tax_id/GeneID integrity checks."
    )
  )

  non_target_tax_ids <- sort(
    unique(
      table_i$tax_id[
        valid_tax_id &
          table_i$tax_id != target_tax_id
      ]
    )
  )

  malformed_tax_id_values <- sort(
    unique(
      table_i$tax_id[
        !valid_tax_id &
          nzchar(
            table_i$tax_id
          )
      ]
    )
  )

  duplicate_audit <- if (
    length(
      duplicate_audit_rows
    ) == 0L
  ) {
    data.frame(
      source_table = character(0),
      GeneID = character(0),
      candidate_row_number = integer(0),
      candidate_source_rows = character(0),
      selected_source_row = integer(0),
      selected_symbol = character(0),
      resolution_rule = character(0),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  } else {
    result_i <- do.call(
      rbind,
      duplicate_audit_rows
    )
    rownames(result_i) <- NULL
    result_i
  }

  filter_audit <- data.frame(
    source_table = table_name,
    target_tax_id = target_tax_id,
    raw_row_number = raw_row_number,
    valid_tax_id_row_number = sum(
      valid_tax_id
    ),
    blank_or_malformed_tax_id_row_number = sum(
      !valid_tax_id
    ),
    target_tax_id_row_number_before_GeneID_filter =
      target_rows_before_geneid_filter,
    non_target_tax_id_row_number = sum(
      valid_tax_id &
        table_i$tax_id != target_tax_id
    ),
    invalid_GeneID_rows_with_target_tax_id =
      invalid_geneid_target_rows,
    exact_duplicate_row_number_removed =
      exact_duplicate_row_number,
    duplicated_GeneID_group_number_resolved =
      length(
        duplicated_geneid_groups
      ),
    retained_unique_target_GeneID_row_number =
      nrow(retained),
    observed_non_target_tax_ids = if (
      length(
        non_target_tax_ids
      ) == 0L
    ) {
      ""
    } else {
      paste(
        non_target_tax_ids,
        collapse = ";"
      )
    },
    malformed_tax_id_values = if (
      length(
        malformed_tax_id_values
      ) == 0L
    ) {
      ""
    } else {
      paste(
        malformed_tax_id_values,
        collapse = ";"
      )
    },
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  retained$source_row_number <- NULL

  list(
    table = retained,
    filter_audit = filter_audit,
    duplicate_audit = duplicate_audit
  )
}

sanitize_ortholog_table <- function(
  table_i,
  table_name = "NCBI_gene_orthologs",
  minimum_retained_rows = 10000L
) {
  required_columns <- c(
    "tax_id",
    "GeneID",
    "relationship",
    "Other_tax_id",
    "Other_GeneID"
  )

  assert_true(
    is.data.frame(table_i) &&
      all(
        required_columns %in%
          colnames(table_i)
      ),
    paste0(
      table_name,
      " is missing required columns before sanitization."
    )
  )

  raw_row_number <- nrow(table_i)

  for (column_i in required_columns) {
    table_i[[column_i]] <- clean_text(
      table_i[[column_i]]
    )
  }

  valid_primary_tax_id <- grepl(
    "^[0-9]+$",
    table_i$tax_id
  )
  valid_primary_gene_id <- grepl(
    "^[0-9]+$",
    table_i$GeneID
  )
  valid_other_tax_id <- grepl(
    "^[0-9]+$",
    table_i$Other_tax_id
  )
  valid_other_gene_id <- grepl(
    "^[0-9]+$",
    table_i$Other_GeneID
  )
  ortholog_relationship <- toupper(
    table_i$relationship
  ) == "ORTHOLOG"

  valid_row <-
    valid_primary_tax_id &
    valid_primary_gene_id &
    valid_other_tax_id &
    valid_other_gene_id &
    ortholog_relationship

  retained <- table_i[
    valid_row,
    ,
    drop = FALSE
  ]

  exact_duplicate_mask <- duplicated(
    retained[
      ,
      required_columns,
      drop = FALSE
    ]
  )
  exact_duplicate_row_number <- sum(
    exact_duplicate_mask
  )

  retained <- retained[
    !exact_duplicate_mask,
    ,
    drop = FALSE
  ]

  rownames(retained) <- NULL

  assert_true(
    nrow(retained) >=
      minimum_retained_rows,
    paste0(
      table_name,
      " retained only ",
      nrow(retained),
      " valid Ortholog rows after sanitization; expected at least ",
      minimum_retained_rows,
      "."
    )
  )

  assert_true(
    all(
      toupper(
        retained$relationship
      ) == "ORTHOLOG"
    ) &&
      all(
        grepl(
          "^[0-9]+$",
          retained$tax_id
        )
      ) &&
      all(
        grepl(
          "^[0-9]+$",
          retained$GeneID
        )
      ) &&
      all(
        grepl(
          "^[0-9]+$",
          retained$Other_tax_id
        )
      ) &&
      all(
        grepl(
          "^[0-9]+$",
          retained$Other_GeneID
        )
      ),
    paste0(
      table_name,
      " failed post-sanitization field checks."
    )
  )

  relationship_values <- sort(
    unique(
      table_i$relationship[
        nzchar(
          table_i$relationship
        )
      ]
    )
  )

  filter_audit <- data.frame(
    source_table = table_name,
    target_tax_id = "ALL_SPECIES",
    raw_row_number = raw_row_number,
    valid_tax_id_row_number = sum(
      valid_primary_tax_id &
        valid_other_tax_id
    ),
    blank_or_malformed_tax_id_row_number = sum(
      !valid_primary_tax_id |
        !valid_other_tax_id
    ),
    target_tax_id_row_number_before_GeneID_filter =
      NA_integer_,
    non_target_tax_id_row_number =
      NA_integer_,
    invalid_GeneID_rows_with_target_tax_id = sum(
      (
        valid_primary_tax_id &
          valid_other_tax_id
      ) &
        (
          !valid_primary_gene_id |
            !valid_other_gene_id
        )
    ),
    exact_duplicate_row_number_removed =
      exact_duplicate_row_number,
    duplicated_GeneID_group_number_resolved =
      NA_integer_,
    retained_unique_target_GeneID_row_number =
      nrow(retained),
    observed_non_target_tax_ids = "",
    malformed_tax_id_values = "",
    observed_relationship_values = if (
      length(
        relationship_values
      ) == 0L
    ) {
      ""
    } else {
      paste(
        relationship_values,
        collapse = ";"
      )
    },
    non_Ortholog_relationship_row_number = sum(
      !ortholog_relationship
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(
    table = retained,
    filter_audit = filter_audit
  )
}

run_internal_boundary_self_tests <- function() {
  test_rows <- list()
  test_index <- 0L

  record_pass <- function(test_name, detail) {
    test_index <<- test_index + 1L
    test_rows[[test_index]] <<- data.frame(
      test_order = test_index,
      test_name = test_name,
      status = "PASS",
      detail = detail,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  empty_direction_source <- data.frame(
    GeneID = character(0),
    Other_GeneID = character(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  empty_direction_result <- make_directional_pair_frame(
    empty_direction_source,
    rat_gene_column = "GeneID",
    human_gene_column = "Other_GeneID",
    orientation_label = "EMPTY_DIRECTION"
  )
  assert_true(
    nrow(empty_direction_result) == 0L &&
      identical(
        colnames(empty_direction_result),
        c(
          "rat_gene_id",
          "human_gene_id",
          "source_orientation"
        )
      ),
    "Internal test failed: zero-row directional pair construction."
  )
  record_pass(
    "ZERO_ROW_DIRECTIONAL_PAIR",
    "A zero-row direction retained the required three-column schema."
  )

  one_direction_source <- data.frame(
    GeneID = "10",
    Other_GeneID = "20",
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  one_direction_result <- make_directional_pair_frame(
    one_direction_source,
    rat_gene_column = "GeneID",
    human_gene_column = "Other_GeneID",
    orientation_label = "ONE_ROW_DIRECTION"
  )
  assert_true(
    nrow(one_direction_result) == 1L &&
      identical(
        one_direction_result$source_orientation,
        "ONE_ROW_DIRECTION"
      ),
    "Internal test failed: one-row directional pair construction."
  )
  record_pass(
    "ONE_ROW_DIRECTIONAL_PAIR",
    "A one-row direction preserved IDs and one orientation label."
  )

  empty_a <- data.frame(
    alpha = character(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  empty_b <- data.frame(
    beta = integer(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  empty_bound <- rbind_fill_base(
    empty_a,
    empty_b
  )
  assert_true(
    nrow(empty_bound) == 0L &&
      all(c("alpha", "beta") %in%
        colnames(empty_bound)),
    "Internal test failed: schema-safe binding of heterogeneous zero-row tables."
  )
  record_pass(
    "ZERO_ROW_SCHEMA_SAFE_BIND",
    "Two heterogeneous zero-row tables were bound without creating rows."
  )

  synthetic_gene_info <- data.frame(
    tax_id = c(
      "9606", "9606", "9606", "9606",
      "10090", "bad", "9606"
    ),
    GeneID = c(
      "1", "1", "2", "2", "3", "4", "bad"
    ),
    Symbol = c(
      "A", "", "B", "B", "C", "D", "E"
    ),
    Synonyms = c(
      "A1", "", "B1", "B1", "C1", "D1", "E1"
    ),
    description = c(
      "gene A", "", "gene B", "gene B",
      "gene C", "gene D", "gene E"
    ),
    type_of_gene = c(
      "protein-coding", "", "protein-coding", "protein-coding",
      "protein-coding", "protein-coding", "protein-coding"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  synthetic_gene_result <- sanitize_gene_info_table(
    synthetic_gene_info,
    target_tax_id = "9606",
    table_name = "SYNTHETIC_HUMAN_GENE_INFO",
    minimum_retained_rows = 2L
  )
  assert_true(
    nrow(synthetic_gene_result$table) == 2L &&
      identical(
        synthetic_gene_result$table$GeneID,
        c("1", "2")
      ) &&
      identical(
        synthetic_gene_result$table$Symbol,
        c("A", "B")
      ) &&
      nrow(
        synthetic_gene_result$duplicate_audit
      ) == 1L,
    "Internal test failed: gene_info filtering or duplicate resolution."
  )
  record_pass(
    "GENE_INFO_SANITIZATION",
    paste0(
      "Non-target/malformed rows were removed; exact duplicates and one ",
      "duplicate GeneID group were resolved deterministically."
    )
  )

  synthetic_ortholog <- data.frame(
    tax_id = c("9606", "9606", "10116", "9606", "bad"),
    GeneID = c("1", "1", "20", "3", "4"),
    relationship = c(
      "Ortholog", "Ortholog", "Ortholog", "Related", "Ortholog"
    ),
    Other_tax_id = c("10116", "10116", "9606", "10116", "10116"),
    Other_GeneID = c("10", "10", "2", "30", "40"),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  synthetic_ortholog_result <- sanitize_ortholog_table(
    synthetic_ortholog,
    table_name = "SYNTHETIC_ORTHOLOG",
    minimum_retained_rows = 2L
  )
  assert_true(
    nrow(synthetic_ortholog_result$table) == 2L &&
      all(
        toupper(
          synthetic_ortholog_result$table$relationship
        ) == "ORTHOLOG"
      ),
    "Internal test failed: ortholog filtering and exact duplicate removal."
  )
  record_pass(
    "ORTHOLOG_SANITIZATION",
    "Non-Ortholog/malformed rows and one exact duplicate were removed."
  )

  result <- do.call(
    rbind,
    test_rows
  )
  rownames(result) <- NULL

  assert_true(
    nrow(result) == 5L &&
      all(result$status == "PASS"),
    "Internal boundary self-test audit is incomplete."
  )

  result
}

internal_self_test_audit <- run_internal_boundary_self_tests()

cat(
  "Internal boundary self-tests passed: ",
  nrow(internal_self_test_audit),
  " / ",
  nrow(internal_self_test_audit),
  "\n",
  sep = ""
)

# ------------------------------
# 2. Verify accepted Script 12C identity
# ------------------------------
assert_true(
  report_contains(
    input_report_file,
    "SCRIPT12C STATUS: COMPLETE"
  ),
  "Script 12C completion marker was not found."
)

assert_true(
  report_contains(
    input_report_file,
    "Script build ID: Script12C_FINAL_20260711"
  ),
  "Script 12C report is not from the accepted FINAL build."
)

expected_bundle_md5 <- manifest_expected_md5(
  input_manifest_file,
  input_bundle_file
)
observed_bundle_md5 <- tolower(
  md5_one(
    input_bundle_file
  )
)
accepted_bundle_md5 <-
  "9fbf19ad50a05ff57529ccc340ca1000"

assert_true(
  identical(
    expected_bundle_md5,
    observed_bundle_md5
  ),
  "Script 12C bundle MD5 differs from its manifest."
)

assert_true(
  identical(
    observed_bundle_md5,
    accepted_bundle_md5
  ),
  paste0(
    "Script 12C bundle differs from the independently accepted bundle.\n",
    "Expected: ",
    accepted_bundle_md5,
    "\nObserved: ",
    observed_bundle_md5
  )
)

expected_matrix_md5 <- manifest_expected_md5(
  input_manifest_file,
  input_matrix_file
)
observed_matrix_md5 <- tolower(
  md5_one(
    input_matrix_file
  )
)
accepted_matrix_md5 <-
  "6fe449a1d9ad640133b31275370e77e3"

assert_true(
  identical(
    expected_matrix_md5,
    observed_matrix_md5
  ),
  "Script 12C standalone matrix MD5 differs from its manifest."
)

assert_true(
  identical(
    observed_matrix_md5,
    accepted_matrix_md5
  ),
  paste0(
    "Script 12C matrix differs from the independently accepted matrix.\n",
    "Expected: ",
    accepted_matrix_md5,
    "\nObserved: ",
    observed_matrix_md5
  )
)

input_integrity <- read.csv(
  input_integrity_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(c(
    "item",
    "value"
  ) %in% colnames(input_integrity)),
  "Script 12C integrity summary is malformed."
)

assert_true(
  anyDuplicated(
    input_integrity$item
  ) == 0L,
  "Script 12C integrity summary contains duplicated items."
)

integrity_lookup <- setNames(
  as.character(
    input_integrity$value
  ),
  input_integrity$item
)

required_integrity_items <- c(
  "Gene_level_expression_dimensions",
  "All_gene_level_values_finite",
  "Sample_order_preserved",
  "Ortholog_mapping_performed",
  "ABCB1_paralog_substitution_performed",
  "Completion_status"
)

assert_true(
  all(
    required_integrity_items %in%
      names(integrity_lookup)
  ),
  "Script 12C integrity summary is missing required items."
)

assert_true(
  identical(
    integrity_lookup[["Completion_status"]],
    "COMPLETE"
  ) &&
    identical(
      integrity_lookup[["Ortholog_mapping_performed"]],
      "FALSE"
    ) &&
    identical(
      integrity_lookup[[
        "ABCB1_paralog_substitution_performed"
      ]],
      "FALSE"
    ),
  "Script 12C integrity policy is inconsistent with the accepted workflow."
)

# ------------------------------
# 3. Read and validate accepted Script 12C objects
# ------------------------------
source_bundle <- readRDS(
  input_bundle_file
)
standalone_matrix <- readRDS(
  input_matrix_file
)
gene_audit_csv <- read.csv(
  input_gene_audit_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

required_bundle_fields <- c(
  "script",
  "script_build_id",
  "source_accession",
  "gene_level_expression",
  "gene_aggregation_audit",
  "signature_gene_coverage",
  "integrity_summary",
  "policy"
)

assert_true(
  is.list(source_bundle) &&
    all(
      required_bundle_fields %in%
        names(source_bundle)
    ),
  "Script 12C bundle is missing required fields."
)

assert_true(
  identical(
    as.character(
      source_bundle$script
    ),
    "Script12C"
  ) &&
    identical(
      as.character(
        source_bundle$script_build_id
      ),
      "Script12C_FINAL_20260711"
    ),
  "Script 12C bundle identity is invalid."
)

gene_expression <- source_bundle$
  gene_level_expression
gene_audit <- source_bundle$
  gene_aggregation_audit

assert_true(
  is.matrix(gene_expression) &&
    is.numeric(gene_expression) &&
    identical(
      dim(gene_expression),
      c(19098L, 50L)
    ),
  "Bundle gene-level expression matrix is not 19,098 x 50."
)

assert_true(
  is.matrix(standalone_matrix) &&
    is.numeric(standalone_matrix) &&
    identical(
      dim(standalone_matrix),
      c(19098L, 50L)
    ),
  "Standalone gene-level expression matrix is not 19,098 x 50."
)

assert_true(
  identical(
    rownames(gene_expression),
    rownames(standalone_matrix)
  ) &&
    identical(
      colnames(gene_expression),
      colnames(standalone_matrix)
    ),
  "Bundle and standalone matrix identifiers differ."
)

assert_true(
  isTRUE(
    all.equal(
      unname(gene_expression),
      unname(standalone_matrix),
      tolerance = 0,
      check.attributes = FALSE
    )
  ),
  "Bundle and standalone gene matrices differ in value."
)

assert_true(
  all(
    is.finite(
      gene_expression
    )
  ),
  "Accepted gene-level expression matrix contains non-finite values."
)

assert_true(
  is.data.frame(gene_audit) &&
    nrow(gene_audit) == 19098L,
  "Bundle gene aggregation audit does not contain 19,098 rows."
)

required_gene_audit_columns <- c(
  "gene_order",
  "rat_gene_symbol",
  "source_entrez_id_number",
  "source_entrez_ids",
  "source_transcript_cluster_number",
  "source_transcript_cluster_ids"
)

assert_true(
  all(
    required_gene_audit_columns %in%
      colnames(gene_audit)
  ),
  paste0(
    "Gene aggregation audit is missing required columns: ",
    paste(
      setdiff(
        required_gene_audit_columns,
        colnames(gene_audit)
      ),
      collapse = ", "
    )
  )
)

gene_audit$rat_gene_symbol <- clean_text(
  gene_audit$rat_gene_symbol
)
gene_audit$source_entrez_ids <- clean_text(
  gene_audit$source_entrez_ids
)

assert_true(
  identical(
    gene_audit$rat_gene_symbol,
    rownames(gene_expression)
  ),
  "Gene aggregation audit is not aligned to expression rows."
)

source_entrez_number <- suppressWarnings(
  as.integer(
    as.character(
      gene_audit$source_entrez_id_number
    )
  )
)

assert_true(
  length(source_entrez_number) == 19098L &&
    !any(is.na(source_entrez_number)) &&
    all(source_entrez_number == 1L),
  "Every Script 12C gene must have exactly one rat Entrez GeneID."
)

rat_gene_ids <- safe_integer_character(
  gene_audit$source_entrez_ids,
  "source_entrez_ids"
)

assert_true(
  length(rat_gene_ids) == 19098L &&
    anyDuplicated(rat_gene_ids) == 0L,
  "Rat GeneIDs are missing or duplicated across the 19,098 gene rows."
)

assert_true(
  is.data.frame(gene_audit_csv) &&
    nrow(gene_audit_csv) == 19098L &&
    identical(
      clean_text(
        gene_audit_csv$rat_gene_symbol
      ),
      gene_audit$rat_gene_symbol
    ),
  "CSV and RDS gene aggregation audits differ in row count or order."
)

assert_true(
  isFALSE(
    source_bundle$policy$
      ortholog_mapping_performed
  ) &&
    isFALSE(
      source_bundle$policy$
        ABCB1_paralog_substitution_performed
    ),
  "Script 12C bundle incorrectly indicates prior ortholog processing."
)

# ------------------------------
# 4. Download current NCBI sources
# ------------------------------
ortholog_url <-
  "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene_orthologs.gz"
human_info_url <- paste0(
  "https://ftp.ncbi.nlm.nih.gov/gene/DATA/GENE_INFO/",
  "Mammalia/Homo_sapiens.gene_info.gz"
)
rat_info_url <- paste0(
  "https://ftp.ncbi.nlm.nih.gov/gene/DATA/GENE_INFO/",
  "Mammalia/Rattus_norvegicus.gene_info.gz"
)

ortholog_file <- file.path(
  stage_download_dir,
  "gene_orthologs.gz"
)
human_info_file <- file.path(
  stage_download_dir,
  "Homo_sapiens.gene_info.gz"
)
rat_info_file <- file.path(
  stage_download_dir,
  "Rattus_norvegicus.gene_info.gz"
)

ortholog_download <- download_with_retries(
  url = ortholog_url,
  destination = ortholog_file,
  minimum_size_bytes = 50 * 1024^2,
  maximum_attempts = 3L
)
human_download <- download_with_retries(
  url = human_info_url,
  destination = human_info_file,
  minimum_size_bytes = 500 * 1024,
  maximum_attempts = 3L
)
rat_download <- download_with_retries(
  url = rat_info_url,
  destination = rat_info_file,
  minimum_size_bytes = 100 * 1024,
  maximum_attempts = 3L
)

download_attempt_audit <- rbind(
  ortholog_download$audit,
  human_download$audit,
  rat_download$audit
)
rownames(download_attempt_audit) <- NULL

downloaded_files <- c(
  ortholog_file,
  human_info_file,
  rat_info_file
)

assert_true(
  all(file.exists(downloaded_files)) &&
    all(
      file.info(downloaded_files)$size > 0
    ),
  "At least one required NCBI source file is absent or empty."
)

download_manifest <- make_manifest(
  downloaded_files
)

# ------------------------------
# 5. Read and validate NCBI source tables
# ------------------------------
ortholog_read <- read_ncbi_gzip_table(
  ortholog_file,
  expected_columns = c(
    "tax_id",
    "GeneID",
    "relationship",
    "Other_tax_id",
    "Other_GeneID"
  ),
  table_name = "NCBI gene_orthologs"
)
ortholog_all_raw <- ortholog_read$table

human_info_read <- read_ncbi_gzip_table(
  human_info_file,
  expected_columns = c(
    "tax_id",
    "GeneID",
    "Symbol",
    "Synonyms",
    "description",
    "type_of_gene"
  ),
  table_name = "NCBI Homo sapiens gene_info"
)
human_info_raw <- human_info_read$table

rat_info_read <- read_ncbi_gzip_table(
  rat_info_file,
  expected_columns = c(
    "tax_id",
    "GeneID",
    "Symbol",
    "Synonyms",
    "description",
    "type_of_gene"
  ),
  table_name = "NCBI Rattus norvegicus gene_info"
)
rat_info_raw <- rat_info_read$table

ortholog_sanitized <- sanitize_ortholog_table(
  ortholog_all_raw,
  table_name = "NCBI_gene_orthologs",
  minimum_retained_rows = 10000L
)
ortholog_all <- ortholog_sanitized$table

human_info_sanitized <- sanitize_gene_info_table(
  human_info_raw,
  target_tax_id = "9606",
  table_name = "NCBI_Homo_sapiens_gene_info",
  minimum_retained_rows = 10000L
)
human_info <- human_info_sanitized$table

rat_info_sanitized <- sanitize_gene_info_table(
  rat_info_raw,
  target_tax_id = "10116",
  table_name = "NCBI_Rattus_norvegicus_gene_info",
  minimum_retained_rows = 10000L
)
rat_info <- rat_info_sanitized$table

source_row_filter_audit <- rbind_fill_base(
  ortholog_sanitized$filter_audit,
  human_info_sanitized$filter_audit,
  rat_info_sanitized$filter_audit
)

gene_info_duplicate_resolution_audit <- rbind_fill_base(
  human_info_sanitized$duplicate_audit,
  rat_info_sanitized$duplicate_audit
)

assert_true(
  is.data.frame(
    source_row_filter_audit
  ) &&
    nrow(
      source_row_filter_audit
    ) == 3L,
  "NCBI source-row filter audit does not contain exactly three source tables."
)

assert_true(
  is.data.frame(
    gene_info_duplicate_resolution_audit
  ) &&
    all(c(
      "source_table",
      "GeneID",
      "candidate_row_number",
      "selected_source_row",
      "resolution_rule"
    ) %in%
      colnames(
        gene_info_duplicate_resolution_audit
      )),
  "gene_info duplicate-resolution audit has an invalid schema."
)

assert_true(
  all(
    human_info$tax_id ==
      "9606"
  ) &&
    all(
      rat_info$tax_id ==
        "10116"
    ),
  paste0(
    "Target-species tax_id filtering did not produce pure human and rat ",
    "gene_info tables."
  )
)

assert_true(
  anyDuplicated(
    human_info$GeneID
  ) == 0L &&
    anyDuplicated(
      rat_info$GeneID
    ) == 0L,
  "Target-species gene_info tables still contain duplicated GeneIDs."
)

assert_true(
  any(
    ortholog_all$tax_id == "9606" &
      ortholog_all$Other_tax_id == "10116"
  ) ||
    any(
      ortholog_all$tax_id == "10116" &
        ortholog_all$Other_tax_id == "9606"
    ),
  "No valid human-rat Ortholog rows remained after source sanitization."
)

# ------------------------------
# 6. Extract rat-human ortholog pairs in either orientation
# ------------------------------
human_to_rat <- ortholog_all[
  ortholog_all$tax_id == "9606" &
    ortholog_all$Other_tax_id == "10116",
  c(
    "GeneID",
    "Other_GeneID"
  ),
  drop = FALSE
]

rat_to_human <- ortholog_all[
  ortholog_all$tax_id == "10116" &
    ortholog_all$Other_tax_id == "9606",
  c(
    "GeneID",
    "Other_GeneID"
  ),
  drop = FALSE
]

pair_from_human <- make_directional_pair_frame(
  source_table = human_to_rat,
  rat_gene_column = "Other_GeneID",
  human_gene_column = "GeneID",
  orientation_label =
    "HUMAN_PRIMARY_TO_RAT_OTHER"
)

pair_from_rat <- make_directional_pair_frame(
  source_table = rat_to_human,
  rat_gene_column = "GeneID",
  human_gene_column = "Other_GeneID",
  orientation_label =
    "RAT_PRIMARY_TO_HUMAN_OTHER"
)

ortholog_direction_audit <- data.frame(
  source_orientation = c(
    "HUMAN_PRIMARY_TO_RAT_OTHER",
    "RAT_PRIMARY_TO_HUMAN_OTHER"
  ),
  source_row_number = c(
    nrow(human_to_rat),
    nrow(rat_to_human)
  ),
  pair_frame_row_number = c(
    nrow(pair_from_human),
    nrow(pair_from_rat)
  ),
  orientation_absent = c(
    nrow(human_to_rat) == 0L,
    nrow(rat_to_human) == 0L
  ),
  zero_row_handled_safely = TRUE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(
    ortholog_direction_audit$
      source_row_number ==
      ortholog_direction_audit$
        pair_frame_row_number
  ),
  "Directional ortholog row counts changed during pair-frame construction."
)

assert_true(
  sum(
    ortholog_direction_audit$
      source_row_number
  ) > 0L,
  "Neither human-primary nor rat-primary human-rat ortholog rows were found."
)

rat_human_pairs_raw <- rbind(
  pair_from_human,
  pair_from_rat
)

rownames(rat_human_pairs_raw) <- NULL

assert_true(
  nrow(rat_human_pairs_raw) ==
    sum(
      ortholog_direction_audit$
        source_row_number
    ),
  "Combined directional ortholog-pair row count is inconsistent."
)

rat_human_pairs_raw$rat_gene_id <-
  safe_integer_character(
    rat_human_pairs_raw$rat_gene_id,
    "rat_human_pairs_raw$rat_gene_id"
  )
rat_human_pairs_raw$human_gene_id <-
  safe_integer_character(
    rat_human_pairs_raw$human_gene_id,
    "rat_human_pairs_raw$human_gene_id"
  )

assert_true(
  nrow(rat_human_pairs_raw) > 5000L,
  paste0(
    "Unexpectedly few rat-human ortholog pair records were found: ",
    nrow(rat_human_pairs_raw),
    "."
  )
)

pair_key <- paste(
  rat_human_pairs_raw$rat_gene_id,
  rat_human_pairs_raw$human_gene_id,
  sep = "::"
)

unique_pair_keys <- unique(
  pair_key
)

rat_human_pairs <- do.call(
  rbind,
  lapply(
    unique_pair_keys,
    function(key_i) {
      row_indices <- which(
        pair_key == key_i
      )

      data.frame(
        rat_gene_id =
          rat_human_pairs_raw$rat_gene_id[
            row_indices[1]
          ],
        human_gene_id =
          rat_human_pairs_raw$human_gene_id[
            row_indices[1]
          ],
        source_orientation = collapse_unique(
          rat_human_pairs_raw$
            source_orientation[
              row_indices
            ]
        ),
        duplicate_source_record_number =
          length(row_indices),
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
  )
)
rownames(rat_human_pairs) <- NULL

assert_true(
  anyDuplicated(
    paste(
      rat_human_pairs$rat_gene_id,
      rat_human_pairs$human_gene_id,
      sep = "::"
    )
  ) == 0L,
  "Deduplicated rat-human pair table still contains duplicated pairs."
)

human_info_index <- match(
  rat_human_pairs$human_gene_id,
  human_info$GeneID
)
rat_info_index <- match(
  rat_human_pairs$rat_gene_id,
  rat_info$GeneID
)

rat_human_pairs$rat_current_symbol <-
  ifelse(
    is.na(rat_info_index),
    "",
    rat_info$Symbol[
      rat_info_index
    ]
  )
rat_human_pairs$rat_current_description <-
  ifelse(
    is.na(rat_info_index),
    "",
    rat_info$description[
      rat_info_index
    ]
  )
rat_human_pairs$human_current_symbol <-
  ifelse(
    is.na(human_info_index),
    "",
    human_info$Symbol[
      human_info_index
    ]
  )
rat_human_pairs$human_current_description <-
  ifelse(
    is.na(human_info_index),
    "",
    human_info$description[
      human_info_index
    ]
  )
rat_human_pairs$rat_gene_record_current <-
  !is.na(rat_info_index)
rat_human_pairs$human_gene_record_current <-
  !is.na(human_info_index)

# ------------------------------
# 7. Build a complete audit for all 19,098 assayed rat genes
# ------------------------------
rat_current_index <- match(
  rat_gene_ids,
  rat_info$GeneID
)

assayed_rat_rows <- vector(
  "list",
  length(rat_gene_ids)
)

pair_row_indices_by_rat_gene_id <- split(
  seq_len(
    nrow(rat_human_pairs)
  ),
  rat_human_pairs$rat_gene_id,
  drop = TRUE
)

for (i in seq_along(rat_gene_ids)) {
  rat_id_i <- rat_gene_ids[i]
  symbol_i <- gene_audit$rat_gene_symbol[i]

  pair_indices_i <- pair_row_indices_by_rat_gene_id[[
    rat_id_i
  ]]

  if (is.null(pair_indices_i)) {
    pair_rows <- rat_human_pairs[
      0L,
      ,
      drop = FALSE
    ]
  } else {
    pair_rows <- rat_human_pairs[
      pair_indices_i,
      ,
      drop = FALSE
    ]
  }

  human_ids_i <- sort(
    unique(
      pair_rows$human_gene_id
    )
  )
  human_ids_i <- human_ids_i[
    nzchar(human_ids_i)
  ]

  human_symbols_i <- sort(
    unique(
      pair_rows$human_current_symbol
    )
  )
  human_symbols_i <- human_symbols_i[
    nzchar(human_symbols_i)
  ]

  current_rat_symbol_i <- if (
    is.na(
      rat_current_index[i]
    )
  ) {
    ""
  } else {
    rat_info$Symbol[
      rat_current_index[i]
    ]
  }

  current_rat_description_i <- if (
    is.na(
      rat_current_index[i]
    )
  ) {
    ""
  } else {
    rat_info$description[
      rat_current_index[i]
    ]
  }

  mapping_class_i <- if (
    is.na(
      rat_current_index[i]
    )
  ) {
    "NO_CURRENT_NCBI_RAT_RECORD"
  } else if (
    length(human_ids_i) == 0L
  ) {
    "NO_HUMAN_ORTHOLOG"
  } else if (
    length(human_ids_i) == 1L
  ) {
    "ONE_HUMAN_ORTHOLOG"
  } else {
    "MULTIPLE_HUMAN_ORTHOLOGS"
  }

  assayed_rat_rows[[i]] <- data.frame(
    gene_order =
      gene_audit$gene_order[i],
    rat_expression_symbol = symbol_i,
    rat_gene_id = rat_id_i,
    current_NCBI_rat_record_available =
      !is.na(
        rat_current_index[i]
      ),
    current_NCBI_rat_symbol =
      current_rat_symbol_i,
    rat_symbol_matches_current_NCBI =
      nzchar(
        current_rat_symbol_i
      ) &&
      identical(
        symbol_i,
        current_rat_symbol_i
      ),
    current_NCBI_rat_description =
      current_rat_description_i,
    human_ortholog_number =
      length(human_ids_i),
    human_gene_ids = if (
      length(human_ids_i) == 0L
    ) {
      ""
    } else {
      paste(
        human_ids_i,
        collapse = ";"
      )
    },
    human_symbols = if (
      length(human_symbols_i) == 0L
    ) {
      ""
    } else {
      paste(
        human_symbols_i,
        collapse = ";"
      )
    },
    rat_to_human_mapping_class =
      mapping_class_i,
    human_expression_row_created = FALSE,
    expression_values_aggregated = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

assayed_rat_gene_audit <- do.call(
  rbind,
  assayed_rat_rows
)
rownames(assayed_rat_gene_audit) <- NULL

assert_true(
  nrow(assayed_rat_gene_audit) == 19098L &&
    identical(
      assayed_rat_gene_audit$
        rat_expression_symbol,
      rownames(gene_expression)
    ) &&
    identical(
      assayed_rat_gene_audit$
        rat_gene_id,
      rat_gene_ids
    ),
  "Assayed rat-gene ortholog audit changed row count or expression order."
)

assert_true(
  sum(
    assayed_rat_gene_audit$
      human_ortholog_number > 0L
  ) > 5000L,
  paste0(
    "Unexpectedly few assayed rat genes had a human ortholog: ",
    sum(
      assayed_rat_gene_audit$
        human_ortholog_number > 0L
    ),
    "."
  )
)

# ------------------------------
# 8. Classify human genes by the number of assayed rat orthologs
# ------------------------------
mapped_rat_rows <- assayed_rat_gene_audit[
  assayed_rat_gene_audit$
    human_ortholog_number > 0L,
  ,
  drop = FALSE
]

assayed_pair_match_index <- match(
  rat_human_pairs$rat_gene_id,
  rat_gene_ids
)
assayed_pair_keep <- !is.na(
  assayed_pair_match_index
)

assert_true(
  any(assayed_pair_keep),
  "No rat-human ortholog pair matched the 19,098 assayed rat GeneIDs."
)

matched_assayed_indices <- assayed_pair_match_index[
  assayed_pair_keep
]
matched_pair_rows <- rat_human_pairs[
  assayed_pair_keep,
  ,
  drop = FALSE
]

expanded_assayed_pairs <- data.frame(
  rat_gene_order = gene_audit$gene_order[
    matched_assayed_indices
  ],
  rat_expression_symbol = gene_audit$rat_gene_symbol[
    matched_assayed_indices
  ],
  rat_gene_id = rat_gene_ids[
    matched_assayed_indices
  ],
  human_gene_id = matched_pair_rows$human_gene_id,
  source_orientation = matched_pair_rows$source_orientation,
  duplicate_source_record_number =
    matched_pair_rows$duplicate_source_record_number,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

expanded_assayed_pairs <- expanded_assayed_pairs[
  order(
    expanded_assayed_pairs$rat_gene_order,
    suppressWarnings(
      as.numeric(
        expanded_assayed_pairs$human_gene_id
      )
    ),
    expanded_assayed_pairs$human_gene_id
  ),
  ,
  drop = FALSE
]
rownames(expanded_assayed_pairs) <- NULL

assert_true(
  nrow(expanded_assayed_pairs) >=
    nrow(mapped_rat_rows) &&
    length(
      unique(
        expanded_assayed_pairs$rat_gene_id
      )
    ) == nrow(mapped_rat_rows) &&
    anyDuplicated(
      paste(
        expanded_assayed_pairs$rat_gene_id,
        expanded_assayed_pairs$human_gene_id,
        sep = "::"
      )
    ) == 0L,
  paste0(
    "Direct assayed-pair construction failed row coverage or uniqueness checks."
  )
)

expanded_human_index <- match(
  expanded_assayed_pairs$human_gene_id,
  human_info$GeneID
)

expanded_assayed_pairs$human_symbol <-
  ifelse(
    is.na(
      expanded_human_index
    ),
    "",
    human_info$Symbol[
      expanded_human_index
    ]
  )
expanded_assayed_pairs$human_description <-
  ifelse(
    is.na(
      expanded_human_index
    ),
    "",
    human_info$description[
      expanded_human_index
    ]
  )
expanded_assayed_pairs$human_gene_record_current <-
  !is.na(
    expanded_human_index
  )

human_ids_assayed <- sort(
  unique(
    expanded_assayed_pairs$
      human_gene_id
  )
)

human_rows <- vector(
  "list",
  length(human_ids_assayed)
)

expanded_row_indices_by_human_gene_id <- split(
  seq_len(
    nrow(expanded_assayed_pairs)
  ),
  expanded_assayed_pairs$human_gene_id,
  drop = TRUE
)

for (i in seq_along(
  human_ids_assayed
)) {
  human_id_i <- human_ids_assayed[i]

  human_pair_indices_i <- expanded_row_indices_by_human_gene_id[[
    human_id_i
  ]]

  assert_true(
    !is.null(human_pair_indices_i) &&
      length(human_pair_indices_i) >= 1L,
    paste0(
      "No expanded assayed pair rows were found for human GeneID ",
      human_id_i,
      "."
    )
  )

  rows_i <- expanded_assayed_pairs[
    human_pair_indices_i,
    ,
    drop = FALSE
  ]

  rat_ids_i <- sort(
    unique(
      rows_i$rat_gene_id
    )
  )
  rat_symbols_i <- sort(
    unique(
      rows_i$rat_expression_symbol
    )
  )

  human_index_i <- match(
    human_id_i,
    human_info$GeneID
  )

  human_rows[[i]] <- data.frame(
    human_gene_id = human_id_i,
    human_symbol = if (
      is.na(human_index_i)
    ) {
      ""
    } else {
      human_info$Symbol[
        human_index_i
      ]
    },
    human_description = if (
      is.na(human_index_i)
    ) {
      ""
    } else {
      human_info$description[
        human_index_i
      ]
    },
    assayed_rat_ortholog_number =
      length(rat_ids_i),
    assayed_rat_gene_ids =
      paste(
        rat_ids_i,
        collapse = ";"
      ),
    assayed_rat_symbols =
      paste(
        rat_symbols_i,
        collapse = ";"
      ),
    rat_to_human_relationship_class = if (
      length(rat_ids_i) == 1L
    ) {
      "ONE_ASSAYED_RAT_GENE"
    } else {
      "MULTIPLE_ASSAYED_RAT_GENES"
    },
    human_expression_row_created = FALSE,
    expression_values_aggregated = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

human_ortholog_target_audit <- do.call(
  rbind,
  human_rows
)
rownames(human_ortholog_target_audit) <- NULL

assert_true(
  anyDuplicated(
    human_ortholog_target_audit$
      human_gene_id
  ) == 0L,
  "Human ortholog target audit contains duplicated human GeneIDs."
)

# ------------------------------
# 9. Audit the locked 24-human-gene signature
# ------------------------------
locked_human_signature <- c(
  "ESR1",
  "AR",
  "PGR",
  "THRA",
  "THRB",
  "CAT",
  "BCL2",
  "BAX",
  "PARP1",
  "IL6",
  "ABCB1",
  "ABCG2",
  "FASN",
  "SCD",
  "TWIST1",
  "PPARG",
  "EGFR",
  "MMP9",
  "JUN",
  "FOS",
  "ADRB2",
  "ERG",
  "H2AX",
  "MITF"
)

assert_true(
  length(locked_human_signature) == 24L &&
    anyDuplicated(
      locked_human_signature
    ) == 0L,
  "Locked human signature is not 24 unique symbols."
)

signature_rows <- vector(
  "list",
  length(locked_human_signature)
)

for (i in seq_along(
  locked_human_signature
)) {
  symbol_i <- locked_human_signature[i]

  human_info_rows <- human_info[
    toupper(
      human_info$Symbol
    ) == toupper(symbol_i),
    ,
    drop = FALSE
  ]

  human_gene_ids_i <- sort(
    unique(
      human_info_rows$GeneID
    )
  )
  human_gene_ids_i <- human_gene_ids_i[
    nzchar(human_gene_ids_i)
  ]

  assayed_pair_rows <- expanded_assayed_pairs[
    expanded_assayed_pairs$
      human_gene_id %in%
      human_gene_ids_i,
    ,
    drop = FALSE
  ]

  rat_ids_i <- sort(
    unique(
      assayed_pair_rows$rat_gene_id
    )
  )
  rat_symbols_i <- sort(
    unique(
      assayed_pair_rows$
        rat_expression_symbol
    )
  )

  signature_rows[[i]] <- data.frame(
    signature_order = i,
    locked_human_symbol = symbol_i,
    current_NCBI_human_gene_record_number =
      length(human_gene_ids_i),
    current_NCBI_human_gene_ids = if (
      length(human_gene_ids_i) == 0L
    ) {
      ""
    } else {
      paste(
        human_gene_ids_i,
        collapse = ";"
      )
    },
    assayed_rat_ortholog_number =
      length(rat_ids_i),
    assayed_rat_gene_ids = if (
      length(rat_ids_i) == 0L
    ) {
      ""
    } else {
      paste(
        rat_ids_i,
        collapse = ";"
      )
    },
    assayed_rat_symbols = if (
      length(rat_symbols_i) == 0L
    ) {
      ""
    } else {
      paste(
        rat_symbols_i,
        collapse = ";"
      )
    },
    signature_mapping_class = if (
      length(rat_ids_i) == 0L
    ) {
      "NO_ASSAYED_RAT_ORTHOLOG"
    } else if (
      length(rat_ids_i) == 1L
    ) {
      "ONE_ASSAYED_RAT_ORTHOLOG"
    } else {
      "MULTIPLE_ASSAYED_RAT_ORTHOLOGS"
    },
    human_expression_row_created = FALSE,
    paralog_expression_combined = FALSE,
    included_in_Triclosan_score = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

signature_ortholog_audit <- do.call(
  rbind,
  signature_rows
)
rownames(signature_ortholog_audit) <- NULL

assert_true(
  nrow(signature_ortholog_audit) == 24L,
  "Signature ortholog audit does not contain 24 rows."
)

# Do not hard-stop on biological mapping coverage, but explicitly identify ABCB1.
abcb1_row <- signature_ortholog_audit[
  signature_ortholog_audit$
    locked_human_symbol == "ABCB1",
  ,
  drop = FALSE
]

assert_true(
  nrow(abcb1_row) == 1L,
  "ABCB1 is missing or duplicated in the signature audit."
)

# ------------------------------
# 10. Build summary tables
# ------------------------------
mapping_class_order <- c(
  "NO_CURRENT_NCBI_RAT_RECORD",
  "NO_HUMAN_ORTHOLOG",
  "ONE_HUMAN_ORTHOLOG",
  "MULTIPLE_HUMAN_ORTHOLOGS"
)

mapping_class_counts <- table(
  factor(
    assayed_rat_gene_audit$
      rat_to_human_mapping_class,
    levels = mapping_class_order
  )
)

human_relationship_counts <- table(
  factor(
    human_ortholog_target_audit$
      rat_to_human_relationship_class,
    levels = c(
      "ONE_ASSAYED_RAT_GENE",
      "MULTIPLE_ASSAYED_RAT_GENES"
    )
  )
)

source_table_summary <- data.frame(
  source_table = c(
    "NCBI_gene_orthologs",
    "NCBI_Homo_sapiens_gene_info",
    "NCBI_Rattus_norvegicus_gene_info"
  ),
  source_file = basename(
    downloaded_files
  ),
  raw_row_number = c(
    nrow(ortholog_all_raw),
    nrow(human_info_raw),
    nrow(rat_info_raw)
  ),
  retained_row_number = c(
    nrow(ortholog_all),
    nrow(human_info),
    nrow(rat_info)
  ),
  removed_row_number = c(
    nrow(ortholog_all_raw) -
      nrow(ortholog_all),
    nrow(human_info_raw) -
      nrow(human_info),
    nrow(rat_info_raw) -
      nrow(rat_info)
  ),
  retained_column_number = c(
    ncol(ortholog_all),
    ncol(human_info),
    ncol(rat_info)
  ),
  read_warning_number = c(
    length(
      ortholog_read$warnings
    ),
    length(
      human_info_read$warnings
    ),
    length(
      rat_info_read$warnings
    )
  ),
  read_warning_messages = c(
    collapse_messages(
      ortholog_read$warnings
    ),
    collapse_messages(
      human_info_read$warnings
    ),
    collapse_messages(
      rat_info_read$warnings
    )
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

integrity_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Script_build_ID",
    "Source_Script12C_bundle_MD5",
    "Source_Script12C_matrix_MD5",
    "Rat_gene_level_expression_dimensions",
    "NCBI_ortholog_source",
    "NCBI_rat_tax_id",
    "NCBI_human_tax_id",
    "Human_primary_to_rat_other_pair_records",
    "Rat_primary_to_human_other_pair_records",
    "Absent_pair_orientation_number",
    "Raw_rat_human_pair_records",
    "Unique_rat_human_pairs",
    "Assayed_rat_gene_number",
    "Assayed_rat_genes_with_current_NCBI_record",
    "Assayed_rat_genes_without_current_NCBI_record",
    "Assayed_rat_genes_without_human_ortholog",
    "Assayed_rat_genes_with_one_human_ortholog",
    "Assayed_rat_genes_with_multiple_human_orthologs",
    "Unique_human_ortholog_target_number",
    "Human_targets_with_one_assayed_rat_gene",
    "Human_targets_with_multiple_assayed_rat_genes",
    "Locked_signature_genes_with_any_assayed_rat_ortholog",
    "Locked_signature_genes_with_one_assayed_rat_ortholog",
    "Locked_signature_genes_with_multiple_assayed_rat_orthologs",
    "Locked_signature_genes_without_assayed_rat_ortholog",
    "ABCB1_assayed_rat_ortholog_number",
    "ABCB1_assayed_rat_symbols",
    "Human_ortholog_expression_matrix_created",
    "Expression_values_aggregated",
    "ABCB1_paralog_expression_combined",
    "Differential_expression_performed",
    "PCA_performed",
    "GSVA_or_GSEA_performed",
    "Completion_status"
  ),
  value = c(
    "GSE95554",
    "12D",
    SCRIPT_BUILD_ID,
    observed_bundle_md5,
    observed_matrix_md5,
    paste(
      dim(gene_expression),
      collapse = " x "
    ),
    "NCBI_GENE_FTP_gene_orthologs",
    "10116",
    "9606",
    nrow(human_to_rat),
    nrow(rat_to_human),
    sum(
      ortholog_direction_audit$
        orientation_absent
    ),
    nrow(rat_human_pairs_raw),
    nrow(rat_human_pairs),
    nrow(assayed_rat_gene_audit),
    sum(
      assayed_rat_gene_audit$
        current_NCBI_rat_record_available
    ),
    unname(
      mapping_class_counts[
        "NO_CURRENT_NCBI_RAT_RECORD"
      ]
    ),
    unname(
      mapping_class_counts[
        "NO_HUMAN_ORTHOLOG"
      ]
    ),
    unname(
      mapping_class_counts[
        "ONE_HUMAN_ORTHOLOG"
      ]
    ),
    unname(
      mapping_class_counts[
        "MULTIPLE_HUMAN_ORTHOLOGS"
      ]
    ),
    nrow(human_ortholog_target_audit),
    unname(
      human_relationship_counts[
        "ONE_ASSAYED_RAT_GENE"
      ]
    ),
    unname(
      human_relationship_counts[
        "MULTIPLE_ASSAYED_RAT_GENES"
      ]
    ),
    sum(
      signature_ortholog_audit$
        assayed_rat_ortholog_number > 0L
    ),
    sum(
      signature_ortholog_audit$
        assayed_rat_ortholog_number == 1L
    ),
    sum(
      signature_ortholog_audit$
        assayed_rat_ortholog_number > 1L
    ),
    sum(
      signature_ortholog_audit$
        assayed_rat_ortholog_number == 0L
    ),
    abcb1_row$
      assayed_rat_ortholog_number,
    abcb1_row$
      assayed_rat_symbols,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 11. Save staging outputs
# ------------------------------
input_manifest <- make_manifest(
  required_inputs
)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step3_GSE95554_real_exposure_validation",
  script = "Script12D",
  script_build_id = SCRIPT_BUILD_ID,
  created_at = format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  ),
  source_accession = "GSE95554",
  source_script12c_bundle_file =
    normalizePath(
      input_bundle_file,
      winslash = "/",
      mustWork = TRUE
    ),
  source_script12c_bundle_md5 =
    observed_bundle_md5,
  source_script12c_matrix_file =
    normalizePath(
      input_matrix_file,
      winslash = "/",
      mustWork = TRUE
    ),
  source_script12c_matrix_md5 =
    observed_matrix_md5,
  source_rat_gene_symbols =
    rownames(gene_expression),
  source_rat_gene_ids =
    rat_gene_ids,
  NCBI_source_urls = list(
    gene_orthologs = ortholog_url,
    human_gene_info = human_info_url,
    rat_gene_info = rat_info_url
  ),
  download_attempt_audit =
    download_attempt_audit,
  download_manifest =
    download_manifest,
  source_table_summary =
    source_table_summary,
  internal_self_test_audit =
    internal_self_test_audit,
  source_row_filter_audit =
    source_row_filter_audit,
  gene_info_duplicate_resolution_audit =
    gene_info_duplicate_resolution_audit,
  ortholog_direction_audit =
    ortholog_direction_audit,
  rat_human_pairs =
    rat_human_pairs,
  assayed_rat_gene_audit =
    assayed_rat_gene_audit,
  expanded_assayed_pairs =
    expanded_assayed_pairs,
  human_ortholog_target_audit =
    human_ortholog_target_audit,
  signature_ortholog_audit =
    signature_ortholog_audit,
  integrity_summary =
    integrity_summary,
  policy = list(
    primary_ortholog_source =
      "NCBI Gene FTP gene_orthologs",
    rat_tax_id = "10116",
    human_tax_id = "9606",
    accept_both_pair_orientations = TRUE,
    allow_either_orientation_to_be_absent = TRUE,
    zero_row_safe_directional_pair_construction = TRUE,
    deduplicate_exact_rat_human_pairs = TRUE,
    single_row_safe_gene_info_resolution = TRUE,
    schema_safe_audit_table_binding = TRUE,
    internal_boundary_self_tests_passed = TRUE,
    direct_expanded_pair_construction = TRUE,
    choose_one_from_multiple_human_orthologs = FALSE,
    human_ortholog_expression_matrix_created = FALSE,
    expression_values_aggregated = FALSE,
    ABCB1_paralog_expression_combined = FALSE,
    differential_expression_performed = FALSE,
    PCA_performed = FALSE,
    GSVA_or_GSEA_performed = FALSE
  ),
  provenance = list(
    accepted_script12c_bundle_md5 =
      accepted_bundle_md5,
    accepted_script12c_matrix_md5 =
      accepted_matrix_md5,
    mapping_date = format(
      Sys.Date(),
      "%Y-%m-%d"
    ),
    next_step_requires_review_of = c(
      "rat genes without human orthologs",
      "one-to-many rat-to-human relationships",
      "many-rat-to-one-human targets",
      "locked 24-gene signature mappings",
      "ABCB1 rat paralog relationship"
    )
  )
)

class(complete_bundle) <- c(
  "GSE95554_rat_human_ortholog_audit_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE95554_rat_human_ortholog_AUDIT_bundle.rds"
)
stage_pair_file <- file.path(
  stage_audit_dir,
  "GSE95554_NCBI_unique_rat_human_ortholog_pairs.csv"
)
stage_rat_audit_file <- file.path(
  stage_audit_dir,
  "GSE95554_assayed_rat_gene_to_human_ortholog_audit.csv"
)
stage_expanded_file <- file.path(
  stage_audit_dir,
  "GSE95554_assayed_rat_human_ortholog_pairs_expanded.csv"
)
stage_human_target_file <- file.path(
  stage_audit_dir,
  "GSE95554_human_ortholog_target_relationship_audit.csv"
)
stage_signature_file <- file.path(
  stage_audit_dir,
  "GSE95554_locked_24gene_NCBI_ortholog_audit.csv"
)
stage_source_summary_file <- file.path(
  stage_audit_dir,
  "Script12D_NCBI_source_table_summary.csv"
)
stage_self_test_file <- file.path(
  stage_audit_dir,
  "Script12D_internal_boundary_self_test_audit.csv"
)
stage_source_filter_file <- file.path(
  stage_audit_dir,
  "Script12D_NCBI_source_row_filter_audit.csv"
)
stage_direction_audit_file <- file.path(
  stage_audit_dir,
  "Script12D_NCBI_ortholog_direction_audit.csv"
)
stage_duplicate_resolution_file <- file.path(
  stage_audit_dir,
  "Script12D_gene_info_duplicate_resolution_audit.csv"
)
stage_download_attempt_file <- file.path(
  stage_audit_dir,
  "Script12D_NCBI_download_attempt_audit.csv"
)
stage_download_manifest_file <- file.path(
  stage_audit_dir,
  "Script12D_downloaded_NCBI_files_with_MD5.csv"
)
stage_integrity_file <- file.path(
  stage_audit_dir,
  "GSE95554_rat_human_ortholog_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script12D_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script12D_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script12D_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script12D_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)

write_csv_utf8(
  rat_human_pairs,
  stage_pair_file
)
write_csv_utf8(
  assayed_rat_gene_audit,
  stage_rat_audit_file
)
write_csv_utf8(
  expanded_assayed_pairs,
  stage_expanded_file
)
write_csv_utf8(
  human_ortholog_target_audit,
  stage_human_target_file
)
write_csv_utf8(
  signature_ortholog_audit,
  stage_signature_file
)
write_csv_utf8(
  source_table_summary,
  stage_source_summary_file
)
write_csv_utf8(
  internal_self_test_audit,
  stage_self_test_file
)
write_csv_utf8(
  source_row_filter_audit,
  stage_source_filter_file
)
write_csv_utf8(
  ortholog_direction_audit,
  stage_direction_audit_file
)
write_csv_utf8(
  gene_info_duplicate_resolution_audit,
  stage_duplicate_resolution_file
)
write_csv_utf8(
  download_attempt_audit,
  stage_download_attempt_file
)
write_csv_utf8(
  download_manifest,
  stage_download_manifest_file
)
write_csv_utf8(
  integrity_summary,
  stage_integrity_file
)
write_csv_utf8(
  input_manifest,
  stage_input_manifest_file
)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# Read-back checks.
bundle_check <- readRDS(
  stage_bundle_file
)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "script_build_id",
      "source_rat_gene_symbols",
      "source_rat_gene_ids",
      "rat_human_pairs",
      "assayed_rat_gene_audit",
      "expanded_assayed_pairs",
      "human_ortholog_target_audit",
      "signature_ortholog_audit",
      "internal_self_test_audit",
      "source_row_filter_audit",
      "ortholog_direction_audit",
      "gene_info_duplicate_resolution_audit",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 12D bundle is missing required fields."
)

assert_true(
  identical(
    as.character(
      bundle_check$script_build_id
    ),
    SCRIPT_BUILD_ID
  ),
  "Saved Script 12D build ID is incorrect."
)

assert_true(
  identical(
    as.character(
      bundle_check$source_rat_gene_symbols
    ),
    rownames(gene_expression)
  ) &&
    identical(
      as.character(
        bundle_check$source_rat_gene_ids
      ),
      rat_gene_ids
    ),
  "Saved source rat-gene identifiers changed order."
)

assert_true(
  nrow(
    bundle_check$assayed_rat_gene_audit
  ) == 19098L &&
    nrow(
      bundle_check$signature_ortholog_audit
    ) == 24L &&
    nrow(
      bundle_check$ortholog_direction_audit
    ) == 2L &&
    nrow(
      bundle_check$internal_self_test_audit
    ) == 5L &&
    all(
      bundle_check$internal_self_test_audit$status == "PASS"
    ),
  "Saved Script 12D audit tables or internal self-tests are incomplete."
)

assert_true(
  isFALSE(
    bundle_check$policy$
      human_ortholog_expression_matrix_created
  ) &&
    isFALSE(
      bundle_check$policy$
        expression_values_aggregated
    ) &&
    isFALSE(
      bundle_check$policy$
        ABCB1_paralog_expression_combined
    ),
  "Saved Script 12D policy incorrectly indicates expression aggregation."
)

bundle_md5 <- md5_one(
  stage_bundle_file
)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 3 - Script 12D",
  "GSE95554 NCBI rat-to-human ortholog audit",
  paste0(
    "Script build ID: ",
    SCRIPT_BUILD_ID
  ),
  "============================================================",
  paste0(
    "Completion time: ",
    format(
      Sys.time(),
      "%Y-%m-%d %H:%M:%S %Z"
    )
  ),
  paste0(
    "Source Script 12C bundle MD5: ",
    observed_bundle_md5
  ),
  paste0(
    "Source Script 12C matrix MD5: ",
    observed_matrix_md5
  ),
  paste0(
    "Rat expression matrix verified: ",
    nrow(gene_expression),
    " x ",
    ncol(gene_expression)
  ),
  paste0(
    "Human-primary to rat-other ortholog rows: ",
    nrow(human_to_rat)
  ),
  paste0(
    "Rat-primary to human-other ortholog rows: ",
    nrow(rat_to_human)
  ),
  paste0(
    "Absent ortholog orientations handled safely: ",
    sum(
      ortholog_direction_audit$
        orientation_absent
    )
  ),
  paste0(
    "NCBI raw rat-human pair records: ",
    nrow(rat_human_pairs_raw)
  ),
  paste0(
    "NCBI unique rat-human pairs: ",
    nrow(rat_human_pairs)
  ),
  paste0(
    "Human gene_info raw / retained rows: ",
    nrow(human_info_raw),
    " / ",
    nrow(human_info)
  ),
  paste0(
    "Rat gene_info raw / retained rows: ",
    nrow(rat_info_raw),
    " / ",
    nrow(rat_info)
  ),
  paste0(
    "Human non-target tax_id rows filtered: ",
    human_info_sanitized$
      filter_audit$
      non_target_tax_id_row_number
  ),
  paste0(
    "Rat non-target tax_id rows filtered: ",
    rat_info_sanitized$
      filter_audit$
      non_target_tax_id_row_number
  ),
  paste0(
    "gene_info duplicated GeneID groups resolved: ",
    nrow(
      gene_info_duplicate_resolution_audit
    )
  ),
  "Single-row-safe completeness scoring: TRUE",
  "Schema-safe audit-table binding: TRUE",
  paste0(
    "Internal boundary self-tests passed: ",
    sum(internal_self_test_audit$status == "PASS"),
    " / ",
    nrow(internal_self_test_audit)
  ),
  "Direct expanded-pair construction without string re-parsing: TRUE",
  "Inherited interactive error handler cleared and restored on exit: TRUE",
  paste0(
    "Assayed rat genes with current NCBI record: ",
    sum(
      assayed_rat_gene_audit$
        current_NCBI_rat_record_available
    ),
    " / 19098"
  ),
  paste0(
    "Assayed rat genes without human ortholog: ",
    unname(
      mapping_class_counts[
        "NO_HUMAN_ORTHOLOG"
      ]
    )
  ),
  paste0(
    "Assayed rat genes with one human ortholog: ",
    unname(
      mapping_class_counts[
        "ONE_HUMAN_ORTHOLOG"
      ]
    )
  ),
  paste0(
    "Assayed rat genes with multiple human orthologs: ",
    unname(
      mapping_class_counts[
        "MULTIPLE_HUMAN_ORTHOLOGS"
      ]
    )
  ),
  paste0(
    "Unique human ortholog targets: ",
    nrow(human_ortholog_target_audit)
  ),
  paste0(
    "Human targets with multiple assayed rat genes: ",
    unname(
      human_relationship_counts[
        "MULTIPLE_ASSAYED_RAT_GENES"
      ]
    )
  ),
  paste0(
    "Locked signature genes with any assayed rat ortholog: ",
    sum(
      signature_ortholog_audit$
        assayed_rat_ortholog_number > 0L
    ),
    " / 24"
  ),
  paste0(
    "Locked signature genes with multiple assayed rat orthologs: ",
    sum(
      signature_ortholog_audit$
        assayed_rat_ortholog_number > 1L
    )
  ),
  paste0(
    "ABCB1 assayed rat ortholog number: ",
    abcb1_row$
      assayed_rat_ortholog_number
  ),
  paste0(
    "ABCB1 assayed rat symbols: ",
    abcb1_row$
      assayed_rat_symbols
  ),
  "Human-ortholog expression matrix created: FALSE",
  "Expression values aggregated: FALSE",
  "ABCB1 paralog expression combined: FALSE",
  "Differential expression performed: FALSE",
  "PCA performed: FALSE",
  "GSVA/GSEA performed: FALSE",
  paste0(
    "Script 12D bundle MD5: ",
    bundle_md5
  ),
  "",
  "SCRIPT12D STATUS: COMPLETE",
  paste0(
    "Current NCBI rat-human ortholog relationships were audited only. ",
    "No expression row was converted, selected or aggregated."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(
    report_lines
  ),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_pair_file,
  stage_rat_audit_file,
  stage_expanded_file,
  stage_human_target_file,
  stage_signature_file,
  stage_source_summary_file,
  stage_self_test_file,
  stage_source_filter_file,
  stage_direction_audit_file,
  stage_duplicate_resolution_file,
  stage_download_attempt_file,
  stage_download_manifest_file,
  stage_integrity_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file,
  downloaded_files
)

output_files_before_manifest <- unique(
  output_files_before_manifest
)

assert_true(
  all(
    file.exists(
      output_files_before_manifest
    )
  ),
  "At least one staged Script 12D output is missing."
)

assert_true(
  all(
    file.info(
      output_files_before_manifest
    )$size > 0
  ),
  "At least one staged Script 12D output is empty."
)

output_manifest <- make_manifest(
  output_files_before_manifest
)

write_csv_utf8(
  output_manifest,
  stage_output_manifest_file
)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) ==
    length(output_files_before_manifest),
  "Script 12D output manifest has an incorrect row count."
)

for (i in seq_along(
  output_files_before_manifest
)) {
  file_i <- output_files_before_manifest[i]

  row_i <- manifest_check[
    manifest_check$absolute_path ==
      normalizePath(
        file_i,
        winslash = "/",
        mustWork = FALSE
      ),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0(
      "Missing or duplicated manifest row for: ",
      basename(file_i)
    )
  )

  assert_true(
    identical(
      tolower(
        as.character(
          row_i$md5
        )
      ),
      tolower(
        md5_one(file_i)
      )
    ),
    paste0(
      "Manifest MD5 mismatch: ",
      basename(file_i)
    )
  )

  assert_true(
    as.numeric(
      row_i$size_bytes
    ) ==
      as.numeric(
        file.info(file_i)$size
      ),
    paste0(
      "Manifest size mismatch: ",
      basename(file_i)
    )
  )
}

# ------------------------------
# 12. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 12D directory appeared during staging."
)

rename_ok <- file.rename(
  stage_root,
  final_root
)

if (!isTRUE(rename_ok)) {
  dir.create(
    final_root,
    recursive = TRUE,
    showWarnings = FALSE
  )

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 12D staging directory."
  )

  unlink(
    stage_root,
    recursive = TRUE,
    force = TRUE
  )
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE95554_rat_human_ortholog_AUDIT_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script12D_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script12D_output_manifest_with_MD5.csv"
)

assert_true(
  all(
    file.exists(c(
      final_bundle_file,
      final_report_file,
      final_manifest_file
    ))
  ),
  "Committed Script 12D output is incomplete."
)

assert_true(
  identical(
    md5_one(
      final_bundle_file
    ),
    bundle_md5
  ),
  "Committed Script 12D bundle MD5 changed after commit."
)

assert_true(
  report_contains(
    final_report_file,
    "SCRIPT12D STATUS: COMPLETE"
  ),
  "Committed Script 12D report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 12D completed successfully.\n")
cat(
  "Assayed rat genes audited: ",
  nrow(
    assayed_rat_gene_audit
  ),
  "\n",
  sep = ""
)
cat(
  "Rat genes with any human ortholog: ",
  sum(
    assayed_rat_gene_audit$
      human_ortholog_number > 0L
  ),
  "\n",
  sep = ""
)
cat(
  "Unique human ortholog targets: ",
  nrow(
    human_ortholog_target_audit
  ),
  "\n",
  sep = ""
)
cat(
  "Locked signature genes with any assayed rat ortholog: ",
  sum(
    signature_ortholog_audit$
      assayed_rat_ortholog_number > 0L
  ),
  " / 24\n",
  sep = ""
)
cat(
  "ABCB1 rat orthologs: ",
  abcb1_row$
    assayed_rat_symbols,
  "\n",
  sep = ""
)
cat("Human-ortholog expression matrix created: FALSE\n")
cat("ABCB1 paralog expression combined: FALSE\n")
cat("Differential expression performed: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat(
  "Bundle MD5: ",
  md5_one(
    final_bundle_file
  ),
  "\n",
  sep = ""
)
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

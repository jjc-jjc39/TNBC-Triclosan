# ==============================================================================
# TNBC_Triclosan
# Step 3 - GSE95554 real Triclosan exposure validation
# Script 12E FINAL
#
# Purpose:
#   Continue strictly from the accepted Script 12C rat gene-level expression
#   matrix and the accepted Script 12D NCBI ortholog audit. Construct a human-
#   ortholog expression matrix only for audited one-rat-to-one-human mappings.
#
# Prespecified conversion policy:
#   1) Use only Script 12D rows classified as one assayed rat gene mapping to
#      one current human ortholog.
#   2) Preserve the original 50-sample order and every selected expression
#      value exactly; conversion changes row identifiers only.
#   3) Do not aggregate, average, maximize, or otherwise combine expression.
#   4) Do not substitute Abcb1a/Abcb1b for human ABCB1.
#   5) Do not substitute Scd/Scd2/Scd3/Scd4 for human SCD.
#   6) The locked signature matrix therefore contains the 22 prespecified genes
#      with audited one-to-one orthologs; ABCB1 and SCD remain explicitly absent.
#
# This script DOES:
#   - verify fixed accepted Script 12C and Script 12D files and MD5 values;
#   - verify that Script 12D mapping is exactly one-to-one for 15,817 rows;
#   - create a 15,817 x 50 human-symbol expression matrix by direct row copying;
#   - create the locked 22-gene ortholog expression subset without scoring it;
#   - save RDS objects, CSV audits, relative-path manifests, report and sessionInfo.
#
# This script DOES NOT:
#   - normalize, transform, impute, center, scale, batch-correct or filter samples;
#   - aggregate expression values or resolve one-to-many mappings;
#   - combine ABCB1 or SCD paralogs;
#   - calculate a Triclosan score;
#   - perform TCS-versus-OIL testing, DEG, PCA, GSVA, GSEA or enrichment analysis;
#   - use any biological result to select genes or mappings.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()

previous_error_option <- getOption("error")
options(stringsAsFactors = FALSE, warn = 1)
options(error = NULL)
Sys.setenv(TZ = "Asia/Singapore")

SCRIPT_BUILD_ID <- "Script12E_FINAL_20260711"

cat("============================================================\n")
cat("RUNNING: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat("Audited one-to-one human ortholog conversion: ENABLED\n")
cat("Expression value aggregation: DISABLED\n")
cat("ABCB1/SCD paralog substitution: DISABLED\n")
cat("Triclosan score and exposure comparison: DISABLED\n")
cat("DEG/PCA/GSVA/GSEA: DISABLED\n")
cat("============================================================\n")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step3_GSE95554_real_exposure_validation"
)

script12c_root <- file.path(
  step_root,
  "02_gene_level_expression"
)
script12d_root <- file.path(
  step_root,
  "03_rat_human_ortholog_audit"
)
final_root <- file.path(
  step_root,
  "04_human_ortholog_expression"
)

script12c_bundle_file <- file.path(
  script12c_root,
  "objects",
  "GSE95554_gene_level_expression_COMPLETE_bundle.rds"
)
script12c_matrix_file <- file.path(
  script12c_root,
  "objects",
  "GSE95554_gene_level_expression_matrix.rds"
)
script12c_manifest_file <- file.path(
  script12c_root,
  "audit",
  "Script12C_output_manifest_with_MD5.csv"
)
script12c_report_file <- file.path(
  script12c_root,
  "logs",
  "Script12C_COMPLETE_report.txt"
)

script12d_bundle_file <- file.path(
  script12d_root,
  "objects",
  "GSE95554_rat_human_ortholog_AUDIT_bundle.rds"
)
script12d_expanded_file <- file.path(
  script12d_root,
  "audit",
  "GSE95554_assayed_rat_human_ortholog_pairs_expanded.csv"
)
script12d_signature_file <- file.path(
  script12d_root,
  "audit",
  "GSE95554_locked_24gene_NCBI_ortholog_audit.csv"
)
script12d_integrity_file <- file.path(
  script12d_root,
  "audit",
  "GSE95554_rat_human_ortholog_integrity_summary.csv"
)
script12d_manifest_file <- file.path(
  script12d_root,
  "audit",
  "Script12D_output_manifest_with_MD5.csv"
)
script12d_report_file <- file.path(
  script12d_root,
  "logs",
  "Script12D_COMPLETE_report.txt"
)

required_inputs <- c(
  script12c_bundle_file,
  script12c_matrix_file,
  script12c_manifest_file,
  script12c_report_file,
  script12d_bundle_file,
  script12d_expanded_file,
  script12d_signature_file,
  script12d_integrity_file,
  script12d_manifest_file,
  script12d_report_file
)

missing_inputs <- required_inputs[
  !file.exists(required_inputs)
]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 12E cannot start because required accepted files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop(
    paste0(
      "Step 3 directory does not exist:\n",
      step_root
    ),
    call. = FALSE
  )
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(
      final_root,
      all.files = TRUE
    ),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(
      final_root,
      recursive = TRUE,
      force = TRUE
    )
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 12E will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive that directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(
  Sys.time(),
  "%Y%m%d_%H%M%S"
)

stage_root <- file.path(
  step_root,
  paste0(
    ".Script12E_staging_",
    stamp,
    "_",
    Sys.getpid()
  )
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

for (directory_i in c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)) {
  dir.create(
    directory_i,
    recursive = TRUE,
    showWarnings = FALSE
  )
}

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop(
    "Unable to create Script 12E staging directories.",
    call. = FALSE
  )
}

committed <- FALSE

on.exit({
  options(error = previous_error_option)

  if (!committed && dir.exists(stage_root)) {
    unlink(
      stage_root,
      recursive = TRUE,
      force = TRUE
    )
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) {
    stop(
      message,
      call. = FALSE
    )
  }
}

md5_one <- function(path) {
  unname(
    tools::md5sum(path)
  )
}

clean_text <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  trimws(x)
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(
    report_file,
    warn = FALSE,
    encoding = "UTF-8"
  )

  any(
    grepl(
      fixed_text,
      lines,
      fixed = TRUE
    )
  )
}

read_manifest <- function(manifest_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c(
      "file_name",
      "size_bytes",
      "md5"
    ) %in% colnames(manifest)),
    paste0(
      "Malformed manifest:\n",
      manifest_file
    )
  )

  assert_true(
    nrow(manifest) >= 1L &&
      anyDuplicated(
        as.character(manifest$file_name)
      ) == 0L,
    paste0(
      "Manifest is empty or has duplicated file names:\n",
      manifest_file
    )
  )

  manifest
}

manifest_expected_md5 <- function(
  manifest,
  target_file
) {
  row_index <- which(
    as.character(manifest$file_name) ==
      basename(target_file)
  )

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file),
      "."
    )
  )

  tolower(
    trimws(
      as.character(
        manifest$md5[row_index]
      )
    )
  )
}

verify_fixed_md5 <- function(
  file,
  expected_md5,
  label
) {
  observed_md5 <- tolower(md5_one(file))

  assert_true(
    identical(
      observed_md5,
      tolower(expected_md5)
    ),
    paste0(
      label,
      " MD5 mismatch.\nExpected: ",
      tolower(expected_md5),
      "\nObserved: ",
      observed_md5,
      "\nFile: ",
      file
    )
  )

  observed_md5
}

safe_integer <- function(x, field_name) {
  original <- clean_text(x)
  result <- suppressWarnings(
    as.integer(original)
  )

  assert_true(
    length(result) == length(original) &&
      !any(is.na(result)) &&
      all(as.character(result) == original),
    paste0(
      "Column ",
      field_name,
      " is not a complete canonical integer vector."
    )
  )

  result
}

safe_gene_id_character <- function(x, field_name) {
  result <- clean_text(x)

  assert_true(
    length(result) == length(x) &&
      all(grepl("^[0-9]+$", result)),
    paste0(
      "Column ",
      field_name,
      " contains a blank or non-numeric GeneID."
    )
  )

  result
}

make_project_input_manifest <- function(
  paths,
  labels,
  project_root
) {
  assert_true(
    length(paths) == length(labels) &&
      length(paths) >= 1L,
    "Input manifest paths and labels are inconsistent."
  )

  project_normalized <- normalizePath(
    project_root,
    winslash = "/",
    mustWork = TRUE
  )

  normalized_paths <- vapply(
    paths,
    normalizePath,
    character(1),
    winslash = "/",
    mustWork = TRUE
  )

  prefix <- paste0(project_normalized, "/")

  assert_true(
    all(startsWith(normalized_paths, prefix)),
    "At least one input file is outside the fixed project root."
  )

  info <- file.info(paths)

  data.frame(
    source_stage = labels,
    file_name = basename(paths),
    project_relative_path = substring(
      normalized_paths,
      nchar(prefix) + 1L
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(
      paths,
      md5_one,
      character(1)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

make_relative_output_manifest <- function(
  paths,
  root
) {
  assert_true(
    length(paths) >= 1L &&
      all(file.exists(paths)),
    "Cannot create output manifest from missing files."
  )

  root_normalized <- normalizePath(
    root,
    winslash = "/",
    mustWork = TRUE
  )
  normalized_paths <- vapply(
    paths,
    normalizePath,
    character(1),
    winslash = "/",
    mustWork = TRUE
  )
  prefix <- paste0(root_normalized, "/")

  assert_true(
    all(startsWith(normalized_paths, prefix)),
    "At least one output file is outside the staging root."
  )

  relative_paths <- substring(
    normalized_paths,
    nchar(prefix) + 1L
  )

  assert_true(
    anyDuplicated(relative_paths) == 0L,
    "Output relative paths are duplicated."
  )

  info <- file.info(paths)

  data.frame(
    file_name = basename(paths),
    relative_path = relative_paths,
    size_bytes = as.numeric(info$size),
    md5 = vapply(
      paths,
      md5_one,
      character(1)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

verify_committed_manifest <- function(
  manifest_file,
  committed_root
) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c(
      "file_name",
      "relative_path",
      "size_bytes",
      "md5"
    ) %in% colnames(manifest)),
    "Committed output manifest is malformed."
  )

  assert_true(
    nrow(manifest) >= 1L &&
      anyDuplicated(manifest$relative_path) == 0L,
    "Committed output manifest is empty or duplicated."
  )

  for (i in seq_len(nrow(manifest))) {
    file_i <- file.path(
      committed_root,
      manifest$relative_path[i]
    )

    assert_true(
      file.exists(file_i),
      paste0(
        "Committed manifest file is missing: ",
        manifest$relative_path[i]
      )
    )

    assert_true(
      as.numeric(file.info(file_i)$size) ==
        as.numeric(manifest$size_bytes[i]),
      paste0(
        "Committed file size mismatch: ",
        manifest$relative_path[i]
      )
    )

    assert_true(
      identical(
        tolower(md5_one(file_i)),
        tolower(as.character(manifest$md5[i]))
      ),
      paste0(
        "Committed file MD5 mismatch: ",
        manifest$relative_path[i]
      )
    )
  }

  invisible(TRUE)
}

# ------------------------------
# 2. Verify accepted input identities
# ------------------------------
accepted_script12c_bundle_md5 <-
  "9fbf19ad50a05ff57529ccc340ca1000"
accepted_script12c_matrix_md5 <-
  "6fe449a1d9ad640133b31275370e77e3"
accepted_script12d_bundle_md5 <-
  "0a0bfd782fe8158b5fac005e229df1d8"
accepted_script12d_expanded_md5 <-
  "a3c6ae2c9e648877190e436c4adf4953"
accepted_script12d_signature_md5 <-
  "0f25e688a34ddb6772bea36c5f40890b"
accepted_script12d_integrity_md5 <-
  "467fb33d57e44a0aa1fa821ebbc5897f"
accepted_script12d_manifest_md5 <-
  "ca753b1c294190e9f550d51290f96bcf"
accepted_script12d_report_md5 <-
  "e91dacb87844f5fc08130274bb32b7e3"

assert_true(
  report_contains(
    script12c_report_file,
    "SCRIPT12C STATUS: COMPLETE"
  ) &&
    report_contains(
      script12c_report_file,
      "Script build ID: Script12C_FINAL_20260711"
    ),
  "Script 12C completion report is not the accepted FINAL report."
)

assert_true(
  report_contains(
    script12d_report_file,
    "SCRIPT12D STATUS: COMPLETE"
  ) &&
    report_contains(
      script12d_report_file,
      "Script build ID: Script12D_v5_FINAL_20260711"
    ),
  "Script 12D completion report is not the accepted v5 FINAL report."
)

script12c_manifest <- read_manifest(
  script12c_manifest_file
)
script12d_manifest <- read_manifest(
  script12d_manifest_file
)

observed_script12c_bundle_md5 <- verify_fixed_md5(
  script12c_bundle_file,
  accepted_script12c_bundle_md5,
  "Accepted Script 12C bundle"
)
observed_script12c_matrix_md5 <- verify_fixed_md5(
  script12c_matrix_file,
  accepted_script12c_matrix_md5,
  "Accepted Script 12C matrix"
)
observed_script12d_bundle_md5 <- verify_fixed_md5(
  script12d_bundle_file,
  accepted_script12d_bundle_md5,
  "Accepted Script 12D bundle"
)
observed_script12d_expanded_md5 <- verify_fixed_md5(
  script12d_expanded_file,
  accepted_script12d_expanded_md5,
  "Accepted Script 12D expanded mapping"
)
observed_script12d_signature_md5 <- verify_fixed_md5(
  script12d_signature_file,
  accepted_script12d_signature_md5,
  "Accepted Script 12D signature audit"
)
observed_script12d_integrity_md5 <- verify_fixed_md5(
  script12d_integrity_file,
  accepted_script12d_integrity_md5,
  "Accepted Script 12D integrity summary"
)
observed_script12d_manifest_md5 <- verify_fixed_md5(
  script12d_manifest_file,
  accepted_script12d_manifest_md5,
  "Accepted Script 12D output manifest"
)
observed_script12d_report_md5 <- verify_fixed_md5(
  script12d_report_file,
  accepted_script12d_report_md5,
  "Accepted Script 12D completion report"
)

assert_true(
  identical(
    manifest_expected_md5(
      script12c_manifest,
      script12c_bundle_file
    ),
    observed_script12c_bundle_md5
  ) &&
    identical(
      manifest_expected_md5(
        script12c_manifest,
        script12c_matrix_file
      ),
      observed_script12c_matrix_md5
    ),
  "Script 12C key files differ from the Script 12C manifest."
)

# Script 12D absolute_path values are intentionally ignored because the accepted
# v5 manifest was generated before the staging directory was committed. File
# names, sizes and MD5 values remain authoritative and were independently audited.
assert_true(
  identical(
    manifest_expected_md5(
      script12d_manifest,
      script12d_bundle_file
    ),
    observed_script12d_bundle_md5
  ) &&
    identical(
      manifest_expected_md5(
        script12d_manifest,
        script12d_expanded_file
      ),
      observed_script12d_expanded_md5
    ) &&
    identical(
      manifest_expected_md5(
        script12d_manifest,
        script12d_signature_file
      ),
      observed_script12d_signature_md5
    ) &&
    identical(
      manifest_expected_md5(
        script12d_manifest,
        script12d_integrity_file
      ),
      observed_script12d_integrity_md5
    ) &&
    identical(
      manifest_expected_md5(
        script12d_manifest,
        script12d_report_file
      ),
      observed_script12d_report_md5
    ),
  "Script 12D key files differ from the accepted Script 12D manifest."
)

# ------------------------------
# 3. Load and validate accepted objects
# ------------------------------
script12c_bundle <- readRDS(
  script12c_bundle_file
)
rat_expression_standalone <- readRDS(
  script12c_matrix_file
)
script12d_bundle <- readRDS(
  script12d_bundle_file
)

assert_true(
  is.list(script12c_bundle) &&
    all(c(
      "script",
      "script_build_id",
      "source_accession",
      "source_platform",
      "design_table",
      "gene_level_expression",
      "gene_aggregation_audit",
      "policy"
    ) %in% names(script12c_bundle)),
  "Script 12C bundle is missing required fields."
)

assert_true(
  identical(
    as.character(script12c_bundle$script),
    "Script12C"
  ) &&
    identical(
      as.character(script12c_bundle$script_build_id),
      "Script12C_FINAL_20260711"
    ) &&
    identical(
      as.character(script12c_bundle$source_accession),
      "GSE95554"
    ) &&
    identical(
      as.character(script12c_bundle$source_platform),
      "GPL17117"
    ),
  "Script 12C bundle identity is incorrect."
)

rat_expression <- script12c_bundle$gene_level_expression
design_table <- script12c_bundle$design_table
gene_aggregation_audit <-
  script12c_bundle$gene_aggregation_audit

assert_true(
  is.matrix(rat_expression) &&
    is.numeric(rat_expression) &&
    identical(dim(rat_expression), c(19098L, 50L)),
  paste0(
    "Expected a 19,098 x 50 Script 12C matrix, detected ",
    paste(dim(rat_expression), collapse = " x "),
    "."
  )
)

assert_true(
  is.matrix(rat_expression_standalone) &&
    identical(
      rat_expression_standalone,
      rat_expression
    ),
  "Script 12C standalone matrix is not identical to the bundle matrix."
)

assert_true(
  sum(!is.finite(rat_expression)) == 0L &&
    !is.null(rownames(rat_expression)) &&
    !is.null(colnames(rat_expression)) &&
    anyDuplicated(rownames(rat_expression)) == 0L &&
    anyDuplicated(colnames(rat_expression)) == 0L &&
    all(nzchar(rownames(rat_expression))) &&
    all(nzchar(colnames(rat_expression))),
  "Script 12C rat expression matrix has invalid values or identifiers."
)

required_design_columns <- c(
  "sample_order",
  "sample_id",
  "GEO_accession",
  "sample_title",
  "exposure_code",
  "reproductive_state_code",
  "primary_TCS_or_OIL_subset",
  "primary_nulliparous_subset",
  "primary_parous_subset"
)

assert_true(
  is.data.frame(design_table) &&
    nrow(design_table) == 50L &&
    all(required_design_columns %in% colnames(design_table)) &&
    anyDuplicated(as.character(design_table$sample_id)) == 0L &&
    identical(
      colnames(rat_expression),
      as.character(design_table$sample_id)
    ),
  "Script 12C design table is malformed or not aligned to expression columns."
)

assert_true(
  sum(design_table$exposure_code == "TCS") == 10L &&
    sum(design_table$exposure_code == "OIL") == 10L &&
    sum(design_table$primary_TCS_or_OIL_subset) == 20L &&
    sum(design_table$primary_nulliparous_subset) == 10L &&
    sum(design_table$primary_parous_subset) == 10L,
  "The accepted TCS/OIL experimental design no longer has the expected counts."
)

assert_true(
  is.data.frame(gene_aggregation_audit) &&
    nrow(gene_aggregation_audit) == 19098L,
  "Script 12C gene aggregation audit is malformed."
)

assert_true(
  is.list(script12d_bundle) &&
    all(c(
      "script",
      "script_build_id",
      "source_accession",
      "source_script12c_bundle_md5",
      "source_script12c_matrix_md5",
      "source_rat_gene_symbols",
      "source_rat_gene_ids",
      "expanded_assayed_pairs",
      "signature_ortholog_audit",
      "integrity_summary",
      "policy"
    ) %in% names(script12d_bundle)),
  "Script 12D bundle is missing required fields."
)

assert_true(
  identical(
    as.character(script12d_bundle$script),
    "Script12D"
  ) &&
    identical(
      as.character(script12d_bundle$script_build_id),
      "Script12D_v5_FINAL_20260711"
    ) &&
    identical(
      as.character(script12d_bundle$source_accession),
      "GSE95554"
    ) &&
    identical(
      as.character(
        script12d_bundle$source_script12c_bundle_md5
      ),
      observed_script12c_bundle_md5
    ) &&
    identical(
      as.character(
        script12d_bundle$source_script12c_matrix_md5
      ),
      observed_script12c_matrix_md5
    ),
  "Script 12D bundle identity or Script 12C provenance is incorrect."
)

assert_true(
  isFALSE(
    script12d_bundle$policy$
      human_ortholog_expression_matrix_created
  ) &&
    isFALSE(
      script12d_bundle$policy$
        expression_values_aggregated
    ) &&
    isFALSE(
      script12d_bundle$policy$
        ABCB1_paralog_expression_combined
    ) &&
    isFALSE(
      script12d_bundle$policy$
        differential_expression_performed
    ) &&
    isFALSE(
      script12d_bundle$policy$PCA_performed
    ) &&
    isFALSE(
      script12d_bundle$policy$GSVA_or_GSEA_performed
    ),
  "Script 12D policy unexpectedly indicates downstream expression analysis."
)

source_rat_symbols <- clean_text(
  script12d_bundle$source_rat_gene_symbols
)
source_rat_gene_ids <- safe_gene_id_character(
  script12d_bundle$source_rat_gene_ids,
  "Script12D source_rat_gene_ids"
)

assert_true(
  length(source_rat_symbols) == 19098L &&
    length(source_rat_gene_ids) == 19098L &&
    anyDuplicated(source_rat_symbols) == 0L &&
    anyDuplicated(source_rat_gene_ids) == 0L &&
    identical(
      source_rat_symbols,
      rownames(rat_expression)
    ),
  "Script 12D source rat identifiers do not match the Script 12C matrix."
)

# ------------------------------
# 4. Verify Script 12D CSV/RDS mapping closure
# ------------------------------
expanded_pairs <- script12d_bundle$expanded_assayed_pairs
signature_audit_12d <-
  script12d_bundle$signature_ortholog_audit
integrity_12d <- script12d_bundle$integrity_summary

required_expanded_columns <- c(
  "rat_gene_order",
  "rat_expression_symbol",
  "rat_gene_id",
  "human_gene_id",
  "source_orientation",
  "duplicate_source_record_number",
  "human_symbol",
  "human_description",
  "human_gene_record_current"
)

assert_true(
  is.data.frame(expanded_pairs) &&
    nrow(expanded_pairs) == 15817L &&
    all(required_expanded_columns %in% colnames(expanded_pairs)),
  "Script 12D expanded one-to-one mapping table is malformed."
)

expanded_csv <- read.csv(
  script12d_expanded_file,
  stringsAsFactors = FALSE,
  check.names = FALSE,
  colClasses = "character"
)

assert_true(
  nrow(expanded_csv) == 15817L &&
    all(required_expanded_columns %in% colnames(expanded_csv)),
  "Script 12D expanded mapping CSV is malformed."
)

comparison_columns <- c(
  "rat_gene_order",
  "rat_expression_symbol",
  "rat_gene_id",
  "human_gene_id",
  "source_orientation",
  "duplicate_source_record_number",
  "human_symbol",
  "human_description"
)

for (column_i in comparison_columns) {
  assert_true(
    identical(
      clean_text(expanded_csv[[column_i]]),
      clean_text(expanded_pairs[[column_i]])
    ),
    paste0(
      "Script 12D expanded CSV and RDS differ in column ",
      column_i,
      "."
    )
  )
}

csv_current <- toupper(
  clean_text(
    expanded_csv$human_gene_record_current
  )
)
rds_current <- ifelse(
  as.logical(
    expanded_pairs$human_gene_record_current
  ),
  "TRUE",
  "FALSE"
)

assert_true(
  identical(csv_current, rds_current),
  "Script 12D expanded CSV and RDS differ in current-record status."
)

rat_gene_order <- safe_integer(
  expanded_pairs$rat_gene_order,
  "rat_gene_order"
)
rat_gene_ids <- safe_gene_id_character(
  expanded_pairs$rat_gene_id,
  "rat_gene_id"
)
human_gene_ids <- safe_gene_id_character(
  expanded_pairs$human_gene_id,
  "human_gene_id"
)
rat_symbols <- clean_text(
  expanded_pairs$rat_expression_symbol
)
human_symbols <- clean_text(
  expanded_pairs$human_symbol
)

mapping_order <- order(rat_gene_order)
expanded_pairs <- expanded_pairs[
  mapping_order,
  ,
  drop = FALSE
]
rat_gene_order <- rat_gene_order[mapping_order]
rat_gene_ids <- rat_gene_ids[mapping_order]
human_gene_ids <- human_gene_ids[mapping_order]
rat_symbols <- rat_symbols[mapping_order]
human_symbols <- human_symbols[mapping_order]
rownames(expanded_pairs) <- NULL

assert_true(
  length(rat_gene_order) == 15817L &&
    all(rat_gene_order >= 1L) &&
    all(rat_gene_order <= 19098L) &&
    anyDuplicated(rat_gene_order) == 0L &&
    anyDuplicated(rat_gene_ids) == 0L &&
    anyDuplicated(human_gene_ids) == 0L &&
    anyDuplicated(rat_symbols) == 0L &&
    anyDuplicated(human_symbols) == 0L,
  "Script 12D one-to-one mapping contains invalid ranges or duplicates."
)

assert_true(
  all(nzchar(rat_symbols)) &&
    all(nzchar(human_symbols)) &&
    all(
      as.logical(
        expanded_pairs$human_gene_record_current
      )
    ) &&
    all(
      as.integer(
        expanded_pairs$duplicate_source_record_number
      ) == 1L
    ),
  "Script 12D one-to-one mapping contains blank symbols, obsolete records or duplicate source records."
)

assert_true(
  identical(
    source_rat_symbols[rat_gene_order],
    rat_symbols
  ) &&
    identical(
      source_rat_gene_ids[rat_gene_order],
      rat_gene_ids
    ) &&
    identical(
      rownames(rat_expression)[rat_gene_order],
      rat_symbols
    ),
  "Mapping row numbers, rat symbols or rat GeneIDs do not align with Script 12C."
)

assert_true(
  is.data.frame(signature_audit_12d) &&
    nrow(signature_audit_12d) == 24L &&
    is.data.frame(integrity_12d) &&
    nrow(integrity_12d) == 36L,
  "Script 12D signature or integrity table is malformed."
)

signature_csv <- read.csv(
  script12d_signature_file,
  stringsAsFactors = FALSE,
  check.names = FALSE,
  colClasses = "character"
)
integrity_csv <- read.csv(
  script12d_integrity_file,
  stringsAsFactors = FALSE,
  check.names = FALSE,
  colClasses = "character"
)

assert_true(
  nrow(signature_csv) == 24L &&
    nrow(integrity_csv) == 36L &&
    identical(
      clean_text(signature_csv$locked_human_symbol),
      clean_text(signature_audit_12d$locked_human_symbol)
    ) &&
    identical(
      clean_text(integrity_csv$item),
      clean_text(integrity_12d$item)
    ) &&
    identical(
      clean_text(integrity_csv$value),
      clean_text(integrity_12d$value)
    ),
  "Script 12D signature/integrity CSV files do not match the RDS bundle."
)

integrity_lookup_12d <- setNames(
  clean_text(integrity_12d$value),
  clean_text(integrity_12d$item)
)

required_integrity_values <- c(
  Assayed_rat_genes_without_human_ortholog = "3281",
  Assayed_rat_genes_with_one_human_ortholog = "15817",
  Assayed_rat_genes_with_multiple_human_orthologs = "0",
  Unique_human_ortholog_target_number = "15817",
  Human_targets_with_multiple_assayed_rat_genes = "0",
  Locked_signature_genes_with_one_assayed_rat_ortholog = "22",
  Locked_signature_genes_without_assayed_rat_ortholog = "2",
  Human_ortholog_expression_matrix_created = "FALSE",
  Expression_values_aggregated = "FALSE",
  ABCB1_paralog_expression_combined = "FALSE",
  Differential_expression_performed = "FALSE",
  PCA_performed = "FALSE",
  GSVA_or_GSEA_performed = "FALSE",
  Completion_status = "COMPLETE"
)

assert_true(
  all(
    names(required_integrity_values) %in%
      names(integrity_lookup_12d)
  ) &&
    all(
      integrity_lookup_12d[
        names(required_integrity_values)
      ] == required_integrity_values
    ),
  "Script 12D integrity summary does not preserve the accepted mapping boundary."
)

# ------------------------------
# 5. Construct direct human-ortholog expression matrices
# ------------------------------
selected_rat_expression <- rat_expression[
  rat_gene_order,
  ,
  drop = FALSE
]

human_expression <- selected_rat_expression
rownames(human_expression) <- human_symbols

assert_true(
  is.matrix(human_expression) &&
    is.numeric(human_expression) &&
    identical(dim(human_expression), c(15817L, 50L)),
  "Human ortholog expression matrix does not have dimensions 15,817 x 50."
)

assert_true(
  identical(
    colnames(human_expression),
    colnames(rat_expression)
  ) &&
    identical(
      rownames(human_expression),
      human_symbols
    ) &&
    anyDuplicated(rownames(human_expression)) == 0L &&
    sum(!is.finite(human_expression)) == 0L,
  "Human ortholog matrix has invalid identifiers, sample order or values."
)

assert_true(
  identical(
    as.numeric(human_expression),
    as.numeric(selected_rat_expression)
  ),
  "At least one expression value changed during human ortholog conversion."
)

human_row_annotation <- data.frame(
  human_expression_row = seq_len(nrow(human_expression)),
  human_symbol = human_symbols,
  human_gene_id = human_gene_ids,
  human_description = clean_text(
    expanded_pairs$human_description
  ),
  source_rat_gene_order = rat_gene_order,
  source_rat_expression_symbol = rat_symbols,
  source_rat_gene_id = rat_gene_ids,
  source_orientation = clean_text(
    expanded_pairs$source_orientation
  ),
  mapping_policy = rep(
    "AUDITED_ONE_RAT_TO_ONE_HUMAN_DIRECT_COPY",
    nrow(human_expression)
  ),
  expression_values_aggregated = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(human_row_annotation) == 15817L &&
    identical(
      human_row_annotation$human_symbol,
      rownames(human_expression)
    ) &&
    identical(
      human_row_annotation$source_rat_expression_symbol,
      rownames(selected_rat_expression)
    ) &&
    !any(human_row_annotation$expression_values_aggregated),
  "Human ortholog row annotation is inconsistent with the expression matrix."
)

# ------------------------------
# 6. Build locked 24-gene availability audit and 22-gene matrix
# ------------------------------
signature_order <- safe_integer(
  signature_audit_12d$signature_order,
  "signature_order"
)
signature_sort <- order(signature_order)
signature_audit_12d <- signature_audit_12d[
  signature_sort,
  ,
  drop = FALSE
]
rownames(signature_audit_12d) <- NULL

locked_24 <- clean_text(
  signature_audit_12d$locked_human_symbol
)

expected_locked_24 <- c(
  "ESR1", "AR", "PGR", "THRA", "THRB", "CAT",
  "BCL2", "BAX", "PARP1", "IL6", "ABCB1", "ABCG2",
  "FASN", "SCD", "TWIST1", "PPARG", "EGFR", "MMP9",
  "JUN", "FOS", "ADRB2", "ERG", "H2AX", "MITF"
)

assert_true(
  identical(locked_24, expected_locked_24) &&
    anyDuplicated(locked_24) == 0L,
  "Locked 24-gene signature order or membership changed."
)

human_row_index <- match(
  locked_24,
  rownames(human_expression)
)
human_expression_available <- !is.na(human_row_index)
missing_locked_genes <- locked_24[
  !human_expression_available
]
available_locked_genes <- locked_24[
  human_expression_available
]

assert_true(
  sum(human_expression_available) == 22L &&
    identical(
      missing_locked_genes,
      c("ABCB1", "SCD")
    ),
  paste0(
    "Expected exactly ABCB1 and SCD to lack audited one-to-one expression. Observed missing genes: ",
    paste(missing_locked_genes, collapse = ";")
  )
)

signature_mapping_counts <- suppressWarnings(
  as.integer(
    clean_text(
      signature_audit_12d$assayed_rat_ortholog_number
    )
  )
)

assert_true(
  !any(is.na(signature_mapping_counts)) &&
    all(
      signature_mapping_counts[
        human_expression_available
      ] == 1L
    ) &&
    all(
      signature_mapping_counts[
        !human_expression_available
      ] == 0L
    ),
  "Script 12D signature mapping counts disagree with Script 12E availability."
)

signature_expression <- human_expression[
  available_locked_genes,
  ,
  drop = FALSE
]

assert_true(
  identical(dim(signature_expression), c(22L, 50L)) &&
    identical(
      rownames(signature_expression),
      available_locked_genes
    ) &&
    identical(
      colnames(signature_expression),
      colnames(human_expression)
    ) &&
    sum(!is.finite(signature_expression)) == 0L,
  "Locked 22-gene ortholog expression matrix is malformed."
)

signature_source_index <- match(
  locked_24,
  human_row_annotation$human_symbol
)

locked_signature_audit <- data.frame(
  signature_order = seq_along(locked_24),
  locked_human_symbol = locked_24,
  Script12D_assayed_rat_ortholog_number =
    signature_mapping_counts,
  human_expression_available =
    human_expression_available,
  human_expression_row = ifelse(
    human_expression_available,
    human_row_index,
    NA_integer_
  ),
  human_gene_id = ifelse(
    human_expression_available,
    human_row_annotation$human_gene_id[
      signature_source_index
    ],
    ""
  ),
  source_rat_gene_id = ifelse(
    human_expression_available,
    human_row_annotation$source_rat_gene_id[
      signature_source_index
    ],
    ""
  ),
  source_rat_expression_symbol = ifelse(
    human_expression_available,
    human_row_annotation$source_rat_expression_symbol[
      signature_source_index
    ],
    ""
  ),
  expression_values_aggregated = FALSE,
  paralog_expression_combined = FALSE,
  included_in_locked_22gene_matrix =
    human_expression_available,
  included_in_Triclosan_score = FALSE,
  exclusion_reason = ifelse(
    human_expression_available,
    "",
    "NO_CURRENT_NCBI_AUDITED_ASSAYED_RAT_ORTHOLOG"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(locked_signature_audit) == 24L &&
    sum(
      locked_signature_audit$
        included_in_locked_22gene_matrix
    ) == 22L &&
    !any(
      locked_signature_audit$
        included_in_Triclosan_score
    ) &&
    !any(
      locked_signature_audit$
        paralog_expression_combined
    ) &&
    !any(
      locked_signature_audit$
        expression_values_aggregated
    ),
  "Locked signature audit violates the prespecified conversion policy."
)

# ------------------------------
# 7. Build integrity summaries
# ------------------------------
matrix_summary <- data.frame(
  item = c(
    "source_rat_gene_number",
    "source_sample_number",
    "audited_one_to_one_mapping_number",
    "human_ortholog_gene_number",
    "human_ortholog_sample_number",
    "unique_human_symbols",
    "unique_human_gene_ids",
    "unique_source_rat_symbols",
    "unique_source_rat_gene_ids",
    "nonfinite_human_expression_values",
    "sample_order_preserved",
    "expression_values_exactly_copied",
    "expression_values_aggregated",
    "expression_values_transformed",
    "expression_values_imputed",
    "locked_signature_gene_number",
    "locked_signature_available_gene_number",
    "locked_signature_missing_gene_number",
    "locked_signature_missing_genes",
    "ABCB1_paralog_expression_combined",
    "SCD_paralog_expression_combined",
    "Triclosan_score_calculated",
    "TCS_OIL_comparison_performed",
    "differential_expression_performed",
    "PCA_performed",
    "GSVA_or_GSEA_performed"
  ),
  value = c(
    nrow(rat_expression),
    ncol(rat_expression),
    nrow(expanded_pairs),
    nrow(human_expression),
    ncol(human_expression),
    length(unique(rownames(human_expression))),
    length(unique(human_gene_ids)),
    length(unique(rat_symbols)),
    length(unique(rat_gene_ids)),
    sum(!is.finite(human_expression)),
    identical(
      colnames(human_expression),
      as.character(design_table$sample_id)
    ),
    identical(
      as.numeric(human_expression),
      as.numeric(selected_rat_expression)
    ),
    FALSE,
    FALSE,
    FALSE,
    length(locked_24),
    nrow(signature_expression),
    length(missing_locked_genes),
    paste(missing_locked_genes, collapse = ";"),
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

integrity_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Script_build_ID",
    "Source_Script12C_bundle_MD5",
    "Source_Script12C_matrix_MD5",
    "Source_Script12D_bundle_MD5",
    "Source_Script12D_expanded_mapping_MD5",
    "Source_Script12D_signature_audit_MD5",
    "Source_Script12D_integrity_summary_MD5",
    "Source_Script12D_manifest_MD5",
    "Source_Script12D_report_MD5",
    "Source_rat_expression_dimensions",
    "Human_ortholog_expression_dimensions",
    "Human_ortholog_rows_created",
    "Human_ortholog_rows_with_aggregated_values",
    "Locked_signature_available_genes",
    "Locked_signature_missing_genes",
    "Locked_signature_missing_gene_symbols",
    "ABCB1_expression_row_created",
    "SCD_expression_row_created",
    "ABCB1_paralog_expression_combined",
    "SCD_paralog_expression_combined",
    "Expression_values_transformed",
    "Expression_values_imputed",
    "Samples_filtered",
    "Triclosan_score_calculated",
    "TCS_OIL_comparison_performed",
    "Differential_expression_performed",
    "PCA_performed",
    "GSVA_or_GSEA_performed",
    "Completion_status"
  ),
  value = c(
    "GSE95554",
    "12E",
    SCRIPT_BUILD_ID,
    observed_script12c_bundle_md5,
    observed_script12c_matrix_md5,
    observed_script12d_bundle_md5,
    observed_script12d_expanded_md5,
    observed_script12d_signature_md5,
    observed_script12d_integrity_md5,
    observed_script12d_manifest_md5,
    observed_script12d_report_md5,
    paste(dim(rat_expression), collapse = " x "),
    paste(dim(human_expression), collapse = " x "),
    nrow(human_expression),
    sum(human_row_annotation$expression_values_aggregated),
    nrow(signature_expression),
    length(missing_locked_genes),
    paste(missing_locked_genes, collapse = ";"),
    "ABCB1" %in% rownames(human_expression),
    "SCD" %in% rownames(human_expression),
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 8. Save staging outputs
# ------------------------------
input_manifest <- make_project_input_manifest(
  paths = required_inputs,
  labels = c(
    rep("Script12C", 4L),
    rep("Script12D", 6L)
  ),
  project_root = project_root
)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step3_GSE95554_real_exposure_validation",
  script = "Script12E",
  script_build_id = SCRIPT_BUILD_ID,
  created_at = format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  ),
  source_accession = "GSE95554",
  source_platform = "GPL17117",
  source_script12c_bundle_md5 =
    observed_script12c_bundle_md5,
  source_script12c_matrix_md5 =
    observed_script12c_matrix_md5,
  source_script12d_bundle_md5 =
    observed_script12d_bundle_md5,
  source_script12d_expanded_mapping_md5 =
    observed_script12d_expanded_md5,
  source_script12d_signature_audit_md5 =
    observed_script12d_signature_md5,
  design_table = design_table,
  human_ortholog_expression = human_expression,
  human_row_annotation = human_row_annotation,
  locked_signature_audit = locked_signature_audit,
  locked_signature_expression = signature_expression,
  matrix_summary = matrix_summary,
  integrity_summary = integrity_summary,
  policy = list(
    source_mapping =
      "Script12D_v5_NCBI_audited_one_to_one_only",
    direct_expression_row_copy = TRUE,
    human_symbol_used_as_matrix_rowname = TRUE,
    expression_values_aggregated = FALSE,
    expression_values_transformed = FALSE,
    expression_values_imputed = FALSE,
    samples_filtered = FALSE,
    ABCB1_paralog_expression_combined = FALSE,
    SCD_paralog_expression_combined = FALSE,
    locked_signature_missing_genes =
      missing_locked_genes,
    Triclosan_score_calculated = FALSE,
    TCS_OIL_comparison_performed = FALSE,
    differential_expression_performed = FALSE,
    PCA_performed = FALSE,
    GSVA_or_GSEA_performed = FALSE
  ),
  provenance = list(
    accepted_script12c_bundle_md5 =
      accepted_script12c_bundle_md5,
    accepted_script12c_matrix_md5 =
      accepted_script12c_matrix_md5,
    accepted_script12d_bundle_md5 =
      accepted_script12d_bundle_md5,
    expected_human_ortholog_gene_number = 15817L,
    expected_locked_signature_available_number = 22L,
    next_step_requires_review_of = c(
      "human ortholog matrix integrity",
      "locked 22-gene expression distributions",
      "prespecified TCS versus OIL comparisons within reproductive state"
    )
  )
)

class(complete_bundle) <- c(
  "GSE95554_human_ortholog_expression_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE95554_human_ortholog_expression_COMPLETE_bundle.rds"
)
stage_human_matrix_file <- file.path(
  stage_object_dir,
  "GSE95554_human_ortholog_expression_matrix.rds"
)
stage_signature_matrix_file <- file.path(
  stage_object_dir,
  "GSE95554_locked_22gene_ortholog_expression_matrix.rds"
)
stage_row_annotation_file <- file.path(
  stage_audit_dir,
  "GSE95554_human_ortholog_expression_row_annotation.csv"
)
stage_signature_audit_file <- file.path(
  stage_audit_dir,
  "GSE95554_locked_24gene_human_expression_availability.csv"
)
stage_signature_expression_csv <- file.path(
  stage_audit_dir,
  "GSE95554_locked_22gene_ortholog_expression_matrix.csv"
)
stage_design_file <- file.path(
  stage_audit_dir,
  "GSE95554_experimental_design_all50_preserved.csv"
)
stage_matrix_summary_file <- file.path(
  stage_audit_dir,
  "GSE95554_human_ortholog_expression_matrix_summary.csv"
)
stage_integrity_file <- file.path(
  stage_audit_dir,
  "GSE95554_human_ortholog_expression_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script12E_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script12E_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script12E_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script12E_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)
saveRDS(
  human_expression,
  stage_human_matrix_file,
  compress = "gzip"
)
saveRDS(
  signature_expression,
  stage_signature_matrix_file,
  compress = "gzip"
)

write_csv_utf8(
  human_row_annotation,
  stage_row_annotation_file
)
write_csv_utf8(
  locked_signature_audit,
  stage_signature_audit_file
)

signature_expression_csv <- data.frame(
  human_symbol = rownames(signature_expression),
  human_gene_id = human_row_annotation$human_gene_id[
    match(
      rownames(signature_expression),
      human_row_annotation$human_symbol
    )
  ],
  source_rat_expression_symbol =
    human_row_annotation$source_rat_expression_symbol[
      match(
        rownames(signature_expression),
        human_row_annotation$human_symbol
      )
    ],
  source_rat_gene_id =
    human_row_annotation$source_rat_gene_id[
      match(
        rownames(signature_expression),
        human_row_annotation$human_symbol
      )
    ],
  as.data.frame(
    signature_expression,
    stringsAsFactors = FALSE,
    check.names = FALSE
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

write_csv_utf8(
  signature_expression_csv,
  stage_signature_expression_csv
)
write_csv_utf8(
  design_table,
  stage_design_file
)
write_csv_utf8(
  matrix_summary,
  stage_matrix_summary_file
)
write_csv_utf8(
  integrity_summary,
  stage_integrity_file
)
write_csv_utf8(
  input_manifest,
  stage_input_manifest_file
)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# ------------------------------
# 9. Read-back validation before report/manifest
# ------------------------------
bundle_check <- readRDS(stage_bundle_file)
human_matrix_check <- readRDS(stage_human_matrix_file)
signature_matrix_check <- readRDS(
  stage_signature_matrix_file
)
row_annotation_check <- read.csv(
  stage_row_annotation_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
signature_audit_check <- read.csv(
  stage_signature_audit_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
signature_expression_csv_check <- read.csv(
  stage_signature_expression_csv,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "script_build_id",
      "design_table",
      "human_ortholog_expression",
      "human_row_annotation",
      "locked_signature_audit",
      "locked_signature_expression",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Saved Script 12E bundle is missing required fields."
)

assert_true(
  identical(
    as.character(bundle_check$script_build_id),
    SCRIPT_BUILD_ID
  ) &&
    identical(
      human_matrix_check,
      human_expression
    ) &&
    identical(
      signature_matrix_check,
      signature_expression
    ) &&
    identical(
      bundle_check$human_ortholog_expression,
      human_expression
    ) &&
    identical(
      bundle_check$locked_signature_expression,
      signature_expression
    ),
  "Saved Script 12E RDS objects changed during write/read-back."
)

assert_true(
  nrow(row_annotation_check) == 15817L &&
    nrow(signature_audit_check) == 24L &&
    nrow(signature_expression_csv_check) == 22L &&
    ncol(signature_expression_csv_check) == 54L,
  "Saved Script 12E CSV outputs have unexpected dimensions."
)

assert_true(
  isTRUE(
    bundle_check$policy$direct_expression_row_copy
  ) &&
    isFALSE(
      bundle_check$policy$expression_values_aggregated
    ) &&
    isFALSE(
      bundle_check$policy$ABCB1_paralog_expression_combined
    ) &&
    isFALSE(
      bundle_check$policy$SCD_paralog_expression_combined
    ) &&
    isFALSE(
      bundle_check$policy$Triclosan_score_calculated
    ) &&
    isFALSE(
      bundle_check$policy$TCS_OIL_comparison_performed
    ) &&
    isFALSE(
      bundle_check$policy$differential_expression_performed
    ) &&
    isFALSE(
      bundle_check$policy$PCA_performed
    ) &&
    isFALSE(
      bundle_check$policy$GSVA_or_GSEA_performed
    ),
  "Saved Script 12E policy incorrectly indicates prohibited analysis."
)

bundle_md5 <- md5_one(stage_bundle_file)
human_matrix_md5 <- md5_one(stage_human_matrix_file)
signature_matrix_md5 <- md5_one(
  stage_signature_matrix_file
)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 3 - Script 12E",
  "GSE95554 audited human-ortholog expression construction",
  paste0("Script build ID: ", SCRIPT_BUILD_ID),
  "============================================================",
  paste0(
    "Completion time: ",
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  ),
  paste0(
    "Source Script 12C bundle MD5: ",
    observed_script12c_bundle_md5
  ),
  paste0(
    "Source Script 12C matrix MD5: ",
    observed_script12c_matrix_md5
  ),
  paste0(
    "Source Script 12D bundle MD5: ",
    observed_script12d_bundle_md5
  ),
  paste0(
    "Source Script 12D expanded mapping MD5: ",
    observed_script12d_expanded_md5
  ),
  paste0(
    "Source rat expression matrix: ",
    nrow(rat_expression),
    " x ",
    ncol(rat_expression)
  ),
  paste0(
    "Audited one-to-one mapping rows: ",
    nrow(expanded_pairs)
  ),
  paste0(
    "Human ortholog expression matrix: ",
    nrow(human_expression),
    " x ",
    ncol(human_expression)
  ),
  paste0(
    "Expression values exactly copied: ",
    identical(
      as.numeric(human_expression),
      as.numeric(selected_rat_expression)
    )
  ),
  paste0(
    "Sample order preserved: ",
    identical(
      colnames(human_expression),
      as.character(design_table$sample_id)
    )
  ),
  paste0(
    "Locked signature genes with expression: ",
    nrow(signature_expression),
    " / 24"
  ),
  paste0(
    "Locked signature genes without expression: ",
    paste(missing_locked_genes, collapse = ";")
  ),
  "Expression values aggregated: FALSE",
  "Expression values transformed: FALSE",
  "Expression values imputed: FALSE",
  "Samples filtered: FALSE",
  "ABCB1 paralog expression combined: FALSE",
  "SCD paralog expression combined: FALSE",
  "Triclosan score calculated: FALSE",
  "TCS/OIL comparison performed: FALSE",
  "Differential expression performed: FALSE",
  "PCA performed: FALSE",
  "GSVA/GSEA performed: FALSE",
  paste0("Human matrix MD5: ", human_matrix_md5),
  paste0(
    "Locked 22-gene matrix MD5: ",
    signature_matrix_md5
  ),
  paste0("Script 12E bundle MD5: ", bundle_md5),
  "",
  "SCRIPT12E STATUS: COMPLETE",
  paste0(
    "A 15,817 x 50 human-ortholog matrix and a locked 22-gene subset were ",
    "constructed by direct value-preserving one-to-one mapping only."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(report_lines),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_human_matrix_file,
  stage_signature_matrix_file,
  stage_row_annotation_file,
  stage_signature_audit_file,
  stage_signature_expression_csv,
  stage_design_file,
  stage_matrix_summary_file,
  stage_integrity_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)) &&
    all(file.info(output_files_before_manifest)$size > 0),
  "At least one staged Script 12E output is missing or empty."
)

output_manifest <- make_relative_output_manifest(
  output_files_before_manifest,
  stage_root
)

write_csv_utf8(
  output_manifest,
  stage_output_manifest_file
)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) ==
    length(output_files_before_manifest) &&
    all(c(
      "file_name",
      "relative_path",
      "size_bytes",
      "md5"
    ) %in% colnames(manifest_check)) &&
    anyDuplicated(manifest_check$relative_path) == 0L &&
    !any(
      grepl(
        "Script12E_staging",
        manifest_check$relative_path,
        fixed = TRUE
      )
    ) &&
    !any(
      grepl(
        "^[A-Za-z]:",
        manifest_check$relative_path
      )
    ),
  "Script 12E relative-path output manifest is malformed."
)

for (i in seq_len(nrow(manifest_check))) {
  file_i <- file.path(
    stage_root,
    manifest_check$relative_path[i]
  )

  assert_true(
    file.exists(file_i) &&
      as.numeric(file.info(file_i)$size) ==
        as.numeric(manifest_check$size_bytes[i]) &&
      identical(
        tolower(md5_one(file_i)),
        tolower(as.character(manifest_check$md5[i]))
      ),
    paste0(
      "Staged output manifest verification failed for ",
      manifest_check$relative_path[i],
      "."
    )
  )
}

# ------------------------------
# 10. Commit staging directory and verify final files
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 12E directory appeared during staging."
)

rename_ok <- file.rename(
  stage_root,
  final_root
)

if (!isTRUE(rename_ok)) {
  dir.create(
    final_root,
    recursive = TRUE,
    showWarnings = FALSE
  )

  staged_entries <- list.files(
    stage_root,
    full.names = TRUE,
    all.files = FALSE
  )

  copied <- file.copy(
    from = staged_entries,
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    length(copied) == length(staged_entries) &&
      all(copied),
    "Unable to commit Script 12E staging directory."
  )

  unlink(
    stage_root,
    recursive = TRUE,
    force = TRUE
  )
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  basename(stage_bundle_file)
)
final_human_matrix_file <- file.path(
  final_root,
  "objects",
  basename(stage_human_matrix_file)
)
final_signature_matrix_file <- file.path(
  final_root,
  "objects",
  basename(stage_signature_matrix_file)
)
final_report_file <- file.path(
  final_root,
  "logs",
  basename(stage_report_file)
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  basename(stage_output_manifest_file)
)

assert_true(
  all(file.exists(c(
    final_bundle_file,
    final_human_matrix_file,
    final_signature_matrix_file,
    final_report_file,
    final_manifest_file
  ))),
  "Committed Script 12E output is incomplete."
)

assert_true(
  identical(md5_one(final_bundle_file), bundle_md5) &&
    identical(
      md5_one(final_human_matrix_file),
      human_matrix_md5
    ) &&
    identical(
      md5_one(final_signature_matrix_file),
      signature_matrix_md5
    ),
  "A committed Script 12E RDS MD5 changed after commit."
)

assert_true(
  report_contains(
    final_report_file,
    "SCRIPT12E STATUS: COMPLETE"
  ),
  "Committed Script 12E report is not marked COMPLETE."
)

verify_committed_manifest(
  final_manifest_file,
  final_root
)

cat("============================================================\n")
cat("Script 12E completed successfully.\n")
cat(
  "Human ortholog expression matrix: ",
  nrow(human_expression),
  " x ",
  ncol(human_expression),
  "\n",
  sep = ""
)
cat(
  "Locked signature expression matrix: ",
  nrow(signature_expression),
  " x ",
  ncol(signature_expression),
  "\n",
  sep = ""
)
cat(
  "Explicitly absent locked genes: ",
  paste(missing_locked_genes, collapse = ";"),
  "\n",
  sep = ""
)
cat("Expression aggregation performed: FALSE\n")
cat("Triclosan score calculated: FALSE\n")
cat("TCS/OIL comparison performed: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

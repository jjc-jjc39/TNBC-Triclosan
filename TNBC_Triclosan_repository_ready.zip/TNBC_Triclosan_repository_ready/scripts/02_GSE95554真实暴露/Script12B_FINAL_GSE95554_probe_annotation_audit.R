# ==============================================================================
# TNBC_Triclosan
# Step 3 - GSE95554 real Triclosan exposure validation
# Script 12B FINAL
#
# Purpose:
#   Continue strictly from the accepted Script 12A GSE95554 preflight bundle.
#   Audit transcript-cluster annotation for GPL17117 before any feature
#   filtering, gene-level aggregation, differential-expression or pathway
#   analysis.
#
# Annotation sources:
#   1) Primary:
#      Bioconductor chip annotation package
#      ragene20sttranscriptcluster.db queried through AnnotationDbi.
#
#   2) Independent audit/fallback:
#      GEO GPL17117 annotated platform table downloaded with GEOquery.
#
# This script DOES:
#   - verify the accepted Script 12A bundle by report, manifest and fixed MD5;
#   - verify the 36,685 x 50 processed expression matrix and sample design;
#   - install missing official Bioconductor annotation packages when possible;
#   - query transcript-cluster IDs for rat SYMBOL, ENTREZID and GENENAME;
#   - download and preserve the GEO GPL17117 annotation table;
#   - audit mapping coverage, one-to-many mappings and source concordance;
#   - audit exact coverage of the prespecified 24-gene Triclosan signature;
#   - save source tables, RDS bundle, CSV audits, MD5 manifests and sessionInfo.
#
# This script DOES NOT:
#   - alter, normalize, log-transform or filter expression values;
#   - discard unmapped or multi-mapped features;
#   - aggregate transcript clusters to genes;
#   - perform PCA, DEG, GSEA, GSVA or cross-species ortholog mapping;
#   - compare TCS with OIL;
#   - choose mapping rules based on biological results.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
options(timeout = max(1200L, getOption("timeout")))
Sys.setenv(TZ = "Asia/Singapore")

SCRIPT_BUILD_ID <- "Script12B_FINAL_20260710"

cat("============================================================\n")
cat("RUNNING: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat("Bioconductor transcript-cluster annotation audit: ENABLED\n")
cat("GEO GPL17117 annotation cross-check: ENABLED\n")
cat("Expression modification and gene aggregation: DISABLED\n")
cat("Differential expression and pathway analysis: DISABLED\n")
cat("============================================================\n")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step3_GSE95554_real_exposure_validation"
)

input_root <- file.path(
  step_root,
  "00_preflight"
)
final_root <- file.path(
  step_root,
  "01_probe_annotation_audit"
)

input_bundle_file <- file.path(
  input_root,
  "objects",
  "GSE95554_preflight_COMPLETE_bundle.rds"
)
input_manifest_file <- file.path(
  input_root,
  "audit",
  "Script12A_output_manifest_with_MD5.csv"
)
input_report_file <- file.path(
  input_root,
  "logs",
  "Script12A_COMPLETE_report.txt"
)
input_summary_file <- file.path(
  input_root,
  "audit",
  "GSE95554_preflight_integrity_summary.csv"
)

required_inputs <- c(
  input_bundle_file,
  input_manifest_file,
  input_report_file,
  input_summary_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 12B cannot start because required accepted Script 12A files ",
      "are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop(
    paste0(
      "Step 3 directory does not exist:\n",
      step_root
    ),
    call. = FALSE
  )
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(
      final_root,
      all.files = TRUE
    ),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(
      final_root,
      recursive = TRUE,
      force = TRUE
    )
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 12B will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive that directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(
  Sys.time(),
  "%Y%m%d_%H%M%S"
)

stage_root <- file.path(
  step_root,
  paste0(
    ".Script12B_staging_",
    stamp,
    "_",
    Sys.getpid()
  )
)
stage_download_dir <- file.path(
  stage_root,
  "downloads"
)
stage_object_dir <- file.path(
  stage_root,
  "objects"
)
stage_audit_dir <- file.path(
  stage_root,
  "audit"
)
stage_log_dir <- file.path(
  stage_root,
  "logs"
)

for (directory_i in c(
  stage_download_dir,
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)) {
  dir.create(
    directory_i,
    recursive = TRUE,
    showWarnings = FALSE
  )
}

if (!all(dir.exists(c(
  stage_download_dir,
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop(
    "Unable to create Script 12B staging directories.",
    call. = FALSE
  )
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(
      stage_root,
      recursive = TRUE,
      force = TRUE
    )
  }
}, add = TRUE)

# ------------------------------
# 1. General helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) {
    stop(
      message,
      call. = FALSE
    )
  }
}

md5_one <- function(path) {
  unname(
    tools::md5sum(path)
  )
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(
    report_file,
    warn = FALSE,
    encoding = "UTF-8"
  )

  any(
    grepl(
      fixed_text,
      lines,
      fixed = TRUE
    )
  )
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(
    length(paths) == length(displayed_paths)
  )

  if (length(paths) == 0L) {
    return(data.frame(
      file_name = character(0),
      relative_path = character(0),
      absolute_path = character(0),
      size_bytes = numeric(0),
      md5 = character(0),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ))
  }

  stage_normalized <- normalizePath(
    stage_root,
    winslash = "/",
    mustWork = TRUE
  )

  info <- file.info(paths)

  relative_paths <- vapply(
    displayed_paths,
    function(path_i) {
      normalized_i <- normalizePath(
        path_i,
        winslash = "/",
        mustWork = FALSE
      )

      prefix_i <- paste0(
        stage_normalized,
        "/"
      )

      if (startsWith(normalized_i, prefix_i)) {
        substring(
          normalized_i,
          nchar(prefix_i) + 1L
        )
      } else {
        basename(normalized_i)
      }
    },
    character(1)
  )

  data.frame(
    file_name = basename(displayed_paths),
    relative_path = relative_paths,
    absolute_path = vapply(
      displayed_paths,
      function(path_i) {
        normalizePath(
          path_i,
          winslash = "/",
          mustWork = FALSE
        )
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(
      paths,
      md5_one,
      character(1)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(
  manifest_file,
  target_file
) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c(
      "file_name",
      "size_bytes",
      "md5"
    ) %in% colnames(manifest)),
    paste0(
      "Malformed output manifest:\n",
      manifest_file
    )
  )

  row_index <- which(
    manifest$file_name ==
      basename(target_file)
  )

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file),
      "."
    )
  )

  tolower(
    trimws(
      as.character(
        manifest$md5[row_index]
      )
    )
  )
}

capture_warnings <- function(expression) {
  warning_messages <- character(0)

  value <- withCallingHandlers(
    expression,
    warning = function(w) {
      warning_messages <<- c(
        warning_messages,
        conditionMessage(w)
      )
      invokeRestart("muffleWarning")
    }
  )

  list(
    value = value,
    warnings = unique(warning_messages)
  )
}

collapse_messages <- function(x) {
  x <- unique(
    trimws(
      as.character(x)
    )
  )
  x <- x[
    !is.na(x) &
      nzchar(x)
  ]

  if (length(x) == 0L) {
    ""
  } else {
    paste(
      x,
      collapse = " | "
    )
  }
}

clean_text <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  trimws(x)
}

clean_annotation_value <- function(x) {
  x <- clean_text(x)

  x[
    x %in% c(
      "---",
      "NA",
      "N/A",
      "null",
      "NULL"
    )
  ] <- ""

  x
}

distinct_sorted_values <- function(x) {
  x <- clean_annotation_value(x)
  x <- x[nzchar(x)]

  if (length(x) == 0L) {
    character(0)
  } else {
    sort(unique(x))
  }
}

collapse_distinct <- function(x) {
  values <- distinct_sorted_values(x)

  if (length(values) == 0L) {
    ""
  } else {
    paste(
      values,
      collapse = ";"
    )
  }
}

count_distinct <- function(x) {
  length(
    distinct_sorted_values(x)
  )
}

select_first_column <- function(
  column_names,
  exact_candidates = character(0),
  regex_candidates = character(0),
  required = FALSE
) {
  lower_names <- tolower(
    column_names
  )

  for (candidate_i in exact_candidates) {
    match_i <- which(
      lower_names ==
        tolower(candidate_i)
    )

    if (length(match_i) > 0L) {
      return(
        column_names[
          match_i[1]
        ]
      )
    }
  }

  for (pattern_i in regex_candidates) {
    match_i <- grep(
      pattern_i,
      lower_names,
      perl = TRUE
    )

    if (length(match_i) > 0L) {
      return(
        column_names[
          match_i[1]
        ]
      )
    }
  }

  if (required) {
    stop(
      paste0(
        "Unable to identify a required annotation column.\n",
        "Available columns: ",
        paste(
          column_names,
          collapse = ";"
        )
      ),
      call. = FALSE
    )
  }

  NA_character_
}

split_annotation_tokens <- function(x) {
  x <- clean_annotation_value(x)

  if (!nzchar(x)) {
    return(character(0))
  }

  tokens <- unlist(
    strsplit(
      x,
      split = "\\s*(?:///|//|;|\\|)\\s*",
      perl = TRUE
    ),
    use.names = FALSE
  )

  tokens <- clean_annotation_value(tokens)
  tokens <- tokens[nzchar(tokens)]
  unique(tokens)
}

install_bioconductor_packages <- function(packages) {
  packages <- unique(
    as.character(packages)
  )

  packages <- packages[
    nzchar(packages)
  ]

  if (length(packages) == 0L) {
    return(data.frame(
      package = character(0),
      needed_installation = logical(0),
      installation_attempted = logical(0),
      installation_succeeded = logical(0),
      error_message = character(0),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ))
  }

  result_rows <- vector(
    "list",
    length(packages)
  )

  if (
    !requireNamespace(
      "BiocManager",
      quietly = TRUE
    )
  ) {
    install.packages(
      "BiocManager",
      repos = "https://cloud.r-project.org",
      dependencies = TRUE
    )
  }

  assert_true(
    requireNamespace(
      "BiocManager",
      quietly = TRUE
    ),
    paste0(
      "BiocManager is unavailable, so required annotation packages cannot ",
      "be installed automatically."
    )
  )

  for (i in seq_along(packages)) {
    package_i <- packages[i]
    already_available <- requireNamespace(
      package_i,
      quietly = TRUE
    )
    install_error <- ""
    attempted <- FALSE

    if (!already_available) {
      attempted <- TRUE

      tryCatch(
        BiocManager::install(
          package_i,
          ask = FALSE,
          update = FALSE,
          dependencies = TRUE
        ),
        error = function(e) {
          install_error <<- conditionMessage(e)
        }
      )
    }

    succeeded <- requireNamespace(
      package_i,
      quietly = TRUE
    )

    result_rows[[i]] <- data.frame(
      package = package_i,
      needed_installation = !already_available,
      installation_attempted = attempted,
      installation_succeeded = succeeded,
      error_message = install_error,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  result <- do.call(
    rbind,
    result_rows
  )
  rownames(result) <- NULL
  result
}

# ------------------------------
# 2. Verify accepted Script 12A identity
# ------------------------------
assert_true(
  report_contains(
    input_report_file,
    "SCRIPT12A STATUS: COMPLETE"
  ),
  "Script 12A completion marker was not found."
)

assert_true(
  report_contains(
    input_report_file,
    "Script build ID: Script12A_FINAL_20260710"
  ),
  "The Script 12A report is not from the accepted FINAL build."
)

expected_bundle_md5 <- manifest_expected_md5(
  input_manifest_file,
  input_bundle_file
)
observed_bundle_md5 <- tolower(
  md5_one(input_bundle_file)
)

assert_true(
  identical(
    expected_bundle_md5,
    observed_bundle_md5
  ),
  paste0(
    "Script 12A bundle MD5 differs from its manifest.\n",
    "Expected: ",
    expected_bundle_md5,
    "\nObserved: ",
    observed_bundle_md5
  )
)

accepted_script12a_bundle_md5 <-
  "ad2d27f5ba68419461aae01b3a7153c3"

assert_true(
  identical(
    observed_bundle_md5,
    accepted_script12a_bundle_md5
  ),
  paste0(
    "Script 12A bundle differs from the independently accepted bundle.\n",
    "Expected: ",
    accepted_script12a_bundle_md5,
    "\nObserved: ",
    observed_bundle_md5
  )
)

input_summary <- read.csv(
  input_summary_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(c(
    "item",
    "value"
  ) %in% colnames(input_summary)),
  "Script 12A integrity summary is malformed."
)

assert_true(
  anyDuplicated(
    input_summary$item
  ) == 0L,
  "Script 12A integrity summary contains duplicated items."
)

input_lookup <- setNames(
  as.character(
    input_summary$value
  ),
  input_summary$item
)

required_summary_items <- c(
  "Platform_selected",
  "Expression_feature_number",
  "Expression_sample_number",
  "Exposure_by_state_group_number",
  "Every_group_has_five_animals",
  "Nonfinite_expression_values",
  "Expression_values_modified",
  "Differential_expression_performed",
  "Completion_status"
)

assert_true(
  all(
    required_summary_items %in%
      names(input_lookup)
  ),
  "Script 12A integrity summary is missing required items."
)

assert_true(
  identical(
    input_lookup[["Completion_status"]],
    "COMPLETE"
  ),
  "Script 12A integrity summary is not marked COMPLETE."
)

# ------------------------------
# 3. Read and validate accepted Script 12A bundle
# ------------------------------
source_bundle <- readRDS(
  input_bundle_file
)

required_bundle_fields <- c(
  "script",
  "script_build_id",
  "source_accession",
  "source_platform",
  "source_organism",
  "expression_matrix",
  "phenotype_raw",
  "feature_data_raw",
  "design_table",
  "group_count_table",
  "integrity_summary",
  "policy"
)

assert_true(
  is.list(source_bundle) &&
    all(
      required_bundle_fields %in%
        names(source_bundle)
    ),
  "Script 12A bundle is missing required fields."
)

assert_true(
  identical(
    as.character(
      source_bundle$script
    ),
    "Script12A"
  ),
  "Input bundle was not created by Script 12A."
)

assert_true(
  identical(
    as.character(
      source_bundle$script_build_id
    ),
    "Script12A_FINAL_20260710"
  ),
  "Input bundle is not from Script 12A FINAL."
)

assert_true(
  identical(
    as.character(
      source_bundle$source_accession
    ),
    "GSE95554"
  ),
  "Input bundle is not for GSE95554."
)

assert_true(
  identical(
    as.character(
      source_bundle$source_platform
    ),
    "GPL17117"
  ),
  "Input bundle is not for GPL17117."
)

expression_matrix <- source_bundle$expression_matrix
feature_data_raw <- source_bundle$feature_data_raw
design_table <- source_bundle$design_table

assert_true(
  is.matrix(expression_matrix) &&
    is.numeric(expression_matrix) &&
    identical(
      dim(expression_matrix),
      c(36685L, 50L)
    ),
  paste0(
    "Expected a 36,685 x 50 expression matrix, detected ",
    paste(
      dim(expression_matrix),
      collapse = " x "
    ),
    "."
  )
)

assert_true(
  sum(!is.finite(expression_matrix)) == 0L,
  "The accepted expression matrix contains non-finite values."
)

assert_true(
  !is.null(
    rownames(expression_matrix)
  ) &&
    anyDuplicated(
      rownames(expression_matrix)
    ) == 0L &&
    all(
      nzchar(
        rownames(expression_matrix)
      )
    ),
  "Expression transcript-cluster IDs are missing, blank or duplicated."
)

assert_true(
  is.data.frame(design_table) &&
    nrow(design_table) == 50L &&
    "sample_id" %in%
      colnames(design_table),
  "The accepted design table is malformed."
)

assert_true(
  identical(
    colnames(expression_matrix),
    as.character(
      design_table$sample_id
    )
  ),
  "Expression columns and design rows are not identically ordered."
)

assert_true(
  is.data.frame(feature_data_raw) &&
    nrow(feature_data_raw) ==
      nrow(expression_matrix),
  "The accepted feature-data table has an unexpected row count."
)

feature_ids <- as.character(
  rownames(expression_matrix)
)

assert_true(
  all(
    grepl(
      "^[0-9]+$",
      feature_ids
    )
  ),
  "At least one GPL17117 feature ID is not numeric."
)

# ------------------------------
# 4. Inspect embedded feature-data columns
# ------------------------------
embedded_feature_audit <- data.frame(
  column_order = seq_len(
    ncol(feature_data_raw)
  ),
  column_name = colnames(
    feature_data_raw
  ),
  nonmissing_number = vapply(
    feature_data_raw,
    function(column_i) {
      values_i <- clean_annotation_value(
        column_i
      )
      sum(
        nzchar(values_i)
      )
    },
    integer(1)
  ),
  unique_nonmissing_number = vapply(
    feature_data_raw,
    function(column_i) {
      values_i <- clean_annotation_value(
        column_i
      )
      length(
        unique(
          values_i[
            nzchar(values_i)
          ]
        )
      )
    },
    integer(1)
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 5. Install/query Bioconductor chip annotation
# ------------------------------
required_annotation_packages <- c(
  "AnnotationDbi",
  "ragene20sttranscriptcluster.db"
)

installation_audit <- install_bioconductor_packages(
  required_annotation_packages
)

chip_packages_ready <- all(
  vapply(
    required_annotation_packages,
    requireNamespace,
    logical(1),
    quietly = TRUE
  )
)

assert_true(
  chip_packages_ready,
  paste0(
    "Required Bioconductor annotation packages are unavailable after the ",
    "automatic installation attempt.\n",
    paste(
      apply(
        installation_audit,
        1L,
        function(row_i) {
          paste(
            row_i,
            collapse = " | "
          )
        }
      ),
      collapse = "\n"
    )
  )
)

chip_db <- tryCatch(
  getExportedValue(
    "ragene20sttranscriptcluster.db",
    "ragene20sttranscriptcluster.db"
  ),
  error = function(e) {
    get(
      "ragene20sttranscriptcluster.db",
      envir = asNamespace(
        "ragene20sttranscriptcluster.db"
      ),
      inherits = FALSE
    )
  }
)

assert_true(
  inherits(
    chip_db,
    "AnnotationDb"
  ),
  "Unable to obtain the ragene20sttranscriptcluster.db AnnotationDb object."
)

available_keytypes <- AnnotationDbi::keytypes(
  chip_db
)
available_columns <- AnnotationDbi::columns(
  chip_db
)

assert_true(
  "PROBEID" %in%
    available_keytypes,
  paste0(
    "PROBEID is not available as a key type in ",
    "ragene20sttranscriptcluster.db."
  )
)

requested_chip_columns <- intersect(
  c(
    "PROBEID",
    "SYMBOL",
    "ENTREZID",
    "GENENAME",
    "ENSEMBL",
    "REFSEQ"
  ),
  available_columns
)

assert_true(
  all(c(
    "PROBEID",
    "SYMBOL",
    "ENTREZID"
  ) %in% requested_chip_columns),
  paste0(
    "The chip annotation package lacks one or more required columns: ",
    "PROBEID, SYMBOL, ENTREZID."
  )
)

chip_select_result <- capture_warnings(
  AnnotationDbi::select(
    chip_db,
    keys = feature_ids,
    keytype = "PROBEID",
    columns = setdiff(
      requested_chip_columns,
      "PROBEID"
    )
  )
)

chip_long <- chip_select_result$value
chip_select_warnings <- chip_select_result$warnings

assert_true(
  is.data.frame(chip_long) &&
    "PROBEID" %in%
      colnames(chip_long),
  "AnnotationDbi::select did not return a valid PROBEID table."
)

chip_long$PROBEID <- as.character(
  chip_long$PROBEID
)

for (column_i in setdiff(
  colnames(chip_long),
  "PROBEID"
)) {
  chip_long[[column_i]] <- clean_annotation_value(
    chip_long[[column_i]]
  )
}

chip_long <- chip_long[
  chip_long$PROBEID %in%
    feature_ids,
  ,
  drop = FALSE
]

chip_annotation_rows <- vector(
  "list",
  length(feature_ids)
)

for (i in seq_along(feature_ids)) {
  feature_i <- feature_ids[i]
  rows_i <- chip_long[
    chip_long$PROBEID == feature_i,
    ,
    drop = FALSE
  ]

  symbols_i <- if (
    "SYMBOL" %in% colnames(rows_i)
  ) {
    distinct_sorted_values(
      rows_i$SYMBOL
    )
  } else {
    character(0)
  }

  entrez_i <- if (
    "ENTREZID" %in% colnames(rows_i)
  ) {
    distinct_sorted_values(
      rows_i$ENTREZID
    )
  } else {
    character(0)
  }

  gene_names_i <- if (
    "GENENAME" %in% colnames(rows_i)
  ) {
    distinct_sorted_values(
      rows_i$GENENAME
    )
  } else {
    character(0)
  }

  ensembl_i <- if (
    "ENSEMBL" %in% colnames(rows_i)
  ) {
    distinct_sorted_values(
      rows_i$ENSEMBL
    )
  } else {
    character(0)
  }

  refseq_i <- if (
    "REFSEQ" %in% colnames(rows_i)
  ) {
    distinct_sorted_values(
      rows_i$REFSEQ
    )
  } else {
    character(0)
  }

  chip_annotation_rows[[i]] <- data.frame(
    feature_order = i,
    transcript_cluster_id = feature_i,
    chip_symbol_count = length(symbols_i),
    chip_symbols = if (
      length(symbols_i) == 0L
    ) {
      ""
    } else {
      paste(
        symbols_i,
        collapse = ";"
      )
    },
    chip_entrez_count = length(entrez_i),
    chip_entrez_ids = if (
      length(entrez_i) == 0L
    ) {
      ""
    } else {
      paste(
        entrez_i,
        collapse = ";"
      )
    },
    chip_gene_name_count = length(gene_names_i),
    chip_gene_names = if (
      length(gene_names_i) == 0L
    ) {
      ""
    } else {
      paste(
        gene_names_i,
        collapse = ";"
      )
    },
    chip_ensembl_count = length(ensembl_i),
    chip_ensembl_ids = if (
      length(ensembl_i) == 0L
    ) {
      ""
    } else {
      paste(
        ensembl_i,
        collapse = ";"
      )
    },
    chip_refseq_count = length(refseq_i),
    chip_refseq_ids = if (
      length(refseq_i) == 0L
    ) {
      ""
    } else {
      paste(
        refseq_i,
        collapse = ";"
      )
    },
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

chip_annotation_audit <- do.call(
  rbind,
  chip_annotation_rows
)
rownames(chip_annotation_audit) <- NULL

assert_true(
  nrow(chip_annotation_audit) ==
    length(feature_ids) &&
    identical(
      chip_annotation_audit$
        transcript_cluster_id,
      feature_ids
    ),
  "Chip annotation audit is not aligned to all 36,685 expression features."
)

# ------------------------------
# 6. Download/query GEO GPL17117 annotation
# ------------------------------
gpl_download_audit <- data.frame(
  attempt = integer(0),
  start_time = character(0),
  end_time = character(0),
  succeeded = logical(0),
  warning_messages = character(0),
  error_message = character(0),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

gpl_object <- NULL
last_gpl_error <- ""

for (attempt_i in seq_len(3L)) {
  start_i <- format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  )
  warning_i <- character(0)
  error_i <- ""

  result_i <- tryCatch(
    withCallingHandlers(
      GEOquery::getGEO(
        GEO = "GPL17117",
        AnnotGPL = TRUE,
        destdir = stage_download_dir
      ),
      warning = function(w) {
        warning_i <<- c(
          warning_i,
          conditionMessage(w)
        )
        invokeRestart(
          "muffleWarning"
        )
      }
    ),
    error = function(e) {
      error_i <<- conditionMessage(e)
      NULL
    }
  )

  success_i <- !is.null(result_i)

  gpl_download_audit <- rbind(
    gpl_download_audit,
    data.frame(
      attempt = attempt_i,
      start_time = start_i,
      end_time = format(
        Sys.time(),
        "%Y-%m-%d %H:%M:%S %Z"
      ),
      succeeded = success_i,
      warning_messages = collapse_messages(
        warning_i
      ),
      error_message = error_i,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  if (success_i) {
    gpl_object <- result_i
    break
  }

  last_gpl_error <- error_i

  if (attempt_i < 3L) {
    Sys.sleep(
      2L * attempt_i
    )
  }
}

assert_true(
  !is.null(gpl_object),
  paste0(
    "Unable to download GPL17117 annotation after three attempts.\n",
    "Last error: ",
    last_gpl_error
  )
)

assert_true(
  inherits(
    gpl_object,
    "GPL"
  ),
  "GEOquery did not return a GPL object for GPL17117."
)

gpl_table <- GEOquery::Table(
  gpl_object
)

assert_true(
  is.data.frame(gpl_table) &&
    nrow(gpl_table) > 10000L &&
    ncol(gpl_table) >= 2L,
  "The GPL17117 annotation table is unexpectedly small or malformed."
)

gpl_column_audit <- data.frame(
  column_order = seq_len(
    ncol(gpl_table)
  ),
  column_name = colnames(
    gpl_table
  ),
  nonmissing_number = vapply(
    gpl_table,
    function(column_i) {
      values_i <- clean_annotation_value(
        column_i
      )
      sum(
        nzchar(values_i)
      )
    },
    integer(1)
  ),
  unique_nonmissing_number = vapply(
    gpl_table,
    function(column_i) {
      values_i <- clean_annotation_value(
        column_i
      )
      length(
        unique(
          values_i[
            nzchar(values_i)
          ]
        )
      )
    },
    integer(1)
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

gpl_id_column <- select_first_column(
  colnames(gpl_table),
  exact_candidates = c(
    "ID",
    "ID_REF",
    "Probe Set ID",
    "PROBEID"
  ),
  regex_candidates = c(
    "^id$",
    "probe.*id",
    "transcript.*cluster"
  ),
  required = TRUE
)

gpl_symbol_column <- select_first_column(
  colnames(gpl_table),
  exact_candidates = c(
    "Gene symbol",
    "Gene Symbol",
    "GENE_SYMBOL",
    "SYMBOL"
  ),
  regex_candidates = c(
    "gene.*symbol",
    "(^|_)symbol($|_)"
  ),
  required = FALSE
)

gpl_entrez_column <- select_first_column(
  colnames(gpl_table),
  exact_candidates = c(
    "Gene ID",
    "ENTREZ_GENE_ID",
    "ENTREZID"
  ),
  regex_candidates = c(
    "entrez",
    "^gene.?id$"
  ),
  required = FALSE
)

gpl_title_column <- select_first_column(
  colnames(gpl_table),
  exact_candidates = c(
    "Gene title",
    "Gene Title",
    "GENE_TITLE",
    "Gene name",
    "GENENAME"
  ),
  regex_candidates = c(
    "gene.*title",
    "gene.*name"
  ),
  required = FALSE
)

gpl_ids <- clean_text(
  gpl_table[[gpl_id_column]]
)

assert_true(
  any(
    gpl_ids %in%
      feature_ids
  ),
  "No GPL17117 annotation IDs matched the expression feature IDs."
)

gpl_annotation_rows <- vector(
  "list",
  length(feature_ids)
)

for (i in seq_along(feature_ids)) {
  feature_i <- feature_ids[i]
  row_index <- which(
    gpl_ids == feature_i
  )

  symbol_tokens <- character(0)
  entrez_tokens <- character(0)
  title_tokens <- character(0)

  if (
    length(row_index) > 0L &&
      !is.na(gpl_symbol_column)
  ) {
    symbol_tokens <- unique(
      unlist(
        lapply(
          gpl_table[
            row_index,
            gpl_symbol_column,
            drop = TRUE
          ],
          split_annotation_tokens
        ),
        use.names = FALSE
      )
    )
  }

  if (
    length(row_index) > 0L &&
      !is.na(gpl_entrez_column)
  ) {
    entrez_tokens <- unique(
      unlist(
        lapply(
          gpl_table[
            row_index,
            gpl_entrez_column,
            drop = TRUE
          ],
          split_annotation_tokens
        ),
        use.names = FALSE
      )
    )
  }

  if (
    length(row_index) > 0L &&
      !is.na(gpl_title_column)
  ) {
    title_tokens <- unique(
      unlist(
        lapply(
          gpl_table[
            row_index,
            gpl_title_column,
            drop = TRUE
          ],
          split_annotation_tokens
        ),
        use.names = FALSE
      )
    )
  }

  symbol_tokens <- distinct_sorted_values(
    symbol_tokens
  )
  entrez_tokens <- distinct_sorted_values(
    entrez_tokens
  )
  title_tokens <- distinct_sorted_values(
    title_tokens
  )

  gpl_annotation_rows[[i]] <- data.frame(
    feature_order = i,
    transcript_cluster_id = feature_i,
    gpl_matching_row_number = length(
      row_index
    ),
    gpl_symbol_count = length(
      symbol_tokens
    ),
    gpl_symbols = if (
      length(symbol_tokens) == 0L
    ) {
      ""
    } else {
      paste(
        symbol_tokens,
        collapse = ";"
      )
    },
    gpl_entrez_count = length(
      entrez_tokens
    ),
    gpl_entrez_ids = if (
      length(entrez_tokens) == 0L
    ) {
      ""
    } else {
      paste(
        entrez_tokens,
        collapse = ";"
      )
    },
    gpl_gene_title_count = length(
      title_tokens
    ),
    gpl_gene_titles = if (
      length(title_tokens) == 0L
    ) {
      ""
    } else {
      paste(
        title_tokens,
        collapse = ";"
      )
    },
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

gpl_annotation_audit <- do.call(
  rbind,
  gpl_annotation_rows
)
rownames(gpl_annotation_audit) <- NULL

assert_true(
  nrow(gpl_annotation_audit) ==
    length(feature_ids) &&
    identical(
      gpl_annotation_audit$
        transcript_cluster_id,
      feature_ids
    ),
  "GPL annotation audit is not aligned to all expression features."
)

# ------------------------------
# 7. Build source-concordance audit
# ------------------------------
annotation_concordance <- merge(
  chip_annotation_audit,
  gpl_annotation_audit,
  by = c(
    "feature_order",
    "transcript_cluster_id"
  ),
  sort = FALSE,
  all = TRUE
)

annotation_concordance <- annotation_concordance[
  order(
    annotation_concordance$feature_order
  ),
  ,
  drop = FALSE
]

rownames(annotation_concordance) <- NULL

assert_true(
  nrow(annotation_concordance) ==
    length(feature_ids) &&
    identical(
      annotation_concordance$
        transcript_cluster_id,
      feature_ids
    ),
  "Combined annotation audit changed feature order or row count."
)

compare_collapsed_sets <- function(x, y) {
  x_set <- distinct_sorted_values(
    unlist(
      strsplit(
        clean_annotation_value(x),
        split = ";",
        fixed = TRUE
      ),
      use.names = FALSE
    )
  )

  y_set <- distinct_sorted_values(
    unlist(
      strsplit(
        clean_annotation_value(y),
        split = ";",
        fixed = TRUE
      ),
      use.names = FALSE
    )
  )

  if (
    length(x_set) == 0L &&
      length(y_set) == 0L
  ) {
    return(
      "BOTH_UNMAPPED"
    )
  }

  if (
    length(x_set) == 0L &&
      length(y_set) > 0L
  ) {
    return(
      "GPL_ONLY"
    )
  }

  if (
    length(x_set) > 0L &&
      length(y_set) == 0L
  ) {
    return(
      "CHIPDB_ONLY"
    )
  }

  if (
    identical(
      x_set,
      y_set
    )
  ) {
    return(
      "EXACT_SET_MATCH"
    )
  }

  if (
    length(
      intersect(
        x_set,
        y_set
      )
    ) > 0L
  ) {
    return(
      "PARTIAL_OVERLAP"
    )
  }

  "DISCORDANT_NONOVERLAPPING"
}

annotation_concordance$symbol_source_concordance <- vapply(
  seq_len(
    nrow(annotation_concordance)
  ),
  function(i) {
    compare_collapsed_sets(
      annotation_concordance$
        chip_symbols[i],
      annotation_concordance$
        gpl_symbols[i]
    )
  },
  character(1)
)

annotation_concordance$entrez_source_concordance <- vapply(
  seq_len(
    nrow(annotation_concordance)
  ),
  function(i) {
    compare_collapsed_sets(
      annotation_concordance$
        chip_entrez_ids[i],
      annotation_concordance$
        gpl_entrez_ids[i]
    )
  },
  character(1)
)

# Prespecified future mapping preference.
annotation_concordance$future_primary_annotation_source <-
  "BIOCONDUCTOR_CHIPDB"

annotation_concordance$future_unique_symbol_candidate <-
  ifelse(
    annotation_concordance$
      chip_symbol_count == 1L,
    annotation_concordance$
      chip_symbols,
    ""
  )

annotation_concordance$
  future_unique_symbol_candidate_eligible <-
  annotation_concordance$
    chip_symbol_count == 1L

annotation_concordance$
  automatic_feature_exclusion_performed <- FALSE

annotation_concordance$
  gene_level_aggregation_performed <- FALSE

# ------------------------------
# 8. Audit the locked 24-gene signature in rat annotation
# ------------------------------
locked_human_signature <- c(
  "ESR1",
  "AR",
  "PGR",
  "THRA",
  "THRB",
  "CAT",
  "BCL2",
  "BAX",
  "PARP1",
  "IL6",
  "ABCB1",
  "ABCG2",
  "FASN",
  "SCD",
  "TWIST1",
  "PPARG",
  "EGFR",
  "MMP9",
  "JUN",
  "FOS",
  "ADRB2",
  "ERG",
  "H2AX",
  "MITF"
)

assert_true(
  length(locked_human_signature) == 24L &&
    anyDuplicated(
      locked_human_signature
    ) == 0L,
  "The locked human Triclosan signature is not 24 unique genes."
)

# Case-insensitive audit only. This does not yet constitute ortholog mapping.
chip_symbol_tokens_by_feature <- lapply(
  annotation_concordance$chip_symbols,
  function(x) {
    split_annotation_tokens(x)
  }
)

all_chip_symbols <- sort(
  unique(
    unlist(
      chip_symbol_tokens_by_feature,
      use.names = FALSE
    )
  )
)

signature_coverage_rows <- vector(
  "list",
  length(locked_human_signature)
)

for (i in seq_along(
  locked_human_signature
)) {
  human_symbol_i <- locked_human_signature[i]

  case_insensitive_matches <- all_chip_symbols[
    toupper(all_chip_symbols) ==
      toupper(human_symbol_i)
  ]

  matched_feature_ids <- annotation_concordance$
    transcript_cluster_id[
      vapply(
        chip_symbol_tokens_by_feature,
        function(symbols_i) {
          any(
            toupper(symbols_i) ==
              toupper(human_symbol_i)
          )
        },
        logical(1)
      )
    ]

  signature_coverage_rows[[i]] <- data.frame(
    signature_order = i,
    locked_human_symbol = human_symbol_i,
    case_insensitive_rat_symbol_match_number =
      length(case_insensitive_matches),
    case_insensitive_rat_symbol_matches = if (
      length(case_insensitive_matches) == 0L
    ) {
      ""
    } else {
      paste(
        case_insensitive_matches,
        collapse = ";"
      )
    },
    matching_transcript_cluster_number =
      length(
        matched_feature_ids
      ),
    matching_transcript_cluster_ids = if (
      length(matched_feature_ids) == 0L
    ) {
      ""
    } else {
      paste(
        matched_feature_ids,
        collapse = ";"
      )
    },
    ortholog_mapping_performed = FALSE,
    included_in_score = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

signature_coverage_audit <- do.call(
  rbind,
  signature_coverage_rows
)
rownames(signature_coverage_audit) <- NULL

# ------------------------------
# 9. Annotation summary
# ------------------------------
concordance_levels <- c(
  "EXACT_SET_MATCH",
  "PARTIAL_OVERLAP",
  "CHIPDB_ONLY",
  "GPL_ONLY",
  "DISCORDANT_NONOVERLAPPING",
  "BOTH_UNMAPPED"
)

symbol_concordance_counts <- table(
  factor(
    annotation_concordance$
      symbol_source_concordance,
    levels = concordance_levels
  )
)

entrez_concordance_counts <- table(
  factor(
    annotation_concordance$
      entrez_source_concordance,
    levels = concordance_levels
  )
)

annotation_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Script_build_ID",
    "Source_Script12A_bundle_MD5",
    "Platform",
    "Expression_features_verified",
    "Expression_samples_verified",
    "Embedded_feature_data_column_number",
    "ChipDb_package",
    "ChipDb_package_version",
    "AnnotationDbi_package_version",
    "ChipDb_select_warning_number",
    "ChipDb_features_with_any_symbol",
    "ChipDb_features_with_unique_symbol",
    "ChipDb_features_with_multiple_symbols",
    "ChipDb_features_without_symbol",
    "ChipDb_features_with_any_EntrezID",
    "ChipDb_features_with_unique_EntrezID",
    "ChipDb_features_with_multiple_EntrezIDs",
    "ChipDb_features_without_EntrezID",
    "GPL_annotation_table_rows",
    "GPL_annotation_table_columns",
    "GPL_ID_column",
    "GPL_symbol_column",
    "GPL_Entrez_column",
    "GPL_gene_title_column",
    "GPL_features_with_any_symbol",
    "Symbol_exact_set_matches_between_sources",
    "Symbol_partial_overlaps_between_sources",
    "Symbol_discordant_nonoverlapping_between_sources",
    "Symbol_both_unmapped_between_sources",
    "Entrez_exact_set_matches_between_sources",
    "Entrez_partial_overlaps_between_sources",
    "Entrez_discordant_nonoverlapping_between_sources",
    "Entrez_both_unmapped_between_sources",
    "Locked_signature_genes_with_case_insensitive_rat_symbol_match",
    "Locked_signature_genes_without_case_insensitive_rat_symbol_match",
    "Primary_future_annotation_source",
    "Expression_values_modified",
    "Features_excluded",
    "Gene_level_aggregation_performed",
    "Ortholog_mapping_performed",
    "Differential_expression_performed",
    "Completion_status"
  ),
  value = c(
    "GSE95554",
    "12B",
    SCRIPT_BUILD_ID,
    observed_bundle_md5,
    "GPL17117",
    nrow(expression_matrix),
    ncol(expression_matrix),
    ncol(feature_data_raw),
    "ragene20sttranscriptcluster.db",
    as.character(
      utils::packageVersion(
        "ragene20sttranscriptcluster.db"
      )
    ),
    as.character(
      utils::packageVersion(
        "AnnotationDbi"
      )
    ),
    length(chip_select_warnings),
    sum(
      chip_annotation_audit$
        chip_symbol_count > 0L
    ),
    sum(
      chip_annotation_audit$
        chip_symbol_count == 1L
    ),
    sum(
      chip_annotation_audit$
        chip_symbol_count > 1L
    ),
    sum(
      chip_annotation_audit$
        chip_symbol_count == 0L
    ),
    sum(
      chip_annotation_audit$
        chip_entrez_count > 0L
    ),
    sum(
      chip_annotation_audit$
        chip_entrez_count == 1L
    ),
    sum(
      chip_annotation_audit$
        chip_entrez_count > 1L
    ),
    sum(
      chip_annotation_audit$
        chip_entrez_count == 0L
    ),
    nrow(gpl_table),
    ncol(gpl_table),
    gpl_id_column,
    ifelse(
      is.na(gpl_symbol_column),
      "",
      gpl_symbol_column
    ),
    ifelse(
      is.na(gpl_entrez_column),
      "",
      gpl_entrez_column
    ),
    ifelse(
      is.na(gpl_title_column),
      "",
      gpl_title_column
    ),
    sum(
      gpl_annotation_audit$
        gpl_symbol_count > 0L
    ),
    unname(
      symbol_concordance_counts[
        "EXACT_SET_MATCH"
      ]
    ),
    unname(
      symbol_concordance_counts[
        "PARTIAL_OVERLAP"
      ]
    ),
    unname(
      symbol_concordance_counts[
        "DISCORDANT_NONOVERLAPPING"
      ]
    ),
    unname(
      symbol_concordance_counts[
        "BOTH_UNMAPPED"
      ]
    ),
    unname(
      entrez_concordance_counts[
        "EXACT_SET_MATCH"
      ]
    ),
    unname(
      entrez_concordance_counts[
        "PARTIAL_OVERLAP"
      ]
    ),
    unname(
      entrez_concordance_counts[
        "DISCORDANT_NONOVERLAPPING"
      ]
    ),
    unname(
      entrez_concordance_counts[
        "BOTH_UNMAPPED"
      ]
    ),
    sum(
      signature_coverage_audit$
        matching_transcript_cluster_number > 0L
    ),
    sum(
      signature_coverage_audit$
        matching_transcript_cluster_number == 0L
    ),
    "BIOCONDUCTOR_CHIPDB",
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Preserve downloaded files
# ------------------------------
downloaded_files <- list.files(
  stage_download_dir,
  recursive = TRUE,
  full.names = TRUE,
  all.files = FALSE
)

assert_true(
  length(downloaded_files) >= 1L,
  "No GPL17117 source file was retained in the download directory."
)

download_manifest <- make_manifest(
  downloaded_files,
  downloaded_files
)

# ------------------------------
# 11. Save staging outputs
# ------------------------------
input_manifest <- make_manifest(
  required_inputs,
  required_inputs
)

package_version_audit <- data.frame(
  package = c(
    "GEOquery",
    "Biobase",
    "AnnotationDbi",
    "ragene20sttranscriptcluster.db",
    "BiocManager"
  ),
  available = vapply(
    c(
      "GEOquery",
      "Biobase",
      "AnnotationDbi",
      "ragene20sttranscriptcluster.db",
      "BiocManager"
    ),
    requireNamespace,
    logical(1),
    quietly = TRUE
  ),
  version = vapply(
    c(
      "GEOquery",
      "Biobase",
      "AnnotationDbi",
      "ragene20sttranscriptcluster.db",
      "BiocManager"
    ),
    function(package_i) {
      if (
        requireNamespace(
          package_i,
          quietly = TRUE
        )
      ) {
        as.character(
          utils::packageVersion(
            package_i
          )
        )
      } else {
        ""
      }
    },
    character(1)
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step3_GSE95554_real_exposure_validation",
  script = "Script12B",
  script_build_id = SCRIPT_BUILD_ID,
  created_at = format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  ),
  source_accession = "GSE95554",
  source_platform = "GPL17117",
  source_script12a_bundle_file =
    normalizePath(
      input_bundle_file,
      winslash = "/",
      mustWork = TRUE
    ),
  source_script12a_bundle_md5 =
    observed_bundle_md5,
  source_expression_dimensions =
    dim(expression_matrix),
  source_feature_ids =
    feature_ids,
  source_sample_ids =
    colnames(expression_matrix),
  embedded_feature_audit =
    embedded_feature_audit,
  chip_annotation_long =
    chip_long,
  chip_annotation_audit =
    chip_annotation_audit,
  chip_select_warnings =
    chip_select_warnings,
  chip_available_keytypes =
    available_keytypes,
  chip_available_columns =
    available_columns,
  gpl_annotation_table =
    gpl_table,
  gpl_column_audit =
    gpl_column_audit,
  gpl_selected_columns = list(
    ID = gpl_id_column,
    SYMBOL = gpl_symbol_column,
    ENTREZID = gpl_entrez_column,
    GENE_TITLE = gpl_title_column
  ),
  gpl_annotation_audit =
    gpl_annotation_audit,
  annotation_concordance =
    annotation_concordance,
  signature_coverage_audit =
    signature_coverage_audit,
  installation_audit =
    installation_audit,
  package_version_audit =
    package_version_audit,
  gpl_download_audit =
    gpl_download_audit,
  download_manifest =
    download_manifest,
  annotation_summary =
    annotation_summary,
  policy = list(
    primary_future_annotation_source =
      "BIOCONDUCTOR_CHIPDB",
    exact_transcript_cluster_matching =
      TRUE,
    automatic_alias_substitution =
      FALSE,
    automatic_feature_exclusion =
      FALSE,
    gene_level_aggregation_performed =
      FALSE,
    expression_values_modified =
      FALSE,
    ortholog_mapping_performed =
      FALSE,
    differential_expression_performed =
      FALSE,
    next_step_must_review_mapping_counts =
      TRUE
  ),
  provenance = list(
    accepted_script12a_bundle_md5 =
      accepted_script12a_bundle_md5,
    chip_annotation_package =
      "ragene20sttranscriptcluster.db",
    independent_annotation_source =
      "GEO GPL17117 AnnotGPL table",
    next_step_requires_review_of = c(
      "unique and multi-symbol feature counts",
      "chip/GPL source concordance",
      "24-gene signature rat-symbol coverage"
    )
  )
)

class(complete_bundle) <- c(
  "GSE95554_probe_annotation_audit_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE95554_probe_annotation_AUDIT_bundle.rds"
)
stage_chip_long_file <- file.path(
  stage_audit_dir,
  "GSE95554_chipDB_annotation_long.csv"
)
stage_chip_audit_file <- file.path(
  stage_audit_dir,
  "GSE95554_chipDB_annotation_per_feature.csv"
)
stage_gpl_table_file <- file.path(
  stage_audit_dir,
  "GPL17117_GEO_annotation_table_SOURCE.csv"
)
stage_gpl_column_file <- file.path(
  stage_audit_dir,
  "GPL17117_GEO_annotation_column_audit.csv"
)
stage_gpl_feature_file <- file.path(
  stage_audit_dir,
  "GSE95554_GEO_GPL_annotation_per_feature.csv"
)
stage_concordance_file <- file.path(
  stage_audit_dir,
  "GSE95554_annotation_source_concordance.csv"
)
stage_signature_file <- file.path(
  stage_audit_dir,
  "GSE95554_locked_24gene_signature_rat_symbol_coverage_audit.csv"
)
stage_embedded_file <- file.path(
  stage_audit_dir,
  "GSE95554_embedded_feature_data_column_audit.csv"
)
stage_install_file <- file.path(
  stage_audit_dir,
  "Script12B_annotation_package_installation_audit.csv"
)
stage_package_file <- file.path(
  stage_audit_dir,
  "Script12B_package_version_audit.csv"
)
stage_gpl_download_file <- file.path(
  stage_audit_dir,
  "Script12B_GPL17117_download_attempt_audit.csv"
)
stage_download_manifest_file <- file.path(
  stage_audit_dir,
  "Script12B_downloaded_annotation_files_with_MD5.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE95554_probe_annotation_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script12B_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script12B_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script12B_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script12B_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)

write_csv_utf8(
  chip_long,
  stage_chip_long_file
)
write_csv_utf8(
  chip_annotation_audit,
  stage_chip_audit_file
)
write_csv_utf8(
  gpl_table,
  stage_gpl_table_file
)
write_csv_utf8(
  gpl_column_audit,
  stage_gpl_column_file
)
write_csv_utf8(
  gpl_annotation_audit,
  stage_gpl_feature_file
)
write_csv_utf8(
  annotation_concordance,
  stage_concordance_file
)
write_csv_utf8(
  signature_coverage_audit,
  stage_signature_file
)
write_csv_utf8(
  embedded_feature_audit,
  stage_embedded_file
)
write_csv_utf8(
  installation_audit,
  stage_install_file
)
write_csv_utf8(
  package_version_audit,
  stage_package_file
)
write_csv_utf8(
  gpl_download_audit,
  stage_gpl_download_file
)
write_csv_utf8(
  download_manifest,
  stage_download_manifest_file
)
write_csv_utf8(
  annotation_summary,
  stage_summary_file
)
write_csv_utf8(
  input_manifest,
  stage_input_manifest_file
)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

bundle_check <- readRDS(
  stage_bundle_file
)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "script_build_id",
      "source_feature_ids",
      "chip_annotation_audit",
      "gpl_annotation_audit",
      "annotation_concordance",
      "signature_coverage_audit",
      "annotation_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 12B bundle is missing required fields."
)

assert_true(
  identical(
    as.character(
      bundle_check$script_build_id
    ),
    SCRIPT_BUILD_ID
  ),
  "Saved Script 12B build ID is incorrect."
)

assert_true(
  identical(
    as.character(
      bundle_check$source_feature_ids
    ),
    feature_ids
  ),
  "Saved Script 12B feature IDs changed order."
)

assert_true(
  nrow(
    bundle_check$annotation_concordance
  ) == 36685L,
  "Saved Script 12B concordance audit does not contain 36,685 rows."
)

assert_true(
  isFALSE(
    bundle_check$policy$
      automatic_feature_exclusion
  ) &&
    isFALSE(
      bundle_check$policy$
        gene_level_aggregation_performed
    ) &&
    isFALSE(
      bundle_check$policy$
        differential_expression_performed
    ),
  "Saved Script 12B policy incorrectly indicates downstream analysis."
)

bundle_md5 <- md5_one(
  stage_bundle_file
)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 3 - Script 12B",
  "GSE95554 GPL17117 transcript-cluster annotation audit",
  paste0(
    "Script build ID: ",
    SCRIPT_BUILD_ID
  ),
  "============================================================",
  paste0(
    "Completion time: ",
    format(
      Sys.time(),
      "%Y-%m-%d %H:%M:%S %Z"
    )
  ),
  paste0(
    "Source Script 12A bundle MD5: ",
    observed_bundle_md5
  ),
  paste0(
    "Expression matrix verified: ",
    nrow(expression_matrix),
    " features x ",
    ncol(expression_matrix),
    " samples"
  ),
  paste0(
    "Embedded feature-data columns: ",
    ncol(feature_data_raw)
  ),
  paste0(
    "Chip annotation package: ragene20sttranscriptcluster.db ",
    as.character(
      utils::packageVersion(
        "ragene20sttranscriptcluster.db"
      )
    )
  ),
  paste0(
    "ChipDB features with any symbol: ",
    sum(
      chip_annotation_audit$
        chip_symbol_count > 0L
    )
  ),
  paste0(
    "ChipDB features with unique symbol: ",
    sum(
      chip_annotation_audit$
        chip_symbol_count == 1L
    )
  ),
  paste0(
    "ChipDB features with multiple symbols: ",
    sum(
      chip_annotation_audit$
        chip_symbol_count > 1L
    )
  ),
  paste0(
    "ChipDB features without symbol: ",
    sum(
      chip_annotation_audit$
        chip_symbol_count == 0L
    )
  ),
  paste0(
    "ChipDB features with any Entrez ID: ",
    sum(
      chip_annotation_audit$
        chip_entrez_count > 0L
    )
  ),
  paste0(
    "GEO GPL annotation rows / columns: ",
    nrow(gpl_table),
    " / ",
    ncol(gpl_table)
  ),
  paste0(
    "GEO GPL selected ID column: ",
    gpl_id_column
  ),
  paste0(
    "GEO GPL selected symbol column: ",
    ifelse(
      is.na(gpl_symbol_column),
      "NONE",
      gpl_symbol_column
    )
  ),
  paste0(
    "Symbol exact-set matches between sources: ",
    unname(
      symbol_concordance_counts[
        "EXACT_SET_MATCH"
      ]
    )
  ),
  paste0(
    "Symbol partial overlaps between sources: ",
    unname(
      symbol_concordance_counts[
        "PARTIAL_OVERLAP"
      ]
    )
  ),
  paste0(
    "Symbol discordant non-overlapping mappings: ",
    unname(
      symbol_concordance_counts[
        "DISCORDANT_NONOVERLAPPING"
      ]
    )
  ),
  paste0(
    "Locked 24 genes with case-insensitive rat-symbol match: ",
    sum(
      signature_coverage_audit$
        matching_transcript_cluster_number > 0L
    ),
    " / 24"
  ),
  "Primary future annotation source: BIOCONDUCTOR_CHIPDB",
  "Expression values modified: FALSE",
  "Features excluded: FALSE",
  "Gene-level aggregation performed: FALSE",
  "Ortholog mapping performed: FALSE",
  "Differential expression performed: FALSE",
  paste0(
    "Script 12B bundle MD5: ",
    bundle_md5
  ),
  "",
  "SCRIPT12B STATUS: COMPLETE",
  paste0(
    "GPL17117 annotation coverage and source concordance were audited only. ",
    "No expression feature was excluded or aggregated."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(
    report_lines
  ),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_chip_long_file,
  stage_chip_audit_file,
  stage_gpl_table_file,
  stage_gpl_column_file,
  stage_gpl_feature_file,
  stage_concordance_file,
  stage_signature_file,
  stage_embedded_file,
  stage_install_file,
  stage_package_file,
  stage_gpl_download_file,
  stage_download_manifest_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file,
  downloaded_files
)

output_files_before_manifest <- unique(
  output_files_before_manifest
)

assert_true(
  all(
    file.exists(
      output_files_before_manifest
    )
  ),
  "At least one staged Script 12B output is missing."
)

assert_true(
  all(
    file.info(
      output_files_before_manifest
    )$size > 0
  ),
  "At least one staged Script 12B output is empty."
)

output_manifest <- make_manifest(
  output_files_before_manifest,
  output_files_before_manifest
)

write_csv_utf8(
  output_manifest,
  stage_output_manifest_file
)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) ==
    length(output_files_before_manifest),
  "Script 12B output manifest has an incorrect row count."
)

for (i in seq_along(
  output_files_before_manifest
)) {
  file_i <- output_files_before_manifest[i]
  expected_relative_i <- make_manifest(
    file_i,
    file_i
  )$relative_path

  row_i <- manifest_check[
    manifest_check$relative_path ==
      expected_relative_i,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0(
      "Missing or duplicated manifest row for: ",
      expected_relative_i
    )
  )

  assert_true(
    identical(
      tolower(
        as.character(
          row_i$md5
        )
      ),
      tolower(
        md5_one(file_i)
      )
    ),
    paste0(
      "Manifest MD5 mismatch for: ",
      expected_relative_i
    )
  )

  assert_true(
    as.numeric(
      row_i$size_bytes
    ) ==
      as.numeric(
        file.info(file_i)$size
      ),
    paste0(
      "Manifest size mismatch for: ",
      expected_relative_i
    )
  )
}

# ------------------------------
# 12. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 12B directory appeared during staging."
)

rename_ok <- file.rename(
  stage_root,
  final_root
)

if (!isTRUE(rename_ok)) {
  dir.create(
    final_root,
    recursive = TRUE,
    showWarnings = FALSE
  )

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 12B staging directory."
  )

  unlink(
    stage_root,
    recursive = TRUE,
    force = TRUE
  )
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE95554_probe_annotation_AUDIT_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script12B_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script12B_output_manifest_with_MD5.csv"
)

assert_true(
  all(
    file.exists(c(
      final_bundle_file,
      final_report_file,
      final_manifest_file
    ))
  ),
  "Committed Script 12B output is incomplete."
)

assert_true(
  identical(
    md5_one(final_bundle_file),
    bundle_md5
  ),
  "Committed Script 12B bundle MD5 changed after commit."
)

assert_true(
  report_contains(
    final_report_file,
    "SCRIPT12B STATUS: COMPLETE"
  ),
  "Committed Script 12B report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 12B completed successfully.\n")
cat(
  "Expression features audited: ",
  nrow(expression_matrix),
  "\n",
  sep = ""
)
cat(
  "ChipDB unique-symbol features: ",
  sum(
    chip_annotation_audit$
      chip_symbol_count == 1L
  ),
  "\n",
  sep = ""
)
cat(
  "ChipDB multi-symbol features: ",
  sum(
    chip_annotation_audit$
      chip_symbol_count > 1L
  ),
  "\n",
  sep = ""
)
cat(
  "ChipDB unmapped-symbol features: ",
  sum(
    chip_annotation_audit$
      chip_symbol_count == 0L
  ),
  "\n",
  sep = ""
)
cat(
  "Locked signature genes with rat-symbol match: ",
  sum(
    signature_coverage_audit$
      matching_transcript_cluster_number > 0L
  ),
  " / 24\n",
  sep = ""
)
cat("Expression values modified: FALSE\n")
cat("Features excluded: FALSE\n")
cat("Gene-level aggregation performed: FALSE\n")
cat("Differential expression performed: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat(
  "Bundle MD5: ",
  md5_one(
    final_bundle_file
  ),
  "\n",
  sep = ""
)
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

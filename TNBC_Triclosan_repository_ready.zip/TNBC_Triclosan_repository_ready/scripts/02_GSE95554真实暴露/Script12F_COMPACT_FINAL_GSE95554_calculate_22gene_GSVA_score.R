# ==============================================================================
# TNBC_Triclosan | GSE95554 | Script 12F COMPACT FINAL
# Purpose: calculate the continuous classical GSVA Triclosan_activity score
#          from the accepted Script 12E full human-ortholog expression matrix.
#
# Fixed boundary:
# - Full 15,817 x 50 matrix supplied to GSVA.
# - Fixed 22-gene set; ABCB1 and SCD remain absent.
# - No expression modification, sample deletion or paralog substitution.
# - No TCS/OIL test, DEG, PCA, GSEA, cutoff or manuscript figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script12F_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step3_GSE95554_real_exposure_validation")
INPUT_ROOT <- file.path(STEP_ROOT, "04_human_ortholog_expression")
OUTPUT_ROOT <- file.path(STEP_ROOT, "05_Triclosan_GSVA_score")

EXPECTED_MD5 <- c(
  bundle = "9802964c311d48239630913adce1f713",
  human_matrix = "6c8b2f6f44f2ccc76fc8f5a7431b9e78",
  signature_matrix = "5fee3d6ea938b6d0ca0245db3973a60d",
  availability = "3211ae0f1309b67d66526436c250cc90",
  matrix_summary = "8005f9697425de752882afbc60f79af7",
  integrity = "c8de16c24c933a4a472df44992495876",
  manifest = "55955e0e9df96718223122a67cb8dc7a",
  report = "617d597e6873ca0133892dfa5a7c65e5"
)

INPUTS <- c(
  bundle = file.path(INPUT_ROOT, "objects",
                     "GSE95554_human_ortholog_expression_COMPLETE_bundle.rds"),
  human_matrix = file.path(INPUT_ROOT, "objects",
                           "GSE95554_human_ortholog_expression_matrix.rds"),
  signature_matrix = file.path(INPUT_ROOT, "objects",
                               "GSE95554_locked_22gene_ortholog_expression_matrix.rds"),
  availability = file.path(INPUT_ROOT, "audit",
                           "GSE95554_locked_24gene_human_expression_availability.csv"),
  matrix_summary = file.path(INPUT_ROOT, "audit",
                             "GSE95554_human_ortholog_expression_matrix_summary.csv"),
  integrity = file.path(INPUT_ROOT, "audit",
                        "GSE95554_human_ortholog_expression_integrity_summary.csv"),
  manifest = file.path(INPUT_ROOT, "audit",
                       "Script12E_output_manifest_with_MD5.csv"),
  report = file.path(INPUT_ROOT, "logs",
                     "Script12E_COMPLETE_report.txt")
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)
LOCKED22 <- setdiff(LOCKED24, c("ABCB1", "SCD"))

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

num_summary <- function(x) {
  x <- as.numeric(x)
  finite <- x[is.finite(x)]
  data.frame(
    n = length(x),
    finite_n = length(finite),
    nonfinite_n = sum(!is.finite(x)),
    min = if (length(finite)) min(finite) else NA_real_,
    q1 = if (length(finite)) unname(quantile(finite, .25)) else NA_real_,
    median = if (length(finite)) median(finite) else NA_real_,
    mean = if (length(finite)) mean(finite) else NA_real_,
    q3 = if (length(finite)) unname(quantile(finite, .75)) else NA_real_,
    max = if (length(finite)) max(finite) else NA_real_,
    sd = if (length(finite) > 1L) sd(finite) else NA_real_,
    unique_n = length(unique(finite)),
    check.names = FALSE
  )
}

safe_read_rds <- function(path) {
  tryCatch(readRDS(path), error = function(e) NULL)
}

manifest_ok <- function(root, manifest_file) {
  m <- tryCatch(
    read.csv(manifest_file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || nrow(m) < 1L ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root_norm <- normalizePath(root, winslash = "/", mustWork = TRUE)
  for (i in seq_len(nrow(m))) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(strsplit(rel, "/", fixed = TRUE)[[1L]] %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f_norm <- normalizePath(f, winslash = "/", mustWork = TRUE)
    if (!startsWith(f_norm, paste0(root_norm, "/"))) return(FALSE)
    if (!identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i]))) return(FALSE)
    if (!identical(md5(f), tolower(trimws(as.character(m$md5[i]))))) return(FALSE)
  }
  TRUE
}

existing_output_valid <- function(root) {
  key <- c(
    bundle = file.path(root, "objects",
      "GSE95554_Triclosan_22gene_GSVA_COMPLETE_bundle.rds"),
    score = file.path(root, "objects",
      "GSE95554_Triclosan_22gene_GSVA_score.rds"),
    manifest = file.path(root, "audit",
      "Script12F_output_manifest_with_MD5.csv"),
    report = file.path(root, "logs",
      "Script12F_COMPLETE_report.txt")
  )
  if (!all(file.exists(key))) return(FALSE)
  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT12F STATUS: COMPLETE", report, fixed = TRUE))) return(FALSE)
  if (!manifest_ok(root, key["manifest"])) return(FALSE)

  b <- safe_read_rds(key["bundle"])
  s <- safe_read_rds(key["score"])
  accepted_builds <- c(
    "Script12F_FINAL_20260711",
    "Script12F_v2_FINAL_20260711",
    BUILD_ID
  )
  required <- c(
    "script","script_build_id","source_script12e_bundle_md5",
    "source_script12e_human_matrix_md5",
    "source_script12e_signature_matrix_md5",
    "source_script12e_manifest_md5","score_matrix",
    "Triclosan_activity","policy"
  )
  if (!is.list(b) || !all(required %in% names(b)) ||
      !identical(as.character(b$script), "Script12F") ||
      !as.character(b$script_build_id) %in% accepted_builds) return(FALSE)

  src_ok <- identical(
    tolower(c(
      bundle = as.character(b$source_script12e_bundle_md5),
      human_matrix = as.character(b$source_script12e_human_matrix_md5),
      signature_matrix = as.character(b$source_script12e_signature_matrix_md5),
      manifest = as.character(b$source_script12e_manifest_md5)
    )),
    EXPECTED_MD5[c("bundle","human_matrix","signature_matrix","manifest")]
  )
  if (!src_ok || !is.numeric(s) || length(s) != 50L ||
      any(!is.finite(s)) || length(unique(s)) <= 1L ||
      is.null(names(s)) || anyDuplicated(names(s))) return(FALSE)

  sm <- b$score_matrix
  if (!is.matrix(sm) || !identical(dim(sm), c(1L, 50L)) ||
      !identical(rownames(sm), "Triclosan_activity") ||
      !identical(colnames(sm), names(s)) ||
      !isTRUE(all.equal(as.numeric(sm), as.numeric(s), tolerance = 0))) return(FALSE)

  prohibited <- c(
    "expression_values_modified","expression_values_renormalized",
    "expression_values_imputed","samples_filtered",
    "ABCB1_paralog_expression_combined","SCD_paralog_expression_combined",
    "alternative_score_calculated","TCS_OIL_comparison_performed",
    "differential_expression_performed","PCA_performed","GSEA_performed",
    "high_low_group_created","cutoff_selected","manuscript_figure_created"
  )
  all(prohibited %in% names(b$policy)) &&
    all(vapply(prohibited, function(x) identical(b$policy[[x]], FALSE), logical(1)))
}

make_manifest <- function(files, root) {
  root_norm <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f_norm <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f_norm, paste0(root_norm, "/")),
           "Output is outside staging directory: %s", f_norm)
    substring(f_norm, nchar(root_norm) + 2L)
  }, character(1))
  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Score only; TCS/OIL comparison and downstream tests are disabled.\n")
  cat("============================================================\n")

  assert(dir.exists(STEP_ROOT), "Step directory does not exist:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted Script 12E inputs:\n%s",
         paste(missing, collapse = "\n"))

  observed <- vapply(INPUTS, md5, character(1))
  assert(identical(observed, EXPECTED_MD5),
         "At least one accepted Script 12E input MD5 is different.\n%s",
         paste(sprintf("%s: expected %s; observed %s",
                       names(EXPECTED_MD5), EXPECTED_MD5, observed),
               collapse = "\n"))
  assert(any(grepl("SCRIPT12E STATUS: COMPLETE",
                   readLines(INPUTS["report"], warn = FALSE), fixed = TRUE)),
         "Script 12E completion marker is missing.")

  if (dir.exists(OUTPUT_ROOT)) {
    entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))
    if (!length(entries)) {
      unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
      assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    } else if (existing_output_valid(OUTPUT_ROOT)) {
      cat("Existing Script 12F output is complete and valid.\n")
      cat("Nothing was overwritten or recalculated.\n")
      cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
      cat("✅ 已完成\n")
      return(invisible(OUTPUT_ROOT))
    } else {
      archive <- file.path(
        STEP_ROOT,
        paste0("05_Triclosan_GSVA_score_INCOMPLETE_",
               format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
      )
      assert(file.rename(OUTPUT_ROOT, archive),
             "Existing directory is incomplete, but safe archiving failed.\nNo file was deleted.\n%s",
             OUTPUT_ROOT)
      assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
             "Archive verification failed. No new analysis was started.")
      cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
    }
  }

  assert(requireNamespace("GSVA", quietly = TRUE),
         "Package GSVA is missing. Install it with BiocManager::install('GSVA').")
  assert(exists("gsvaParam", envir = asNamespace("GSVA"), mode = "function"),
         "Installed GSVA does not provide gsvaParam(); update GSVA.")

  source_bundle <- readRDS(INPUTS["bundle"])
  expr <- readRDS(INPUTS["human_matrix"])
  sig_expr <- readRDS(INPUTS["signature_matrix"])

  required_bundle <- c(
    "script","script_build_id","source_accession","source_platform",
    "design_table","human_ortholog_expression","locked_signature_audit",
    "locked_signature_expression","policy"
  )
  assert(is.list(source_bundle) && all(required_bundle %in% names(source_bundle)),
         "Script 12E bundle is malformed.")
  assert(identical(as.character(source_bundle$script), "Script12E") &&
         identical(as.character(source_bundle$script_build_id),
                   "Script12E_FINAL_20260711"),
         "Script 12E bundle identity is incorrect.")

  design <- source_bundle$design_table
  sig_audit <- source_bundle$locked_signature_audit

  assert(is.matrix(expr) && is.numeric(expr) &&
         identical(dim(expr), c(15817L, 50L)),
         "Expected a 15,817 x 50 numeric human matrix.")
  assert(identical(expr, source_bundle$human_ortholog_expression),
         "Standalone and bundled human matrices differ.")
  assert(is.matrix(sig_expr) && is.numeric(sig_expr) &&
         identical(dim(sig_expr), c(22L, 50L)) &&
         identical(sig_expr, source_bundle$locked_signature_expression),
         "Standalone and bundled 22-gene matrices differ.")
  assert(!is.null(rownames(expr)) && !is.null(colnames(expr)) &&
         !anyDuplicated(rownames(expr)) && !anyDuplicated(colnames(expr)) &&
         all(nzchar(rownames(expr))) && all(nzchar(colnames(expr))) &&
         !any(!is.finite(expr)),
         "Human matrix has invalid names, duplicates or non-finite values.")
  assert(all(apply(expr, 1L, sd) > 0),
         "Human matrix contains a constant or invalid gene row.")

  required_design <- c(
    "sample_order","sample_id","exposure_code","reproductive_state",
    "exposure_state_group","primary_TCS_or_OIL_subset",
    "primary_nulliparous_subset","primary_parous_subset"
  )
  assert(is.data.frame(design) && nrow(design) == 50L &&
         all(required_design %in% names(design)) &&
         identical(as.integer(design$sample_order), 1:50) &&
         identical(as.character(design$sample_id), colnames(expr)),
         "Design table is malformed or not aligned with expression columns.")
  assert(length(table(design$exposure_state_group)) == 10L &&
         all(table(design$exposure_state_group) == 5L) &&
         sum(as.logical(design$primary_TCS_or_OIL_subset)) == 20L &&
         sum(as.logical(design$primary_nulliparous_subset)) == 10L &&
         sum(as.logical(design$primary_parous_subset)) == 10L,
         "Prespecified sample groups are incorrect.")

  assert(is.data.frame(sig_audit) && nrow(sig_audit) == 24L &&
         identical(as.character(sig_audit$locked_human_symbol), LOCKED24),
         "Locked 24-gene audit is malformed or reordered.")
  unavailable <- as.character(sig_audit$locked_human_symbol[
    !as.logical(sig_audit$human_expression_available)
  ])
  assert(identical(unavailable, c("ABCB1", "SCD")),
         "Unavailable genes are not exactly ABCB1 and SCD.")
  assert(identical(rownames(sig_expr), LOCKED22) &&
         identical(colnames(sig_expr), colnames(expr)) &&
         identical(sig_expr, expr[LOCKED22, , drop = FALSE]) &&
         !any(c("ABCB1", "SCD") %in% rownames(expr)) &&
         all(apply(sig_expr, 1L, sd) > 0),
         "Locked 22-gene matrix is inconsistent with the accepted full matrix.")

  set.seed(20260711L)
  gene_set <- list(Triclosan_activity = LOCKED22)
  param <- GSVA::gsvaParam(expr, gene_set)
  score_obj <- GSVA::gsva(param)
  score_mat <- if (is.matrix(score_obj)) {
    score_obj
  } else if (inherits(score_obj, "SummarizedExperiment") &&
             requireNamespace("SummarizedExperiment", quietly = TRUE)) {
    as.matrix(SummarizedExperiment::assay(score_obj))
  } else {
    as.matrix(score_obj)
  }

  assert(is.matrix(score_mat) && is.numeric(score_mat) &&
         identical(dim(score_mat), c(1L, 50L)) &&
         identical(rownames(score_mat), "Triclosan_activity") &&
         identical(colnames(score_mat), colnames(expr)),
         "GSVA did not return the expected 1 x 50 score matrix.")

  score <- as.numeric(score_mat[1L, ])
  names(score) <- colnames(score_mat)
  assert(all(is.finite(score)) && sd(score) > 0 &&
         length(unique(score)) > 1L,
         "GSVA score is non-finite or invariant.")

  score_table <- design
  score_table$Triclosan_activity <- score
  score_table$score_method <- "Classical_GSVA"
  score_table$expression_input_gene_number <- nrow(expr)
  score_table$signature_gene_number <- length(LOCKED22)
  score_table$missing_locked_genes <- "ABCB1;SCD"
  score_table$TCS_OIL_comparison_performed <- FALSE
  score_table$high_low_group_created <- FALSE

  overall_summary <- cbind(
    data.frame(score_name = "Triclosan_activity",
               score_method = "Classical_GSVA", check.names = FALSE),
    num_summary(score),
    data.frame(expression_input_gene_number = nrow(expr),
               signature_gene_number = length(LOCKED22),
               TCS_OIL_comparison_performed = FALSE,
               high_low_cutoff_selected = FALSE, check.names = FALSE)
  )

  group_vars <- c(
    "exposure_code","reproductive_state","exposure_state_group",
    "primary_TCS_or_OIL_subset","primary_nulliparous_subset",
    "primary_parous_subset"
  )
  group_summary <- do.call(rbind, lapply(group_vars, function(v) {
    groups <- as.character(score_table[[v]])
    groups[is.na(groups) | !nzchar(groups)] <- "<MISSING>"
    do.call(rbind, lapply(unique(groups), function(g) {
      cbind(data.frame(group_variable = v, group_value = g,
                       check.names = FALSE),
            num_summary(score[groups == g]))
    }))
  }))
  rownames(group_summary) <- NULL

  signature_distribution <- do.call(rbind, lapply(LOCKED22, function(g) {
    all_s <- num_summary(sig_expr[g, ])
    primary_s <- num_summary(sig_expr[g,
      as.logical(design$primary_TCS_or_OIL_subset)])
    row <- sig_audit[sig_audit$locked_human_symbol == g, , drop = FALSE]
    data.frame(
      signature_order = match(g, LOCKED24),
      human_symbol = g,
      human_gene_id = as.character(row$human_gene_id),
      source_rat_expression_symbol =
        as.character(row$source_rat_expression_symbol),
      source_rat_gene_id = as.character(row$source_rat_gene_id),
      all50_minimum = all_s$min,
      all50_median = all_s$median,
      all50_mean = all_s$mean,
      all50_maximum = all_s$max,
      all50_standard_deviation = all_s$sd,
      all50_unique_value_number = all_s$unique_n,
      primary20_minimum = primary_s$min,
      primary20_median = primary_s$median,
      primary20_mean = primary_s$mean,
      primary20_maximum = primary_s$max,
      primary20_standard_deviation = primary_s$sd,
      primary20_unique_value_number = primary_s$unique_n,
      nonfinite_value_number = all_s$nonfinite_n,
      zero_variance_all50 = all_s$sd == 0,
      included_in_GSVA_score = TRUE,
      check.names = FALSE
    )
  }))
  rownames(signature_distribution) <- NULL

  parameter_lock <- data.frame(
    field = c(
      "GSVA_package_version","Expression_input_dimensions",
      "Expression_input_scope","Gene_set_name","Gene_set_size",
      "Missing_locked_genes","Parameter_constructor_call",
      "Score_execution_call","Method","Expression_modified",
      "Sample_filtering","Paralog_substitution",
      "Alternative_score_calculated","TCS_OIL_comparison_performed",
      "High_low_cutoff_selected"
    ),
    value = c(
      as.character(packageVersion("GSVA")), paste(dim(expr), collapse = " x "),
      "Full human-ortholog matrix","Triclosan_activity",length(LOCKED22),
      "ABCB1;SCD","GSVA::gsvaParam(expr, gene_set)",
      "GSVA::gsva(param)","Classical_GSVA","FALSE","FALSE","FALSE",
      "FALSE","FALSE","FALSE"
    ),
    check.names = FALSE
  )

  policy <- list(
    scoring_method = "Classical_GSVA",
    full_human_matrix_supplied = TRUE,
    expression_input_gene_number = 15817L,
    signature_gene_number = 22L,
    missing_locked_genes = c("ABCB1", "SCD"),
    expression_values_modified = FALSE,
    expression_values_renormalized = FALSE,
    expression_values_imputed = FALSE,
    samples_filtered = FALSE,
    ABCB1_paralog_expression_combined = FALSE,
    SCD_paralog_expression_combined = FALSE,
    alternative_score_calculated = FALSE,
    TCS_OIL_comparison_performed = FALSE,
    differential_expression_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    high_low_group_created = FALSE,
    cutoff_selected = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID",
      "Source_Script12E_bundle_MD5","Source_Script12E_human_matrix_MD5",
      "Source_Script12E_signature_matrix_MD5","Source_Script12E_manifest_MD5",
      "GSVA_package_version","Human_expression_dimensions",
      "Human_expression_nonfinite_values","Human_expression_zero_variance_genes",
      "Locked_signature_gene_number","Locked_signature_missing_genes",
      "Locked_signature_nonfinite_values","Locked_signature_zero_variance_genes",
      "GSVA_score_dimensions","Finite_score_number","Nonfinite_score_number",
      "Unique_score_number","Score_standard_deviation",
      "Score_sample_order_preserved","Expression_values_modified",
      "Samples_filtered","ABCB1_paralog_expression_combined",
      "SCD_paralog_expression_combined","Alternative_score_calculated",
      "TCS_OIL_comparison_performed","Differential_expression_performed",
      "PCA_performed","GSEA_performed","High_low_group_created",
      "High_low_cutoff_selected","Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "GSE95554","12F",BUILD_ID,EXPECTED_MD5["bundle"],
      EXPECTED_MD5["human_matrix"],EXPECTED_MD5["signature_matrix"],
      EXPECTED_MD5["manifest"],as.character(packageVersion("GSVA")),
      paste(dim(expr), collapse = " x "),sum(!is.finite(expr)),
      sum(apply(expr, 1L, sd) == 0),length(LOCKED22),"ABCB1;SCD",
      sum(!is.finite(sig_expr)),sum(apply(sig_expr, 1L, sd) == 0),
      paste(dim(score_mat), collapse = " x "),sum(is.finite(score)),
      sum(!is.finite(score)),length(unique(score)),sd(score),
      identical(names(score), colnames(expr)),FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,"COMPLETE"
    )),
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = "Script12E",
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step3_GSE95554_real_exposure_validation",
    script = "Script12F",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE95554",
    source_platform = "GPL17117",
    source_script12e_bundle_md5 = EXPECTED_MD5["bundle"],
    source_script12e_human_matrix_md5 = EXPECTED_MD5["human_matrix"],
    source_script12e_signature_matrix_md5 = EXPECTED_MD5["signature_matrix"],
    source_script12e_manifest_md5 = EXPECTED_MD5["manifest"],
    design_table = design,
    locked_signature_genes = LOCKED22,
    missing_locked_genes = c("ABCB1", "SCD"),
    score_matrix = score_mat,
    Triclosan_activity = score,
    score_table = score_table,
    overall_score_summary = overall_summary,
    score_by_group = group_summary,
    signature_expression_distribution = signature_distribution,
    parameter_lock = parameter_lock,
    package_audit = data.frame(
      package = "GSVA", available = TRUE,
      version = as.character(packageVersion("GSVA")),
      required_function = "gsvaParam",
      required_function_available = TRUE,
      check.names = FALSE
    ),
    integrity_summary = integrity,
    policy = policy,
    provenance = list(
      accepted_script12e_md5 = EXPECTED_MD5,
      next_step = "Prespecified TCS versus OIL comparisons after result audit"
    )
  )
  class(bundle) <- c("GSE95554_Triclosan_GSVA_score_bundle", "list")

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script12F_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(stage, "objects",
      "GSE95554_Triclosan_22gene_GSVA_COMPLETE_bundle.rds"),
    score = file.path(stage, "objects",
      "GSE95554_Triclosan_22gene_GSVA_score.rds"),
    score_table = file.path(stage, "audit",
      "GSE95554_Triclosan_22gene_GSVA_score_all50.csv"),
    overall = file.path(stage, "audit",
      "GSE95554_Triclosan_22gene_GSVA_score_summary.csv"),
    groups = file.path(stage, "audit",
      "GSE95554_Triclosan_22gene_GSVA_score_by_group.csv"),
    gene_distribution = file.path(stage, "audit",
      "GSE95554_locked_22gene_expression_distribution.csv"),
    parameters = file.path(stage, "audit",
      "GSE95554_Triclosan_22gene_GSVA_parameter_lock.csv"),
    package = file.path(stage, "audit",
      "Script12F_package_version_audit.csv"),
    integrity = file.path(stage, "audit",
      "GSE95554_Triclosan_22gene_GSVA_integrity_summary.csv"),
    inputs = file.path(stage, "audit",
      "Script12F_input_manifest_with_MD5.csv"),
    details = file.path(stage, "logs",
      "Script12F_GSVA_parameter_details.txt"),
    session = file.path(stage, "logs", "Script12F_sessionInfo.txt"),
    report = file.path(stage, "logs", "Script12F_COMPLETE_report.txt")
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(score, files["score"], version = 3)
  write_csv(score_table, files["score_table"])
  write_csv(overall_summary, files["overall"])
  write_csv(group_summary, files["groups"])
  write_csv(signature_distribution, files["gene_distribution"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(bundle$package_audit, files["package"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  writeLines(capture.output(show(param)), files["details"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 3 - Script 12F",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("GSVA package version: ", packageVersion("GSVA")),
    "Full human matrix supplied: 15817 x 50",
    "Locked signature genes used: 22 / 24",
    "Unavailable locked genes: ABCB1;SCD",
    paste0("Finite scores: ", sum(is.finite(score)), " / 50"),
    paste0("Unique scores: ", length(unique(score))),
    paste0("Score range: ", format(min(score), digits = 16), " to ",
           format(max(score), digits = 16)),
    paste0("Score standard deviation: ", format(sd(score), digits = 16)),
    "Expression values modified: FALSE",
    "Samples filtered: FALSE",
    "Paralog substitution: FALSE",
    "Alternative score calculated: FALSE",
    "TCS/OIL comparison performed: FALSE",
    "DEG/PCA/GSEA/cutoff/figure performed: FALSE",
    "",
    "SCRIPT12F STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")
  assert(identical(readRDS(files["score"]), score),
         "Standalone score changed during save/read-back.")
  check_bundle <- readRDS(files["bundle"])
  assert(identical(check_bundle$Triclosan_activity, score) &&
         identical(check_bundle$score_matrix, score_mat),
         "Bundle score changed during save/read-back.")
  check_csv <- read.csv(files["score_table"],
                        stringsAsFactors = FALSE, check.names = FALSE)
  assert(nrow(check_csv) == 50L &&
         identical(as.character(check_csv$sample_id),
                   as.character(design$sample_id)) &&
         isTRUE(all.equal(check_csv$Triclosan_activity, score,
                          tolerance = 1e-14, check.attributes = FALSE)),
         "Saved score CSV is inconsistent.")

  output_manifest_file <- file.path(
    stage, "audit", "Script12F_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest_file)
  assert(manifest_ok(stage, output_manifest_file),
         "Staged output manifest verification failed.")

  assert(file.rename(stage, OUTPUT_ROOT),
         "Atomic commit failed; staged files were not moved to final directory.")
  committed <- TRUE

  final_manifest <- file.path(
    OUTPUT_ROOT, "audit", "Script12F_output_manifest_with_MD5.csv"
  )
  assert(manifest_ok(OUTPUT_ROOT, final_manifest),
         "Post-commit manifest verification failed.")
  assert(existing_output_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 12F completed successfully.\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("Finite GSVA scores: 50 / 50\n")
  cat("TCS/OIL comparison performed: FALSE\n")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

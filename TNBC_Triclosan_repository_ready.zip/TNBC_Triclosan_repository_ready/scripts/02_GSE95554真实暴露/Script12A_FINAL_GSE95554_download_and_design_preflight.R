# ==============================================================================
# TNBC_Triclosan
# Step 3 - GSE95554 real Triclosan exposure validation
# Script 12A FINAL
#
# Purpose:
#   Download the processed GEO series-matrix object for GSE95554 and perform a
#   strict design/data-integrity audit before any differential-expression,
#   pathway or cross-species analysis.
#
# Study design expected from GEO:
#   - Organism: Rattus norvegicus
#   - Platform: GPL17117, Affymetrix Rat Gene 2.0 ST Array
#   - 50 mammary-tissue samples
#   - Exposures: DEP, MPB, TCS, MIX, OIL vehicle
#   - Reproductive states: nulliparous ("null") and parous ("par")
#   - 5 biological animals in every exposure-by-state group
#   - Primary real-exposure comparison planned later:
#       TCS versus OIL, stratified by reproductive state
#
# This script DOES:
#   - verify required package availability;
#   - download GSE95554 with bounded retries and local caching;
#   - select the GPL17117 ExpressionSet robustly;
#   - preserve the original ExpressionSet and processed expression matrix;
#   - reconstruct exposure, reproductive state and animal identifier from the
#     GEO sample title;
#   - verify the 5 x 2 factorial group structure and TCS/OIL subset;
#   - audit dimensions, feature/sample uniqueness, finite values and expression
#     distribution without changing the data;
#   - save source files, objects, CSV audits, MD5 manifests, report and
#     sessionInfo.
#
# This script DOES NOT:
#   - download or process the 483.5-MB CEL archive;
#   - normalize, log-transform, impute or filter expression values;
#   - annotate probes or map rat genes to human orthologs;
#   - calculate DEG, PCA, GSVA, GSEA or pathway enrichment;
#   - compare TCS and OIL;
#   - use TNBC outcomes or any outcome-guided threshold.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
options(timeout = max(1200L, getOption("timeout")))
Sys.setenv(TZ = "Asia/Singapore")

SCRIPT_BUILD_ID <- "Script12A_FINAL_20260710"

cat("============================================================\n")
cat("RUNNING: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat("Processed GEO series-matrix download: ENABLED\n")
cat("Raw CEL download: DISABLED\n")
cat("Expression modification: DISABLED\n")
cat("Differential expression: DISABLED\n")
cat("============================================================\n")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step3_GSE95554_real_exposure_validation"
)
final_root <- file.path(
  step_root,
  "00_preflight"
)

if (!dir.exists(project_root)) {
  stop(
    paste0(
      "Project root does not exist:\n",
      project_root
    ),
    call. = FALSE
  )
}

dir.create(
  step_root,
  recursive = TRUE,
  showWarnings = FALSE
)

if (!dir.exists(step_root)) {
  stop(
    paste0(
      "Unable to create Step 3 directory:\n",
      step_root
    ),
    call. = FALSE
  )
}

# Never overwrite an existing result directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(
      final_root,
      all.files = TRUE
    ),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(
      final_root,
      recursive = TRUE,
      force = TRUE
    )
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 12A will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive that directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(
  Sys.time(),
  "%Y%m%d_%H%M%S"
)

stage_root <- file.path(
  step_root,
  paste0(
    ".Script12A_staging_",
    stamp,
    "_",
    Sys.getpid()
  )
)
stage_download_dir <- file.path(
  stage_root,
  "downloads"
)
stage_object_dir <- file.path(
  stage_root,
  "objects"
)
stage_audit_dir <- file.path(
  stage_root,
  "audit"
)
stage_log_dir <- file.path(
  stage_root,
  "logs"
)

for (directory_i in c(
  stage_download_dir,
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)) {
  dir.create(
    directory_i,
    recursive = TRUE,
    showWarnings = FALSE
  )
}

if (!all(dir.exists(c(
  stage_download_dir,
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop(
    "Unable to create Script 12A staging directories.",
    call. = FALSE
  )
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(
      stage_root,
      recursive = TRUE,
      force = TRUE
    )
  }
}, add = TRUE)

# ------------------------------
# 1. General helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) {
    stop(
      message,
      call. = FALSE
    )
  }
}

md5_one <- function(path) {
  unname(
    tools::md5sum(path)
  )
}

normalize_existing_path <- function(path) {
  normalizePath(
    path,
    winslash = "/",
    mustWork = TRUE
  )
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(
    length(paths) == length(displayed_paths)
  )

  if (length(paths) == 0L) {
    return(data.frame(
      file_name = character(0),
      relative_path = character(0),
      absolute_path = character(0),
      size_bytes = numeric(0),
      md5 = character(0),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ))
  }

  info <- file.info(paths)

  data.frame(
    file_name = basename(displayed_paths),
    relative_path = vapply(
      displayed_paths,
      function(path_i) {
        path_i <- normalizePath(
          path_i,
          winslash = "/",
          mustWork = FALSE
        )
        stage_i <- normalizePath(
          stage_root,
          winslash = "/",
          mustWork = TRUE
        )
        sub(
          paste0("^", gsub(
            "([][{}()+*^$|\\\\?.])",
            "\\\\\\1",
            stage_i
          ), "/?"),
          "",
          path_i
        )
      },
      character(1)
    ),
    absolute_path = vapply(
      displayed_paths,
      function(path_i) {
        normalizePath(
          path_i,
          winslash = "/",
          mustWork = FALSE
        )
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(
      paths,
      md5_one,
      character(1)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

capture_warnings <- function(expression) {
  warning_messages <- character(0)

  value <- withCallingHandlers(
    expression,
    warning = function(w) {
      warning_messages <<- c(
        warning_messages,
        conditionMessage(w)
      )
      invokeRestart("muffleWarning")
    }
  )

  list(
    value = value,
    warnings = unique(warning_messages)
  )
}

collapse_messages <- function(x) {
  x <- unique(
    trimws(
      as.character(x)
    )
  )
  x <- x[
    !is.na(x) &
      nzchar(x)
  ]

  if (length(x) == 0L) {
    ""
  } else {
    paste(
      x,
      collapse = " | "
    )
  }
}

safe_quantile <- function(x, probability) {
  x <- as.numeric(x)
  x <- x[is.finite(x)]

  if (length(x) == 0L) {
    return(NA_real_)
  }

  as.numeric(
    stats::quantile(
      x,
      probs = probability,
      names = FALSE,
      type = 7
    )
  )
}

first_existing_column <- function(
  data,
  candidate_names,
  required = TRUE
) {
  matching <- candidate_names[
    candidate_names %in%
      colnames(data)
  ]

  if (length(matching) > 0L) {
    return(matching[1])
  }

  if (required) {
    stop(
      paste0(
        "None of the required phenotype columns were found: ",
        paste(
          candidate_names,
          collapse = ", "
        ),
        "\nAvailable columns: ",
        paste(
          colnames(data),
          collapse = ", "
        )
      ),
      call. = FALSE
    )
  }

  NA_character_
}

clean_scalar_text <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  trimws(x)
}

# ------------------------------
# 2. Required-package preflight
# ------------------------------
required_packages <- c(
  "GEOquery",
  "Biobase"
)

package_available <- vapply(
  required_packages,
  requireNamespace,
  logical(1),
  quietly = TRUE
)

package_audit <- data.frame(
  package = required_packages,
  available = package_available,
  version = vapply(
    required_packages,
    function(package_i) {
      if (
        requireNamespace(
          package_i,
          quietly = TRUE
        )
      ) {
        as.character(
          utils::packageVersion(package_i)
        )
      } else {
        ""
      }
    },
    character(1)
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

if (!all(package_available)) {
  missing_packages <- required_packages[
    !package_available
  ]

  stop(
    paste0(
      "Required Bioconductor package(s) are missing: ",
      paste(
        missing_packages,
        collapse = ", "
      ),
      "\nInstall once with:\n",
      "if (!requireNamespace('BiocManager', quietly = TRUE)) ",
      "install.packages('BiocManager')\n",
      "BiocManager::install(c(",
      paste(
        sprintf("'%s'", missing_packages),
        collapse = ", "
      ),
      "))"
    ),
    call. = FALSE
  )
}

# ------------------------------
# 3. Download GSE95554 with retries
# ------------------------------
geo_accession <- "GSE95554"
expected_platform <- "GPL17117"
expected_sample_number <- 50L

download_attempt_audit <- data.frame(
  attempt = integer(0),
  start_time = character(0),
  end_time = character(0),
  succeeded = logical(0),
  warning_messages = character(0),
  error_message = character(0),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

geo_result <- NULL
last_error <- ""

for (attempt_i in seq_len(3L)) {
  attempt_start <- format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  )
  attempt_warnings <- character(0)
  attempt_error <- ""

  result_i <- tryCatch(
    withCallingHandlers(
      GEOquery::getGEO(
        GEO = geo_accession,
        GSEMatrix = TRUE,
        getGPL = FALSE,
        destdir = stage_download_dir
      ),
      warning = function(w) {
        attempt_warnings <<- c(
          attempt_warnings,
          conditionMessage(w)
        )
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      attempt_error <<- conditionMessage(e)
      NULL
    }
  )

  attempt_succeeded <- !is.null(result_i)

  download_attempt_audit <- rbind(
    download_attempt_audit,
    data.frame(
      attempt = attempt_i,
      start_time = attempt_start,
      end_time = format(
        Sys.time(),
        "%Y-%m-%d %H:%M:%S %Z"
      ),
      succeeded = attempt_succeeded,
      warning_messages = collapse_messages(
        attempt_warnings
      ),
      error_message = attempt_error,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  if (attempt_succeeded) {
    geo_result <- result_i
    break
  }

  last_error <- attempt_error

  if (attempt_i < 3L) {
    Sys.sleep(
      2L * attempt_i
    )
  }
}

if (is.null(geo_result)) {
  stop(
    paste0(
      "Unable to download GSE95554 after three attempts.\n",
      "Last error: ",
      last_error,
      "\nNo output directory was committed."
    ),
    call. = FALSE
  )
}

# GEOquery may return one ExpressionSet directly or a list of ExpressionSets.
if (
  inherits(
    geo_result,
    "ExpressionSet"
  )
) {
  geo_list <- list(
    geo_result
  )
} else if (
  is.list(geo_result) &&
    length(geo_result) >= 1L
) {
  geo_list <- geo_result
} else {
  stop(
    "GEOquery returned an unsupported object type.",
    call. = FALSE
  )
}

is_expression_set <- vapply(
  geo_list,
  function(object_i) {
    inherits(
      object_i,
      "ExpressionSet"
    )
  },
  logical(1)
)

assert_true(
  all(is_expression_set),
  "At least one GEOquery result is not an ExpressionSet."
)

platform_ids <- vapply(
  geo_list,
  function(object_i) {
    platform_i <- tryCatch(
      Biobase::annotation(object_i),
      error = function(e) ""
    )

    platform_i <- clean_scalar_text(
      platform_i
    )

    if (
      length(platform_i) == 0L ||
        !nzchar(platform_i[1])
    ) {
      platform_i <- tryCatch(
        clean_scalar_text(
          Biobase::experimentData(object_i)@other$platform_id
        ),
        error = function(e) ""
      )
    }

    if (
      length(platform_i) == 0L
    ) {
      ""
    } else {
      platform_i[1]
    }
  },
  character(1)
)

sample_counts <- vapply(
  geo_list,
  function(object_i) {
    length(
      Biobase::sampleNames(object_i)
    )
  },
  integer(1)
)

candidate_indices <- which(
  platform_ids == expected_platform
)

if (length(candidate_indices) == 0L) {
  candidate_indices <- which(
    sample_counts == expected_sample_number
  )
}

assert_true(
  length(candidate_indices) == 1L,
  paste0(
    "Unable to identify exactly one GPL17117/50-sample ExpressionSet.\n",
    "Detected platforms: ",
    paste(
      ifelse(
        nzchar(platform_ids),
        platform_ids,
        "<UNKNOWN>"
      ),
      collapse = ";"
    ),
    "\nDetected sample counts: ",
    paste(
      sample_counts,
      collapse = ";"
    )
  )
)

selected_index <- candidate_indices[1]
gse_eset <- geo_list[[selected_index]]

# ------------------------------
# 4. Extract and validate source objects
# ------------------------------
expression_matrix <- Biobase::exprs(
  gse_eset
)
phenotype_raw <- Biobase::pData(
  gse_eset
)
feature_raw <- Biobase::fData(
  gse_eset
)

assert_true(
  is.matrix(expression_matrix) &&
    is.numeric(expression_matrix),
  "The processed GEO expression object is not a numeric matrix."
)
assert_true(
  ncol(expression_matrix) == expected_sample_number,
  paste0(
    "Expected 50 samples, detected ",
    ncol(expression_matrix),
    "."
  )
)
assert_true(
  nrow(expression_matrix) > 10000L,
  paste0(
    "Unexpectedly small feature count: ",
    nrow(expression_matrix),
    "."
  )
)
assert_true(
  sum(!is.finite(expression_matrix)) == 0L,
  "The processed expression matrix contains non-finite values."
)
assert_true(
  !is.null(
    rownames(expression_matrix)
  ) &&
    length(
      rownames(expression_matrix)
    ) == nrow(expression_matrix) &&
    all(
      nzchar(
        rownames(expression_matrix)
      )
    ) &&
    anyDuplicated(
      rownames(expression_matrix)
    ) == 0L,
  "Expression feature identifiers are missing, blank or duplicated."
)
assert_true(
  !is.null(
    colnames(expression_matrix)
  ) &&
    length(
      colnames(expression_matrix)
    ) == ncol(expression_matrix) &&
    all(
      nzchar(
        colnames(expression_matrix)
      )
    ) &&
    anyDuplicated(
      colnames(expression_matrix)
    ) == 0L,
  "Expression sample identifiers are missing, blank or duplicated."
)
assert_true(
  is.data.frame(phenotype_raw) &&
    nrow(phenotype_raw) == expected_sample_number,
  "The GEO phenotype table is missing or does not contain 50 rows."
)
assert_true(
  identical(
    rownames(phenotype_raw),
    colnames(expression_matrix)
  ),
  "Phenotype rows and expression columns are not identically ordered."
)

# ------------------------------
# 5. Reconstruct the experimental design
# ------------------------------
title_column <- first_existing_column(
  phenotype_raw,
  c(
    "title",
    "sample_title",
    "sample.title"
  )
)

accession_column <- first_existing_column(
  phenotype_raw,
  c(
    "geo_accession",
    "geo.accession",
    "accession"
  ),
  required = FALSE
)

sample_title <- clean_scalar_text(
  phenotype_raw[[title_column]]
)

sample_accession <- if (
  is.na(accession_column)
) {
  rownames(phenotype_raw)
} else {
  clean_scalar_text(
    phenotype_raw[[accession_column]]
  )
}

sample_accession[
  !nzchar(sample_accession)
] <- rownames(phenotype_raw)[
  !nzchar(sample_accession)
]

title_pattern <- paste0(
  "^(DEP|MPB|TCS|MIX|OIL)_",
  "(null|par)_",
  "([0-9]+)$"
)

title_matches <- regexec(
  title_pattern,
  sample_title,
  perl = TRUE
)
title_parts <- regmatches(
  sample_title,
  title_matches
)

title_parse_success <- lengths(
  title_parts
) == 4L

assert_true(
  all(title_parse_success),
  paste0(
    "At least one sample title does not match the expected pattern ",
    "EXPOSURE_null/par_ANIMALID.\n",
    "Unparsed titles: ",
    paste(
      sample_title[
        !title_parse_success
      ],
      collapse = ";"
    )
  )
)

exposure_code <- vapply(
  title_parts,
  function(parts_i) {
    parts_i[2]
  },
  character(1)
)

state_code <- vapply(
  title_parts,
  function(parts_i) {
    parts_i[3]
  },
  character(1)
)

animal_id <- vapply(
  title_parts,
  function(parts_i) {
    parts_i[4]
  },
  character(1)
)

exposure_label <- factor(
  exposure_code,
  levels = c(
    "OIL",
    "TCS",
    "DEP",
    "MPB",
    "MIX"
  )
)

reproductive_state <- factor(
  ifelse(
    state_code == "null",
    "NULLIPAROUS",
    "PAROUS"
  ),
  levels = c(
    "NULLIPAROUS",
    "PAROUS"
  )
)

group_id <- paste(
  exposure_code,
  state_code,
  sep = "_"
)

design_table <- data.frame(
  sample_order = seq_len(
    expected_sample_number
  ),
  sample_id = colnames(
    expression_matrix
  ),
  GEO_accession = sample_accession,
  sample_title = sample_title,
  exposure_code = exposure_code,
  exposure_label = as.character(
    exposure_label
  ),
  reproductive_state_code = state_code,
  reproductive_state = as.character(
    reproductive_state
  ),
  animal_id = animal_id,
  exposure_state_group = group_id,
  primary_TCS_or_OIL_subset =
    exposure_code %in% c(
      "TCS",
      "OIL"
    ),
  primary_nulliparous_subset =
    exposure_code %in% c(
      "TCS",
      "OIL"
    ) &
      state_code == "null",
  primary_parous_subset =
    exposure_code %in% c(
      "TCS",
      "OIL"
    ) &
      state_code == "par",
  expression_sample_order_identical = TRUE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  identical(
    design_table$sample_id,
    colnames(expression_matrix)
  ),
  "Design-table sample order differs from the expression matrix."
)
assert_true(
  anyDuplicated(
    design_table$GEO_accession
  ) == 0L,
  "GEO sample accessions are duplicated."
)
assert_true(
  anyDuplicated(
    design_table$sample_title
  ) == 0L,
  "GEO sample titles are duplicated."
)
assert_true(
  anyDuplicated(
    paste(
      design_table$exposure_code,
      design_table$animal_id,
      sep = "_"
    )
  ) == 0L,
  "Exposure-specific animal identifiers are duplicated."
)

expected_exposures <- c(
  "DEP",
  "MIX",
  "MPB",
  "OIL",
  "TCS"
)
observed_exposures <- sort(
  unique(
    design_table$exposure_code
  )
)

assert_true(
  identical(
    observed_exposures,
    expected_exposures
  ),
  paste0(
    "Observed exposure groups differ from the expected five groups.\n",
    "Observed: ",
    paste(
      observed_exposures,
      collapse = ";"
    )
  )
)

observed_states <- sort(
  unique(
    design_table$reproductive_state_code
  )
)

assert_true(
  identical(
    observed_states,
    c("null", "par")
  ),
  "Observed reproductive-state codes differ from null/par."
)

group_count_table <- as.data.frame(
  table(
    exposure_code =
      design_table$exposure_code,
    reproductive_state_code =
      design_table$reproductive_state_code
  ),
  stringsAsFactors = FALSE
)

colnames(group_count_table)[
  colnames(group_count_table) == "Freq"
] <- "sample_number"

group_count_table <- group_count_table[
  order(
    group_count_table$exposure_code,
    group_count_table$reproductive_state_code
  ),
  ,
  drop = FALSE
]

rownames(group_count_table) <- NULL

assert_true(
  nrow(group_count_table) == 10L &&
    all(group_count_table$sample_number == 5L),
  paste0(
    "The expected 10 groups with five animals each were not recovered.\n",
    paste(
      apply(
        group_count_table,
        1L,
        paste,
        collapse = ":"
      ),
      collapse = " | "
    )
  )
)

assert_true(
  sum(
    design_table$primary_TCS_or_OIL_subset
  ) == 20L,
  "The TCS/OIL primary subset does not contain 20 samples."
)
assert_true(
  sum(
    design_table$primary_nulliparous_subset
  ) == 10L,
  "The nulliparous TCS/OIL subset does not contain 10 samples."
)
assert_true(
  sum(
    design_table$primary_parous_subset
  ) == 10L,
  "The parous TCS/OIL subset does not contain 10 samples."
)

# ------------------------------
# 6. Expression-distribution audit
# ------------------------------
all_values <- as.numeric(
  expression_matrix
)

expression_summary <- data.frame(
  item = c(
    "feature_number",
    "sample_number",
    "finite_value_number",
    "nonfinite_value_number",
    "minimum",
    "first_quartile",
    "median",
    "mean",
    "third_quartile",
    "maximum",
    "standard_deviation",
    "first_percentile",
    "ninety_ninth_percentile",
    "likely_log2_processed_scale",
    "expression_values_modified",
    "expression_values_log_transformed",
    "expression_values_normalized_in_Script12A",
    "features_filtered_in_Script12A",
    "samples_filtered_in_Script12A"
  ),
  value = c(
    nrow(expression_matrix),
    ncol(expression_matrix),
    sum(is.finite(all_values)),
    sum(!is.finite(all_values)),
    min(all_values),
    safe_quantile(all_values, 0.25),
    stats::median(all_values),
    mean(all_values),
    safe_quantile(all_values, 0.75),
    max(all_values),
    stats::sd(all_values),
    safe_quantile(all_values, 0.01),
    safe_quantile(all_values, 0.99),
    max(all_values) < 30 &&
      safe_quantile(all_values, 0.99) < 25,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

sample_distribution_rows <- vector(
  "list",
  ncol(expression_matrix)
)

for (i in seq_len(
  ncol(expression_matrix)
)) {
  values_i <- expression_matrix[, i]

  sample_distribution_rows[[i]] <- data.frame(
    sample_order = i,
    sample_id = colnames(expression_matrix)[i],
    GEO_accession = design_table$GEO_accession[i],
    sample_title = design_table$sample_title[i],
    exposure_code = design_table$exposure_code[i],
    reproductive_state_code =
      design_table$reproductive_state_code[i],
    finite_feature_number =
      sum(is.finite(values_i)),
    nonfinite_feature_number =
      sum(!is.finite(values_i)),
    minimum = min(values_i),
    first_quartile =
      safe_quantile(values_i, 0.25),
    median = stats::median(values_i),
    mean = mean(values_i),
    third_quartile =
      safe_quantile(values_i, 0.75),
    maximum = max(values_i),
    standard_deviation =
      stats::sd(values_i),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

sample_distribution_audit <- do.call(
  rbind,
  sample_distribution_rows
)
rownames(sample_distribution_audit) <- NULL

assert_true(
  nrow(sample_distribution_audit) ==
    expected_sample_number,
  "Sample-distribution audit does not contain 50 rows."
)
assert_true(
  all(
    sample_distribution_audit$
      nonfinite_feature_number == 0L
  ),
  "At least one sample contains a non-finite expression value."
)

# ------------------------------
# 7. Feature and phenotype-column audits
# ------------------------------
feature_audit <- data.frame(
  feature_order = seq_len(
    nrow(expression_matrix)
  ),
  feature_id = rownames(
    expression_matrix
  ),
  present_in_feature_data =
    rownames(expression_matrix) %in%
      rownames(feature_raw),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

phenotype_column_audit <- data.frame(
  column_order = seq_len(
    ncol(phenotype_raw)
  ),
  column_name = colnames(
    phenotype_raw
  ),
  nonmissing_number = vapply(
    phenotype_raw,
    function(column_i) {
      sum(
        !is.na(column_i) &
          nzchar(
            trimws(
              as.character(column_i)
            )
          )
      )
    },
    integer(1)
  ),
  unique_nonmissing_number = vapply(
    phenotype_raw,
    function(column_i) {
      values_i <- trimws(
        as.character(column_i)
      )
      values_i <- values_i[
        !is.na(values_i) &
          nzchar(values_i)
      ]
      length(unique(values_i))
    },
    integer(1)
  ),
  selected_for_design = colnames(
    phenotype_raw
  ) %in% c(
    title_column,
    if (
      is.na(accession_column)
    ) {
      character(0)
    } else {
      accession_column
    }
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 8. Downloaded-file audit
# ------------------------------
downloaded_files <- list.files(
  stage_download_dir,
  recursive = TRUE,
  full.names = TRUE,
  all.files = FALSE
)

assert_true(
  length(downloaded_files) >= 1L,
  paste0(
    "GEOquery returned an object but no source file was retained in ",
    "the download directory."
  )
)

download_manifest <- make_manifest(
  downloaded_files,
  downloaded_files
)

# ------------------------------
# 9. Integrity summary
# ------------------------------
selected_platform_id <- platform_ids[
  selected_index
]

if (
  length(selected_platform_id) == 0L ||
    !nzchar(selected_platform_id)
) {
  selected_platform_id <- expected_platform
}

integrity_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Script_build_ID",
    "Organism_expected",
    "Platform_expected",
    "Platform_selected",
    "Expression_feature_number",
    "Expression_sample_number",
    "Phenotype_row_number",
    "Feature_data_row_number",
    "Expression_phenotype_order_identical",
    "Unique_expression_feature_IDs",
    "Unique_expression_sample_IDs",
    "Nonfinite_expression_values",
    "Exposure_group_number",
    "Reproductive_state_number",
    "Exposure_by_state_group_number",
    "Every_group_has_five_animals",
    "TCS_total_samples",
    "OIL_total_samples",
    "TCS_OIL_primary_subset_samples",
    "TCS_OIL_nulliparous_samples",
    "TCS_OIL_parous_samples",
    "Processed_series_matrix_used",
    "Raw_CEL_archive_downloaded",
    "Expression_values_modified",
    "Differential_expression_performed",
    "Ortholog_mapping_performed",
    "Completion_status"
  ),
  value = c(
    geo_accession,
    "12A",
    SCRIPT_BUILD_ID,
    "Rattus norvegicus",
    expected_platform,
    selected_platform_id,
    nrow(expression_matrix),
    ncol(expression_matrix),
    nrow(phenotype_raw),
    nrow(feature_raw),
    identical(
      rownames(phenotype_raw),
      colnames(expression_matrix)
    ),
    anyDuplicated(
      rownames(expression_matrix)
    ) == 0L,
    anyDuplicated(
      colnames(expression_matrix)
    ) == 0L,
    sum(!is.finite(expression_matrix)),
    length(
      unique(
        design_table$exposure_code
      )
    ),
    length(
      unique(
        design_table$reproductive_state_code
      )
    ),
    nrow(group_count_table),
    all(
      group_count_table$sample_number == 5L
    ),
    sum(
      design_table$exposure_code == "TCS"
    ),
    sum(
      design_table$exposure_code == "OIL"
    ),
    sum(
      design_table$primary_TCS_or_OIL_subset
    ),
    sum(
      design_table$primary_nulliparous_subset
    ),
    sum(
      design_table$primary_parous_subset
    ),
    TRUE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Save all staging outputs
# ------------------------------
stage_eset_file <- file.path(
  stage_object_dir,
  "GSE95554_GPL17117_processed_ExpressionSet_SOURCE.rds"
)
stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE95554_preflight_COMPLETE_bundle.rds"
)
stage_design_file <- file.path(
  stage_audit_dir,
  "GSE95554_experimental_design_all50.csv"
)
stage_group_file <- file.path(
  stage_audit_dir,
  "GSE95554_exposure_by_state_group_counts.csv"
)
stage_expression_file <- file.path(
  stage_audit_dir,
  "GSE95554_processed_expression_distribution_summary.csv"
)
stage_sample_distribution_file <- file.path(
  stage_audit_dir,
  "GSE95554_sample_expression_distribution_audit.csv"
)
stage_feature_file <- file.path(
  stage_audit_dir,
  "GSE95554_feature_ID_audit.csv"
)
stage_phenotype_column_file <- file.path(
  stage_audit_dir,
  "GSE95554_phenotype_column_audit.csv"
)
stage_download_attempt_file <- file.path(
  stage_audit_dir,
  "GSE95554_download_attempt_audit.csv"
)
stage_download_manifest_file <- file.path(
  stage_audit_dir,
  "GSE95554_downloaded_source_files_with_MD5.csv"
)
stage_package_file <- file.path(
  stage_audit_dir,
  "Script12A_package_audit.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE95554_preflight_integrity_summary.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script12A_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script12A_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script12A_COMPLETE_report.txt"
)

saveRDS(
  gse_eset,
  stage_eset_file,
  compress = "gzip"
)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step3_GSE95554_real_exposure_validation",
  script = "Script12A",
  script_build_id = SCRIPT_BUILD_ID,
  created_at = format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  ),
  source_accession = geo_accession,
  source_platform = selected_platform_id,
  source_organism = "Rattus norvegicus",
  source_processed_ExpressionSet_file =
    normalizePath(
      stage_eset_file,
      winslash = "/",
      mustWork = FALSE
    ),
  expression_matrix = expression_matrix,
  phenotype_raw = phenotype_raw,
  feature_data_raw = feature_raw,
  design_table = design_table,
  group_count_table = group_count_table,
  expression_summary = expression_summary,
  sample_distribution_audit =
    sample_distribution_audit,
  feature_audit = feature_audit,
  phenotype_column_audit =
    phenotype_column_audit,
  download_attempt_audit =
    download_attempt_audit,
  download_manifest =
    download_manifest,
  package_audit = package_audit,
  integrity_summary = integrity_summary,
  policy = list(
    processed_series_matrix_used = TRUE,
    raw_CEL_archive_downloaded = FALSE,
    expression_values_modified = FALSE,
    expression_values_log_transformed = FALSE,
    expression_values_normalized = FALSE,
    features_filtered = FALSE,
    samples_filtered = FALSE,
    differential_expression_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    ortholog_mapping_performed = FALSE,
    primary_future_comparison =
      "TCS versus OIL within reproductive state",
    nulliparous_primary_subset_number = 10L,
    parous_primary_subset_number = 10L
  ),
  provenance = list(
    GEOquery_version =
      package_audit$version[
        package_audit$package == "GEOquery"
      ],
    Biobase_version =
      package_audit$version[
        package_audit$package == "Biobase"
      ],
    download_attempt_number =
      nrow(download_attempt_audit),
    next_step_requires_review_of = c(
      "expression dimensions and distributions",
      "feature annotation availability",
      "TCS/OIL sample design"
    )
  )
)

class(complete_bundle) <- c(
  "GSE95554_preflight_bundle",
  "list"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)

write_csv_utf8(
  design_table,
  stage_design_file
)
write_csv_utf8(
  group_count_table,
  stage_group_file
)
write_csv_utf8(
  expression_summary,
  stage_expression_file
)
write_csv_utf8(
  sample_distribution_audit,
  stage_sample_distribution_file
)
write_csv_utf8(
  feature_audit,
  stage_feature_file
)
write_csv_utf8(
  phenotype_column_audit,
  stage_phenotype_column_file
)
write_csv_utf8(
  download_attempt_audit,
  stage_download_attempt_file
)
write_csv_utf8(
  download_manifest,
  stage_download_manifest_file
)
write_csv_utf8(
  package_audit,
  stage_package_file
)
write_csv_utf8(
  integrity_summary,
  stage_summary_file
)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# Read-back validation.
bundle_check <- readRDS(
  stage_bundle_file
)
eset_check <- readRDS(
  stage_eset_file
)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "script_build_id",
      "expression_matrix",
      "phenotype_raw",
      "feature_data_raw",
      "design_table",
      "group_count_table",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 12A bundle is missing required fields."
)
assert_true(
  identical(
    as.character(
      bundle_check$script_build_id
    ),
    SCRIPT_BUILD_ID
  ),
  "Saved Script 12A build ID is incorrect."
)
assert_true(
  inherits(
    eset_check,
    "ExpressionSet"
  ),
  "Saved source ExpressionSet cannot be read back."
)
assert_true(
  identical(
    dim(
      bundle_check$expression_matrix
    ),
    dim(expression_matrix)
  ),
  "Saved expression dimensions changed."
)
assert_true(
  identical(
    colnames(
      bundle_check$expression_matrix
    ),
    design_table$sample_id
  ),
  "Saved expression/design sample order changed."
)
assert_true(
  isFALSE(
    bundle_check$policy$
      expression_values_modified
  ) &&
    isFALSE(
      bundle_check$policy$
        differential_expression_performed
    ) &&
    isFALSE(
      bundle_check$policy$
        ortholog_mapping_performed
    ),
  "Saved Script 12A policy incorrectly indicates downstream analysis."
)

source_eset_md5 <- md5_one(
  stage_eset_file
)
bundle_md5 <- md5_one(
  stage_bundle_file
)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 3 - Script 12A",
  "GSE95554 processed-data and design preflight",
  paste0(
    "Script build ID: ",
    SCRIPT_BUILD_ID
  ),
  "============================================================",
  paste0(
    "Completion time: ",
    format(
      Sys.time(),
      "%Y-%m-%d %H:%M:%S %Z"
    )
  ),
  paste0(
    "GEO accession: ",
    geo_accession
  ),
  paste0(
    "Selected platform: ",
    selected_platform_id
  ),
  paste0(
    "Expression dimensions: ",
    nrow(expression_matrix),
    " features x ",
    ncol(expression_matrix),
    " samples"
  ),
  paste0(
    "Phenotype rows: ",
    nrow(phenotype_raw)
  ),
  paste0(
    "Feature-data rows: ",
    nrow(feature_raw)
  ),
  paste0(
    "Non-finite expression values: ",
    sum(
      !is.finite(
        expression_matrix
      )
    )
  ),
  paste0(
    "Exposure groups: ",
    paste(
      sort(
        unique(
          design_table$exposure_code
        )
      ),
      collapse = ";"
    )
  ),
  paste0(
    "Reproductive-state codes: ",
    paste(
      sort(
        unique(
          design_table$
            reproductive_state_code
        )
      ),
      collapse = ";"
    )
  ),
  paste0(
    "Exposure-by-state groups: ",
    nrow(group_count_table)
  ),
  paste0(
    "All groups contain five animals: ",
    all(
      group_count_table$
        sample_number == 5L
    )
  ),
  paste0(
    "TCS samples: ",
    sum(
      design_table$
        exposure_code == "TCS"
    )
  ),
  paste0(
    "OIL vehicle samples: ",
    sum(
      design_table$
        exposure_code == "OIL"
    )
  ),
  paste0(
    "TCS/OIL nulliparous subset: ",
    sum(
      design_table$
        primary_nulliparous_subset
    )
  ),
  paste0(
    "TCS/OIL parous subset: ",
    sum(
      design_table$
        primary_parous_subset
    )
  ),
  paste0(
    "Likely processed log2-scale matrix: ",
    expression_summary$value[
      expression_summary$item ==
        "likely_log2_processed_scale"
    ]
  ),
  paste0(
    "Download attempts used: ",
    nrow(download_attempt_audit)
  ),
  paste0(
    "Source ExpressionSet MD5: ",
    source_eset_md5
  ),
  paste0(
    "Preflight bundle MD5: ",
    bundle_md5
  ),
  "Processed series matrix used: TRUE",
  "Raw CEL archive downloaded: FALSE",
  "Expression values modified: FALSE",
  "Differential expression performed: FALSE",
  "Ortholog mapping performed: FALSE",
  "",
  "SCRIPT12A STATUS: COMPLETE",
  paste0(
    "GSE95554 was downloaded and its 50-sample experimental design was ",
    "verified. No biological comparison was performed."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(
    report_lines
  ),
  con = stage_report_file,
  useBytes = TRUE
)

# Output manifest excludes itself but includes retained GEO source downloads.
output_files_before_manifest <- c(
  stage_eset_file,
  stage_bundle_file,
  stage_design_file,
  stage_group_file,
  stage_expression_file,
  stage_sample_distribution_file,
  stage_feature_file,
  stage_phenotype_column_file,
  stage_download_attempt_file,
  stage_download_manifest_file,
  stage_package_file,
  stage_summary_file,
  stage_session_file,
  stage_report_file,
  downloaded_files
)

output_files_before_manifest <- unique(
  output_files_before_manifest
)

assert_true(
  all(
    file.exists(
      output_files_before_manifest
    )
  ),
  "At least one staged Script 12A output is missing."
)
assert_true(
  all(
    file.info(
      output_files_before_manifest
    )$size > 0
  ),
  "At least one staged Script 12A output is empty."
)

output_manifest <- make_manifest(
  output_files_before_manifest,
  output_files_before_manifest
)

write_csv_utf8(
  output_manifest,
  stage_output_manifest_file
)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) ==
    length(output_files_before_manifest),
  "Script 12A output manifest has an incorrect row count."
)

for (i in seq_along(
  output_files_before_manifest
)) {
  file_i <- output_files_before_manifest[i]
  row_i <- manifest_check[
    manifest_check$relative_path ==
      make_manifest(
        file_i,
        file_i
      )$relative_path,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0(
      "Missing or duplicated manifest row for: ",
      file_i
    )
  )
  assert_true(
    identical(
      tolower(
        as.character(
          row_i$md5
        )
      ),
      tolower(
        md5_one(file_i)
      )
    ),
    paste0(
      "Manifest MD5 mismatch for: ",
      file_i
    )
  )
  assert_true(
    as.numeric(
      row_i$size_bytes
    ) ==
      as.numeric(
        file.info(file_i)$size
      ),
    paste0(
      "Manifest size mismatch for: ",
      file_i
    )
  )
}

# ------------------------------
# 11. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 12A directory appeared during staging."
)

rename_ok <- file.rename(
  stage_root,
  final_root
)

if (!isTRUE(rename_ok)) {
  dir.create(
    final_root,
    recursive = TRUE,
    showWarnings = FALSE
  )

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 12A staging directory."
  )

  unlink(
    stage_root,
    recursive = TRUE,
    force = TRUE
  )
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE95554_preflight_COMPLETE_bundle.rds"
)
final_eset_file <- file.path(
  final_root,
  "objects",
  "GSE95554_GPL17117_processed_ExpressionSet_SOURCE.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script12A_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script12A_output_manifest_with_MD5.csv"
)

assert_true(
  all(
    file.exists(c(
      final_bundle_file,
      final_eset_file,
      final_report_file,
      final_manifest_file
    ))
  ),
  "Committed Script 12A output is incomplete."
)
assert_true(
  identical(
    md5_one(final_bundle_file),
    bundle_md5
  ),
  "Committed Script 12A bundle MD5 changed after commit."
)
assert_true(
  identical(
    md5_one(final_eset_file),
    source_eset_md5
  ),
  "Committed source ExpressionSet MD5 changed after commit."
)
assert_true(
  any(
    grepl(
      "SCRIPT12A STATUS: COMPLETE",
      readLines(
        final_report_file,
        warn = FALSE,
        encoding = "UTF-8"
      ),
      fixed = TRUE
    )
  ),
  "Committed Script 12A report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 12A completed successfully.\n")
cat(
  "Expression matrix: ",
  nrow(expression_matrix),
  " x ",
  ncol(expression_matrix),
  "\n",
  sep = ""
)
cat(
  "Verified exposure-by-state groups: ",
  nrow(group_count_table),
  "\n",
  sep = ""
)
cat(
  "Every group has five animals: ",
  all(
    group_count_table$sample_number == 5L
  ),
  "\n",
  sep = ""
)
cat(
  "TCS/OIL primary samples: ",
  sum(
    design_table$
      primary_TCS_or_OIL_subset
  ),
  "\n",
  sep = ""
)
cat("Expression values modified: FALSE\n")
cat("Differential expression performed: FALSE\n")
cat("Ortholog mapping performed: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat(
  "Bundle MD5: ",
  md5_one(
    final_bundle_file
  ),
  "\n",
  sep = ""
)
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

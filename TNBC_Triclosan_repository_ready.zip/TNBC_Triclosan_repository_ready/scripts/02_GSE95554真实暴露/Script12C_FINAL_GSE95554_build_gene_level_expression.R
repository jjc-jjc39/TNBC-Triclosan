# ==============================================================================
# TNBC_Triclosan
# Step 3 - GSE95554 real Triclosan exposure validation
# Script 12C FINAL
#
# Purpose:
#   Continue strictly from the accepted Script 12A preflight bundle and
#   Script 12B annotation-audit bundle. Build a gene-level rat expression
#   matrix using only unambiguous Bioconductor ChipDb mappings.
#
# Prespecified mapping and aggregation policy:
#   1) Primary annotation source:
#      ragene20sttranscriptcluster.db, as audited in Script 12B.
#   2) Include only transcript clusters with exactly one rat gene SYMBOL and
#      exactly one ENTREZID.
#   3) Exclude, without imputation:
#      - transcript clusters with no gene symbol;
#      - transcript clusters mapped to more than one gene symbol;
#      - any symbol/Entrez mapping inconsistency.
#   4) For a gene represented by one transcript cluster, retain that row.
#   5) For a gene represented by multiple eligible transcript clusters,
#      aggregate per sample using the median.
#   6) Preserve all 50 samples and their accepted Script 12A order.
#
# This script DOES:
#   - verify accepted Script 12A and Script 12B reports, manifests and MD5s;
#   - rebuild the gene-level matrix from saved disk objects only;
#   - create complete feature-inclusion and gene-aggregation audits;
#   - audit exact/case-insensitive coverage of the locked 24-gene signature;
#   - save RDS objects, CSV audits, MD5 manifests, report and sessionInfo.
#
# This script DOES NOT:
#   - normalize, log-transform or impute expression values;
#   - use GEO GPL annotation as the primary mapping source;
#   - select transcript clusters by variance, differential expression or
#     biological outcome;
#   - perform rat-to-human ortholog mapping;
#   - substitute ABCB1 with Abcb1a/Abcb1b;
#   - perform PCA, DEG, GSVA, GSEA or TCS-versus-OIL testing.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

SCRIPT_BUILD_ID <- "Script12C_FINAL_20260711"

cat("============================================================\n")
cat("RUNNING: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat("Unique ChipDb SYMBOL + ENTREZID mapping: ENABLED\n")
cat("Multi-feature gene aggregation by median: ENABLED\n")
cat("Expression renormalization and imputation: DISABLED\n")
cat("Ortholog mapping and differential expression: DISABLED\n")
cat("============================================================\n")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step3_GSE95554_real_exposure_validation"
)

preflight_root <- file.path(
  step_root,
  "00_preflight"
)
annotation_root <- file.path(
  step_root,
  "01_probe_annotation_audit"
)
final_root <- file.path(
  step_root,
  "02_gene_level_expression"
)

preflight_bundle_file <- file.path(
  preflight_root,
  "objects",
  "GSE95554_preflight_COMPLETE_bundle.rds"
)
preflight_manifest_file <- file.path(
  preflight_root,
  "audit",
  "Script12A_output_manifest_with_MD5.csv"
)
preflight_report_file <- file.path(
  preflight_root,
  "logs",
  "Script12A_COMPLETE_report.txt"
)

annotation_bundle_file <- file.path(
  annotation_root,
  "objects",
  "GSE95554_probe_annotation_AUDIT_bundle.rds"
)
annotation_manifest_file <- file.path(
  annotation_root,
  "audit",
  "Script12B_output_manifest_with_MD5.csv"
)
annotation_report_file <- file.path(
  annotation_root,
  "logs",
  "Script12B_COMPLETE_report.txt"
)
annotation_summary_file <- file.path(
  annotation_root,
  "audit",
  "GSE95554_probe_annotation_integrity_summary.csv"
)

required_inputs <- c(
  preflight_bundle_file,
  preflight_manifest_file,
  preflight_report_file,
  annotation_bundle_file,
  annotation_manifest_file,
  annotation_report_file,
  annotation_summary_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 12C cannot start because required accepted files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop(
    paste0(
      "Step 3 directory does not exist:\n",
      step_root
    ),
    call. = FALSE
  )
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(
      final_root,
      all.files = TRUE
    ),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(
      final_root,
      recursive = TRUE,
      force = TRUE
    )
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 12C will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive that directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(
  Sys.time(),
  "%Y%m%d_%H%M%S"
)

stage_root <- file.path(
  step_root,
  paste0(
    ".Script12C_staging_",
    stamp,
    "_",
    Sys.getpid()
  )
)
stage_object_dir <- file.path(
  stage_root,
  "objects"
)
stage_audit_dir <- file.path(
  stage_root,
  "audit"
)
stage_log_dir <- file.path(
  stage_root,
  "logs"
)

for (directory_i in c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)) {
  dir.create(
    directory_i,
    recursive = TRUE,
    showWarnings = FALSE
  )
}

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop(
    "Unable to create Script 12C staging directories.",
    call. = FALSE
  )
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(
      stage_root,
      recursive = TRUE,
      force = TRUE
    )
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) {
    stop(
      message,
      call. = FALSE
    )
  }
}

md5_one <- function(path) {
  unname(
    tools::md5sum(path)
  )
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(
    report_file,
    warn = FALSE,
    encoding = "UTF-8"
  )

  any(
    grepl(
      fixed_text,
      lines,
      fixed = TRUE
    )
  )
}

manifest_expected_md5 <- function(
  manifest_file,
  target_file
) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c(
      "file_name",
      "size_bytes",
      "md5"
    ) %in% colnames(manifest)),
    paste0(
      "Malformed manifest:\n",
      manifest_file
    )
  )

  row_index <- which(
    manifest$file_name ==
      basename(target_file)
  )

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file),
      "."
    )
  )

  tolower(
    trimws(
      as.character(
        manifest$md5[row_index]
      )
    )
  )
}

make_manifest <- function(paths) {
  assert_true(
    length(paths) >= 1L,
    "Cannot create an empty manifest."
  )

  info <- file.info(paths)

  data.frame(
    file_name = basename(paths),
    absolute_path = vapply(
      paths,
      function(path_i) {
        normalizePath(
          path_i,
          winslash = "/",
          mustWork = FALSE
        )
      },
      character(1)
    ),
    size_bytes = as.numeric(
      info$size
    ),
    md5 = vapply(
      paths,
      md5_one,
      character(1)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

clean_text <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  trimws(x)
}

split_semicolon_values <- function(x) {
  x <- clean_text(x)

  if (!nzchar(x)) {
    return(character(0))
  }

  values <- unlist(
    strsplit(
      x,
      split = ";",
      fixed = TRUE
    ),
    use.names = FALSE
  )

  values <- clean_text(values)
  sort(
    unique(
      values[nzchar(values)]
    )
  )
}

collapse_distinct_semicolon <- function(x) {
  values <- sort(
    unique(
      clean_text(x)
    )
  )
  values <- values[nzchar(values)]

  if (length(values) == 0L) {
    ""
  } else {
    paste(
      values,
      collapse = ";"
    )
  }
}

safe_integer <- function(x, field_name) {
  result <- suppressWarnings(
    as.integer(
      as.character(x)
    )
  )

  assert_true(
    length(result) == length(x) &&
      !any(is.na(result)),
    paste0(
      "Column ",
      field_name,
      " cannot be converted completely to integer."
    )
  )

  result
}

aggregate_gene_row <- function(
  feature_indices,
  expression_matrix
) {
  assert_true(
    length(feature_indices) >= 1L,
    "A gene aggregation group is empty."
  )

  if (length(feature_indices) == 1L) {
    result <- as.numeric(
      expression_matrix[
        feature_indices,
        ,
        drop = TRUE
      ]
    )
  } else {
    result <- apply(
      expression_matrix[
        feature_indices,
        ,
        drop = FALSE
      ],
      2L,
      stats::median,
      na.rm = FALSE
    )
  }

  assert_true(
    length(result) ==
      ncol(expression_matrix) &&
      all(is.finite(result)),
    "A gene aggregation result has invalid length or non-finite values."
  )

  as.numeric(result)
}

# ------------------------------
# 2. Verify accepted input identities
# ------------------------------
assert_true(
  report_contains(
    preflight_report_file,
    "SCRIPT12A STATUS: COMPLETE"
  ),
  "Script 12A completion marker was not found."
)
assert_true(
  report_contains(
    preflight_report_file,
    "Script build ID: Script12A_FINAL_20260710"
  ),
  "Script 12A report is not from the accepted FINAL build."
)
assert_true(
  report_contains(
    annotation_report_file,
    "SCRIPT12B STATUS: COMPLETE"
  ),
  "Script 12B completion marker was not found."
)
assert_true(
  report_contains(
    annotation_report_file,
    "Script build ID: Script12B_FINAL_20260710"
  ),
  "Script 12B report is not from the accepted FINAL build."
)

expected_preflight_md5 <- manifest_expected_md5(
  preflight_manifest_file,
  preflight_bundle_file
)
observed_preflight_md5 <- tolower(
  md5_one(
    preflight_bundle_file
  )
)
accepted_preflight_md5 <-
  "ad2d27f5ba68419461aae01b3a7153c3"

assert_true(
  identical(
    expected_preflight_md5,
    observed_preflight_md5
  ),
  "Script 12A bundle MD5 differs from its manifest."
)
assert_true(
  identical(
    observed_preflight_md5,
    accepted_preflight_md5
  ),
  paste0(
    "Script 12A bundle differs from the independently accepted bundle.\n",
    "Expected: ",
    accepted_preflight_md5,
    "\nObserved: ",
    observed_preflight_md5
  )
)

expected_annotation_md5 <- manifest_expected_md5(
  annotation_manifest_file,
  annotation_bundle_file
)
observed_annotation_md5 <- tolower(
  md5_one(
    annotation_bundle_file
  )
)
accepted_annotation_md5 <-
  "369c5c782ca0f4041725185e83c8db80"

assert_true(
  identical(
    expected_annotation_md5,
    observed_annotation_md5
  ),
  "Script 12B bundle MD5 differs from its manifest."
)
assert_true(
  identical(
    observed_annotation_md5,
    accepted_annotation_md5
  ),
  paste0(
    "Script 12B bundle differs from the independently accepted bundle.\n",
    "Expected: ",
    accepted_annotation_md5,
    "\nObserved: ",
    observed_annotation_md5
  )
)

annotation_summary <- read.csv(
  annotation_summary_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(c(
    "item",
    "value"
  ) %in% colnames(annotation_summary)),
  "Script 12B annotation summary is malformed."
)
assert_true(
  anyDuplicated(
    annotation_summary$item
  ) == 0L,
  "Script 12B annotation summary contains duplicated items."
)

annotation_lookup <- setNames(
  as.character(
    annotation_summary$value
  ),
  annotation_summary$item
)

required_annotation_items <- c(
  "Expression_features_verified",
  "Expression_samples_verified",
  "ChipDb_features_with_unique_symbol",
  "ChipDb_features_with_multiple_symbols",
  "ChipDb_features_without_symbol",
  "Locked_signature_genes_with_case_insensitive_rat_symbol_match",
  "Primary_future_annotation_source",
  "Gene_level_aggregation_performed",
  "Completion_status"
)

assert_true(
  all(
    required_annotation_items %in%
      names(annotation_lookup)
  ),
  "Script 12B annotation summary is missing required items."
)

assert_true(
  identical(
    annotation_lookup[["Completion_status"]],
    "COMPLETE"
  ) &&
    identical(
      annotation_lookup[["Primary_future_annotation_source"]],
      "BIOCONDUCTOR_CHIPDB"
    ) &&
    identical(
      annotation_lookup[["Gene_level_aggregation_performed"]],
      "FALSE"
    ),
  "Script 12B summary does not preserve the accepted annotation policy."
)

# ------------------------------
# 3. Load and validate input bundles
# ------------------------------
preflight_bundle <- readRDS(
  preflight_bundle_file
)
annotation_bundle <- readRDS(
  annotation_bundle_file
)

assert_true(
  is.list(preflight_bundle) &&
    all(c(
      "script",
      "script_build_id",
      "expression_matrix",
      "design_table",
      "policy"
    ) %in% names(preflight_bundle)),
  "Script 12A bundle is missing required fields."
)
assert_true(
  identical(
    as.character(
      preflight_bundle$script
    ),
    "Script12A"
  ) &&
    identical(
      as.character(
        preflight_bundle$script_build_id
      ),
      "Script12A_FINAL_20260710"
    ),
  "Preflight bundle identity is invalid."
)

assert_true(
  is.list(annotation_bundle) &&
    all(c(
      "script",
      "script_build_id",
      "source_script12a_bundle_md5",
      "source_feature_ids",
      "chip_annotation_audit",
      "signature_coverage_audit",
      "policy"
    ) %in% names(annotation_bundle)),
  "Script 12B bundle is missing required fields."
)
assert_true(
  identical(
    as.character(
      annotation_bundle$script
    ),
    "Script12B"
  ) &&
    identical(
      as.character(
        annotation_bundle$script_build_id
      ),
      "Script12B_FINAL_20260710"
    ),
  "Annotation bundle identity is invalid."
)
assert_true(
  identical(
    tolower(
      as.character(
        annotation_bundle$
          source_script12a_bundle_md5
      )
    ),
    observed_preflight_md5
  ),
  "Script 12B bundle does not point to the accepted Script 12A bundle."
)

expression_matrix <- preflight_bundle$expression_matrix
design_table <- preflight_bundle$design_table
chip_audit <- annotation_bundle$chip_annotation_audit

assert_true(
  is.matrix(expression_matrix) &&
    is.numeric(expression_matrix) &&
    identical(
      dim(expression_matrix),
      c(36685L, 50L)
    ),
  "Accepted expression matrix is not 36,685 x 50."
)
assert_true(
  sum(!is.finite(expression_matrix)) == 0L,
  "Accepted expression matrix contains non-finite values."
)
assert_true(
  is.data.frame(design_table) &&
    nrow(design_table) == 50L &&
    "sample_id" %in%
      colnames(design_table),
  "Accepted design table is malformed."
)
assert_true(
  identical(
    colnames(expression_matrix),
    as.character(
      design_table$sample_id
    )
  ),
  "Expression sample order differs from the accepted design table."
)
assert_true(
  is.data.frame(chip_audit) &&
    nrow(chip_audit) == 36685L,
  "Chip annotation audit does not contain 36,685 feature rows."
)

required_chip_columns <- c(
  "feature_order",
  "transcript_cluster_id",
  "chip_symbol_count",
  "chip_symbols",
  "chip_entrez_count",
  "chip_entrez_ids",
  "chip_gene_names",
  "chip_ensembl_ids",
  "chip_refseq_ids"
)

assert_true(
  all(
    required_chip_columns %in%
      colnames(chip_audit)
  ),
  paste0(
    "Chip annotation audit is missing required columns: ",
    paste(
      setdiff(
        required_chip_columns,
        colnames(chip_audit)
      ),
      collapse = ", "
    )
  )
)

chip_audit$transcript_cluster_id <- clean_text(
  chip_audit$transcript_cluster_id
)
chip_audit$chip_symbols <- clean_text(
  chip_audit$chip_symbols
)
chip_audit$chip_entrez_ids <- clean_text(
  chip_audit$chip_entrez_ids
)
chip_audit$chip_gene_names <- clean_text(
  chip_audit$chip_gene_names
)
chip_audit$chip_ensembl_ids <- clean_text(
  chip_audit$chip_ensembl_ids
)
chip_audit$chip_refseq_ids <- clean_text(
  chip_audit$chip_refseq_ids
)

chip_audit$chip_symbol_count <- safe_integer(
  chip_audit$chip_symbol_count,
  "chip_symbol_count"
)
chip_audit$chip_entrez_count <- safe_integer(
  chip_audit$chip_entrez_count,
  "chip_entrez_count"
)

assert_true(
  identical(
    chip_audit$transcript_cluster_id,
    rownames(expression_matrix)
  ),
  "Chip annotation rows are not aligned to expression rows."
)
assert_true(
  identical(
    as.character(
      annotation_bundle$source_feature_ids
    ),
    rownames(expression_matrix)
  ),
  "Saved Script 12B feature IDs differ from the expression matrix."
)
assert_true(
  isFALSE(
    annotation_bundle$policy$
      automatic_feature_exclusion
  ) &&
    isFALSE(
      annotation_bundle$policy$
        gene_level_aggregation_performed
    ),
  "Script 12B bundle incorrectly indicates prior exclusion or aggregation."
)

# ------------------------------
# 4. Lock feature inclusion/exclusion
# ------------------------------
symbol_unmapped <- chip_audit$chip_symbol_count == 0L
symbol_unique <- chip_audit$chip_symbol_count == 1L
symbol_multiple <- chip_audit$chip_symbol_count > 1L

entrez_unmapped <- chip_audit$chip_entrez_count == 0L
entrez_unique <- chip_audit$chip_entrez_count == 1L
entrez_multiple <- chip_audit$chip_entrez_count > 1L

assert_true(
  sum(symbol_unique) == 19704L &&
    sum(symbol_multiple) == 476L &&
    sum(symbol_unmapped) == 16505L,
  paste0(
    "Observed symbol-mapping counts differ from the accepted Script 12B ",
    "audit. Unique/multiple/unmapped: ",
    sum(symbol_unique),
    "/",
    sum(symbol_multiple),
    "/",
    sum(symbol_unmapped),
    "."
  )
)

assert_true(
  identical(
    symbol_unique,
    entrez_unique
  ) &&
    identical(
      symbol_multiple,
      entrez_multiple
    ) &&
    identical(
      symbol_unmapped,
      entrez_unmapped
    ),
  paste0(
    "SYMBOL and ENTREZID mapping classes are not identical. ",
    "Script 12C will not guess through inconsistent mappings."
  )
)

eligible_feature <- symbol_unique &
  entrez_unique &
  nzchar(chip_audit$chip_symbols) &
  nzchar(chip_audit$chip_entrez_ids)

assert_true(
  sum(eligible_feature) == 19704L,
  "The eligible unambiguous feature count is not 19,704."
)

exclusion_reason <- rep(
  "INCLUDED_UNIQUE_SYMBOL_AND_ENTREZ",
  nrow(chip_audit)
)

exclusion_reason[
  symbol_unmapped
] <- "EXCLUDED_UNMAPPED_SYMBOL_AND_ENTREZ"

exclusion_reason[
  symbol_multiple
] <- "EXCLUDED_MULTIPLE_SYMBOLS_AND_ENTREZ_IDS"

inclusion_audit <- data.frame(
  feature_order = chip_audit$feature_order,
  transcript_cluster_id =
    chip_audit$transcript_cluster_id,
  chip_symbol_count =
    chip_audit$chip_symbol_count,
  chip_symbols =
    chip_audit$chip_symbols,
  chip_entrez_count =
    chip_audit$chip_entrez_count,
  chip_entrez_ids =
    chip_audit$chip_entrez_ids,
  eligible_for_gene_level_matrix =
    eligible_feature,
  inclusion_or_exclusion_reason =
    exclusion_reason,
  expression_values_modified = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(inclusion_audit) == 36685L &&
    sum(
      inclusion_audit$
        eligible_for_gene_level_matrix
    ) == 19704L,
  "Feature inclusion audit is incomplete."
)

# ------------------------------
# 5. Build gene-level expression matrix
# ------------------------------
eligible_indices <- which(
  eligible_feature
)

eligible_expression <- expression_matrix[
  eligible_indices,
  ,
  drop = FALSE
]

eligible_annotation <- chip_audit[
  eligible_indices,
  ,
  drop = FALSE
]

gene_symbols <- eligible_annotation$chip_symbols

assert_true(
  length(gene_symbols) == 19704L &&
    all(nzchar(gene_symbols)) &&
    !any(grepl(";", gene_symbols, fixed = TRUE)),
  "Eligible gene symbols are blank or still contain multiple mappings."
)

gene_groups <- split(
  seq_along(gene_symbols),
  gene_symbols
)

gene_names_sorted <- sort(
  names(gene_groups)
)

gene_groups <- gene_groups[
  gene_names_sorted
]

expected_gene_number <- 19098L

assert_true(
  length(gene_groups) == expected_gene_number,
  paste0(
    "Expected 19,098 unique rat gene symbols, detected ",
    length(gene_groups),
    "."
  )
)

gene_expression_matrix <- t(
  vapply(
    gene_groups,
    aggregate_gene_row,
    numeric(
      ncol(eligible_expression)
    ),
    expression_matrix = eligible_expression
  )
)

storage.mode(
  gene_expression_matrix
) <- "double"

rownames(gene_expression_matrix) <-
  gene_names_sorted
colnames(gene_expression_matrix) <-
  colnames(expression_matrix)

assert_true(
  is.matrix(gene_expression_matrix) &&
    is.numeric(gene_expression_matrix) &&
    identical(
      dim(gene_expression_matrix),
      c(expected_gene_number, 50L)
    ),
  "Gene-level expression matrix is not 19,098 x 50."
)
assert_true(
  all(is.finite(gene_expression_matrix)),
  "Gene-level expression matrix contains non-finite values."
)
assert_true(
  anyDuplicated(
    rownames(gene_expression_matrix)
  ) == 0L &&
    anyDuplicated(
      colnames(gene_expression_matrix)
    ) == 0L,
  "Gene-level expression matrix has duplicated row or column identifiers."
)
assert_true(
  identical(
    colnames(gene_expression_matrix),
    as.character(
      design_table$sample_id
    )
  ),
  "Gene-level expression sample order changed."
)

# ------------------------------
# 6. Build per-gene aggregation audit
# ------------------------------
gene_audit_rows <- vector(
  "list",
  length(gene_groups)
)

for (i in seq_along(gene_groups)) {
  symbol_i <- names(gene_groups)[i]
  local_indices <- gene_groups[[i]]
  source_rows <- eligible_annotation[
    local_indices,
    ,
    drop = FALSE
  ]

  transcript_ids_i <- as.character(
    source_rows$transcript_cluster_id
  )
  entrez_ids_i <- sort(
    unique(
      clean_text(
        source_rows$chip_entrez_ids
      )
    )
  )
  entrez_ids_i <- entrez_ids_i[
    nzchar(entrez_ids_i)
  ]

  gene_names_i <- sort(
    unique(
      unlist(
        lapply(
          source_rows$chip_gene_names,
          split_semicolon_values
        ),
        use.names = FALSE
      )
    )
  )
  gene_names_i <- gene_names_i[
    nzchar(gene_names_i)
  ]

  ensembl_ids_i <- sort(
    unique(
      unlist(
        lapply(
          source_rows$chip_ensembl_ids,
          split_semicolon_values
        ),
        use.names = FALSE
      )
    )
  )
  ensembl_ids_i <- ensembl_ids_i[
    nzchar(ensembl_ids_i)
  ]

  refseq_ids_i <- sort(
    unique(
      unlist(
        lapply(
          source_rows$chip_refseq_ids,
          split_semicolon_values
        ),
        use.names = FALSE
      )
    )
  )
  refseq_ids_i <- refseq_ids_i[
    nzchar(refseq_ids_i)
  ]

  gene_audit_rows[[i]] <- data.frame(
    gene_order = i,
    rat_gene_symbol = symbol_i,
    source_transcript_cluster_number =
      length(local_indices),
    source_transcript_cluster_ids =
      paste(
        transcript_ids_i,
        collapse = ";"
      ),
    source_entrez_id_number =
      length(entrez_ids_i),
    source_entrez_ids = if (
      length(entrez_ids_i) == 0L
    ) {
      ""
    } else {
      paste(
        entrez_ids_i,
        collapse = ";"
      )
    },
    source_gene_name_number =
      length(gene_names_i),
    source_gene_names = if (
      length(gene_names_i) == 0L
    ) {
      ""
    } else {
      paste(
        gene_names_i,
        collapse = ";"
      )
    },
    source_ensembl_id_number =
      length(ensembl_ids_i),
    source_ensembl_ids = if (
      length(ensembl_ids_i) == 0L
    ) {
      ""
    } else {
      paste(
        ensembl_ids_i,
        collapse = ";"
      )
    },
    source_refseq_id_number =
      length(refseq_ids_i),
    source_refseq_ids = if (
      length(refseq_ids_i) == 0L
    ) {
      ""
    } else {
      paste(
        refseq_ids_i,
        collapse = ";"
      )
    },
    aggregation_method = if (
      length(local_indices) == 1L
    ) {
      "SINGLE_TRANSCRIPT_CLUSTER"
    } else {
      "PER_SAMPLE_MEDIAN"
    },
    expression_values_renormalized = FALSE,
    expression_values_imputed = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

gene_aggregation_audit <- do.call(
  rbind,
  gene_audit_rows
)

rownames(gene_aggregation_audit) <- NULL

assert_true(
  nrow(gene_aggregation_audit) ==
    expected_gene_number &&
    identical(
      gene_aggregation_audit$rat_gene_symbol,
      rownames(gene_expression_matrix)
    ),
  "Gene aggregation audit is not aligned to the gene-level matrix."
)

single_feature_gene_number <- sum(
  gene_aggregation_audit$
    source_transcript_cluster_number == 1L
)
multi_feature_gene_number <- sum(
  gene_aggregation_audit$
    source_transcript_cluster_number > 1L
)

assert_true(
  single_feature_gene_number == 18633L &&
    multi_feature_gene_number == 465L,
  paste0(
    "Expected 18,633 single-feature and 465 multi-feature genes, detected ",
    single_feature_gene_number,
    " and ",
    multi_feature_gene_number,
    "."
  )
)

# Verify single-feature genes were copied exactly.
single_gene_rows <- which(
  gene_aggregation_audit$
    source_transcript_cluster_number == 1L
)

for (gene_row_i in single_gene_rows) {
  transcript_id_i <-
    gene_aggregation_audit$
      source_transcript_cluster_ids[
        gene_row_i
      ]

  source_row_i <- match(
    transcript_id_i,
    rownames(expression_matrix)
  )

  assert_true(
    !is.na(source_row_i),
    paste0(
      "Single-feature transcript cluster was not found: ",
      transcript_id_i
    )
  )

  identical_values <- isTRUE(
    all.equal(
      as.numeric(
        gene_expression_matrix[
          gene_row_i,
          ,
          drop = TRUE
        ]
      ),
      as.numeric(
        expression_matrix[
          source_row_i,
          ,
          drop = TRUE
        ]
      ),
      tolerance = 0,
      check.attributes = FALSE
    )
  )

  assert_true(
    identical_values,
    paste0(
      "Single-feature gene values changed for ",
      gene_aggregation_audit$
        rat_gene_symbol[
          gene_row_i
        ],
      "."
    )
  )
}

# ------------------------------
# 7. Locked 24-gene direct-symbol coverage audit
# ------------------------------
locked_human_signature <- c(
  "ESR1",
  "AR",
  "PGR",
  "THRA",
  "THRB",
  "CAT",
  "BCL2",
  "BAX",
  "PARP1",
  "IL6",
  "ABCB1",
  "ABCG2",
  "FASN",
  "SCD",
  "TWIST1",
  "PPARG",
  "EGFR",
  "MMP9",
  "JUN",
  "FOS",
  "ADRB2",
  "ERG",
  "H2AX",
  "MITF"
)

assert_true(
  length(locked_human_signature) == 24L &&
    anyDuplicated(
      locked_human_signature
    ) == 0L,
  "Locked human signature is not 24 unique genes."
)

rat_gene_symbols <- rownames(
  gene_expression_matrix
)

signature_rows <- vector(
  "list",
  length(locked_human_signature)
)

for (i in seq_along(
  locked_human_signature
)) {
  human_symbol_i <- locked_human_signature[i]

  direct_rat_matches <- rat_gene_symbols[
    toupper(rat_gene_symbols) ==
      toupper(human_symbol_i)
  ]

  signature_rows[[i]] <- data.frame(
    signature_order = i,
    locked_human_symbol =
      human_symbol_i,
    case_insensitive_direct_rat_symbol_match_number =
      length(direct_rat_matches),
    case_insensitive_direct_rat_symbols = if (
      length(direct_rat_matches) == 0L
    ) {
      ""
    } else {
      paste(
        direct_rat_matches,
        collapse = ";"
      )
    },
    direct_symbol_expression_available =
      length(direct_rat_matches) == 1L,
    ortholog_mapping_performed = FALSE,
    paralog_substitution_performed = FALSE,
    included_in_Triclosan_score = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

signature_gene_coverage <- do.call(
  rbind,
  signature_rows
)
rownames(signature_gene_coverage) <- NULL

assert_true(
  sum(
    signature_gene_coverage$
      direct_symbol_expression_available
  ) == 23L,
  paste0(
    "Expected 23 of 24 locked genes to have direct rat-symbol coverage, ",
    "detected ",
    sum(
      signature_gene_coverage$
        direct_symbol_expression_available
    ),
    "."
  )
)

missing_direct_signature_genes <-
  signature_gene_coverage$
    locked_human_symbol[
      !signature_gene_coverage$
        direct_symbol_expression_available
    ]

assert_true(
  identical(
    missing_direct_signature_genes,
    "ABCB1"
  ),
  paste0(
    "The only expected direct-symbol absence is ABCB1. Observed: ",
    paste(
      missing_direct_signature_genes,
      collapse = ";"
    )
  )
)

# ------------------------------
# 8. Matrix and mapping summaries
# ------------------------------
matrix_summary <- data.frame(
  item = c(
    "source_feature_number",
    "source_sample_number",
    "eligible_unique_feature_number",
    "excluded_unmapped_feature_number",
    "excluded_multimapped_feature_number",
    "gene_level_gene_number",
    "gene_level_sample_number",
    "single_transcript_cluster_gene_number",
    "multi_transcript_cluster_gene_number",
    "maximum_transcript_clusters_per_gene",
    "nonfinite_gene_level_values",
    "sample_order_preserved",
    "expression_values_renormalized",
    "expression_values_imputed",
    "ortholog_mapping_performed",
    "differential_expression_performed"
  ),
  value = c(
    nrow(expression_matrix),
    ncol(expression_matrix),
    sum(eligible_feature),
    sum(symbol_unmapped),
    sum(symbol_multiple),
    nrow(gene_expression_matrix),
    ncol(gene_expression_matrix),
    single_feature_gene_number,
    multi_feature_gene_number,
    max(
      gene_aggregation_audit$
        source_transcript_cluster_number
    ),
    sum(!is.finite(gene_expression_matrix)),
    identical(
      colnames(gene_expression_matrix),
      as.character(
        design_table$sample_id
      )
    ),
    FALSE,
    FALSE,
    FALSE,
    FALSE
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

integrity_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Script_build_ID",
    "Source_Script12A_bundle_MD5",
    "Source_Script12B_bundle_MD5",
    "Primary_annotation_source",
    "Source_expression_dimensions",
    "Included_unique_mapped_transcript_clusters",
    "Excluded_unmapped_transcript_clusters",
    "Excluded_multigene_transcript_clusters",
    "Gene_level_expression_dimensions",
    "Single_transcript_cluster_genes",
    "Median_aggregated_multitranscript_genes",
    "Locked_signature_direct_rat_symbol_coverage",
    "Locked_signature_missing_direct_symbol",
    "All_gene_level_values_finite",
    "Sample_order_preserved",
    "Expression_values_renormalized",
    "Expression_values_imputed",
    "Ortholog_mapping_performed",
    "ABCB1_paralog_substitution_performed",
    "Differential_expression_performed",
    "PCA_performed",
    "GSVA_or_GSEA_performed",
    "Completion_status"
  ),
  value = c(
    "GSE95554",
    "12C",
    SCRIPT_BUILD_ID,
    observed_preflight_md5,
    observed_annotation_md5,
    "ragene20sttranscriptcluster.db",
    paste(
      dim(expression_matrix),
      collapse = " x "
    ),
    sum(eligible_feature),
    sum(symbol_unmapped),
    sum(symbol_multiple),
    paste(
      dim(gene_expression_matrix),
      collapse = " x "
    ),
    single_feature_gene_number,
    multi_feature_gene_number,
    sum(
      signature_gene_coverage$
        direct_symbol_expression_available
    ),
    paste(
      missing_direct_signature_genes,
      collapse = ";"
    ),
    all(
      is.finite(
        gene_expression_matrix
      )
    ),
    identical(
      colnames(gene_expression_matrix),
      as.character(
        design_table$sample_id
      )
    ),
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 9. Save staging outputs
# ------------------------------
input_manifest <- make_manifest(
  required_inputs
)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step3_GSE95554_real_exposure_validation",
  script = "Script12C",
  script_build_id = SCRIPT_BUILD_ID,
  created_at = format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  ),
  source_accession = "GSE95554",
  source_platform = "GPL17117",
  source_script12a_bundle_file =
    normalizePath(
      preflight_bundle_file,
      winslash = "/",
      mustWork = TRUE
    ),
  source_script12a_bundle_md5 =
    observed_preflight_md5,
  source_script12b_bundle_file =
    normalizePath(
      annotation_bundle_file,
      winslash = "/",
      mustWork = TRUE
    ),
  source_script12b_bundle_md5 =
    observed_annotation_md5,
  design_table = design_table,
  gene_level_expression =
    gene_expression_matrix,
  feature_inclusion_audit =
    inclusion_audit,
  gene_aggregation_audit =
    gene_aggregation_audit,
  signature_gene_coverage =
    signature_gene_coverage,
  matrix_summary = matrix_summary,
  integrity_summary =
    integrity_summary,
  policy = list(
    primary_annotation_source =
      "ragene20sttranscriptcluster.db",
    require_exactly_one_symbol = TRUE,
    require_exactly_one_entrez_id = TRUE,
    exclude_unmapped_features = TRUE,
    exclude_multigene_features = TRUE,
    multiple_transcript_cluster_aggregation =
      "PER_SAMPLE_MEDIAN",
    expression_values_renormalized = FALSE,
    expression_values_imputed = FALSE,
    variance_based_feature_selection = FALSE,
    outcome_guided_feature_selection = FALSE,
    ortholog_mapping_performed = FALSE,
    ABCB1_paralog_substitution_performed = FALSE,
    differential_expression_performed = FALSE,
    PCA_performed = FALSE,
    GSVA_or_GSEA_performed = FALSE
  ),
  provenance = list(
    accepted_script12a_bundle_md5 =
      accepted_preflight_md5,
    accepted_script12b_bundle_md5 =
      accepted_annotation_md5,
    expected_source_feature_number = 36685L,
    expected_included_feature_number = 19704L,
    expected_gene_number = 19098L,
    next_step_requires_review_of = c(
      "gene-level matrix integrity",
      "rat-to-human ortholog strategy",
      "ABCB1 one-to-many rat paralog handling"
    )
  )
)

class(complete_bundle) <- c(
  "GSE95554_gene_level_expression_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE95554_gene_level_expression_COMPLETE_bundle.rds"
)
stage_matrix_file <- file.path(
  stage_object_dir,
  "GSE95554_gene_level_expression_matrix.rds"
)
stage_inclusion_file <- file.path(
  stage_audit_dir,
  "GSE95554_transcript_cluster_inclusion_audit.csv"
)
stage_gene_audit_file <- file.path(
  stage_audit_dir,
  "GSE95554_gene_level_aggregation_audit.csv"
)
stage_signature_file <- file.path(
  stage_audit_dir,
  "GSE95554_locked_24gene_direct_rat_symbol_coverage.csv"
)
stage_matrix_summary_file <- file.path(
  stage_audit_dir,
  "GSE95554_gene_level_expression_matrix_summary.csv"
)
stage_integrity_file <- file.path(
  stage_audit_dir,
  "GSE95554_gene_level_expression_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script12C_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script12C_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script12C_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script12C_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)
saveRDS(
  gene_expression_matrix,
  stage_matrix_file,
  compress = "gzip"
)

write_csv_utf8(
  inclusion_audit,
  stage_inclusion_file
)
write_csv_utf8(
  gene_aggregation_audit,
  stage_gene_audit_file
)
write_csv_utf8(
  signature_gene_coverage,
  stage_signature_file
)
write_csv_utf8(
  matrix_summary,
  stage_matrix_summary_file
)
write_csv_utf8(
  integrity_summary,
  stage_integrity_file
)
write_csv_utf8(
  input_manifest,
  stage_input_manifest_file
)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# Read-back and exact-order checks.
bundle_check <- readRDS(
  stage_bundle_file
)
matrix_check <- readRDS(
  stage_matrix_file
)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "script_build_id",
      "gene_level_expression",
      "feature_inclusion_audit",
      "gene_aggregation_audit",
      "signature_gene_coverage",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 12C bundle is missing required fields."
)
assert_true(
  identical(
    as.character(
      bundle_check$script_build_id
    ),
    SCRIPT_BUILD_ID
  ),
  "Saved Script 12C build ID is incorrect."
)
assert_true(
  is.matrix(matrix_check) &&
    identical(
      dim(matrix_check),
      c(expected_gene_number, 50L)
    ) &&
    identical(
      rownames(matrix_check),
      rownames(gene_expression_matrix)
    ) &&
    identical(
      colnames(matrix_check),
      colnames(gene_expression_matrix)
    ),
  "Saved standalone gene matrix changed dimensions or identifiers."
)
assert_true(
  isTRUE(
    all.equal(
      unname(matrix_check),
      unname(gene_expression_matrix),
      tolerance = 0,
      check.attributes = FALSE
    )
  ),
  "Saved standalone gene matrix values differ from the in-memory matrix."
)
assert_true(
  isFALSE(
    bundle_check$policy$
      expression_values_renormalized
  ) &&
    isFALSE(
      bundle_check$policy$
        ortholog_mapping_performed
    ) &&
    isFALSE(
      bundle_check$policy$
        differential_expression_performed
    ),
  "Saved Script 12C policy incorrectly indicates downstream analysis."
)

bundle_md5 <- md5_one(
  stage_bundle_file
)
matrix_md5 <- md5_one(
  stage_matrix_file
)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 3 - Script 12C",
  "GSE95554 gene-level expression construction",
  paste0(
    "Script build ID: ",
    SCRIPT_BUILD_ID
  ),
  "============================================================",
  paste0(
    "Completion time: ",
    format(
      Sys.time(),
      "%Y-%m-%d %H:%M:%S %Z"
    )
  ),
  paste0(
    "Source Script 12A bundle MD5: ",
    observed_preflight_md5
  ),
  paste0(
    "Source Script 12B bundle MD5: ",
    observed_annotation_md5
  ),
  paste0(
    "Source expression dimensions: ",
    nrow(expression_matrix),
    " x ",
    ncol(expression_matrix)
  ),
  paste0(
    "Included unique-mapped transcript clusters: ",
    sum(eligible_feature)
  ),
  paste0(
    "Excluded unmapped transcript clusters: ",
    sum(symbol_unmapped)
  ),
  paste0(
    "Excluded multi-gene transcript clusters: ",
    sum(symbol_multiple)
  ),
  paste0(
    "Gene-level expression dimensions: ",
    nrow(gene_expression_matrix),
    " x ",
    ncol(gene_expression_matrix)
  ),
  paste0(
    "Single-transcript-cluster genes: ",
    single_feature_gene_number
  ),
  paste0(
    "Median-aggregated multi-transcript-cluster genes: ",
    multi_feature_gene_number
  ),
  paste0(
    "Maximum transcript clusters per gene: ",
    max(
      gene_aggregation_audit$
        source_transcript_cluster_number
    )
  ),
  paste0(
    "Locked signature direct rat-symbol coverage: ",
    sum(
      signature_gene_coverage$
        direct_symbol_expression_available
    ),
    " / 24"
  ),
  paste0(
    "Missing direct rat-symbol signature gene: ",
    paste(
      missing_direct_signature_genes,
      collapse = ";"
    )
  ),
  "ABCB1 paralog substitution performed: FALSE",
  "Expression values renormalized: FALSE",
  "Expression values imputed: FALSE",
  "Ortholog mapping performed: FALSE",
  "Differential expression performed: FALSE",
  "PCA performed: FALSE",
  "GSVA/GSEA performed: FALSE",
  paste0(
    "Standalone gene matrix MD5: ",
    matrix_md5
  ),
  paste0(
    "Script 12C bundle MD5: ",
    bundle_md5
  ),
  "",
  "SCRIPT12C STATUS: COMPLETE",
  paste0(
    "A 19,098 x 50 rat gene-level matrix was built using unambiguous ChipDb ",
    "mappings and per-sample median aggregation only."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(
    report_lines
  ),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_matrix_file,
  stage_inclusion_file,
  stage_gene_audit_file,
  stage_signature_file,
  stage_matrix_summary_file,
  stage_integrity_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(
    file.exists(
      output_files_before_manifest
    )
  ),
  "At least one staged Script 12C output is missing."
)
assert_true(
  all(
    file.info(
      output_files_before_manifest
    )$size > 0
  ),
  "At least one staged Script 12C output is empty."
)

output_manifest <- make_manifest(
  output_files_before_manifest
)

write_csv_utf8(
  output_manifest,
  stage_output_manifest_file
)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) ==
    length(output_files_before_manifest),
  "Script 12C output manifest has an incorrect row count."
)

for (i in seq_along(
  output_files_before_manifest
)) {
  file_i <- output_files_before_manifest[i]
  row_i <- manifest_check[
    manifest_check$file_name ==
      basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0(
      "Missing or duplicated manifest row: ",
      basename(file_i)
    )
  )
  assert_true(
    identical(
      tolower(
        as.character(
          row_i$md5
        )
      ),
      tolower(
        md5_one(file_i)
      )
    ),
    paste0(
      "Manifest MD5 mismatch: ",
      basename(file_i)
    )
  )
  assert_true(
    as.numeric(
      row_i$size_bytes
    ) ==
      as.numeric(
        file.info(file_i)$size
      ),
    paste0(
      "Manifest size mismatch: ",
      basename(file_i)
    )
  )
}

# ------------------------------
# 10. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 12C directory appeared during staging."
)

rename_ok <- file.rename(
  stage_root,
  final_root
)

if (!isTRUE(rename_ok)) {
  dir.create(
    final_root,
    recursive = TRUE,
    showWarnings = FALSE
  )

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 12C staging directory."
  )

  unlink(
    stage_root,
    recursive = TRUE,
    force = TRUE
  )
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE95554_gene_level_expression_COMPLETE_bundle.rds"
)
final_matrix_file <- file.path(
  final_root,
  "objects",
  "GSE95554_gene_level_expression_matrix.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script12C_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script12C_output_manifest_with_MD5.csv"
)

assert_true(
  all(
    file.exists(c(
      final_bundle_file,
      final_matrix_file,
      final_report_file,
      final_manifest_file
    ))
  ),
  "Committed Script 12C output is incomplete."
)
assert_true(
  identical(
    md5_one(final_bundle_file),
    bundle_md5
  ),
  "Committed Script 12C bundle MD5 changed after commit."
)
assert_true(
  identical(
    md5_one(final_matrix_file),
    matrix_md5
  ),
  "Committed standalone gene matrix MD5 changed after commit."
)
assert_true(
  report_contains(
    final_report_file,
    "SCRIPT12C STATUS: COMPLETE"
  ),
  "Committed Script 12C report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 12C completed successfully.\n")
cat(
  "Included unique-mapped transcript clusters: ",
  sum(eligible_feature),
  "\n",
  sep = ""
)
cat(
  "Gene-level expression matrix: ",
  nrow(gene_expression_matrix),
  " x ",
  ncol(gene_expression_matrix),
  "\n",
  sep = ""
)
cat(
  "Single-feature / median-aggregated genes: ",
  single_feature_gene_number,
  " / ",
  multi_feature_gene_number,
  "\n",
  sep = ""
)
cat(
  "Locked signature direct rat-symbol coverage: ",
  sum(
    signature_gene_coverage$
      direct_symbol_expression_available
  ),
  " / 24\n",
  sep = ""
)
cat(
  "Missing direct symbol: ",
  paste(
    missing_direct_signature_genes,
    collapse = ";"
  ),
  "\n",
  sep = ""
)
cat("ABCB1 paralog substitution performed: FALSE\n")
cat("Expression values renormalized: FALSE\n")
cat("Ortholog mapping performed: FALSE\n")
cat("Differential expression performed: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat(
  "Bundle MD5: ",
  md5_one(
    final_bundle_file
  ),
  "\n",
  sep = ""
)
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

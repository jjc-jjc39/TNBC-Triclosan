# ==============================================================================
# TNBC_Triclosan | GSE95554 | Script 12G COMPACT FINAL
# Primary inference for the locked 22-gene classical GSVA score.
#
# Prespecified tests:
# 1) Nulliparous: TCS vs OIL, exact two-sided permutation test.
# 2) Parous: TCS vs OIL, exact two-sided permutation test.
# 3) Interaction: (TCS-OIL)_Parous - (TCS-OIL)_Nulliparous,
#    exact stratified permutation test.
#
# Secondary summaries: Hedges g and Welch/linear-model sensitivity results.
# No sample deletion, alternative score, cutoff, DEG, PCA, GSEA or figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script12G_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step3_GSE95554_real_exposure_validation")
INPUT_ROOT <- file.path(STEP_ROOT, "05_Triclosan_GSVA_score")
OUTPUT_ROOT <- file.path(STEP_ROOT, "06_primary_TCS_OIL_GSVA_tests")

INPUTS <- c(
  bundle = file.path(INPUT_ROOT, "objects",
    "GSE95554_Triclosan_22gene_GSVA_COMPLETE_bundle.rds"),
  score = file.path(INPUT_ROOT, "objects",
    "GSE95554_Triclosan_22gene_GSVA_score.rds"),
  score_csv = file.path(INPUT_ROOT, "audit",
    "GSE95554_Triclosan_22gene_GSVA_score_all50.csv"),
  integrity = file.path(INPUT_ROOT, "audit",
    "GSE95554_Triclosan_22gene_GSVA_integrity_summary.csv"),
  manifest = file.path(INPUT_ROOT, "audit",
    "Script12F_output_manifest_with_MD5.csv"),
  report = file.path(INPUT_ROOT, "logs",
    "Script12F_COMPLETE_report.txt")
)

EXPECTED_MD5 <- c(
  bundle = "9095175efccb551d5e9f8b5574c6c538",
  score = "b836377a538bfd4540d467822874c396",
  score_csv = "d91da16faeb469824fce6d06359e6048",
  integrity = "568cbfc58d367ad85e59621c70787b15",
  manifest = "50ebf463cd051eee50d36cbc55af207e",
  report = "9e98ba87b489f1abfb6bd5ebe12fda26"
)

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

summary_row <- function(x) {
  x <- as.numeric(x)
  data.frame(
    n = length(x),
    mean = mean(x),
    sd = sd(x),
    median = median(x),
    q1 = unname(quantile(x, 0.25)),
    q3 = unname(quantile(x, 0.75)),
    min = min(x),
    max = max(x),
    check.names = FALSE
  )
}

manifest_ok <- function(root, manifest_file) {
  m <- tryCatch(
    read.csv(manifest_file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || nrow(m) < 1L ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root <- normalizePath(root, winslash = "/", mustWork = TRUE)
  for (i in seq_len(nrow(m))) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    if (!startsWith(f2, paste0(root, "/")) ||
        !identical(as.numeric(file.info(f)$size),
                   as.numeric(m$size_bytes[i])) ||
        !identical(md5(f), tolower(trimws(as.character(m$md5[i]))))) {
      return(FALSE)
    }
  }
  TRUE
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging directory: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))
  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}

archive_or_reuse <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))
  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }

  key <- c(
    bundle = file.path(OUTPUT_ROOT, "objects",
      "GSE95554_Triclosan_GSVA_primary_tests_COMPLETE_bundle.rds"),
    manifest = file.path(OUTPUT_ROOT, "audit",
      "Script12G_output_manifest_with_MD5.csv"),
    report = file.path(OUTPUT_ROOT, "logs",
      "Script12G_COMPLETE_report.txt")
  )
  valid <- all(file.exists(key)) &&
    manifest_ok(OUTPUT_ROOT, key["manifest"]) &&
    any(grepl("SCRIPT12G STATUS: COMPLETE",
              tryCatch(readLines(key["report"], warn = FALSE),
                       error = function(e) ""), fixed = TRUE))

  if (valid) {
    b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
    valid <- is.list(b) &&
      identical(as.character(b$script), "Script12G") &&
      identical(as.character(b$source_script12f_bundle_md5),
                unname(EXPECTED_MD5["bundle"])) &&
      identical(nrow(b$primary_tests), 3L) &&
      isFALSE(b$policy$samples_filtered) &&
      isFALSE(b$policy$cutoff_selected)
  }
  if (valid) {
    cat("Existing Script 12G output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    STEP_ROOT,
    paste0("06_primary_TCS_OIL_GSVA_tests_INCOMPLETE_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.\n%s",
         OUTPUT_ROOT)
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

exact_state_test <- function(d, state) {
  z <- d[d$reproductive_state == state, , drop = FALSE]
  y <- z$Triclosan_activity
  tcs <- z$exposure_code == "TCS"
  assert(nrow(z) == 10L && sum(tcs) == 5L,
         "%s stratum is not 5 TCS plus 5 OIL.", state)

  obs <- mean(y[tcs]) - mean(y[!tcs])
  cmb <- combn(seq_along(y), 5L)
  null <- apply(cmb, 2L, function(i) mean(y[i]) - mean(y[-i]))
  p <- mean(abs(null) >= abs(obs) - sqrt(.Machine$double.eps))

  list(
    state = state,
    estimate = obs,
    p = p,
    null = null,
    permutations = length(null)
  )
}

hedges_g <- function(tcs, oil) {
  n1 <- length(tcs); n0 <- length(oil)
  pooled <- sqrt(((n1 - 1) * var(tcs) + (n0 - 1) * var(oil)) /
                 (n1 + n0 - 2))
  if (!is.finite(pooled) || pooled == 0) return(NA_real_)
  d <- (mean(tcs) - mean(oil)) / pooled
  correction <- 1 - 3 / (4 * (n1 + n0 - 2) - 1)
  correction * d
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Primary exact tests only; no threshold or downstream omics analysis.\n")
  cat("============================================================\n")

  assert(dir.exists(STEP_ROOT), "Step directory does not exist:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted Script 12F inputs:\n%s",
         paste(missing, collapse = "\n"))

  observed <- vapply(INPUTS, md5, character(1))
  assert(identical(observed, EXPECTED_MD5),
         "At least one Script 12F input MD5 differs from the accepted result.\n%s",
         paste(sprintf("%s: expected %s; observed %s",
                       names(EXPECTED_MD5), EXPECTED_MD5, observed),
               collapse = "\n"))
  assert(any(grepl("SCRIPT12F STATUS: COMPLETE",
                   readLines(INPUTS["report"], warn = FALSE), fixed = TRUE)),
         "Script 12F completion marker is missing.")

  if (archive_or_reuse()) return(invisible(OUTPUT_ROOT))

  source_bundle <- readRDS(INPUTS["bundle"])
  score <- readRDS(INPUTS["score"])
  score_csv <- read.csv(INPUTS["score_csv"], stringsAsFactors = FALSE,
                        check.names = FALSE, na.strings = "")

  required <- c(
    "script", "script_build_id", "source_accession", "design_table",
    "Triclosan_activity", "score_matrix", "score_table", "policy"
  )
  assert(is.list(source_bundle) && all(required %in% names(source_bundle)) &&
         identical(as.character(source_bundle$script), "Script12F") &&
         identical(as.character(source_bundle$script_build_id),
                   "Script12F_FINAL_20260711"),
         "Script 12F bundle identity is incorrect.")
  assert(is.numeric(score) && length(score) == 50L &&
         all(is.finite(score)) && length(unique(score)) == 50L &&
         !is.null(names(score)) && !anyDuplicated(names(score)),
         "Standalone GSVA score is malformed.")
  assert(identical(score, source_bundle$Triclosan_activity) &&
         identical(as.numeric(source_bundle$score_matrix[1L, ]), as.numeric(score)) &&
         identical(colnames(source_bundle$score_matrix), names(score)),
         "Bundle and standalone GSVA scores differ.")
  assert(nrow(score_csv) == 50L &&
         identical(as.character(score_csv$sample_id), names(score)) &&
         isTRUE(all.equal(score_csv$Triclosan_activity, as.numeric(score),
                          tolerance = 1e-14, check.attributes = FALSE)),
         "Score CSV differs from the accepted RDS score.")

  prohibited <- c(
    "samples_filtered", "alternative_score_calculated",
    "TCS_OIL_comparison_performed", "differential_expression_performed",
    "PCA_performed", "GSEA_performed", "high_low_group_created",
    "cutoff_selected", "manuscript_figure_created"
  )
  assert(all(prohibited %in% names(source_bundle$policy)) &&
         all(vapply(prohibited,
                    function(x) identical(source_bundle$policy[[x]], FALSE),
                    logical(1))),
         "Script 12F policy boundary is not intact.")

  d <- source_bundle$score_table
  assert(is.data.frame(d) && nrow(d) == 50L &&
         all(c("sample_order", "sample_id", "exposure_code",
               "reproductive_state", "primary_TCS_or_OIL_subset",
               "Triclosan_activity") %in% names(d)) &&
         identical(as.character(d$sample_id), names(score)) &&
         isTRUE(all.equal(d$Triclosan_activity, as.numeric(score),
                          tolerance = 0, check.attributes = FALSE)),
         "Script 12F score table is malformed.")

  primary <- d[as.logical(d$primary_TCS_or_OIL_subset), , drop = FALSE]
  primary <- primary[order(primary$sample_order), , drop = FALSE]
  assert(nrow(primary) == 20L &&
         identical(sort(unique(primary$exposure_code)), c("OIL", "TCS")) &&
         identical(sort(unique(primary$reproductive_state)),
                   c("NULLIPAROUS", "PAROUS")) &&
         all(table(primary$reproductive_state, primary$exposure_code) == 5L) &&
         !any(!is.finite(primary$Triclosan_activity)),
         "Prespecified 20-sample TCS/OIL subset is incorrect.")

  null_test <- exact_state_test(primary, "NULLIPAROUS")
  par_test <- exact_state_test(primary, "PAROUS")
  interaction_estimate <- par_test$estimate - null_test$estimate
  interaction_null <- as.vector(
    outer(par_test$null, null_test$null, "-")
  )
  interaction_p <- mean(
    abs(interaction_null) >=
      abs(interaction_estimate) - sqrt(.Machine$double.eps)
  )
  assert(length(null_test$null) == 252L &&
         length(par_test$null) == 252L &&
         length(interaction_null) == 63504L,
         "Exact permutation counts are incorrect.")

  primary_tests <- data.frame(
    test = c(
      "Nulliparous_TCS_vs_OIL",
      "Parous_TCS_vs_OIL",
      "Exposure_by_state_interaction"
    ),
    estimand = c(
      "mean(TCS)-mean(OIL) within Nulliparous",
      "mean(TCS)-mean(OIL) within Parous",
      "(TCS-OIL)_Parous-(TCS-OIL)_Nulliparous"
    ),
    sample_number = c(10L, 10L, 20L),
    cell_n = c(5L, 5L, 5L),
    estimate = c(
      null_test$estimate,
      par_test$estimate,
      interaction_estimate
    ),
    exact_permutation_number = c(
      null_test$permutations,
      par_test$permutations,
      length(interaction_null)
    ),
    exact_two_sided_p = c(
      null_test$p,
      par_test$p,
      interaction_p
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  primary_tests$BH_adjusted_p <- p.adjust(
    primary_tests$exact_two_sided_p, method = "BH"
  )
  primary_tests$Holm_adjusted_p <- p.adjust(
    primary_tests$exact_two_sided_p, method = "holm"
  )
  primary_tests$significance_threshold_selected <- FALSE

  group_descriptives <- do.call(rbind, lapply(
    c("NULLIPAROUS", "PAROUS"), function(state) {
      do.call(rbind, lapply(c("OIL", "TCS"), function(exposure) {
        x <- primary$Triclosan_activity[
          primary$reproductive_state == state &
            primary$exposure_code == exposure
        ]
        cbind(
          data.frame(reproductive_state = state, exposure_code = exposure,
                     check.names = FALSE),
          summary_row(x)
        )
      }))
    }
  ))
  rownames(group_descriptives) <- NULL

  state_sensitivity <- do.call(rbind, lapply(
    c("NULLIPAROUS", "PAROUS"), function(state) {
      z <- primary[primary$reproductive_state == state, , drop = FALSE]
      tcs <- z$Triclosan_activity[z$exposure_code == "TCS"]
      oil <- z$Triclosan_activity[z$exposure_code == "OIL"]
      wt <- t.test(tcs, oil, var.equal = FALSE, conf.level = 0.95)
      data.frame(
        test = paste0(state, "_TCS_vs_OIL"),
        method = "Welch_t_test_secondary",
        estimate = mean(tcs) - mean(oil),
        standard_error = unname(wt$stderr),
        degrees_of_freedom = unname(wt$parameter),
        confidence_level = 0.95,
        confidence_interval_lower = unname(wt$conf.int[1L]),
        confidence_interval_upper = unname(wt$conf.int[2L]),
        two_sided_p = wt$p.value,
        Hedges_g = hedges_g(tcs, oil),
        primary_test = FALSE,
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
  ))

  model_data <- data.frame(
    score = primary$Triclosan_activity,
    state_parous = as.integer(primary$reproductive_state == "PAROUS"),
    exposure_tcs = as.integer(primary$exposure_code == "TCS")
  )
  fit <- lm(score ~ state_parous * exposure_tcs, data = model_data)
  term <- "state_parous:exposure_tcs"
  fit_summary <- summary(fit)$coefficients
  fit_ci <- confint(fit, term, level = 0.95)
  interaction_sensitivity <- data.frame(
    test = "Exposure_by_state_interaction",
    method = "OLS_interaction_secondary",
    estimate = unname(coef(fit)[term]),
    standard_error = unname(fit_summary[term, "Std. Error"]),
    degrees_of_freedom = df.residual(fit),
    confidence_level = 0.95,
    confidence_interval_lower = unname(fit_ci[1L]),
    confidence_interval_upper = unname(fit_ci[2L]),
    two_sided_p = unname(fit_summary[term, "Pr(>|t|)"]),
    Hedges_g = NA_real_,
    primary_test = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  sensitivity_tests <- rbind(state_sensitivity, interaction_sensitivity)

  null_distributions <- list(
    Nulliparous_TCS_vs_OIL = null_test$null,
    Parous_TCS_vs_OIL = par_test$null,
    Exposure_by_state_interaction = interaction_null
  )
  null_summary <- do.call(rbind, lapply(names(null_distributions), function(nm) {
    x <- null_distributions[[nm]]
    data.frame(
      test = nm,
      permutation_number = length(x),
      minimum = min(x),
      q025 = unname(quantile(x, 0.025)),
      q25 = unname(quantile(x, 0.25)),
      median = median(x),
      mean = mean(x),
      q75 = unname(quantile(x, 0.75)),
      q975 = unname(quantile(x, 0.975)),
      maximum = max(x),
      standard_deviation = sd(x),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
  rownames(null_summary) <- NULL

  parameter_lock <- data.frame(
    field = c(
      "Primary_subset", "Nulliparous_test", "Parous_test",
      "Interaction_estimand", "Interaction_test",
      "Primary_p_value", "Multiplicity_summaries",
      "Secondary_sensitivity", "Samples_filtered",
      "Outliers_removed", "Alternative_score_used",
      "Cutoff_selected", "DEG_PCA_GSEA_figure"
    ),
    value = c(
      "Prespecified 20 TCS/OIL samples; 5 per exposure-by-state cell",
      "Exact two-sided permutation of 5 TCS labels among 10 samples; 252 assignments",
      "Exact two-sided permutation of 5 TCS labels among 10 samples; 252 assignments",
      "(TCS-OIL)_Parous-(TCS-OIL)_Nulliparous",
      "All 252 x 252 stratified assignments; 63,504 combinations",
      "Absolute-statistic exact randomization p",
      "BH and Holm across the three prespecified primary tests",
      "Welch t tests, Hedges g, and OLS interaction; explicitly secondary",
      "FALSE", "FALSE", "FALSE", "FALSE", "FALSE"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    prespecified_primary_subset_only = TRUE,
    primary_sample_number = 20L,
    cell_n = 5L,
    exact_state_permutation_number = 252L,
    exact_interaction_permutation_number = 63504L,
    samples_filtered = FALSE,
    outliers_removed = FALSE,
    alternative_score_used = FALSE,
    cutoff_selected = FALSE,
    differential_expression_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession", "Script", "Script_build_ID",
      "Source_Script12F_bundle_MD5", "Source_score_MD5",
      "Source_score_CSV_MD5", "Primary_sample_number",
      "Nulliparous_TCS_n", "Nulliparous_OIL_n",
      "Parous_TCS_n", "Parous_OIL_n",
      "Finite_primary_scores", "Unique_primary_scores",
      "Nulliparous_permutation_number",
      "Parous_permutation_number", "Interaction_permutation_number",
      "Primary_test_number", "Samples_filtered", "Outliers_removed",
      "Alternative_score_used", "Cutoff_selected",
      "Differential_expression_performed", "PCA_performed",
      "GSEA_performed", "Manuscript_figure_created",
      "Completion_status"
    ),
    value = as.character(c(
      "GSE95554", "12G", BUILD_ID, EXPECTED_MD5["bundle"],
      EXPECTED_MD5["score"], EXPECTED_MD5["score_csv"], nrow(primary),
      sum(primary$reproductive_state == "NULLIPAROUS" &
            primary$exposure_code == "TCS"),
      sum(primary$reproductive_state == "NULLIPAROUS" &
            primary$exposure_code == "OIL"),
      sum(primary$reproductive_state == "PAROUS" &
            primary$exposure_code == "TCS"),
      sum(primary$reproductive_state == "PAROUS" &
            primary$exposure_code == "OIL"),
      sum(is.finite(primary$Triclosan_activity)),
      length(unique(primary$Triclosan_activity)),
      length(null_test$null), length(par_test$null),
      length(interaction_null), nrow(primary_tests),
      FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = "Script12F",
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  result_bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step3_GSE95554_real_exposure_validation",
    script = "Script12G",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE95554",
    source_script12f_bundle_md5 = unname(EXPECTED_MD5["bundle"]),
    source_score_md5 = unname(EXPECTED_MD5["score"]),
    source_score_csv_md5 = unname(EXPECTED_MD5["score_csv"]),
    primary_sample_scores = primary,
    group_descriptives = group_descriptives,
    primary_tests = primary_tests,
    sensitivity_tests = sensitivity_tests,
    permutation_null_distributions = null_distributions,
    permutation_null_summary = null_summary,
    parameter_lock = parameter_lock,
    integrity_summary = integrity,
    policy = policy
  )
  class(result_bundle) <- c(
    "GSE95554_Triclosan_GSVA_primary_tests_bundle", "list"
  )

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script12G_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(stage, "objects",
      "GSE95554_Triclosan_GSVA_primary_tests_COMPLETE_bundle.rds"),
    nulls = file.path(stage, "objects",
      "GSE95554_Triclosan_GSVA_exact_permutation_nulls.rds"),
    samples = file.path(stage, "audit",
      "GSE95554_Triclosan_GSVA_primary20_sample_scores.csv"),
    groups = file.path(stage, "audit",
      "GSE95554_Triclosan_GSVA_primary_group_descriptives.csv"),
    primary = file.path(stage, "audit",
      "GSE95554_Triclosan_GSVA_exact_primary_tests.csv"),
    sensitivity = file.path(stage, "audit",
      "GSE95554_Triclosan_GSVA_parametric_sensitivity.csv"),
    null_summary = file.path(stage, "audit",
      "GSE95554_Triclosan_GSVA_permutation_null_summary.csv"),
    parameters = file.path(stage, "audit",
      "GSE95554_Triclosan_GSVA_primary_test_parameter_lock.csv"),
    integrity = file.path(stage, "audit",
      "GSE95554_Triclosan_GSVA_primary_test_integrity_summary.csv"),
    inputs = file.path(stage, "audit",
      "Script12G_input_manifest_with_MD5.csv"),
    session = file.path(stage, "logs", "Script12G_sessionInfo.txt"),
    report = file.path(stage, "logs", "Script12G_COMPLETE_report.txt")
  )

  saveRDS(result_bundle, files["bundle"], version = 3)
  saveRDS(null_distributions, files["nulls"], version = 3)
  write_csv(primary, files["samples"])
  write_csv(group_descriptives, files["groups"])
  write_csv(primary_tests, files["primary"])
  write_csv(sensitivity_tests, files["sensitivity"])
  write_csv(null_summary, files["null_summary"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 3 - Script 12G",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("Source Script 12F bundle MD5: ", EXPECTED_MD5["bundle"]),
    "Primary subset: 20 prespecified TCS/OIL samples; 5 per cell",
    paste0("Nulliparous TCS-OIL estimate: ",
           format(null_test$estimate, digits = 16)),
    paste0("Nulliparous exact two-sided p: ",
           format(null_test$p, digits = 16)),
    paste0("Parous TCS-OIL estimate: ",
           format(par_test$estimate, digits = 16)),
    paste0("Parous exact two-sided p: ",
           format(par_test$p, digits = 16)),
    paste0("Interaction estimate: ",
           format(interaction_estimate, digits = 16)),
    paste0("Interaction exact two-sided p: ",
           format(interaction_p, digits = 16)),
    "State-stratum assignments: 252 each",
    "Stratified interaction assignments: 63,504",
    "Samples filtered: FALSE",
    "Outliers removed: FALSE",
    "Alternative score used: FALSE",
    "Cutoff selected: FALSE",
    "DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT12G STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")
  b2 <- readRDS(files["bundle"])
  n2 <- readRDS(files["nulls"])
  assert(identical(b2$primary_tests, primary_tests) &&
         identical(unname(vapply(n2, length, integer(1))),
                   c(252L, 252L, 63504L)),
         "RDS read-back validation failed.")
  p2 <- read.csv(files["primary"], stringsAsFactors = FALSE,
                 check.names = FALSE)
  assert(nrow(p2) == 3L &&
         isTRUE(all.equal(p2$estimate, primary_tests$estimate,
                          tolerance = 1e-14, check.attributes = FALSE)) &&
         isTRUE(all.equal(p2$exact_two_sided_p,
                          primary_tests$exact_two_sided_p,
                          tolerance = 1e-14, check.attributes = FALSE)),
         "Primary-test CSV read-back validation failed.")

  output_manifest <- file.path(
    stage, "audit", "Script12G_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(stage, full.names = TRUE, all.files = TRUE, no.. = TRUE)
    copied <- file.copy(entries, OUTPUT_ROOT, recursive = TRUE,
                        copy.mode = TRUE, copy.date = TRUE)
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf(
        "Final-directory commit failed. The staging directory was preserved at:\n%s",
        stage
      )
    }
    assert(manifest_ok(OUTPUT_ROOT, file.path(
      OUTPUT_ROOT, "audit", "Script12G_output_manifest_with_MD5.csv")),
      "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }
  committed <- TRUE

  final_manifest <- file.path(
    OUTPUT_ROOT, "audit", "Script12G_output_manifest_with_MD5.csv"
  )
  assert(manifest_ok(OUTPUT_ROOT, final_manifest),
         "Post-commit manifest verification failed.")

  cat("============================================================\n")
  cat("Script 12G completed successfully.\n")
  cat("Primary exact tests: 3\n")
  cat("Samples retained: 20 / 20 prespecified primary samples\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

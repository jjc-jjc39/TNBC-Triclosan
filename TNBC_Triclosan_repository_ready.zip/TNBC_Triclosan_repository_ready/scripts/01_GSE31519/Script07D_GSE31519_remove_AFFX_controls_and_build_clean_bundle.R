# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 07D
#
# Purpose:
#   Continue strictly from the completed Script 07C v2 abnormal-value audit.
#   Reconstruct the 22,283 x 579 expression matrix from the official files,
#   verify every one of the 1,053 non-finite cells against the saved 07C audit,
#   remove only the 15 affected AFFX control probesets, perform no imputation,
#   and save a clean 22,268 x 579 matrix plus aligned phenotype metadata.
#
# Important:
#   - This script does NOT rerun Script 07A, 07B, or 07C.
#   - This script does NOT impute any expression value.
#   - This script does NOT perform annotation, scoring, survival analysis, or plots.
#   - Existing non-empty 02_clean_expression output is never overwritten.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(project_root, "Step2_GSE31519_external_validation")
raw_dir <- file.path(step_root, "01_raw_download")
preflight_dir <- file.path(step_root, "00_preflight")
final_root <- file.path(step_root, "02_clean_expression")

expr_file <- file.path(raw_dir, "GSE31519_complete_dataset.txt.gz")
meta_file <- file.path(raw_dir, "GSE31519_TNBC_SampleInfo_BCR.txt.gz")

audit_invalid_file <- file.path(
  preflight_dir,
  "GSE31519_invalid_expression_cells_FULL_AUDIT.csv"
)
audit_by_probe_file <- file.path(
  preflight_dir,
  "GSE31519_invalid_values_by_probeset.csv"
)
audit_by_sample_file <- file.path(
  preflight_dir,
  "GSE31519_invalid_values_by_sample.csv"
)
audit_safety_file <- file.path(
  preflight_dir,
  "GSE31519_controlled_repair_safety_check.csv"
)
audit_match_file <- file.path(
  preflight_dir,
  "GSE31519_all579_sample_ID_matching_audit.csv"
)
manifest_07c_file <- file.path(
  preflight_dir,
  "Script07C_input_manifest_with_MD5.csv"
)

required_inputs <- c(
  expr_file,
  meta_file,
  audit_invalid_file,
  audit_by_probe_file,
  audit_by_sample_file,
  audit_safety_file,
  audit_match_file,
  manifest_07c_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]
if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 07D cannot start because required files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist: ", step_root, call. = FALSE)
}

# Never overwrite a completed or partially populated fixed output directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )
  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty, so Script 07D will not overwrite it:\n",
        final_root,
        "\nPlease inspect the existing result before deciding whether it should be archived."
      ),
      call. = FALSE
    )
  }
}

# Build every output in one staging directory and commit only after all checks pass.
stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script07D_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(stage_object_dir, stage_audit_dir, stage_log_dir)))) {
  stop("Unable to create the Script 07D staging directories.", call. = FALSE)
}

committed <- FALSE
on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
normalize_existing_path <- function(x) {
  normalizePath(x, winslash = "/", mustWork = TRUE)
}

md5_one <- function(x) {
  unname(tools::md5sum(x))
}

read_gz_delim <- function(path, ...) {
  con <- gzfile(path, open = "rt")
  on.exit(close(con), add = TRUE)
  read.delim(con, ...)
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)
  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(z) normalizePath(z, winslash = "/", mustWork = FALSE),
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

# ------------------------------
# 2. Confirm raw-file identity against the saved Script 07C manifest
# ------------------------------
manifest_07c <- read.csv(
  manifest_07c_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

required_manifest_columns <- c("file_name", "md5")
assert_true(
  all(required_manifest_columns %in% colnames(manifest_07c)),
  "Script07C_input_manifest_with_MD5.csv is missing required columns."
)

current_raw_md5 <- c(
  GSE31519_complete_dataset.txt.gz = md5_one(expr_file),
  GSE31519_TNBC_SampleInfo_BCR.txt.gz = md5_one(meta_file)
)

for (nm in names(current_raw_md5)) {
  hit <- which(manifest_07c$file_name == nm)
  assert_true(
    length(hit) == 1L,
    paste0("The Script 07C manifest does not contain exactly one row for ", nm, ".")
  )
  expected_md5 <- tolower(trimws(manifest_07c$md5[hit]))
  observed_md5 <- tolower(current_raw_md5[[nm]])
  assert_true(
    identical(expected_md5, observed_md5),
    paste0(
      "Raw-file MD5 mismatch for ", nm, ".\n",
      "Expected from Script 07C: ", expected_md5, "\n",
      "Observed now: ", observed_md5, "\n",
      "No output was written."
    )
  )
}

# ------------------------------
# 3. Load and validate the saved Script 07C audit tables
# ------------------------------
invalid_audit <- read.csv(
  audit_invalid_file,
  stringsAsFactors = FALSE,
  check.names = FALSE,
  na.strings = c("", "NA")
)
by_probe_audit <- read.csv(
  audit_by_probe_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
by_sample_audit <- read.csv(
  audit_by_sample_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
safety_audit <- read.csv(
  audit_safety_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
matching_audit <- read.csv(
  audit_match_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(c("probeset_id", "sample_id") %in% colnames(invalid_audit)),
  "The full invalid-cell audit is missing probeset_id or sample_id."
)
assert_true(
  all(c("probeset_id", "invalid_value_number", "invalid_fraction") %in%
        colnames(by_probe_audit)),
  "The probeset-level invalid-value audit is incomplete."
)
assert_true(
  all(c("sample_id", "invalid_value_number", "invalid_fraction") %in%
        colnames(by_sample_audit)),
  "The sample-level invalid-value audit is incomplete."
)
assert_true(
  nrow(invalid_audit) == 1053L,
  paste0(
    "Expected 1,053 invalid cells from Script 07C v2, but the audit contains ",
    nrow(invalid_audit), "."
  )
)

remove_probe_ids <- unique(trimws(invalid_audit$probeset_id))
assert_true(
  length(remove_probe_ids) == 15L,
  paste0(
    "Expected exactly 15 affected probesets, but found ",
    length(remove_probe_ids), "."
  )
)
assert_true(
  all(grepl("^AFFX-", remove_probe_ids)),
  "At least one affected probeset is not an AFFX control probeset; removal is not allowed."
)

# The prespecified 07C gate must show that the original repair was not allowed.
assert_true(
  all(c("criterion", "observed_value", "passed") %in% colnames(safety_audit)),
  "The Script 07C safety-check table is incomplete."
)
assert_true(
  any(!as.logical(safety_audit$passed)),
  "The supplied safety-check table does not contain the expected failed gate."
)

# ------------------------------
# 4. Reconstruct the expression matrix directly from the official file
# ------------------------------
# Rows in the official file:
#   line 1: dataset description
#   line 2: sample-name header
#   line 3: ArrayExpress IDs for relevant samples
#   line 4: GSM accessions for relevant samples
#   line 5 onward: 22,283 U133A probesets
header4 <- read_gz_delim(
  expr_file,
  header = FALSE,
  sep = "\t",
  quote = "",
  comment.char = "",
  fill = TRUE,
  nrows = 4L,
  colClasses = "character",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

assert_true(
  nrow(header4) == 4L,
  "Unable to read the first four structural rows of the complete dataset."
)
assert_true(
  ncol(header4) == 603L,
  paste0(
    "Expected 603 raw fields, but detected ", ncol(header4),
    ". The file structure differs from the audited input."
  )
)

sample_header <- trimws(as.character(header4[2L, ]))
header_sample_column_index <- which(grepl("^TNBC_[0-9]{3}$", sample_header))
header_sample_ids <- sample_header[header_sample_column_index]
expected_sample_ids <- sprintf("TNBC_%03d", seq_len(579L))

assert_true(
  length(header_sample_column_index) == 579L,
  paste0(
    "Expected 579 TNBC sample columns in line 2, but detected ",
    length(header_sample_column_index), "."
  )
)
assert_true(
  anyDuplicated(header_sample_ids) == 0L,
  "Duplicate TNBC sample IDs were detected in the expression header."
)
assert_true(
  setequal(header_sample_ids, expected_sample_ids),
  "The expression header does not contain exactly TNBC_001 through TNBC_579."
)

# The 23 ArrayExpress-derived samples are not necessarily stored in numerical
# TNBC order in the raw file. Import by the audited header positions first,
# then explicitly reorder the matrix to TNBC_001 through TNBC_579.
sample_ids <- expected_sample_ids

# Read only the probeset-ID column and the 579 audited sample columns.
# The 23 unused structural columns are skipped at import and never enter the matrix.
column_classes <- rep("NULL", ncol(header4))
column_classes[1L] <- "character"
column_classes[header_sample_column_index] <- "numeric"

expr_import <- read_gz_delim(
  expr_file,
  header = FALSE,
  sep = "\t",
  quote = "",
  comment.char = "",
  fill = TRUE,
  skip = 4L,
  colClasses = column_classes,
  na.strings = c("", "NA", "NaN"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)

assert_true(
  nrow(expr_import) == 22283L,
  paste0(
    "Expected 22,283 probeset rows, but imported ", nrow(expr_import), "."
  )
)
assert_true(
  ncol(expr_import) == 580L,
  paste0(
    "Expected one probeset-ID column plus 579 sample columns, but imported ",
    ncol(expr_import), " columns."
  )
)

probeset_ids <- trimws(as.character(expr_import[[1L]]))
assert_true(
  !anyNA(probeset_ids) && all(nzchar(probeset_ids)),
  "Missing or blank probeset IDs were detected."
)
assert_true(
  anyDuplicated(probeset_ids) == 0L,
  "Duplicate probeset IDs were detected."
)

expr_matrix <- as.matrix(expr_import[, -1L, drop = FALSE])
storage.mode(expr_matrix) <- "double"
rownames(expr_matrix) <- probeset_ids
colnames(expr_matrix) <- header_sample_ids

assert_true(
  setequal(colnames(expr_matrix), sample_ids),
  "Imported expression columns do not contain the expected 579 TNBC sample IDs."
)
expr_matrix <- expr_matrix[, sample_ids, drop = FALSE]

rm(expr_import)
gc()

assert_true(
  identical(dim(expr_matrix), c(22283L, 579L)),
  "The reconstructed expression matrix does not have dimensions 22,283 x 579."
)
assert_true(
  identical(colnames(expr_matrix), sample_ids),
  "Expression columns could not be reordered to TNBC_001 through TNBC_579."
)

# ------------------------------
# 5. Verify every non-finite cell against the saved 07C audit
# ------------------------------
nonfinite_index <- which(!is.finite(expr_matrix), arr.ind = TRUE)
assert_true(
  nrow(nonfinite_index) == 1053L,
  paste0(
    "The reconstructed matrix contains ", nrow(nonfinite_index),
    " non-finite cells instead of the audited 1,053."
  )
)

current_nonfinite <- data.frame(
  probeset_id = rownames(expr_matrix)[nonfinite_index[, "row"]],
  sample_id = colnames(expr_matrix)[nonfinite_index[, "col"]],
  stringsAsFactors = FALSE
)

current_keys <- paste(
  current_nonfinite$probeset_id,
  current_nonfinite$sample_id,
  sep = "||"
)
audit_keys <- paste(
  trimws(invalid_audit$probeset_id),
  trimws(invalid_audit$sample_id),
  sep = "||"
)

assert_true(
  identical(sort(current_keys), sort(audit_keys)),
  paste0(
    "The current non-finite cells do not exactly match the Script 07C v2 audit.\n",
    "No probeset was removed and no output was committed."
  )
)

current_nonfinite_probes <- unique(current_nonfinite$probeset_id)
assert_true(
  setequal(current_nonfinite_probes, remove_probe_ids),
  "The current affected probesets do not exactly match the 15 audited AFFX probesets."
)
assert_true(
  all(grepl("^AFFX-", current_nonfinite_probes)),
  "A current non-finite value occurs outside an AFFX control probeset."
)

biological_probe_mask <- !rownames(expr_matrix) %in% remove_probe_ids
assert_true(
  all(is.finite(expr_matrix[biological_probe_mask, , drop = FALSE])),
  "At least one non-finite value remains outside the 15 audited AFFX controls."
)

# ------------------------------
# 6. Remove only the 15 affected AFFX control probesets; no imputation
# ------------------------------
expr_clean <- expr_matrix[biological_probe_mask, , drop = FALSE]

assert_true(
  identical(dim(expr_clean), c(22268L, 579L)),
  paste0(
    "Expected a final matrix of 22,268 x 579 after removing 15 controls, but obtained ",
    paste(dim(expr_clean), collapse = " x "), "."
  )
)
assert_true(
  all(is.finite(expr_clean)),
  "The filtered expression matrix still contains a non-finite value."
)
assert_true(
  !any(rownames(expr_clean) %in% remove_probe_ids),
  "At least one audited AFFX control probeset remains in the filtered matrix."
)

# ------------------------------
# 7. Rebuild and align phenotype metadata
# ------------------------------
meta_raw <- read_gz_delim(
  meta_file,
  header = TRUE,
  sep = "\t",
  quote = "",
  comment.char = "",
  fill = TRUE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  na.strings = c("", "NA", "N/A")
)

assert_true(
  identical(dim(meta_raw), c(11L, 580L)),
  paste0(
    "Expected the raw sample-information table to be 11 x 580, but detected ",
    paste(dim(meta_raw), collapse = " x "), "."
  )
)
assert_true(
  identical(colnames(meta_raw)[1L], "SampleNames"),
  "The first sample-information column is not named SampleNames."
)

metadata_field_names <- trimws(as.character(meta_raw[[1L]]))
assert_true(
  length(metadata_field_names) == 11L &&
    all(nzchar(metadata_field_names)) &&
    anyDuplicated(metadata_field_names) == 0L,
  "The 11 metadata field names are blank or duplicated."
)

metadata_sample_ids <- trimws(colnames(meta_raw)[-1L])
assert_true(
  length(metadata_sample_ids) == 579L && anyDuplicated(metadata_sample_ids) == 0L,
  "The sample-information header does not contain 579 unique sample IDs."
)
assert_true(
  setequal(metadata_sample_ids, sample_ids),
  "The metadata and expression files do not contain the same 579 TNBC sample IDs."
)

meta_matrix <- t(as.matrix(meta_raw[, -1L, drop = FALSE]))
colnames(meta_matrix) <- metadata_field_names
rownames(meta_matrix) <- metadata_sample_ids

phenotype <- data.frame(
  sample_id = rownames(meta_matrix),
  meta_matrix,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# Convert genuinely numeric metadata columns while retaining text fields as character.
for (nm in setdiff(colnames(phenotype), "sample_id")) {
  x <- trimws(as.character(phenotype[[nm]]))
  x[x %in% c("", "NA", "N/A")] <- NA_character_
  phenotype[[nm]] <- type.convert(
    x,
    na.strings = c("", "NA", "N/A"),
    as.is = TRUE
  )
}

metadata_order <- match(colnames(expr_clean), phenotype$sample_id)
assert_true(
  !anyNA(metadata_order),
  "At least one expression sample could not be matched to phenotype metadata."
)
phenotype <- phenotype[metadata_order, , drop = FALSE]
rownames(phenotype) <- phenotype$sample_id

assert_true(
  identical(phenotype$sample_id, colnames(expr_clean)),
  "Phenotype rows are not in exactly the same order as expression-matrix columns."
)
assert_true(
  nrow(phenotype) == 579L,
  "The aligned phenotype table does not contain 579 rows."
)

# Confirm the saved 07C matching audit also supports the same exact alignment.
assert_true(
  all(c("metadata_sample_id", "exact_normalized_match") %in%
        colnames(matching_audit)),
  "The 579-sample matching audit is incomplete."
)
assert_true(
  nrow(matching_audit) == 579L &&
    all(as.logical(matching_audit$exact_normalized_match)) &&
    identical(trimws(matching_audit$metadata_sample_id), sample_ids),
  "The saved 07C sample-ID matching audit is not an exact 579-sample match."
)

# ------------------------------
# 8. Create audit outputs
# ------------------------------
removed_probe_audit <- by_probe_audit[
  by_probe_audit$probeset_id %in% remove_probe_ids,
  c("probeset_id", "invalid_value_number", "invalid_fraction"),
  drop = FALSE
]
removed_probe_audit <- removed_probe_audit[
  match(remove_probe_ids, removed_probe_audit$probeset_id),
  ,
  drop = FALSE
]
removed_probe_audit$probe_class <- "AFFX control probeset"
removed_probe_audit$action <- "REMOVED_ROW_NO_IMPUTATION"
removed_probe_audit$reason <- paste0(
  "Non-finite values were confined to audited AFFX control probesets; ",
  "all non-AFFX probesets were complete."
)

sample_alignment_audit <- data.frame(
  matrix_column_order = seq_along(colnames(expr_clean)),
  expression_sample_id = colnames(expr_clean),
  phenotype_sample_id = phenotype$sample_id,
  exact_match = colnames(expr_clean) == phenotype$sample_id,
  stringsAsFactors = FALSE
)

postfilter_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Raw_probeset_number",
    "Sample_number",
    "Audited_nonfinite_cell_number_before_filter",
    "Affected_probeset_number",
    "All_affected_probesets_AFFX_controls",
    "Non_AFFX_nonfinite_cell_number_before_filter",
    "Imputed_value_number",
    "Removed_AFFX_control_probeset_number",
    "Final_probeset_number",
    "Final_sample_number",
    "Nonfinite_cell_number_after_filter",
    "Phenotype_row_number",
    "Expression_phenotype_order_identical",
    "Raw_expression_MD5",
    "Raw_metadata_MD5",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "07D",
    nrow(expr_matrix),
    ncol(expr_matrix),
    nrow(nonfinite_index),
    length(remove_probe_ids),
    all(grepl("^AFFX-", remove_probe_ids)),
    sum(!is.finite(expr_matrix[biological_probe_mask, , drop = FALSE])),
    0L,
    length(remove_probe_ids),
    nrow(expr_clean),
    ncol(expr_clean),
    sum(!is.finite(expr_clean)),
    nrow(phenotype),
    identical(colnames(expr_clean), phenotype$sample_id),
    current_raw_md5[["GSE31519_complete_dataset.txt.gz"]],
    current_raw_md5[["GSE31519_TNBC_SampleInfo_BCR.txt.gz"]],
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

input_manifest <- make_manifest(required_inputs)

# ------------------------------
# 9. Save the complete bundle and provenance in staging
# ------------------------------
bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script07D",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  expression_matrix = expr_clean,
  phenotype = phenotype,
  removed_AFFX_control_probes = removed_probe_audit,
  postfilter_summary = postfilter_summary,
  sample_alignment_audit = sample_alignment_audit,
  provenance = list(
    raw_expression_file = normalize_existing_path(expr_file),
    raw_metadata_file = normalize_existing_path(meta_file),
    script07C_invalid_cell_audit = normalize_existing_path(audit_invalid_file),
    raw_expression_md5 = current_raw_md5[["GSE31519_complete_dataset.txt.gz"]],
    raw_metadata_md5 = current_raw_md5[["GSE31519_TNBC_SampleInfo_BCR.txt.gz"]],
    nonfinite_handling = "Removed 15 affected AFFX control probeset rows; no value imputation",
    final_dimensions = dim(expr_clean)
  )
)
class(bundle) <- c("GSE31519_clean_bundle", "list")

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_clean_expression_COMPLETE_bundle.rds"
)
stage_removed_file <- file.path(
  stage_audit_dir,
  "GSE31519_removed_AFFX_control_probes.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_postfilter_integrity_summary.csv"
)
stage_alignment_file <- file.path(
  stage_audit_dir,
  "GSE31519_expression_phenotype_alignment_audit.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script07D_input_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script07D_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script07D_COMPLETE_report.txt"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script07D_output_manifest_with_MD5.csv"
)

saveRDS(bundle, stage_bundle_file, compress = "gzip")
write_csv_utf8(removed_probe_audit, stage_removed_file)
write_csv_utf8(postfilter_summary, stage_summary_file)
write_csv_utf8(sample_alignment_audit, stage_alignment_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)
writeLines(capture.output(sessionInfo()), con = stage_session_file, useBytes = TRUE)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 07D",
  "GSE31519 AFFX-control removal and clean-bundle construction",
  "============================================================",
  paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Raw expression dimensions: ", nrow(expr_matrix), " x ", ncol(expr_matrix)),
  paste0("Audited non-finite cells before filtering: ", nrow(nonfinite_index)),
  paste0("Affected probesets: ", length(remove_probe_ids)),
  paste0("All affected probesets are AFFX controls: ", all(grepl("^AFFX-", remove_probe_ids))),
  paste0("Non-AFFX non-finite cells before filtering: ", sum(!is.finite(expr_matrix[biological_probe_mask, , drop = FALSE]))),
  "Imputed values: 0",
  paste0("Removed AFFX control probesets: ", length(remove_probe_ids)),
  paste0("Final expression dimensions: ", nrow(expr_clean), " x ", ncol(expr_clean)),
  paste0("Non-finite cells after filtering: ", sum(!is.finite(expr_clean))),
  paste0("Aligned phenotype rows: ", nrow(phenotype)),
  paste0("Expression/phenotype order identical: ", identical(colnames(expr_clean), phenotype$sample_id)),
  paste0("Bundle MD5: ", bundle_md5),
  "",
  "SCRIPT07D STATUS: COMPLETE",
  "No biological probeset was removed because of missingness.",
  "No expression value was imputed.",
  "No downstream annotation, scoring, survival analysis, or plotting was performed.",
  "============================================================"
)
writeLines(report_lines, con = stage_report_file, useBytes = TRUE)

# Output manifest uses the final committed paths but hashes the staged files.
stage_output_files <- c(
  stage_bundle_file,
  stage_removed_file,
  stage_summary_file,
  stage_alignment_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)
final_output_files <- c(
  file.path(final_root, "objects", basename(stage_bundle_file)),
  file.path(final_root, "audit", basename(stage_removed_file)),
  file.path(final_root, "audit", basename(stage_summary_file)),
  file.path(final_root, "audit", basename(stage_alignment_file)),
  file.path(final_root, "audit", basename(stage_input_manifest_file)),
  file.path(final_root, "logs", basename(stage_session_file)),
  file.path(final_root, "logs", basename(stage_report_file))
)
output_manifest <- make_manifest(stage_output_files, final_output_files)
write_csv_utf8(output_manifest, stage_output_manifest_file)

# Final staging verification before the one-step directory commit.
all_stage_outputs <- c(stage_output_files, stage_output_manifest_file)
assert_true(
  all(file.exists(all_stage_outputs)),
  "At least one staged output is missing; the final directory was not committed."
)
assert_true(
  file.info(stage_bundle_file)$size > 0,
  "The staged RDS bundle is empty; the final directory was not committed."
)

# ------------------------------
# 10. Commit the complete result directory atomically
# ------------------------------
commit_ok <- file.rename(stage_root, final_root)
assert_true(
  commit_ok && dir.exists(final_root),
  paste0(
    "All checks passed, but the staging directory could not be renamed to:\n",
    final_root,
    "\nThe staging directory has not been intentionally overwritten."
  )
)
committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_clean_expression_COMPLETE_bundle.rds"
)

cat("\n")
cat("============================================================\n")
cat("Script 07D completed successfully.\n")
cat("Removed only 15 audited AFFX control probesets.\n")
cat("Imputed expression values: 0\n")
cat("Final expression matrix: 22,268 probesets x 579 samples\n")
cat("Final non-finite values: 0\n")
cat("Bundle: ", normalizePath(final_bundle_file, winslash = "/", mustWork = TRUE), "\n", sep = "")
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("✅ 已完成\n")

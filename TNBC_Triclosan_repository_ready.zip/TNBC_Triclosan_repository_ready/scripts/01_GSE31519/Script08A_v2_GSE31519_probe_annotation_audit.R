# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 08A v2
#
# Purpose:
#   Continue strictly from the completed and audited Script 07D clean bundle.
#   Audit the 22,268 retained HG-U133A rows, separate 53 complete AFFX controls,
#   and annotate the 22,215 non-AFFX probesets with the official
#   Bioconductor hgu133a.db package and audit the real mapping structure.
#
# This script DOES:
#   - verify the Script 07D bundle identity by MD5;
#   - verify dimensions, sample alignment and finite values;
#   - audit the 53 complete AFFX control probesets retained by Script 07D;
#   - exclude those controls only from annotation input;
#   - retrieve PROBEID -> SYMBOL / ENTREZID / GENENAME mappings for non-AFFX probesets;
#   - save complete mapping, unmapped probes, multi-symbol probes and
#     gene-to-probe multiplicity audits;
#   - save an annotation audit bundle, manifests, MD5 and sessionInfo.
#
# This script DOES NOT:
#   - rerun Scripts 07A-07D;
#   - alter or normalize expression values;
#   - choose a representative probe;
#   - collapse probesets to genes;
#   - calculate a Triclosan score;
#   - perform survival analysis or plotting.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(project_root, "Step2_GSE31519_external_validation")
clean_root <- file.path(step_root, "02_clean_expression")
final_root <- file.path(step_root, "03_probe_annotation_audit")

clean_bundle_file <- file.path(
  clean_root,
  "objects",
  "GSE31519_clean_expression_COMPLETE_bundle.rds"
)
manifest_07d_file <- file.path(
  clean_root,
  "audit",
  "Script07D_output_manifest_with_MD5.csv"
)
summary_07d_file <- file.path(
  clean_root,
  "audit",
  "GSE31519_postfilter_integrity_summary.csv"
)
report_07d_file <- file.path(
  clean_root,
  "logs",
  "Script07D_COMPLETE_report.txt"
)

required_inputs <- c(
  clean_bundle_file,
  manifest_07d_file,
  summary_07d_file,
  report_07d_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]
if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 08A cannot start because required Script 07D files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist: ", step_root, call. = FALSE)
}

# Never overwrite a completed or partially populated fixed output directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )
  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty, so Script 08A will not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

# Build every output in a staging directory; commit only after all checks pass.
stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script08A_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(stage_object_dir, stage_audit_dir, stage_log_dir)))) {
  stop("Unable to create Script 08A staging directories.", call. = FALSE)
}

committed <- FALSE
on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

normalize_existing_path <- function(x) {
  normalizePath(x, winslash = "/", mustWork = TRUE)
}

md5_one <- function(x) {
  unname(tools::md5sum(x))
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)
  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(z) normalizePath(z, winslash = "/", mustWork = FALSE),
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

clean_character <- function(x) {
  x <- trimws(as.character(x))
  x[x == ""] <- NA_character_
  x
}

install_bioc_if_missing <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) == 0L) return(invisible(TRUE))

  if (!requireNamespace("BiocManager", quietly = TRUE)) {
    install.packages("BiocManager", repos = "https://cloud.r-project.org")
  }

  BiocManager::install(
    missing,
    ask = FALSE,
    update = FALSE
  )

  still_missing <- missing[
    !vapply(missing, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(still_missing) > 0L) {
    stop(
      paste0(
        "Required Bioconductor package installation failed:\n",
        paste0("- ", still_missing, collapse = "\n"),
        "\nNo final output directory was committed."
      ),
      call. = FALSE
    )
  }

  invisible(TRUE)
}

# ------------------------------
# 2. Verify Script 07D bundle identity and completion
# ------------------------------
manifest_07d <- read.csv(
  manifest_07d_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(c("file_name", "md5") %in% colnames(manifest_07d)),
  "Script07D_output_manifest_with_MD5.csv is missing file_name or md5."
)

bundle_name <- basename(clean_bundle_file)
bundle_rows <- which(manifest_07d$file_name == bundle_name)
assert_true(
  length(bundle_rows) == 1L,
  paste0("The Script 07D output manifest must contain exactly one row for ", bundle_name, ".")
)

expected_bundle_md5 <- tolower(trimws(manifest_07d$md5[bundle_rows]))
observed_bundle_md5 <- tolower(md5_one(clean_bundle_file))
assert_true(
  identical(expected_bundle_md5, observed_bundle_md5),
  paste0(
    "Script 07D bundle MD5 mismatch.\n",
    "Expected: ", expected_bundle_md5, "\n",
    "Observed: ", observed_bundle_md5, "\n",
    "No output was committed."
  )
)

summary_07d <- read.csv(
  summary_07d_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
assert_true(
  all(c("item", "value") %in% colnames(summary_07d)),
  "GSE31519_postfilter_integrity_summary.csv is malformed."
)
summary_lookup <- setNames(as.character(summary_07d$value), summary_07d$item)
assert_true(
  identical(summary_lookup[["Completion_status"]], "COMPLETE"),
  "Script 07D completion status is not COMPLETE."
)
assert_true(
  identical(summary_lookup[["Final_probeset_number"]], "22268"),
  "Script 07D final probeset number is not 22,268."
)
assert_true(
  identical(summary_lookup[["Final_sample_number"]], "579"),
  "Script 07D final sample number is not 579."
)
assert_true(
  identical(summary_lookup[["Nonfinite_cell_number_after_filter"]], "0"),
  "Script 07D reported non-finite values after filtering."
)
assert_true(
  identical(summary_lookup[["Expression_phenotype_order_identical"]], "TRUE"),
  "Script 07D reported expression/phenotype misalignment."
)

# ------------------------------
# 3. Read and independently validate the Script 07D bundle
# ------------------------------
clean_bundle <- readRDS(clean_bundle_file)

required_bundle_fields <- c(
  "project",
  "step",
  "script",
  "source_accession",
  "expression_matrix",
  "phenotype",
  "removed_AFFX_control_probes",
  "postfilter_summary",
  "sample_alignment_audit",
  "provenance"
)
assert_true(
  is.list(clean_bundle) && all(required_bundle_fields %in% names(clean_bundle)),
  "The Script 07D RDS does not contain the required bundle fields."
)
assert_true(
  identical(as.character(clean_bundle$source_accession), "GSE31519"),
  "The Script 07D bundle source accession is not GSE31519."
)

expr <- clean_bundle$expression_matrix
phenotype <- clean_bundle$phenotype

assert_true(is.matrix(expr), "expression_matrix is not a matrix.")
assert_true(is.numeric(expr), "expression_matrix is not numeric.")
assert_true(
  identical(dim(expr), c(22268L, 579L)),
  paste0(
    "Unexpected expression dimensions: ",
    paste(dim(expr), collapse = " x "),
    ". Expected 22268 x 579."
  )
)
assert_true(
  !is.null(rownames(expr)) && !anyDuplicated(rownames(expr)),
  "Expression probeset IDs are missing or duplicated."
)
assert_true(
  !is.null(colnames(expr)) && !anyDuplicated(colnames(expr)),
  "Expression sample IDs are missing or duplicated."
)
assert_true(
  sum(!is.finite(expr)) == 0L,
  "The Script 07D expression matrix contains a non-finite value."
)
assert_true(
  is.data.frame(phenotype) && nrow(phenotype) == 579L,
  "The phenotype table is not a 579-row data.frame."
)
assert_true(
  "sample_id" %in% colnames(phenotype),
  "The phenotype table does not contain sample_id."
)
assert_true(
  identical(colnames(expr), as.character(phenotype$sample_id)),
  "Expression columns and phenotype rows are not identically ordered."
)

# Script 07D removed only the 15 AFFX rows that contained non-finite values.
# Complete AFFX control rows were intentionally retained in the clean matrix.
probe_ids <- rownames(expr)
retained_affx_mask <- grepl("^AFFX-", probe_ids, ignore.case = FALSE)
retained_affx_ids <- probe_ids[retained_affx_mask]
annotation_probe_ids <- probe_ids[!retained_affx_mask]

removed_affx <- clean_bundle$removed_AFFX_control_probes
assert_true(
  is.data.frame(removed_affx) && "probeset_id" %in% colnames(removed_affx),
  "The Script 07D removed-AFFX audit is missing or malformed."
)
removed_affx_ids <- unique(clean_character(removed_affx$probeset_id))
removed_affx_ids <- removed_affx_ids[!is.na(removed_affx_ids)]

assert_true(
  length(removed_affx_ids) == 15L && all(grepl("^AFFX-", removed_affx_ids)),
  "The Script 07D bundle does not document exactly 15 removed AFFX controls."
)
assert_true(
  length(retained_affx_ids) == 53L,
  paste0(
    "Unexpected number of complete AFFX controls retained after Script 07D: ",
    length(retained_affx_ids), ". Expected 53."
  )
)
assert_true(
  length(annotation_probe_ids) == 22215L,
  paste0(
    "Unexpected number of non-AFFX probesets available for annotation: ",
    length(annotation_probe_ids), ". Expected 22,215."
  )
)
assert_true(
  length(intersect(retained_affx_ids, removed_affx_ids)) == 0L,
  "A probeset is simultaneously listed as removed and retained."
)
assert_true(
  length(unique(c(removed_affx_ids, retained_affx_ids))) == 68L,
  "The combined removed and retained AFFX control inventory is not 68 probesets."
)
assert_true(
  sum(!is.finite(expr[retained_affx_ids, , drop = FALSE])) == 0L,
  "At least one retained AFFX control contains a non-finite value."
)

retained_affx_audit <- data.frame(
  probeset_id = retained_affx_ids,
  source_matrix_row = match(retained_affx_ids, probe_ids),
  sample_number = ncol(expr),
  nonfinite_value_number = vapply(
    retained_affx_ids,
    function(id) sum(!is.finite(expr[id, ])),
    integer(1)
  ),
  action_in_script08a = "EXCLUDED_FROM_GENE_ANNOTATION_ONLY",
  reason = paste0(
    "Complete AFFX platform-control probeset retained by Script 07D; ",
    "not a biological gene-expression probeset."
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
assert_true(
  all(retained_affx_audit$nonfinite_value_number == 0L),
  "The retained AFFX audit contains a non-finite value."
)

# ------------------------------
# 4. Install/load the official annotation resources
# ------------------------------
install_bioc_if_missing(c("AnnotationDbi", "hgu133a.db"))

annotation_db <- hgu133a.db::hgu133a.db
annotation_db_metadata <- AnnotationDbi::metadata(annotation_db)
annotation_db_metadata <- as.data.frame(
  annotation_db_metadata,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

package_audit <- data.frame(
  package = c("AnnotationDbi", "hgu133a.db"),
  version = c(
    as.character(utils::packageVersion("AnnotationDbi")),
    as.character(utils::packageVersion("hgu133a.db"))
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 5. Retrieve complete probeset annotation without collapsing expression
# ------------------------------
annotation_raw <- suppressMessages(
  AnnotationDbi::select(
    annotation_db,
    keys = annotation_probe_ids,
    keytype = "PROBEID",
    columns = c("SYMBOL", "ENTREZID", "GENENAME")
  )
)

required_annotation_columns <- c("PROBEID", "SYMBOL", "ENTREZID", "GENENAME")
assert_true(
  all(required_annotation_columns %in% colnames(annotation_raw)),
  "hgu133a.db select() did not return the required annotation columns."
)

annotation_full <- data.frame(
  probeset_id = clean_character(annotation_raw$PROBEID),
  gene_symbol = clean_character(annotation_raw$SYMBOL),
  entrez_id = clean_character(annotation_raw$ENTREZID),
  gene_name = clean_character(annotation_raw$GENENAME),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# Add any input key unexpectedly omitted by select(), preserving a complete audit.
omitted_probes <- setdiff(annotation_probe_ids, annotation_full$probeset_id)
if (length(omitted_probes) > 0L) {
  annotation_full <- rbind(
    annotation_full,
    data.frame(
      probeset_id = omitted_probes,
      gene_symbol = NA_character_,
      entrez_id = NA_character_,
      gene_name = NA_character_,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )
}

annotation_full <- unique(annotation_full)
annotation_full$input_probe_order <- match(annotation_full$probeset_id, annotation_probe_ids)
assert_true(
  !anyNA(annotation_full$input_probe_order),
  "Annotation output contains a probeset not present in the Script 07D matrix."
)

annotation_full$valid_gene_symbol <- !is.na(annotation_full$gene_symbol)
annotation_full <- annotation_full[
  order(
    annotation_full$input_probe_order,
    !annotation_full$valid_gene_symbol,
    annotation_full$gene_symbol,
    annotation_full$entrez_id,
    na.last = TRUE
  ),
  ,
  drop = FALSE
]
rownames(annotation_full) <- NULL

assert_true(
  identical(sort(unique(annotation_full$probeset_id)), sort(annotation_probe_ids)),
  "The full annotation audit does not cover exactly all 22,215 non-AFFX input probesets."
)

# ------------------------------
# 6. Build one-row-per-probeset annotation status audit
# ------------------------------
rows_per_probe_table <- table(annotation_full$probeset_id)
rows_per_probe <- as.integer(rows_per_probe_table[annotation_probe_ids])

valid_map <- annotation_full[
  annotation_full$valid_gene_symbol,
  c("probeset_id", "gene_symbol", "entrez_id", "gene_name"),
  drop = FALSE
]
valid_probe_symbol_pairs <- unique(
  valid_map[, c("probeset_id", "gene_symbol"), drop = FALSE]
)

symbol_count <- integer(length(annotation_probe_ids))
names(symbol_count) <- annotation_probe_ids
if (nrow(valid_probe_symbol_pairs) > 0L) {
  symbol_table <- table(valid_probe_symbol_pairs$probeset_id)
  symbol_count[names(symbol_table)] <- as.integer(symbol_table)
}

entrez_count <- integer(length(annotation_probe_ids))
names(entrez_count) <- annotation_probe_ids
valid_entrez_map <- unique(
  valid_map[
    !is.na(valid_map$entrez_id),
    c("probeset_id", "entrez_id"),
    drop = FALSE
  ]
)
if (nrow(valid_entrez_map) > 0L) {
  entrez_table <- table(valid_entrez_map$probeset_id)
  entrez_count[names(entrez_table)] <- as.integer(entrez_table)
}

probe_status <- data.frame(
  input_probe_order = seq_along(annotation_probe_ids),
  probeset_id = annotation_probe_ids,
  annotation_row_number = rows_per_probe,
  valid_gene_symbol_number = unname(symbol_count[annotation_probe_ids]),
  valid_entrez_id_number = unname(entrez_count[annotation_probe_ids]),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

probe_status$annotation_status <- ifelse(
  probe_status$valid_gene_symbol_number == 0L,
  "UNMAPPED_NO_VALID_SYMBOL",
  ifelse(
    probe_status$valid_gene_symbol_number == 1L,
    "UNIQUE_GENE_SYMBOL",
    "MULTIPLE_GENE_SYMBOLS"
  )
)

assert_true(
  nrow(probe_status) == 22215L && !anyDuplicated(probe_status$probeset_id),
  "The one-row-per-probeset status audit is incomplete or duplicated."
)

unmapped_probes <- probe_status[
  probe_status$annotation_status == "UNMAPPED_NO_VALID_SYMBOL",
  ,
  drop = FALSE
]

multisymbol_ids <- probe_status$probeset_id[
  probe_status$annotation_status == "MULTIPLE_GENE_SYMBOLS"
]
multisymbol_probes <- annotation_full[
  annotation_full$probeset_id %in% multisymbol_ids &
    annotation_full$valid_gene_symbol,
  ,
  drop = FALSE
]

# ------------------------------
# 7. Audit one-gene-to-multiple-probeset structure
# ------------------------------
if (nrow(valid_probe_symbol_pairs) > 0L) {
  gene_probe_table <- sort(
    table(valid_probe_symbol_pairs$gene_symbol),
    decreasing = TRUE
  )
  gene_probe_multiplicity <- data.frame(
    gene_symbol = names(gene_probe_table),
    probeset_number = as.integer(gene_probe_table),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
} else {
  gene_probe_multiplicity <- data.frame(
    gene_symbol = character(0),
    probeset_number = integer(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

gene_probe_multiplicity$multiple_probesets <-
  gene_probe_multiplicity$probeset_number > 1L

probe_ids_by_gene <- split(
  valid_probe_symbol_pairs$probeset_id,
  valid_probe_symbol_pairs$gene_symbol
)
if (nrow(gene_probe_multiplicity) > 0L) {
  gene_probe_multiplicity$probeset_ids <- vapply(
    gene_probe_multiplicity$gene_symbol,
    function(g) paste(sort(unique(probe_ids_by_gene[[g]])), collapse = ";"),
    character(1)
  )
} else {
  gene_probe_multiplicity$probeset_ids <- character(0)
}

# ------------------------------
# 8. Summarize mapping structure without choosing a collapse rule
# ------------------------------
n_input <- length(annotation_probe_ids)
n_mapped <- sum(probe_status$valid_gene_symbol_number >= 1L)
n_unique <- sum(probe_status$valid_gene_symbol_number == 1L)
n_multi <- sum(probe_status$valid_gene_symbol_number > 1L)
n_unmapped <- sum(probe_status$valid_gene_symbol_number == 0L)
n_gene_symbols <- nrow(gene_probe_multiplicity)
n_genes_one_probe <- sum(gene_probe_multiplicity$probeset_number == 1L)
n_genes_multi_probe <- sum(gene_probe_multiplicity$probeset_number > 1L)
max_probe_per_gene <- if (n_gene_symbols > 0L) {
  max(gene_probe_multiplicity$probeset_number)
} else {
  0L
}

annotation_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Annotation_platform",
    "Source_clean_matrix_probeset_number",
    "Removed_AFFX_controls_in_Script07D",
    "Retained_complete_AFFX_controls",
    "Non_AFFX_probesets_submitted_for_annotation",
    "Input_probeset_number",
    "Sample_number_reference_only",
    "Full_annotation_row_number",
    "Probesets_with_at_least_one_valid_symbol",
    "Probeset_symbol_mapping_rate",
    "Probesets_with_exactly_one_valid_symbol",
    "Probesets_with_multiple_valid_symbols",
    "Probesets_without_valid_symbol",
    "Unique_valid_gene_symbol_number",
    "Genes_represented_by_one_probeset",
    "Genes_represented_by_multiple_probesets",
    "Maximum_probesets_per_gene_symbol",
    "Expression_values_modified",
    "Gene_level_matrix_created",
    "Representative_probe_selected",
    "Source_clean_bundle_MD5",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "08A_v2",
    "Affymetrix HG-U133A / hgu133a.db",
    nrow(expr),
    length(removed_affx_ids),
    length(retained_affx_ids),
    length(annotation_probe_ids),
    n_input,
    ncol(expr),
    nrow(annotation_full),
    n_mapped,
    format(n_mapped / n_input, digits = 10, scientific = FALSE),
    n_unique,
    n_multi,
    n_unmapped,
    n_gene_symbols,
    n_genes_one_probe,
    n_genes_multi_probe,
    max_probe_per_gene,
    "FALSE",
    "FALSE",
    "FALSE",
    observed_bundle_md5,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  n_mapped > 0L && n_gene_symbols > 0L,
  "No valid gene-symbol mappings were recovered; no final output was committed."
)
assert_true(
  n_unique + n_multi + n_unmapped == n_input,
  "Probe annotation status counts do not sum to 22,215."
)

# ------------------------------
# 9. Save complete annotation audit bundle and provenance
# ------------------------------
input_manifest <- make_manifest(required_inputs)

annotation_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script08A_v2",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_clean_bundle_file = normalize_existing_path(clean_bundle_file),
  source_clean_bundle_md5 = observed_bundle_md5,
  source_expression_dimensions = dim(expr),
  source_expression_probeset_ids = probe_ids,
  removed_affx_control_probeset_ids = removed_affx_ids,
  retained_complete_affx_control_audit = retained_affx_audit,
  annotation_input_non_affx_probeset_ids = annotation_probe_ids,
  source_sample_ids = colnames(expr),
  annotation_package_versions = package_audit,
  annotation_database_metadata = annotation_db_metadata,
  full_probe_annotation = annotation_full,
  probe_annotation_status = probe_status,
  unmapped_probes = unmapped_probes,
  multisymbol_probe_annotation = multisymbol_probes,
  valid_probe_symbol_pairs = valid_probe_symbol_pairs,
  gene_probe_multiplicity = gene_probe_multiplicity,
  annotation_summary = annotation_summary,
  decision_status = paste0(
    "ANNOTATION_AUDIT_ONLY: no representative probe or gene-level ",
    "aggregation rule was selected in Script 08A."
  )
)
class(annotation_bundle) <- c("GSE31519_annotation_audit_bundle", "list")

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_probe_annotation_AUDIT_bundle.rds"
)
stage_full_map_file <- file.path(
  stage_audit_dir,
  "GSE31519_probe_to_gene_annotation_FULL.csv"
)
stage_probe_status_file <- file.path(
  stage_audit_dir,
  "GSE31519_probe_annotation_status.csv"
)
stage_retained_affx_file <- file.path(
  stage_audit_dir,
  "GSE31519_retained_complete_AFFX_controls.csv"
)
stage_unmapped_file <- file.path(
  stage_audit_dir,
  "GSE31519_unmapped_probes.csv"
)
stage_multisymbol_file <- file.path(
  stage_audit_dir,
  "GSE31519_multisymbol_probes.csv"
)
stage_gene_multiplicity_file <- file.path(
  stage_audit_dir,
  "GSE31519_gene_probe_multiplicity.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_annotation_summary.csv"
)
stage_db_metadata_file <- file.path(
  stage_audit_dir,
  "GSE31519_annotation_database_metadata.csv"
)
stage_package_file <- file.path(
  stage_audit_dir,
  "GSE31519_annotation_package_versions.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script08A_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script08A_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script08A_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script08A_COMPLETE_report.txt"
)

saveRDS(annotation_bundle, stage_bundle_file, compress = "gzip")
write_csv_utf8(annotation_full, stage_full_map_file)
write_csv_utf8(probe_status, stage_probe_status_file)
write_csv_utf8(retained_affx_audit, stage_retained_affx_file)
write_csv_utf8(unmapped_probes, stage_unmapped_file)
write_csv_utf8(multisymbol_probes, stage_multisymbol_file)
write_csv_utf8(gene_probe_multiplicity, stage_gene_multiplicity_file)
write_csv_utf8(annotation_summary, stage_summary_file)
write_csv_utf8(annotation_db_metadata, stage_db_metadata_file)
write_csv_utf8(package_audit, stage_package_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)
writeLines(capture.output(sessionInfo()), con = stage_session_file, useBytes = TRUE)

annotation_bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 08A v2",
  "GSE31519 HG-U133A probeset annotation structure audit",
  "============================================================",
  paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Source Script 07D bundle MD5: ", observed_bundle_md5),
  paste0("Source clean matrix: ", nrow(expr), " probesets x ", ncol(expr), " samples"),
  paste0("AFFX controls removed by Script 07D: ", length(removed_affx_ids)),
  paste0("Complete AFFX controls retained and audited: ", length(retained_affx_ids)),
  paste0("Non-AFFX probesets submitted for annotation: ", n_input),
  paste0("Full annotation rows: ", nrow(annotation_full)),
  paste0("Probesets with >=1 valid gene symbol: ", n_mapped),
  paste0("Probeset symbol mapping rate: ", format(n_mapped / n_input, digits = 6)),
  paste0("Probesets with exactly one valid symbol: ", n_unique),
  paste0("Probesets with multiple valid symbols: ", n_multi),
  paste0("Probesets without a valid symbol: ", n_unmapped),
  paste0("Unique valid gene symbols: ", n_gene_symbols),
  paste0("Genes represented by multiple probesets: ", n_genes_multi_probe),
  paste0("Maximum probesets for one gene symbol: ", max_probe_per_gene),
  paste0("Annotation audit bundle MD5: ", annotation_bundle_md5),
  "",
  "SCRIPT08A_V2 STATUS: COMPLETE",
  "Expression values were not modified or duplicated in the output bundle.",
  "The 53 complete AFFX controls were audited and excluded only from gene annotation.",
  "No probeset-to-gene collapse rule was selected.",
  "No gene-level expression matrix, score, survival model or plot was produced.",
  "============================================================"
)
writeLines(report_lines, con = stage_report_file, useBytes = TRUE)

stage_output_files <- c(
  stage_bundle_file,
  stage_full_map_file,
  stage_probe_status_file,
  stage_retained_affx_file,
  stage_unmapped_file,
  stage_multisymbol_file,
  stage_gene_multiplicity_file,
  stage_summary_file,
  stage_db_metadata_file,
  stage_package_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

final_output_files <- c(
  file.path(final_root, "objects", basename(stage_bundle_file)),
  file.path(final_root, "audit", basename(stage_full_map_file)),
  file.path(final_root, "audit", basename(stage_probe_status_file)),
  file.path(final_root, "audit", basename(stage_retained_affx_file)),
  file.path(final_root, "audit", basename(stage_unmapped_file)),
  file.path(final_root, "audit", basename(stage_multisymbol_file)),
  file.path(final_root, "audit", basename(stage_gene_multiplicity_file)),
  file.path(final_root, "audit", basename(stage_summary_file)),
  file.path(final_root, "audit", basename(stage_db_metadata_file)),
  file.path(final_root, "audit", basename(stage_package_file)),
  file.path(final_root, "audit", basename(stage_input_manifest_file)),
  file.path(final_root, "logs", basename(stage_session_file)),
  file.path(final_root, "logs", basename(stage_report_file))
)

output_manifest <- make_manifest(stage_output_files, final_output_files)
write_csv_utf8(output_manifest, stage_output_manifest_file)

all_stage_outputs <- c(stage_output_files, stage_output_manifest_file)
assert_true(
  all(file.exists(all_stage_outputs)),
  "At least one Script 08A staged output is missing; final output was not committed."
)
assert_true(
  all(file.info(all_stage_outputs)$size > 0),
  "At least one Script 08A staged output is empty; final output was not committed."
)

# ------------------------------
# 10. Atomically commit the complete result directory
# ------------------------------
commit_ok <- file.rename(stage_root, final_root)
assert_true(
  commit_ok && dir.exists(final_root),
  paste0(
    "All Script 08A checks passed, but the staging directory could not be renamed to:\n",
    final_root,
    "\nThe staging result was not intentionally overwritten."
  )
)
committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_probe_annotation_AUDIT_bundle.rds"
)

cat("\n")
cat("============================================================\n")
cat("Script 08A v2 completed successfully.\n")
cat("Source clean-matrix probesets: ", nrow(expr), "\n", sep = "")
cat("Retained complete AFFX controls audited: ", length(retained_affx_ids), "\n", sep = "")
cat("Non-AFFX probesets annotated: ", n_input, "\n", sep = "")
cat("Mapped probesets: ", n_mapped, "\n", sep = "")
cat("Unmapped probesets: ", n_unmapped, "\n", sep = "")
cat("Multi-symbol probesets: ", n_multi, "\n", sep = "")
cat("Unique valid gene symbols: ", n_gene_symbols, "\n", sep = "")
cat("Expression values modified: FALSE\n")
cat("Gene-level matrix created: FALSE\n")
cat("Bundle: ", normalizePath(final_bundle_file, winslash = "/", mustWork = TRUE), "\n", sep = "")
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("✅ 已完成\n")

# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 10C
#
# Purpose:
#   Continue strictly from the accepted Script 09B clinical-endpoint bundle and
#   Script 10B v3 Triclosan_activity GSVA-score bundle.
#
#   Audit technical heterogeneity of the continuous score and lock the survival
#   analysis design before any Cox or Kaplan-Meier model is fitted.
#
# Core design principles locked here:
#   1) Primary predictor: continuous Triclosan_activity score.
#   2) Primary effect scale: hazard ratio per 1 SD of the score in the analysis
#      set; no outcome-guided transformation or cutoff.
#   3) Primary survival model: Cox model stratified by source_dataset_id, because
#      GSE31519 pools many source cohorts with different baseline hazards and
#      detectable score-location shifts.
#   4) Primary endpoint set: all 383 records with complete fu_120 / ev120.
#   5) Sensitivity endpoint set: 379 records with positive follow-up time.
#   6) Clinical adjustment candidate: age + nodal status + tumor-size group +
#      histologic-grade group, using complete cases only.
#   7) Dataset-level meta-analysis sensitivity eligibility:
#      n >= 10, events >= 3, censored >= 3, and non-zero score variance.
#   8) No optimized cutoff. Any later median split is descriptive only.
#
# This script DOES:
#   - verify accepted Script 09B and Script 10B bundles and MD5 identities;
#   - merge the continuous score with the curated clinical table;
#   - audit score shifts by array, source dataset and biopsy-method code;
#   - quantify one-way technical-group variance fractions (eta squared);
#   - audit source-dataset survival information and meta-analysis eligibility;
#   - create outcome-independent score standardizations for later use;
#   - lock the complete survival-analysis plan in auditable tables;
#   - save RDS, CSV tables, MD5 manifests, report and sessionInfo.
#
# This script DOES NOT:
#   - rerun Scripts 07A-10B;
#   - modify expression values or recompute GSVA;
#   - fit Cox, Kaplan-Meier or meta-analysis models;
#   - use an optimized cutoff;
#   - select covariates based on statistical significance;
#   - delete or impute clinical records.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step2_GSE31519_external_validation"
)

clinical_root <- file.path(
  step_root,
  "06_curated_clinical_endpoint"
)
score_root <- file.path(
  step_root,
  "08_Triclosan_GSVA_score"
)
final_root <- file.path(
  step_root,
  "09_technical_confounding_and_survival_design"
)

clinical_bundle_file <- file.path(
  clinical_root,
  "objects",
  "GSE31519_curated_clinical_endpoint_COMPLETE_bundle.rds"
)
clinical_manifest_file <- file.path(
  clinical_root,
  "audit",
  "Script09B_output_manifest_with_MD5.csv"
)
clinical_report_file <- file.path(
  clinical_root,
  "logs",
  "Script09B_COMPLETE_report.txt"
)

score_bundle_file <- file.path(
  score_root,
  "objects",
  "GSE31519_Triclosan_GSVA_score_COMPLETE_bundle.rds"
)
score_manifest_file <- file.path(
  score_root,
  "audit",
  "Script10B_output_manifest_with_MD5.csv"
)
score_report_file <- file.path(
  score_root,
  "logs",
  "Script10B_COMPLETE_report.txt"
)

required_inputs <- c(
  clinical_bundle_file,
  clinical_manifest_file,
  clinical_report_file,
  score_bundle_file,
  score_manifest_file,
  score_report_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 10C cannot start because required accepted files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist.", call. = FALSE)
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 10C will ",
        "not overwrite it:\n",
        final_root
      ),
      call. = FALSE
    )
  }
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script10C_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop("Unable to create Script 10C staging directories.", call. = FALSE)
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helpers
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

md5_one <- function(path) {
  unname(tools::md5sum(path))
}

normalize_existing_path <- function(path) {
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(report_file, warn = FALSE, encoding = "UTF-8")
  any(grepl(fixed_text, lines, fixed = TRUE))
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)

  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(path) {
        normalizePath(path, winslash = "/", mustWork = FALSE)
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c("file_name", "size_bytes", "md5") %in% colnames(manifest)),
    paste0("Malformed manifest: ", manifest_file)
  )

  row_index <- which(manifest$file_name == basename(target_file))

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file)
    )
  )

  tolower(trimws(as.character(manifest$md5[row_index])))
}

safe_sd <- function(x) {
  x <- as.numeric(x)
  x <- x[is.finite(x)]
  if (length(x) <= 1L) return(NA_real_)
  stats::sd(x)
}

safe_quantile <- function(x, probability) {
  x <- as.numeric(x)
  x <- x[is.finite(x)]
  if (length(x) == 0L) return(NA_real_)

  as.numeric(
    stats::quantile(
      x,
      probs = probability,
      names = FALSE,
      type = 7
    )
  )
}

standardize_vector <- function(x) {
  x <- as.numeric(x)
  mean_x <- mean(x)
  sd_x <- stats::sd(x)

  assert_true(
    is.finite(mean_x) && is.finite(sd_x) && sd_x > 0,
    "A requested score standardization has invalid mean or SD."
  )

  (x - mean_x) / sd_x
}

one_way_eta_squared <- function(score, group) {
  score <- as.numeric(score)
  group <- as.character(group)

  valid <- is.finite(score) & !is.na(group) & nzchar(group)
  score <- score[valid]
  group <- group[valid]

  if (length(score) == 0L || length(unique(group)) < 2L) {
    return(NA_real_)
  }

  grand_mean <- mean(score)
  total_ss <- sum((score - grand_mean)^2)

  if (!is.finite(total_ss) || total_ss <= 0) {
    return(NA_real_)
  }

  split_score <- split(score, group)
  between_ss <- sum(vapply(
    split_score,
    function(x) {
      length(x) * (mean(x) - grand_mean)^2
    },
    numeric(1)
  ))

  between_ss / total_ss
}

kruskal_p_value <- function(score, group) {
  score <- as.numeric(score)
  group <- as.character(group)

  valid <- is.finite(score) & !is.na(group) & nzchar(group)
  score <- score[valid]
  group <- group[valid]

  if (length(score) == 0L || length(unique(group)) < 2L) {
    return(NA_real_)
  }

  result <- stats::kruskal.test(score ~ factor(group))
  as.numeric(result$p.value)
}

summarize_groups <- function(data, group_name, analysis_set_name) {
  group_value <- as.character(data[[group_name]])
  group_value[is.na(group_value) | !nzchar(group_value)] <- "<MISSING>"

  levels_present <- sort(unique(group_value))
  rows <- vector("list", length(levels_present))

  for (i in seq_along(levels_present)) {
    level_i <- levels_present[i]
    x <- data$Triclosan_activity[group_value == level_i]
    x <- x[is.finite(x)]

    rows[[i]] <- data.frame(
      analysis_set = analysis_set_name,
      group_variable = group_name,
      group_value = level_i,
      sample_number = length(x),
      minimum = min(x),
      first_quartile = safe_quantile(x, 0.25),
      median = stats::median(x),
      mean = mean(x),
      third_quartile = safe_quantile(x, 0.75),
      maximum = max(x),
      standard_deviation = safe_sd(x),
      unique_score_number = length(unique(x)),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  result <- do.call(rbind, rows)
  rownames(result) <- NULL
  result
}

build_global_test_row <- function(data, group_name, analysis_set_name) {
  group_value <- as.character(data[[group_name]])

  data.frame(
    analysis_set = analysis_set_name,
    group_variable = group_name,
    sample_number = nrow(data),
    group_number = length(unique(group_value[!is.na(group_value)])),
    eta_squared_one_way = one_way_eta_squared(
      data$Triclosan_activity,
      group_value
    ),
    kruskal_wallis_p_value = kruskal_p_value(
      data$Triclosan_activity,
      group_value
    ),
    inferential_role = "TECHNICAL_HETEROGENEITY_AUDIT_ONLY",
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

# ------------------------------
# 2. Verify accepted bundle identities
# ------------------------------
assert_true(
  report_contains(clinical_report_file, "SCRIPT09B STATUS: COMPLETE"),
  "Script 09B completion marker was not found."
)
assert_true(
  report_contains(score_report_file, "SCRIPT10B STATUS: COMPLETE"),
  "Script 10B completion marker was not found."
)

expected_clinical_md5 <- manifest_expected_md5(
  clinical_manifest_file,
  clinical_bundle_file
)
observed_clinical_md5 <- tolower(md5_one(clinical_bundle_file))
accepted_clinical_md5 <- "02606ffd117178bcd20571ab34740104"

assert_true(
  identical(expected_clinical_md5, observed_clinical_md5),
  "Script 09B bundle MD5 differs from its manifest."
)
assert_true(
  identical(observed_clinical_md5, accepted_clinical_md5),
  "Script 09B bundle differs from the independently accepted bundle."
)

expected_score_md5 <- manifest_expected_md5(
  score_manifest_file,
  score_bundle_file
)
observed_score_md5 <- tolower(md5_one(score_bundle_file))
accepted_score_md5 <- "2a9a2e6f0ad35d0478f76347897244b4"

assert_true(
  identical(expected_score_md5, observed_score_md5),
  "Script 10B bundle MD5 differs from its manifest."
)
assert_true(
  identical(observed_score_md5, accepted_score_md5),
  "Script 10B bundle differs from the independently accepted bundle."
)

# ------------------------------
# 3. Read and validate accepted objects
# ------------------------------
clinical_bundle <- readRDS(clinical_bundle_file)
score_bundle <- readRDS(score_bundle_file)

assert_true(
  is.list(clinical_bundle) &&
    all(c(
      "script",
      "source_accession",
      "expression_matrix",
      "curated_clinical"
    ) %in% names(clinical_bundle)),
  "Script 09B bundle is missing required fields."
)
assert_true(
  identical(as.character(clinical_bundle$script), "Script09B"),
  "Clinical bundle was not created by Script 09B."
)

assert_true(
  is.list(score_bundle) &&
    all(c(
      "script",
      "source_accession",
      "source_script09b_bundle_md5",
      "Triclosan_activity",
      "score_table",
      "locked_signature_genes",
      "policy"
    ) %in% names(score_bundle)),
  "Script 10B bundle is missing required fields."
)
assert_true(
  identical(as.character(score_bundle$script), "Script10B"),
  "Score bundle was not created by Script 10B."
)
assert_true(
  identical(
    tolower(as.character(score_bundle$source_script09b_bundle_md5)),
    observed_clinical_md5
  ),
  "Script 10B bundle does not point to the accepted Script 09B bundle."
)

expr_gene <- clinical_bundle$expression_matrix
clinical <- clinical_bundle$curated_clinical
score_table <- score_bundle$score_table
score_vector <- as.numeric(score_bundle$Triclosan_activity)

assert_true(
  is.matrix(expr_gene) &&
    is.numeric(expr_gene) &&
    identical(dim(expr_gene), c(12650L, 579L)),
  "Accepted expression matrix is not 12,650 x 579."
)
assert_true(
  sum(!is.finite(expr_gene)) == 0L,
  "Accepted expression matrix contains non-finite values."
)

assert_true(
  is.data.frame(clinical) &&
    nrow(clinical) == 579L &&
    "sample_id" %in% colnames(clinical),
  "Accepted curated clinical table is malformed."
)
assert_true(
  is.data.frame(score_table) &&
    nrow(score_table) == 579L &&
    all(c("sample_id", "Triclosan_activity") %in% colnames(score_table)),
  "Accepted score table is malformed."
)

assert_true(
  identical(
    as.character(clinical$sample_id),
    colnames(expr_gene)
  ),
  "Clinical samples are not aligned with expression samples."
)
assert_true(
  identical(
    as.character(score_table$sample_id),
    colnames(expr_gene)
  ),
  "Score samples are not aligned with expression samples."
)
assert_true(
  length(score_vector) == 579L &&
    all(is.finite(score_vector)) &&
    stats::sd(score_vector) > 0,
  "Accepted score vector is incomplete or invariant."
)
assert_true(
  isTRUE(all.equal(
    as.numeric(score_table$Triclosan_activity),
    score_vector,
    tolerance = 0,
    check.attributes = FALSE
  )),
  "Score table values differ from the accepted score vector."
)

required_clinical_columns <- c(
  "sample_order",
  "sample_id",
  "source_dataset_id",
  "array_type",
  "biopsy_method_code_raw",
  "age_years",
  "nodal_status",
  "tumor_size_group",
  "histologic_grade_group",
  "adjuvant_chemotherapy",
  "efs_time_months",
  "efs_event",
  "efs_complete_public_set",
  "efs_zero_time",
  "efs_positive_time_sensitivity_set"
)

assert_true(
  all(required_clinical_columns %in% colnames(clinical)),
  paste0(
    "Curated clinical table is missing columns: ",
    paste(
      setdiff(required_clinical_columns, colnames(clinical)),
      collapse = ", "
    )
  )
)

# ------------------------------
# 4. Build one aligned analysis table
# ------------------------------
analysis_table <- clinical
analysis_table$Triclosan_activity <- score_vector

analysis_table$source_dataset_id <- as.character(
  analysis_table$source_dataset_id
)
analysis_table$array_type <- as.character(
  analysis_table$array_type
)
analysis_table$biopsy_method_code_raw <- as.character(
  analysis_table$biopsy_method_code_raw
)

analysis_table$score_z_all579 <- standardize_vector(
  analysis_table$Triclosan_activity
)

analysis_table$score_z_EFS383 <- NA_real_
efs383_mask <- as.logical(analysis_table$efs_complete_public_set)

assert_true(
  sum(efs383_mask) == 383L,
  "Expected 383 complete EFS records."
)

analysis_table$score_z_EFS383[efs383_mask] <- standardize_vector(
  analysis_table$Triclosan_activity[efs383_mask]
)

analysis_table$score_z_EFS379 <- NA_real_
efs379_mask <- as.logical(
  analysis_table$efs_positive_time_sensitivity_set
)

assert_true(
  sum(efs379_mask) == 379L,
  "Expected 379 positive-time EFS records."
)

analysis_table$score_z_EFS379[efs379_mask] <- standardize_vector(
  analysis_table$Triclosan_activity[efs379_mask]
)

# Outcome-independent within-source centering and scaling for technical audit.
analysis_table$score_centered_within_source_all579 <- NA_real_
analysis_table$score_z_within_source_all579 <- NA_real_

source_ids <- sort(unique(analysis_table$source_dataset_id))

for (source_id in source_ids) {
  source_mask <- analysis_table$source_dataset_id == source_id
  source_score <- analysis_table$Triclosan_activity[source_mask]

  analysis_table$score_centered_within_source_all579[source_mask] <-
    source_score - mean(source_score)

  source_sd <- safe_sd(source_score)

  if (is.finite(source_sd) && source_sd > 0) {
    analysis_table$score_z_within_source_all579[source_mask] <-
      (source_score - mean(source_score)) / source_sd
  }
}

assert_true(
  identical(
    as.character(analysis_table$sample_id),
    colnames(expr_gene)
  ),
  "Analysis table sample order changed."
)
assert_true(
  all(is.finite(analysis_table$score_z_all579)),
  "Global all-579 score z values are non-finite."
)
assert_true(
  sum(is.finite(analysis_table$score_z_EFS383)) == 383L,
  "EFS383 z-score count is not 383."
)
assert_true(
  sum(is.finite(analysis_table$score_z_EFS379)) == 379L,
  "EFS379 z-score count is not 379."
)

# ------------------------------
# 5. Technical heterogeneity audits
# ------------------------------
all579 <- analysis_table
efs383 <- analysis_table[efs383_mask, , drop = FALSE]

technical_group_variables <- c(
  "array_type",
  "source_dataset_id",
  "biopsy_method_code_raw"
)

group_summary_rows <- list()
test_rows <- list()
group_index <- 0L
test_index <- 0L

for (set_name in c("ALL579", "EFS383")) {
  set_data <- if (set_name == "ALL579") all579 else efs383

  for (group_name in technical_group_variables) {
    group_index <- group_index + 1L
    group_summary_rows[[group_index]] <- summarize_groups(
      set_data,
      group_name,
      set_name
    )

    test_index <- test_index + 1L
    test_rows[[test_index]] <- build_global_test_row(
      set_data,
      group_name,
      set_name
    )
  }
}

technical_group_summary <- do.call(
  rbind,
  group_summary_rows
)
rownames(technical_group_summary) <- NULL

technical_global_tests <- do.call(
  rbind,
  test_rows
)
rownames(technical_global_tests) <- NULL

# ------------------------------
# 6. Source-dataset survival-information audit
# ------------------------------
dataset_rows <- vector("list", length(source_ids))

for (i in seq_along(source_ids)) {
  source_id <- source_ids[i]
  d <- analysis_table[
    analysis_table$source_dataset_id == source_id,
    ,
    drop = FALSE
  ]

  endpoint_d <- d[
    as.logical(d$efs_complete_public_set),
    ,
    drop = FALSE
  ]

  positive_d <- d[
    as.logical(d$efs_positive_time_sensitivity_set),
    ,
    drop = FALSE
  ]

  endpoint_n <- nrow(endpoint_d)
  events <- if (endpoint_n == 0L) {
    0L
  } else {
    sum(endpoint_d$efs_event == 1L, na.rm = TRUE)
  }
  censored <- if (endpoint_n == 0L) {
    0L
  } else {
    sum(endpoint_d$efs_event == 0L, na.rm = TRUE)
  }

  endpoint_score_sd <- if (endpoint_n <= 1L) {
    NA_real_
  } else {
    safe_sd(endpoint_d$Triclosan_activity)
  }

  dataset_rows[[i]] <- data.frame(
    source_dataset_id = source_id,
    array_types = paste(sort(unique(d$array_type)), collapse = ";"),
    total_sample_number = nrow(d),
    complete_EFS_number = endpoint_n,
    positive_time_EFS_number = nrow(positive_d),
    event_number = events,
    censored_number = censored,
    zero_time_number = sum(endpoint_d$efs_zero_time, na.rm = TRUE),
    score_mean_all_samples = mean(d$Triclosan_activity),
    score_sd_all_samples = safe_sd(d$Triclosan_activity),
    score_mean_complete_EFS = if (endpoint_n == 0L) {
      NA_real_
    } else {
      mean(endpoint_d$Triclosan_activity)
    },
    score_sd_complete_EFS = endpoint_score_sd,
    score_minimum_complete_EFS = if (endpoint_n == 0L) {
      NA_real_
    } else {
      min(endpoint_d$Triclosan_activity)
    },
    score_maximum_complete_EFS = if (endpoint_n == 0L) {
      NA_real_
    } else {
      max(endpoint_d$Triclosan_activity)
    },
    contributes_event_to_stratified_cox =
      endpoint_n >= 2L &&
      events >= 1L &&
      is.finite(endpoint_score_sd) &&
      endpoint_score_sd > 0,
    eligible_for_dataset_meta_analysis =
      endpoint_n >= 10L &&
      events >= 3L &&
      censored >= 3L &&
      is.finite(endpoint_score_sd) &&
      endpoint_score_sd > 0,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

source_dataset_survival_audit <- do.call(
  rbind,
  dataset_rows
)
rownames(source_dataset_survival_audit) <- NULL

assert_true(
  sum(source_dataset_survival_audit$total_sample_number) == 579L,
  "Source-dataset audit does not sum to 579 samples."
)
assert_true(
  sum(source_dataset_survival_audit$complete_EFS_number) == 383L,
  "Source-dataset audit does not sum to 383 complete EFS records."
)
assert_true(
  sum(source_dataset_survival_audit$event_number) == 169L,
  "Source-dataset audit does not sum to 169 events."
)
assert_true(
  sum(source_dataset_survival_audit$censored_number) == 214L,
  "Source-dataset audit does not sum to 214 censored records."
)
assert_true(
  sum(
    source_dataset_survival_audit$eligible_for_dataset_meta_analysis
  ) == 11L,
  paste0(
    "Expected 11 source datasets eligible for the prespecified dataset-level ",
    "meta-analysis sensitivity."
  )
)

# ------------------------------
# 7. Covariate complete-case audit
# ------------------------------
covariate_sets <- list(
  UNADJUSTED = character(0),
  AGE = c("age_years"),
  AGE_NODAL = c(
    "age_years",
    "nodal_status"
  ),
  AGE_NODAL_SIZE_GRADE = c(
    "age_years",
    "nodal_status",
    "tumor_size_group",
    "histologic_grade_group"
  ),
  AGE_NODAL_SIZE_GRADE_CHEMO = c(
    "age_years",
    "nodal_status",
    "tumor_size_group",
    "histologic_grade_group",
    "adjuvant_chemotherapy"
  )
)

analysis_sets <- list(
  EFS383 = efs383_mask,
  EFS379 = efs379_mask
)

complete_case_rows <- list()
complete_case_index <- 0L

for (analysis_set_name in names(analysis_sets)) {
  set_mask <- analysis_sets[[analysis_set_name]]

  for (covariate_set_name in names(covariate_sets)) {
    variables <- covariate_sets[[covariate_set_name]]

    if (length(variables) == 0L) {
      complete_mask <- set_mask
    } else {
      complete_mask <- set_mask &
        stats::complete.cases(
          analysis_table[, variables, drop = FALSE]
        )
    }

    complete_case_index <- complete_case_index + 1L

    complete_case_rows[[complete_case_index]] <- data.frame(
      analysis_set = analysis_set_name,
      covariate_set_name = covariate_set_name,
      covariates = if (length(variables) == 0L) {
        ""
      } else {
        paste(variables, collapse = ";")
      },
      endpoint_set_number = sum(set_mask),
      complete_case_number = sum(complete_mask),
      excluded_for_covariate_missingness =
        sum(set_mask) - sum(complete_mask),
      event_number_complete_cases = sum(
        analysis_table$efs_event[complete_mask] == 1L,
        na.rm = TRUE
      ),
      censored_number_complete_cases = sum(
        analysis_table$efs_event[complete_mask] == 0L,
        na.rm = TRUE
      ),
      model_fitted = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }
}

covariate_complete_case_audit <- do.call(
  rbind,
  complete_case_rows
)
rownames(covariate_complete_case_audit) <- NULL

# ------------------------------
# 8. Lock survival-analysis design
# ------------------------------
survival_design_lock <- data.frame(
  analysis_order = 1:9,
  analysis_id = c(
    "PRIMARY_CONTINUOUS_EFS383",
    "SENSITIVITY_POSITIVE_TIME_EFS379",
    "PRIMARY_CLINICALLY_ADJUSTED_EFS383",
    "ADJUSTED_POSITIVE_TIME_EFS379",
    "TREATMENT_ADDED_SENSITIVITY_EFS383",
    "PROPORTIONAL_HAZARDS_CHECKS",
    "DATASET_LEVEL_META_ANALYSIS_SENSITIVITY",
    "DESCRIPTIVE_MEDIAN_SPLIT_ONLY",
    "NO_OPTIMIZED_CUTOFF"
  ),
  analysis_set = c(
    "EFS383",
    "EFS379",
    "EFS383_COMPLETE_CASE",
    "EFS379_COMPLETE_CASE",
    "EFS383_COMPLETE_CASE",
    "MODEL_SPECIFIC",
    "ELIGIBLE_SOURCE_DATASETS",
    "EFS383",
    "ALL"
  ),
  predictor = c(
    "score_z_EFS383",
    "score_z_EFS379",
    "score_z_EFS383",
    "score_z_EFS379",
    "score_z_EFS383",
    "MODEL_SPECIFIC",
    "Within-dataset score standardized to 1 SD",
    "Raw Triclosan_activity split at prespecified EFS383 median",
    "NOT_APPLICABLE"
  ),
  model_or_action = c(
    paste0(
      "Cox PH: Surv(efs_time_months, efs_event) ~ score_z_EFS383 + ",
      "strata(source_dataset_id)"
    ),
    paste0(
      "Cox PH: Surv(efs_time_months, efs_event) ~ score_z_EFS379 + ",
      "strata(source_dataset_id)"
    ),
    paste0(
      "Cox PH: score + age + nodal + tumor size + histologic grade + ",
      "strata(source_dataset_id)"
    ),
    paste0(
      "Same clinically adjusted Cox model in positive-time EFS379 set"
    ),
    paste0(
      "Add adjuvant chemotherapy as a separate sensitivity model only"
    ),
    "cox.zph for score and global proportional-hazards assessment",
    paste0(
      "Fit continuous score Cox within each eligible dataset, then report ",
      "fixed-effect and random-effects summaries"
    ),
    paste0(
      "Kaplan-Meier/log-rank visualization only; not the primary inferential ",
      "analysis and not used to select the signature"
    ),
    "Do not use maximally selected rank statistics, surv_cutpoint or repeated cutoff search"
  ),
  source_dataset_handling = c(
    "STRATIFIED_BASELINE_HAZARD",
    "STRATIFIED_BASELINE_HAZARD",
    "STRATIFIED_BASELINE_HAZARD",
    "STRATIFIED_BASELINE_HAZARD",
    "STRATIFIED_BASELINE_HAZARD",
    "MATCH_PARENT_MODEL",
    "SEPARATE_DATASET_ESTIMATES",
    "REPORT_SOURCE_DISTRIBUTION_AND_INTERPRET_AS_SECONDARY",
    "NOT_APPLICABLE"
  ),
  cutoff_optimized = FALSE,
  model_fitted_in_script10C = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 9. Integrity summary
# ------------------------------
lookup_eta <- function(set_name, group_name) {
  row <- technical_global_tests[
    technical_global_tests$analysis_set == set_name &
      technical_global_tests$group_variable == group_name,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row) == 1L,
    "Technical global-test lookup failed."
  )

  as.numeric(row$eta_squared_one_way)
}

summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Source_Script09B_bundle_MD5",
    "Source_Script10B_bundle_MD5",
    "Total_samples",
    "Complete_EFS_records",
    "Positive_time_EFS_records",
    "Events_complete_EFS",
    "Censored_complete_EFS",
    "Source_dataset_number_all579",
    "Source_dataset_number_with_complete_EFS",
    "Source_datasets_contributing_events_to_stratified_Cox",
    "Source_datasets_eligible_for_meta_analysis_sensitivity",
    "Array_type_eta_squared_all579",
    "Source_dataset_eta_squared_all579",
    "Biopsy_method_eta_squared_all579",
    "Array_type_eta_squared_EFS383",
    "Source_dataset_eta_squared_EFS383",
    "Biopsy_method_eta_squared_EFS383",
    "Primary_predictor",
    "Primary_endpoint_set",
    "Primary_model_source_handling",
    "Outcome_guided_score_transformation",
    "Optimized_cutoff_selected",
    "Survival_model_fitted",
    "Clinical_values_imputed",
    "Expression_values_modified",
    "GSVA_recomputed",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "10C",
    observed_clinical_md5,
    observed_score_md5,
    nrow(analysis_table),
    sum(efs383_mask),
    sum(efs379_mask),
    sum(analysis_table$efs_event[efs383_mask] == 1L),
    sum(analysis_table$efs_event[efs383_mask] == 0L),
    length(unique(analysis_table$source_dataset_id)),
    sum(source_dataset_survival_audit$complete_EFS_number > 0L),
    sum(
      source_dataset_survival_audit$
        contributes_event_to_stratified_cox
    ),
    sum(
      source_dataset_survival_audit$
        eligible_for_dataset_meta_analysis
    ),
    lookup_eta("ALL579", "array_type"),
    lookup_eta("ALL579", "source_dataset_id"),
    lookup_eta("ALL579", "biopsy_method_code_raw"),
    lookup_eta("EFS383", "array_type"),
    lookup_eta("EFS383", "source_dataset_id"),
    lookup_eta("EFS383", "biopsy_method_code_raw"),
    "Continuous Triclosan_activity per 1 SD",
    "383 complete 120-month pooled EFS records",
    "Cox baseline hazard stratified by source_dataset_id",
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Save staging outputs
# ------------------------------
input_manifest <- make_manifest(required_inputs)

audit_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script10C",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_script09b_bundle_file =
    normalize_existing_path(clinical_bundle_file),
  source_script09b_bundle_md5 = observed_clinical_md5,
  source_script10b_bundle_file =
    normalize_existing_path(score_bundle_file),
  source_script10b_bundle_md5 = observed_score_md5,
  locked_signature_genes = score_bundle$locked_signature_genes,
  analysis_table = analysis_table,
  technical_group_summary = technical_group_summary,
  technical_global_tests = technical_global_tests,
  source_dataset_survival_audit =
    source_dataset_survival_audit,
  covariate_complete_case_audit =
    covariate_complete_case_audit,
  survival_design_lock = survival_design_lock,
  integrity_summary = summary_table,
  policy = list(
    primary_predictor =
      "Continuous Triclosan_activity score standardized per 1 SD",
    primary_endpoint_set =
      "EFS383",
    primary_source_dataset_handling =
      "Cox model stratified by source_dataset_id",
    primary_clinical_covariates = c(
      "age_years",
      "nodal_status",
      "tumor_size_group",
      "histologic_grade_group"
    ),
    positive_time_sensitivity_set =
      "EFS379",
    treatment_added_model_is_sensitivity_only =
      TRUE,
    dataset_meta_analysis_eligibility = list(
      minimum_n = 10L,
      minimum_events = 3L,
      minimum_censored = 3L,
      nonzero_score_variance = TRUE
    ),
    optimized_cutoff_allowed = FALSE,
    survival_model_fitted = FALSE,
    expression_values_modified = FALSE,
    GSVA_recomputed = FALSE
  ),
  provenance = list(
    accepted_script09b_bundle_md5 = accepted_clinical_md5,
    accepted_script10b_bundle_md5 = accepted_score_md5,
    next_step =
      "Fit prespecified continuous survival models only after Script10C review"
  )
)

class(audit_bundle) <- c(
  "GSE31519_technical_confounding_survival_design_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_technical_confounding_survival_design_COMPLETE_bundle.rds"
)
stage_analysis_file <- file.path(
  stage_audit_dir,
  "GSE31519_score_clinical_analysis_table_all579.csv"
)
stage_group_file <- file.path(
  stage_audit_dir,
  "GSE31519_score_technical_group_summary.csv"
)
stage_test_file <- file.path(
  stage_audit_dir,
  "GSE31519_score_technical_global_tests.csv"
)
stage_dataset_file <- file.path(
  stage_audit_dir,
  "GSE31519_source_dataset_survival_eligibility_audit.csv"
)
stage_complete_case_file <- file.path(
  stage_audit_dir,
  "GSE31519_survival_covariate_complete_case_audit.csv"
)
stage_design_file <- file.path(
  stage_audit_dir,
  "GSE31519_prespecified_survival_analysis_design.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_technical_confounding_survival_design_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script10C_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script10C_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script10C_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script10C_COMPLETE_report.txt"
)

saveRDS(audit_bundle, stage_bundle_file, compress = "gzip")
write_csv_utf8(analysis_table, stage_analysis_file)
write_csv_utf8(technical_group_summary, stage_group_file)
write_csv_utf8(technical_global_tests, stage_test_file)
write_csv_utf8(
  source_dataset_survival_audit,
  stage_dataset_file
)
write_csv_utf8(
  covariate_complete_case_audit,
  stage_complete_case_file
)
write_csv_utf8(survival_design_lock, stage_design_file)
write_csv_utf8(summary_table, stage_summary_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)

capture.output(sessionInfo(), file = stage_session_file)

bundle_check <- readRDS(stage_bundle_file)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "analysis_table",
      "technical_global_tests",
      "source_dataset_survival_audit",
      "survival_design_lock",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 10C bundle is missing required fields."
)
assert_true(
  identical(
    as.character(bundle_check$analysis_table$sample_id),
    colnames(expr_gene)
  ),
  "Saved Script 10C analysis table changed sample order."
)
assert_true(
  isFALSE(bundle_check$policy$survival_model_fitted),
  "Staged Script 10C bundle incorrectly indicates a fitted model."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 10C",
  "Technical confounding audit and survival-design lock",
  "============================================================",
  paste0(
    "Completion time: ",
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  ),
  paste0("Source Script 09B bundle MD5: ", observed_clinical_md5),
  paste0("Source Script 10B bundle MD5: ", observed_score_md5),
  paste0("Total samples: ", nrow(analysis_table)),
  paste0("Complete EFS records: ", sum(efs383_mask)),
  paste0("Positive-time EFS records: ", sum(efs379_mask)),
  paste0(
    "Events / censored in EFS383: ",
    sum(analysis_table$efs_event[efs383_mask] == 1L),
    " / ",
    sum(analysis_table$efs_event[efs383_mask] == 0L)
  ),
  paste0(
    "Source datasets represented: ",
    length(unique(analysis_table$source_dataset_id))
  ),
  paste0(
    "Source datasets with complete EFS records: ",
    sum(source_dataset_survival_audit$complete_EFS_number > 0L)
  ),
  paste0(
    "Datasets eligible for meta-analysis sensitivity: ",
    sum(
      source_dataset_survival_audit$
        eligible_for_dataset_meta_analysis
    )
  ),
  paste0(
    "All579 source-dataset eta squared: ",
    format(
      lookup_eta("ALL579", "source_dataset_id"),
      digits = 8
    )
  ),
  paste0(
    "EFS383 source-dataset eta squared: ",
    format(
      lookup_eta("EFS383", "source_dataset_id"),
      digits = 8
    )
  ),
  "Primary predictor: continuous Triclosan_activity per 1 SD",
  "Primary endpoint set: EFS383",
  "Primary model: Cox PH stratified by source_dataset_id",
  paste0(
    "Primary clinical adjustment: age + nodal status + tumor size + ",
    "histologic grade"
  ),
  "Positive-time sensitivity set: EFS379",
  "Optimized cutoff selected: FALSE",
  "Survival model fitted: FALSE",
  "Clinical values imputed: FALSE",
  "Expression values modified: FALSE",
  "GSVA recomputed: FALSE",
  paste0("Script 10C bundle MD5: ", bundle_md5),
  "",
  "SCRIPT10C STATUS: COMPLETE",
  paste0(
    "Technical heterogeneity was audited and the survival-analysis design was ",
    "locked before model fitting."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(report_lines),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_analysis_file,
  stage_group_file,
  stage_test_file,
  stage_dataset_file,
  stage_complete_case_file,
  stage_design_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)),
  "At least one staged Script 10C output is missing."
)
assert_true(
  all(file.info(output_files_before_manifest)$size > 0),
  "At least one staged Script 10C output is empty."
)

output_manifest <- make_manifest(output_files_before_manifest)
write_csv_utf8(output_manifest, stage_output_manifest_file)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) == length(output_files_before_manifest),
  "Script 10C output manifest has an incorrect row count."
)

for (i in seq_along(output_files_before_manifest)) {
  file_i <- output_files_before_manifest[i]
  row_i <- manifest_check[
    manifest_check$file_name == basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0("Missing or duplicated manifest row: ", basename(file_i))
  )
  assert_true(
    identical(
      tolower(as.character(row_i$md5)),
      tolower(md5_one(file_i))
    ),
    paste0("Manifest MD5 mismatch: ", basename(file_i))
  )
  assert_true(
    as.numeric(row_i$size_bytes) ==
      as.numeric(file.info(file_i)$size),
    paste0("Manifest size mismatch: ", basename(file_i))
  )
}

# ------------------------------
# 11. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 10C directory appeared during staging."
)

rename_ok <- file.rename(stage_root, final_root)

if (!isTRUE(rename_ok)) {
  dir.create(final_root, recursive = TRUE, showWarnings = FALSE)

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 10C staging directory."
  )

  unlink(stage_root, recursive = TRUE, force = TRUE)
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_technical_confounding_survival_design_COMPLETE_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script10C_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script10C_output_manifest_with_MD5.csv"
)

assert_true(
  all(file.exists(c(
    final_bundle_file,
    final_report_file,
    final_manifest_file
  ))),
  "Committed Script 10C output is incomplete."
)
assert_true(
  identical(md5_one(final_bundle_file), bundle_md5),
  "Committed Script 10C bundle MD5 changed after commit."
)
assert_true(
  report_contains(
    final_report_file,
    "SCRIPT10C STATUS: COMPLETE"
  ),
  "Committed Script 10C report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 10C completed successfully.\n")
cat("Total samples: ", nrow(analysis_table), "\n", sep = "")
cat("Complete EFS records: ", sum(efs383_mask), "\n", sep = "")
cat("Positive-time EFS records: ", sum(efs379_mask), "\n", sep = "")
cat(
  "Source-dataset eta squared (ALL579 / EFS383): ",
  format(lookup_eta("ALL579", "source_dataset_id"), digits = 6),
  " / ",
  format(lookup_eta("EFS383", "source_dataset_id"), digits = 6),
  "\n",
  sep = ""
)
cat(
  "Datasets eligible for meta-analysis sensitivity: ",
  sum(
    source_dataset_survival_audit$
      eligible_for_dataset_meta_analysis
  ),
  "\n",
  sep = ""
)
cat("Primary predictor: continuous score per 1 SD\n")
cat("Primary model source handling: strata(source_dataset_id)\n")
cat("Optimized cutoff selected: FALSE\n")
cat("Survival model fitted: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

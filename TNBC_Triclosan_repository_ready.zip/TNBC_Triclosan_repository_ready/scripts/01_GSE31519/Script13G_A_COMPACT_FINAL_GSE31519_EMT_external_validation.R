# ==============================================================================
# TNBC_Triclosan | GSE31519 | Script 13G-A COMPACT FINAL
# Source-stratified EMT external validation only.
#
# Why source-stratified:
# GSE31519 pools multiple source cohorts with detectable score-location shifts.
# The primary association therefore removes source-dataset location effects
# before testing the continuous Triclosan_activity–EMT relationship.
#
# Primary:
# - classical GSVA Hallmark EMT score from the full 12,650 x 579 matrix;
# - partial Spearman correlation adjusted for source_dataset_id by centering
#   global ranks within each source dataset;
# - two-sided within-source permutation p value;
# - within-source bootstrap 95% confidence interval.
#
# Prespecified sensitivities:
# - repeat after removing locked-24/EMT gene overlap;
# - raw pooled Spearman correlation;
# - source-dataset-specific Spearman correlations and Fisher-z synthesis.
#
# No survival refit, cutoff, high/low group, sample deletion, alternative
# Triclosan score, DEG, PCA, GSEA or manuscript figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13G_A_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step2_GSE31519_external_validation")
CLINICAL_ROOT <- file.path(STEP_ROOT, "06_curated_clinical_endpoint")
SCORE_ROOT <- file.path(STEP_ROOT, "08_Triclosan_GSVA_score")
OUTPUT_ROOT <- file.path(STEP_ROOT, "13_EMT_external_validation")

INPUTS <- c(
  clinical_bundle = file.path(
    CLINICAL_ROOT, "objects",
    "GSE31519_curated_clinical_endpoint_COMPLETE_bundle.rds"
  ),
  clinical_manifest = file.path(
    CLINICAL_ROOT, "audit",
    "Script09B_output_manifest_with_MD5.csv"
  ),
  clinical_report = file.path(
    CLINICAL_ROOT, "logs",
    "Script09B_COMPLETE_report.txt"
  ),
  score_bundle = file.path(
    SCORE_ROOT, "objects",
    "GSE31519_Triclosan_GSVA_score_COMPLETE_bundle.rds"
  ),
  score_manifest = file.path(
    SCORE_ROOT, "audit",
    "Script10B_output_manifest_with_MD5.csv"
  ),
  score_report = file.path(
    SCORE_ROOT, "logs",
    "Script10B_COMPLETE_report.txt"
  )
)

EXPECTED_BUNDLE_MD5 <- c(
  clinical_bundle = "02606ffd117178bcd20571ab34740104",
  score_bundle = "2a9a2e6f0ad35d0478f76347897244b4"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)
EMT_NAME <- "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"
RESAMPLE_N <- 10000L
PERMUTATION_SEED <- 20260711L
BOOTSTRAP_SEED <- 20260712L
MIN_SOURCE_N <- 10L

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

report_contains <- function(file, text) {
  any(grepl(
    text,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_target_ok <- function(manifest_file, target_file) {
  m <- tryCatch(
    read.csv(manifest_file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) ||
      !all(c("file_name", "size_bytes", "md5") %in% names(m))) {
    return(FALSE)
  }
  i <- which(as.character(m$file_name) == basename(target_file))
  if (length(i) != 1L || !file.exists(target_file)) return(FALSE)
  identical(
    as.numeric(m$size_bytes[i]),
    as.numeric(file.info(target_file)$size)
  ) && identical(
    tolower(trimws(as.character(m$md5[i]))),
    md5(target_file)
  )
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

rank_residual <- function(x, source) {
  r <- rank(x, ties.method = "average")
  r - ave(r, source, FUN = mean)
}

source_adjusted_spearman <- function(x, y, source) {
  rx <- rank_residual(x, source)
  ry <- rank_residual(y, source)
  stats::cor(rx, ry, method = "pearson")
}

permute_within_source <- function(x, source) {
  out <- x
  groups <- split(seq_along(source), source)
  for (i in groups) out[i] <- sample(x[i], replace = FALSE)
  out
}

resample_within_source_indices <- function(source) {
  groups <- split(seq_along(source), source)
  unlist(
    lapply(groups, function(i) sample(i, length(i), replace = TRUE)),
    use.names = FALSE
  )
}

source_adjusted_inference <- function(
  x, y, source, n_resample, permutation_seed, bootstrap_seed
) {
  observed <- source_adjusted_spearman(x, y, source)

  set.seed(permutation_seed)
  permutation <- replicate(n_resample, {
    xp <- permute_within_source(x, source)
    source_adjusted_spearman(xp, y, source)
  })
  assert(all(is.finite(permutation)),
         "A non-finite source-stratified permutation estimate occurred.")
  p <- (1 + sum(abs(permutation) >= abs(observed))) / (n_resample + 1)

  set.seed(bootstrap_seed)
  bootstrap <- replicate(n_resample, {
    i <- resample_within_source_indices(source)
    source_adjusted_spearman(x[i], y[i], source[i])
  })
  bootstrap <- bootstrap[is.finite(bootstrap)]
  assert(length(bootstrap) >= 0.99 * n_resample,
         "Too many non-finite source-stratified bootstrap estimates.")

  list(
    estimate = observed,
    p = p,
    CI_lower = unname(quantile(bootstrap, 0.025)),
    CI_upper = unname(quantile(bootstrap, 0.975)),
    permutation = permutation,
    bootstrap = bootstrap
  )
}

fisher_synthesis <- function(effect_table) {
  valid <- effect_table[
    effect_table$fit_valid &
      is.finite(effect_table$fisher_z) &
      is.finite(effect_table$fisher_z_variance) &
      effect_table$fisher_z_variance > 0,
    ,
    drop = FALSE
  ]
  assert(nrow(valid) >= 2L,
         "Fewer than two valid source-dataset correlations are available.")

  z <- valid$fisher_z
  v <- valid$fisher_z_variance
  w <- 1 / v
  z_fixed <- sum(w * z) / sum(w)
  se_fixed <- sqrt(1 / sum(w))
  Q <- sum(w * (z - z_fixed)^2)
  df <- length(z) - 1L
  Q_p <- pchisq(Q, df = df, lower.tail = FALSE)
  I2 <- if (Q > 0) max(0, (Q - df) / Q) * 100 else 0
  C <- sum(w) - sum(w^2) / sum(w)
  tau2_DL <- if (C > 0) max(0, (Q - df) / C) else 0
  wr <- 1 / (v + tau2_DL)
  z_random <- sum(wr * z) / sum(wr)
  se_random <- sqrt(1 / sum(wr))

  build_row <- function(method, z_pool, se_pool, tau2) {
    data.frame(
      pooling_method = method,
      source_dataset_number = nrow(valid),
      pooled_fisher_z = z_pool,
      standard_error = se_pool,
      confidence_level = 0.95,
      confidence_interval_lower_z = z_pool - 1.96 * se_pool,
      confidence_interval_upper_z = z_pool + 1.96 * se_pool,
      pooled_rho = tanh(z_pool),
      confidence_interval_lower_rho = tanh(z_pool - 1.96 * se_pool),
      confidence_interval_upper_rho = tanh(z_pool + 1.96 * se_pool),
      two_sided_p = 2 * pnorm(abs(z_pool / se_pool), lower.tail = FALSE),
      Q = Q,
      Q_df = df,
      Q_p = Q_p,
      I2_percent = I2,
      tau2 = tau2,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  rbind(
    build_row("FIXED_INVERSE_VARIANCE", z_fixed, se_fixed, 0),
    build_row("RANDOM_DERSIMONIAN_LAIRD", z_random, se_random, tau2_DL)
  )
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "GSE31519_EMT_external_validation_COMPLETE_bundle.rds"
    ),
    manifest = file.path(
      root, "audit",
      "Script13G_A_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script13G_A_COMPLETE_report.txt"
    )
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT13G_A STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  is.list(b) &&
    identical(as.character(b$script), "Script13G_A") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    identical(
      as.character(b$source_clinical_bundle_md5),
      unname(EXPECTED_BUNDLE_MD5["clinical_bundle"])
    ) &&
    identical(
      as.character(b$source_score_bundle_md5),
      unname(EXPECTED_BUNDLE_MD5["score_bundle"])
    ) &&
    nrow(b$primary_and_sensitivity_results) == 4L &&
    isFALSE(b$policy$survival_model_fitted) &&
    isFALSE(b$policy$cutoff_selected) &&
    isFALSE(b$policy$samples_filtered)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13G-A output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    STEP_ROOT,
    paste0(
      "13_EMT_external_validation_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("GSE31519 source-stratified EMT validation only.\n")
  cat("============================================================\n")

  packages <- c("GSVA", "msigdbr")
  missing_packages <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  assert(!length(missing_packages),
         "Missing package(s): %s", paste(missing_packages, collapse = ", "))

  assert(dir.exists(STEP_ROOT), "GSE31519 step directory is missing:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted GSE31519 input(s):\n%s",
         paste(missing, collapse = "\n"))

  assert(
    report_contains(INPUTS["clinical_report"], "SCRIPT09B STATUS: COMPLETE"),
    "Script 09B completion marker is missing."
  )
  assert(
    report_contains(INPUTS["score_report"], "SCRIPT10B STATUS: COMPLETE"),
    "Script 10B completion marker is missing."
  )
  assert(
    manifest_target_ok(
      INPUTS["clinical_manifest"], INPUTS["clinical_bundle"]
    ),
    "Script 09B bundle does not match its output manifest."
  )
  assert(
    manifest_target_ok(INPUTS["score_manifest"], INPUTS["score_bundle"]),
    "Script 10B bundle does not match its output manifest."
  )

  observed_bundle_md5 <- c(
    clinical_bundle = md5(INPUTS["clinical_bundle"]),
    score_bundle = md5(INPUTS["score_bundle"])
  )
  assert(
    identical(observed_bundle_md5, EXPECTED_BUNDLE_MD5),
    paste(
      sprintf(
        "%s: expected %s; observed %s",
        names(EXPECTED_BUNDLE_MD5),
        EXPECTED_BUNDLE_MD5,
        observed_bundle_md5
      ),
      collapse = "\n"
    )
  )
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  clinical_bundle <- readRDS(INPUTS["clinical_bundle"])
  score_bundle <- readRDS(INPUTS["score_bundle"])

  assert(
    is.list(clinical_bundle) &&
      identical(as.character(clinical_bundle$script), "Script09B") &&
      identical(as.character(clinical_bundle$source_accession), "GSE31519") &&
      all(c("expression_matrix", "curated_clinical") %in%
            names(clinical_bundle)),
    "Accepted Script 09B bundle identity is incorrect."
  )
  assert(
    is.list(score_bundle) &&
      identical(as.character(score_bundle$script), "Script10B") &&
      identical(as.character(score_bundle$source_accession), "GSE31519") &&
      identical(
        tolower(as.character(score_bundle$source_script09b_bundle_md5)),
        unname(EXPECTED_BUNDLE_MD5["clinical_bundle"])
      ),
    "Accepted Script 10B bundle identity or provenance is incorrect."
  )

  expr <- clinical_bundle$expression_matrix
  phenotype <- clinical_bundle$curated_clinical
  score <- as.numeric(score_bundle$Triclosan_activity)
  names(score) <- names(score_bundle$Triclosan_activity)
  score_table <- score_bundle$score_table

  assert(
    is.matrix(expr) && is.numeric(expr) &&
      identical(dim(expr), c(12650L, 579L)) &&
      all(is.finite(expr)) &&
      !anyDuplicated(rownames(expr)) &&
      !anyDuplicated(colnames(expr)),
    "Accepted GSE31519 expression matrix is malformed."
  )
  assert(
    is.data.frame(phenotype) &&
      nrow(phenotype) == 579L &&
      all(c("sample_id", "source_dataset_id") %in% names(phenotype)) &&
      !anyDuplicated(as.character(phenotype$sample_id)) &&
      identical(as.character(phenotype$sample_id), colnames(expr)),
    "GSE31519 curated clinical data are malformed or misaligned."
  )
  assert(
    is.data.frame(score_table) && nrow(score_table) == 579L &&
      all(c("sample_id", "Triclosan_activity") %in% names(score_table)) &&
      identical(as.character(score_table$sample_id), colnames(expr)) &&
      length(score) == 579L && all(is.finite(score)) && sd(score) > 0 &&
      identical(names(score), colnames(expr)) &&
      isTRUE(all.equal(
        as.numeric(score_table$Triclosan_activity),
        score,
        tolerance = 0,
        check.attributes = FALSE
      )),
    "Accepted GSE31519 Triclosan score is malformed or misaligned."
  )

  source <- trimws(as.character(phenotype$source_dataset_id))
  assert(
    length(source) == 579L &&
      all(!is.na(source) & nzchar(source)) &&
      length(unique(source)) >= 2L,
    "source_dataset_id is incomplete or invariant."
  )

  msig_formals <- names(formals(msigdbr::msigdbr))
  msig_args <- list(species = "Homo sapiens")
  if ("db_species" %in% msig_formals) msig_args$db_species <- "HS"
  if ("collection" %in% msig_formals) {
    msig_args$collection <- "H"
  } else {
    msig_args$category <- "H"
  }

  hallmark <- do.call(msigdbr::msigdbr, msig_args)
  assert(
    is.data.frame(hallmark) &&
      all(c("gs_name", "gene_symbol") %in% names(hallmark)),
    "msigdbr Hallmark output is malformed."
  )

  emt_all <- sort(unique(as.character(
    hallmark$gene_symbol[hallmark$gs_name == EMT_NAME]
  )))
  emt_all <- emt_all[!is.na(emt_all) & nzchar(emt_all)]
  assert(length(emt_all) >= 150L && length(emt_all) <= 250L,
         "Retrieved Hallmark EMT gene count is implausible: %d.", length(emt_all))

  emt_detected <- emt_all[emt_all %in% rownames(expr)]
  overlap <- intersect(emt_detected, LOCKED24)
  emt_no_overlap <- setdiff(emt_detected, LOCKED24)

  assert(
    length(emt_detected) >= ceiling(0.70 * length(emt_all)),
    "GSE31519 Hallmark EMT platform coverage is below 70%%."
  )
  assert(
    length(emt_no_overlap) >= ceiling(0.90 * length(emt_detected)),
    "Overlap-removed EMT set is unexpectedly small."
  )

  gene_sets <- list(
    HALLMARK_EMT_FULL = emt_detected,
    HALLMARK_EMT_NO_TRICLOSAN_OVERLAP = emt_no_overlap
  )
  set.seed(20260711L)
  param <- GSVA::gsvaParam(expr, gene_sets)
  emt_object <- GSVA::gsva(param)
  emt_matrix <- if (is.matrix(emt_object)) {
    emt_object
  } else if (
    inherits(emt_object, "SummarizedExperiment") &&
      requireNamespace("SummarizedExperiment", quietly = TRUE)
  ) {
    as.matrix(SummarizedExperiment::assay(emt_object))
  } else {
    as.matrix(emt_object)
  }

  assert(
    is.matrix(emt_matrix) && is.numeric(emt_matrix) &&
      identical(dim(emt_matrix), c(2L, 579L)) &&
      identical(rownames(emt_matrix), names(gene_sets)) &&
      identical(colnames(emt_matrix), colnames(expr)) &&
      all(is.finite(emt_matrix)) &&
      all(apply(emt_matrix, 1L, sd) > 0),
    "EMT GSVA result failed dimension, order, finite-value or variance checks."
  )

  emt_full <- as.numeric(emt_matrix["HALLMARK_EMT_FULL", ])
  emt_no_overlap_score <- as.numeric(
    emt_matrix["HALLMARK_EMT_NO_TRICLOSAN_OVERLAP", ]
  )
  names(emt_full) <- colnames(expr)
  names(emt_no_overlap_score) <- colnames(expr)

  primary <- source_adjusted_inference(
    score, emt_full, source,
    RESAMPLE_N, PERMUTATION_SEED, BOOTSTRAP_SEED
  )
  overlap_sensitivity <- source_adjusted_inference(
    score, emt_no_overlap_score, source,
    RESAMPLE_N, PERMUTATION_SEED + 10L, BOOTSTRAP_SEED + 10L
  )
  raw_full <- suppressWarnings(cor.test(
    score, emt_full, method = "spearman", exact = FALSE
  ))
  raw_no_overlap <- suppressWarnings(cor.test(
    score, emt_no_overlap_score, method = "spearman", exact = FALSE
  ))

  result_table <- data.frame(
    analysis = c(
      "PRIMARY_SOURCE_ADJUSTED_FULL_EMT",
      "SENSITIVITY_SOURCE_ADJUSTED_NO_OVERLAP_EMT",
      "SENSITIVITY_RAW_POOLED_FULL_EMT",
      "SENSITIVITY_RAW_POOLED_NO_OVERLAP_EMT"
    ),
    method = c(
      "Partial_Spearman_source_centered_ranks",
      "Partial_Spearman_source_centered_ranks",
      "Raw_pooled_Spearman",
      "Raw_pooled_Spearman"
    ),
    EMT_score = c(
      "HALLMARK_EMT_FULL",
      "HALLMARK_EMT_NO_TRICLOSAN_OVERLAP",
      "HALLMARK_EMT_FULL",
      "HALLMARK_EMT_NO_TRICLOSAN_OVERLAP"
    ),
    sample_number = 579L,
    source_dataset_number = length(unique(source)),
    estimate = c(
      primary$estimate,
      overlap_sensitivity$estimate,
      unname(raw_full$estimate),
      unname(raw_no_overlap$estimate)
    ),
    confidence_level = 0.95,
    confidence_interval_method = c(
      paste0("Within-source bootstrap; B=", RESAMPLE_N),
      paste0("Within-source bootstrap; B=", RESAMPLE_N),
      "Not calculated for raw pooled sensitivity",
      "Not calculated for raw pooled sensitivity"
    ),
    confidence_interval_lower = c(
      primary$CI_lower,
      overlap_sensitivity$CI_lower,
      NA_real_,
      NA_real_
    ),
    confidence_interval_upper = c(
      primary$CI_upper,
      overlap_sensitivity$CI_upper,
      NA_real_,
      NA_real_
    ),
    p_value_method = c(
      paste0("Within-source permutation; B=", RESAMPLE_N),
      paste0("Within-source permutation; B=", RESAMPLE_N),
      "Spearman asymptotic two-sided",
      "Spearman asymptotic two-sided"
    ),
    two_sided_p = c(
      primary$p,
      overlap_sensitivity$p,
      raw_full$p.value,
      raw_no_overlap$p.value
    ),
    expected_direction = "positive",
    direction_matches_TCGA = c(
      primary$estimate > 0,
      overlap_sensitivity$estimate > 0,
      unname(raw_full$estimate) > 0,
      unname(raw_no_overlap$estimate) > 0
    ),
    primary_analysis = c(TRUE, FALSE, FALSE, FALSE),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  result_table$secondary_BH_adjusted_p <- c(
    NA_real_,
    p.adjust(result_table$two_sided_p[2:4], method = "BH")
  )

  source_levels <- sort(unique(source))
  source_effects <- do.call(rbind, lapply(source_levels, function(s) {
    i <- which(source == s)
    x <- score[i]
    y <- emt_full[i]
    valid <- length(i) >= MIN_SOURCE_N &&
      length(unique(x)) > 1L &&
      length(unique(y)) > 1L

    if (valid) {
      test <- suppressWarnings(cor.test(
        x, y, method = "spearman", exact = FALSE
      ))
      rho <- unname(test$estimate)
      p <- test$p.value
      z <- atanh(max(min(rho, 0.999999), -0.999999))
      variance <- 1 / (length(i) - 3)
    } else {
      rho <- p <- z <- variance <- NA_real_
    }

    data.frame(
      source_dataset_id = s,
      sample_number = length(i),
      Triclosan_score_unique_number = length(unique(x)),
      EMT_score_unique_number = length(unique(y)),
      minimum_required_n = MIN_SOURCE_N,
      fit_valid = valid,
      Spearman_rho = rho,
      two_sided_p = p,
      fisher_z = z,
      fisher_z_variance = variance,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
  rownames(source_effects) <- NULL

  source_meta <- fisher_synthesis(source_effects)

  valid_sources <- source_effects[source_effects$fit_valid, , drop = FALSE]
  leave_one_out <- if (nrow(valid_sources) >= 3L) {
    do.call(rbind, lapply(seq_len(nrow(valid_sources)), function(i) {
      reduced <- valid_sources[-i, , drop = FALSE]
      meta_i <- fisher_synthesis(reduced)
      random_i <- meta_i[
        meta_i$pooling_method == "RANDOM_DERSIMONIAN_LAIRD",
        ,
        drop = FALSE
      ]
      data.frame(
        omitted_source_dataset_id = valid_sources$source_dataset_id[i],
        retained_source_dataset_number = nrow(reduced),
        pooled_rho = random_i$pooled_rho,
        confidence_interval_lower_rho =
          random_i$confidence_interval_lower_rho,
        confidence_interval_upper_rho =
          random_i$confidence_interval_upper_rho,
        two_sided_p = random_i$two_sided_p,
        I2_percent = random_i$I2_percent,
        tau2 = random_i$tau2,
        pooling_method = random_i$pooling_method,
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }))
  } else {
    data.frame(
      omitted_source_dataset_id = character(),
      retained_source_dataset_number = integer(),
      pooled_rho = numeric(),
      confidence_interval_lower_rho = numeric(),
      confidence_interval_upper_rho = numeric(),
      two_sided_p = numeric(),
      I2_percent = numeric(),
      tau2 = numeric(),
      pooling_method = character(),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  emt_gene_audit <- data.frame(
    pathway = EMT_NAME,
    human_symbol = emt_all,
    present_in_GSE31519 = emt_all %in% emt_detected,
    overlaps_locked_24gene_signature = emt_all %in% overlap,
    used_in_primary_EMT_score = emt_all %in% emt_detected,
    used_in_overlap_removed_EMT_score = emt_all %in% emt_no_overlap,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  emt_summary <- data.frame(
    pathway = EMT_NAME,
    msigdbr_version = as.character(packageVersion("msigdbr")),
    total_gene_number = length(emt_all),
    detected_gene_number = length(emt_detected),
    detected_fraction = length(emt_detected) / length(emt_all),
    locked24_overlap_gene_number = length(overlap),
    locked24_overlap_genes =
      if (length(overlap)) paste(overlap, collapse = ";") else "",
    overlap_removed_gene_number = length(emt_no_overlap),
    full_score_zero_variance = sd(emt_full) == 0,
    overlap_removed_score_zero_variance =
      sd(emt_no_overlap_score) == 0,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  sample_table <- data.frame(
    sample_order = seq_len(ncol(expr)),
    sample_id = colnames(expr),
    source_dataset_id = source,
    Triclosan_activity = score,
    HALLMARK_EMT_FULL = emt_full,
    HALLMARK_EMT_NO_TRICLOSAN_OVERLAP = emt_no_overlap_score,
    source_adjusted_rank_Triclosan =
      rank_residual(score, source),
    source_adjusted_rank_EMT_FULL =
      rank_residual(emt_full, source),
    samples_filtered = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  parameter_lock <- data.frame(
    field = c(
      "Primary_endpoint",
      "Primary_method",
      "Source_adjustment",
      "Primary_p_value",
      "Primary_confidence_interval",
      "EMT_source",
      "EMT_scoring",
      "Expression_input",
      "Overlap_sensitivity",
      "Source_dataset_synthesis",
      "Minimum_source_dataset_n",
      "Survival_refit",
      "Cutoff_or_high_low_group",
      "Sample_filtering",
      "DEG_PCA_GSEA_figure"
    ),
    value = c(
      "Triclosan_activity versus HALLMARK_EMT_FULL",
      "Partial Spearman correlation",
      "Global ranks centered within source_dataset_id",
      paste0("Within-source permutation; B=", RESAMPLE_N,
             "; seed=", PERMUTATION_SEED),
      paste0("Within-source bootstrap; B=", RESAMPLE_N,
             "; seed=", BOOTSTRAP_SEED),
      paste0("msigdbr ", packageVersion("msigdbr")),
      "Classical GSVA",
      "Full 12650-gene x 579-sample expression matrix",
      "Remove all locked-24 overlap genes and rescore EMT",
      "Per-source Spearman Fisher-z; fixed and DL random effects",
      MIN_SOURCE_N,
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    primary_endpoint =
      "Source_adjusted_continuous_Triclosan_activity_vs_Hallmark_EMT",
    full_expression_matrix_used_for_EMT_GSVA = TRUE,
    source_dataset_adjustment_prespecified = TRUE,
    alternative_Triclosan_score_calculated = FALSE,
    survival_model_fitted = FALSE,
    samples_filtered = FALSE,
    outliers_removed = FALSE,
    cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    Kaplan_Meier_performed = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID",
      "Source_Script09B_bundle_MD5","Source_Script10B_bundle_MD5",
      "Expression_dimensions","Sample_number","Source_dataset_number",
      "Finite_Triclosan_scores","Finite_EMT_scores",
      "Hallmark_EMT_total_genes","Hallmark_EMT_detected_genes",
      "Hallmark_EMT_overlap_locked24","Hallmark_EMT_no_overlap_genes",
      "Primary_test_number","Valid_source_dataset_correlations",
      "Source_dataset_meta_rows","Leave_one_out_rows",
      "Survival_model_fitted","Samples_filtered","Outliers_removed",
      "Alternative_score_calculated","Cutoff_selected",
      "High_low_group_created","Kaplan_Meier_performed",
      "DEG_performed","PCA_performed","GSEA_performed",
      "Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "GSE31519","13G_A",BUILD_ID,
      EXPECTED_BUNDLE_MD5["clinical_bundle"],
      EXPECTED_BUNDLE_MD5["score_bundle"],
      paste(dim(expr), collapse = " x "),
      length(score),length(unique(source)),
      sum(is.finite(score)),sum(is.finite(emt_matrix)),
      length(emt_all),length(emt_detected),length(overlap),
      length(emt_no_overlap),sum(result_table$primary_analysis),
      sum(source_effects$fit_valid),nrow(source_meta),nrow(leave_one_out),
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,"COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = c("Script09B","Script09B","Script09B",
                     "Script10B","Script10B","Script10B"),
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = vapply(INPUTS, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step2_GSE31519_external_validation",
    script = "Script13G_A",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE31519",
    source_clinical_bundle_md5 =
      unname(EXPECTED_BUNDLE_MD5["clinical_bundle"]),
    source_score_bundle_md5 =
      unname(EXPECTED_BUNDLE_MD5["score_bundle"]),
    Triclosan_activity = score,
    EMT_score_matrix = emt_matrix,
    sample_level_scores = sample_table,
    EMT_gene_set_summary = emt_summary,
    EMT_gene_set_audit = emt_gene_audit,
    primary_and_sensitivity_results = result_table,
    source_dataset_effects = source_effects,
    source_dataset_meta_summary = source_meta,
    source_dataset_leave_one_out = leave_one_out,
    parameter_lock = parameter_lock,
    integrity_summary = integrity,
    policy = policy
  )
  class(bundle) <- c(
    "GSE31519_EMT_external_validation_bundle", "list"
  )

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script13G_A_staging_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "GSE31519_EMT_external_validation_COMPLETE_bundle.rds"
    ),
    EMT_scores = file.path(
      stage, "objects",
      "GSE31519_Hallmark_EMT_GSVA_scores.rds"
    ),
    resampling = file.path(
      stage, "objects",
      "GSE31519_EMT_source_adjusted_resampling_distributions.rds"
    ),
    samples = file.path(
      stage, "audit",
      "GSE31519_Triclosan_EMT_scores_all579.csv"
    ),
    EMT_summary = file.path(
      stage, "audit",
      "GSE31519_Hallmark_EMT_gene_set_summary.csv"
    ),
    EMT_audit = file.path(
      stage, "audit",
      "GSE31519_Hallmark_EMT_gene_set_audit.csv"
    ),
    results = file.path(
      stage, "audit",
      "GSE31519_Triclosan_EMT_source_adjusted_results.csv"
    ),
    source_effects = file.path(
      stage, "audit",
      "GSE31519_source_dataset_EMT_correlations.csv"
    ),
    source_meta = file.path(
      stage, "audit",
      "GSE31519_source_dataset_EMT_correlation_meta_summary.csv"
    ),
    leave_one_out = file.path(
      stage, "audit",
      "GSE31519_source_dataset_EMT_meta_leave_one_out.csv"
    ),
    parameters = file.path(
      stage, "audit",
      "GSE31519_EMT_validation_parameter_lock.csv"
    ),
    packages = file.path(
      stage, "audit",
      "Script13G_A_package_audit.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "GSE31519_EMT_validation_integrity_summary.csv"
    ),
    inputs = file.path(
      stage, "audit",
      "Script13G_A_input_manifest_with_MD5.csv"
    ),
    GSVA_details = file.path(
      stage, "logs",
      "Script13G_A_EMT_GSVA_parameter_details.txt"
    ),
    session = file.path(
      stage, "logs",
      "Script13G_A_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs",
      "Script13G_A_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(emt_matrix, files["EMT_scores"], version = 3)
  saveRDS(list(
    primary_permutation = primary$permutation,
    primary_bootstrap = primary$bootstrap,
    no_overlap_permutation = overlap_sensitivity$permutation,
    no_overlap_bootstrap = overlap_sensitivity$bootstrap,
    resample_n = RESAMPLE_N,
    seeds = c(
      primary_permutation = PERMUTATION_SEED,
      primary_bootstrap = BOOTSTRAP_SEED,
      no_overlap_permutation = PERMUTATION_SEED + 10L,
      no_overlap_bootstrap = BOOTSTRAP_SEED + 10L
    )
  ), files["resampling"], version = 3)

  write_csv(sample_table, files["samples"])
  write_csv(emt_summary, files["EMT_summary"])
  write_csv(emt_gene_audit, files["EMT_audit"])
  write_csv(result_table, files["results"])
  write_csv(source_effects, files["source_effects"])
  write_csv(source_meta, files["source_meta"])
  write_csv(leave_one_out, files["leave_one_out"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(data.frame(
    package = packages,
    version = vapply(
      packages, function(x) as.character(packageVersion(x)), character(1)
    ),
    available = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  ), files["packages"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  writeLines(capture.output(show(param)),
             files["GSVA_details"], useBytes = TRUE)
  capture.output(sessionInfo(), file = files["session"])

  random_meta <- source_meta[
    source_meta$pooling_method == "RANDOM_DERSIMONIAN_LAIRD",
    ,
    drop = FALSE
  ]
  report <- c(
    "============================================================",
    "TNBC_Triclosan - GSE31519 Script 13G-A",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("Expression dimensions: ", paste(dim(expr), collapse = " x ")),
    paste0("Source datasets: ", length(unique(source))),
    paste0("Hallmark EMT detected: ", length(emt_detected), " / ",
           length(emt_all)),
    paste0("Locked-24 overlap genes: ", length(overlap),
           if (length(overlap))
             paste0(" [", paste(overlap, collapse = ";"), "]") else ""),
    paste0("Primary source-adjusted rho: ",
           format(primary$estimate, digits = 16)),
    paste0("Primary permutation p: ",
           format(primary$p, digits = 16)),
    paste0("Primary bootstrap 95% CI: ",
           format(primary$CI_lower, digits = 16), " to ",
           format(primary$CI_upper, digits = 16)),
    paste0("Overlap-removed source-adjusted rho: ",
           format(overlap_sensitivity$estimate, digits = 16)),
    paste0("Overlap-removed permutation p: ",
           format(overlap_sensitivity$p, digits = 16)),
    paste0("Valid source-dataset correlations: ",
           sum(source_effects$fit_valid)),
    paste0("Source random-effects pooled rho: ",
           format(random_meta$pooled_rho, digits = 16)),
    paste0("Source random-effects p: ",
           format(random_meta$two_sided_p, digits = 16)),
    paste0("Source random-effects I2: ",
           format(random_meta$I2_percent, digits = 8), "%"),
    "Survival model fitted: FALSE",
    "Samples filtered or outliers removed: FALSE",
    "Alternative Triclosan score calculated: FALSE",
    "Cutoff/high-low/KM/DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13G_A STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  e2 <- readRDS(files["EMT_scores"])
  r2 <- read.csv(
    files["results"], stringsAsFactors = FALSE, check.names = FALSE
  )
  m2 <- read.csv(
    files["source_meta"], stringsAsFactors = FALSE, check.names = FALSE
  )
  assert(
    identical(e2, emt_matrix) &&
      identical(b2$EMT_score_matrix, emt_matrix) &&
      nrow(r2) == 4L &&
      isTRUE(all.equal(
        r2$estimate, result_table$estimate,
        tolerance = 1e-14, check.attributes = FALSE
      )) &&
      isTRUE(all.equal(
        r2$two_sided_p, result_table$two_sided_p,
        tolerance = 1e-14, check.attributes = FALSE
      )) &&
      nrow(m2) == 2L &&
      isTRUE(all.equal(
        m2$pooled_rho, source_meta$pooled_rho,
        tolerance = 1e-14, check.attributes = FALSE
      )),
    "RDS/CSV save-read validation failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script13G_A_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script13G_A_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script13G_A_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13G-A completed successfully.\n")
  cat("Samples retained: 579 / 579\n")
  cat("Source-stratified EMT primary test completed.\n")
  cat("Survival refit/cutoff/figure performed: FALSE\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 10B v3
#
# Purpose:
#   Continue strictly from the accepted Script 09B curated clinical endpoint
#   bundle and Script 10A signature coverage audit.
#
#   Calculate one continuous Triclosan_activity score per GSE31519 sample using
#   the same prespecified workflow previously used in the project:
#
#       gene_set <- list(Triclosan_activity = locked_24_genes)
#       param <- GSVA::gsvaParam(expr_gene, gene_set)
#       score_matrix <- GSVA::gsva(param)
#
#   The full 12,650-gene x 579-sample matrix is supplied to GSVA. The score is
#   not calculated from the 24-gene submatrix alone.
#
# This script DOES:
#   - verify the accepted Script 09B and Script 10A bundles by MD5;
#   - verify complete 24/24 exact signature coverage;
#   - calculate the continuous classical GSVA score for all 579 samples;
#   - preserve original sample order;
#   - audit score completeness, variability and technical-source distributions;
#   - save the score, parameter record, RDS bundle, manifests and sessionInfo.
#
# This script DOES NOT:
#   - rerun Scripts 07A-10A;
#   - modify or re-normalize expression values;
#   - substitute gene aliases;
#   - calculate an alternative score;
#   - use EFS time, event status or any other outcome;
#   - divide samples into high/low groups;
#   - select a cutoff;
#   - fit Kaplan-Meier, Cox or any other clinical model;
#   - create a manuscript figure.
#
# v3 correction:
#   Numeric score equality is checked independently from vector names and other
#   attributes. This prevents false failures when a named GSVA vector is stored
#   as a data.frame column, while still requiring exact element-wise equality
#   and separately requiring identical sample order.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step2_GSE31519_external_validation"
)

clinical_root <- file.path(
  step_root,
  "06_curated_clinical_endpoint"
)
coverage_root <- file.path(
  step_root,
  "07_signature_coverage_audit"
)
final_root <- file.path(
  step_root,
  "08_Triclosan_GSVA_score"
)

clinical_bundle_file <- file.path(
  clinical_root,
  "objects",
  "GSE31519_curated_clinical_endpoint_COMPLETE_bundle.rds"
)
clinical_manifest_file <- file.path(
  clinical_root,
  "audit",
  "Script09B_output_manifest_with_MD5.csv"
)
clinical_report_file <- file.path(
  clinical_root,
  "logs",
  "Script09B_COMPLETE_report.txt"
)

coverage_bundle_file <- file.path(
  coverage_root,
  "objects",
  "GSE31519_Triclosan_signature_coverage_AUDIT_bundle.rds"
)
coverage_manifest_file <- file.path(
  coverage_root,
  "audit",
  "Script10A_output_manifest_with_MD5.csv"
)
coverage_report_file <- file.path(
  coverage_root,
  "logs",
  "Script10A_COMPLETE_report.txt"
)
coverage_summary_file <- file.path(
  coverage_root,
  "audit",
  "GSE31519_Triclosan_signature_coverage_summary.csv"
)

required_inputs <- c(
  clinical_bundle_file,
  clinical_manifest_file,
  clinical_report_file,
  coverage_bundle_file,
  coverage_manifest_file,
  coverage_report_file,
  coverage_summary_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 10B cannot start because required accepted inputs are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop(
    "Step 2 project directory does not exist: ",
    step_root,
    call. = FALSE
  )
}

# Never overwrite an existing output directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(
      final_root,
      all.files = TRUE
    ),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(
      final_root,
      recursive = TRUE,
      force = TRUE
    )
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty, so Script 10B ",
        "will not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(
  Sys.time(),
  "%Y%m%d_%H%M%S"
)

stage_root <- file.path(
  step_root,
  paste0(
    ".Script10B_staging_",
    stamp,
    "_",
    Sys.getpid()
  )
)

stage_object_dir <- file.path(
  stage_root,
  "objects"
)
stage_audit_dir <- file.path(
  stage_root,
  "audit"
)
stage_log_dir <- file.path(
  stage_root,
  "logs"
)

dir.create(
  stage_object_dir,
  recursive = TRUE,
  showWarnings = FALSE
)
dir.create(
  stage_audit_dir,
  recursive = TRUE,
  showWarnings = FALSE
)
dir.create(
  stage_log_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop(
    "Unable to create Script 10B staging directories.",
    call. = FALSE
  )
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(
      stage_root,
      recursive = TRUE,
      force = TRUE
    )
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) {
    stop(
      message,
      call. = FALSE
    )
  }
}

same_numeric_values <- function(x, y, tolerance = 0) {
  x_numeric <- unname(as.numeric(x))
  y_numeric <- unname(as.numeric(y))

  if (length(x_numeric) != length(y_numeric)) {
    return(FALSE)
  }

  if (!identical(is.na(x_numeric), is.na(y_numeric))) {
    return(FALSE)
  }

  comparable <- !is.na(x_numeric) & !is.na(y_numeric)

  if (!any(comparable)) {
    return(TRUE)
  }

  isTRUE(
    all.equal(
      x_numeric[comparable],
      y_numeric[comparable],
      tolerance = tolerance,
      check.attributes = FALSE
    )
  )
}

md5_one <- function(path) {
  unname(
    tools::md5sum(path)
  )
}

normalize_existing_path <- function(path) {
  normalizePath(
    path,
    winslash = "/",
    mustWork = TRUE
  )
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(
    report_file,
    warn = FALSE,
    encoding = "UTF-8"
  )

  any(
    grepl(
      fixed_text,
      lines,
      fixed = TRUE
    )
  )
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(
    length(paths) == length(displayed_paths)
  )

  info <- file.info(paths)

  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(path) {
        normalizePath(
          path,
          winslash = "/",
          mustWork = FALSE
        )
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(
      paths,
      md5_one,
      character(1)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  required_columns <- c(
    "file_name",
    "size_bytes",
    "md5"
  )

  assert_true(
    all(required_columns %in% colnames(manifest)),
    paste0(
      "Malformed output manifest: ",
      manifest_file
    )
  )

  rows <- which(
    manifest$file_name == basename(target_file)
  )

  assert_true(
    length(rows) == 1L,
    paste0(
      "The manifest must contain exactly one row for ",
      basename(target_file),
      ": ",
      manifest_file
    )
  )

  tolower(
    trimws(
      as.character(
        manifest$md5[rows]
      )
    )
  )
}

safe_quantile <- function(x, probability) {
  as.numeric(
    stats::quantile(
      x,
      probs = probability,
      na.rm = TRUE,
      names = FALSE,
      type = 7
    )
  )
}

summarize_numeric_vector <- function(x) {
  x <- as.numeric(x)
  finite_x <- x[is.finite(x)]

  data.frame(
    sample_number = length(x),
    finite_number = length(finite_x),
    nonfinite_number = sum(!is.finite(x)),
    minimum = if (length(finite_x) == 0L) {
      NA_real_
    } else {
      min(finite_x)
    },
    first_quartile = if (length(finite_x) == 0L) {
      NA_real_
    } else {
      safe_quantile(finite_x, 0.25)
    },
    median = if (length(finite_x) == 0L) {
      NA_real_
    } else {
      stats::median(finite_x)
    },
    mean = if (length(finite_x) == 0L) {
      NA_real_
    } else {
      mean(finite_x)
    },
    third_quartile = if (length(finite_x) == 0L) {
      NA_real_
    } else {
      safe_quantile(finite_x, 0.75)
    },
    maximum = if (length(finite_x) == 0L) {
      NA_real_
    } else {
      max(finite_x)
    },
    standard_deviation = if (length(finite_x) <= 1L) {
      NA_real_
    } else {
      stats::sd(finite_x)
    },
    interquartile_range = if (length(finite_x) == 0L) {
      NA_real_
    } else {
      stats::IQR(finite_x)
    },
    unique_finite_value_number = length(unique(finite_x)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

summarize_by_group <- function(score_table, group_column) {
  group_value <- as.character(
    score_table[[group_column]]
  )
  group_value[
    is.na(group_value) |
      !nzchar(trimws(group_value))
  ] <- "<MISSING>"

  group_levels <- sort(
    unique(group_value)
  )

  rows <- vector(
    "list",
    length(group_levels)
  )

  for (i in seq_along(group_levels)) {
    level_i <- group_levels[i]
    mask_i <- group_value == level_i

    summary_i <- summarize_numeric_vector(
      score_table$Triclosan_activity[mask_i]
    )

    rows[[i]] <- data.frame(
      group_variable = group_column,
      group_value = level_i,
      summary_i,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  result <- do.call(
    rbind,
    rows
  )

  rownames(result) <- NULL
  result
}

as_score_matrix <- function(x) {
  if (is.matrix(x)) {
    return(x)
  }

  if (
    inherits(x, "SummarizedExperiment") &&
      requireNamespace(
        "SummarizedExperiment",
        quietly = TRUE
      )
  ) {
    return(
      as.matrix(
        SummarizedExperiment::assay(x)
      )
    )
  }

  if (
    inherits(x, "ExpressionSet") &&
      requireNamespace(
        "Biobase",
        quietly = TRUE
      )
  ) {
    return(
      as.matrix(
        Biobase::exprs(x)
      )
    )
  }

  as.matrix(x)
}

# ------------------------------
# 2. Package preflight
# ------------------------------
required_packages <- c(
  "GSVA"
)

missing_packages <- required_packages[
  !vapply(
    required_packages,
    requireNamespace,
    logical(1),
    quietly = TRUE
  )
]

if (length(missing_packages) > 0L) {
  stop(
    paste0(
      "Required Bioconductor package is not installed: ",
      paste(missing_packages, collapse = ", "),
      "\nInstall it once with:\n",
      "if (!requireNamespace('BiocManager', quietly = TRUE)) ",
      "install.packages('BiocManager')\n",
      "BiocManager::install('GSVA')"
    ),
    call. = FALSE
  )
}

assert_true(
  exists(
    "gsvaParam",
    envir = asNamespace("GSVA"),
    mode = "function",
    inherits = FALSE
  ),
  paste0(
    "The installed GSVA package does not provide gsvaParam(). ",
    "Update GSVA through BiocManager before running Script 10B."
  )
)

gsva_version <- as.character(
  utils::packageVersion("GSVA")
)

biocparallel_available <- requireNamespace(
  "BiocParallel",
  quietly = TRUE
)

biocparallel_version <- if (biocparallel_available) {
  as.character(
    utils::packageVersion("BiocParallel")
  )
} else {
  NA_character_
}

# ------------------------------
# 3. Verify accepted input identities
# ------------------------------
assert_true(
  report_contains(
    clinical_report_file,
    "SCRIPT09B STATUS: COMPLETE"
  ),
  "Script 09B completion status was not found in its report."
)

assert_true(
  report_contains(
    coverage_report_file,
    "SCRIPT10A STATUS: COMPLETE"
  ),
  "Script 10A completion status was not found in its report."
)

expected_clinical_md5 <- manifest_expected_md5(
  clinical_manifest_file,
  clinical_bundle_file
)
observed_clinical_md5 <- tolower(
  md5_one(clinical_bundle_file)
)

assert_true(
  identical(
    expected_clinical_md5,
    observed_clinical_md5
  ),
  paste0(
    "Script 09B bundle MD5 mismatch.\n",
    "Expected from manifest: ",
    expected_clinical_md5,
    "\nObserved: ",
    observed_clinical_md5
  )
)

accepted_script09b_bundle_md5 <-
  "02606ffd117178bcd20571ab34740104"

assert_true(
  identical(
    observed_clinical_md5,
    accepted_script09b_bundle_md5
  ),
  paste0(
    "The Script 09B bundle does not match the accepted bundle.\n",
    "Expected: ",
    accepted_script09b_bundle_md5,
    "\nObserved: ",
    observed_clinical_md5
  )
)

expected_coverage_md5 <- manifest_expected_md5(
  coverage_manifest_file,
  coverage_bundle_file
)
observed_coverage_md5 <- tolower(
  md5_one(coverage_bundle_file)
)

assert_true(
  identical(
    expected_coverage_md5,
    observed_coverage_md5
  ),
  paste0(
    "Script 10A bundle MD5 mismatch.\n",
    "Expected from manifest: ",
    expected_coverage_md5,
    "\nObserved: ",
    observed_coverage_md5
  )
)

accepted_script10a_bundle_md5 <-
  "1db7f5c245b01b78a976a9a1580fca53"

assert_true(
  identical(
    observed_coverage_md5,
    accepted_script10a_bundle_md5
  ),
  paste0(
    "The Script 10A bundle does not match the accepted bundle.\n",
    "Expected: ",
    accepted_script10a_bundle_md5,
    "\nObserved: ",
    observed_coverage_md5
  )
)

coverage_summary <- read.csv(
  coverage_summary_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(
    c("item", "value") %in%
      colnames(coverage_summary)
  ),
  "The Script 10A coverage summary is malformed."
)

assert_true(
  anyDuplicated(
    coverage_summary$item
  ) == 0L,
  "The Script 10A coverage summary contains duplicated item names."
)

coverage_lookup <- setNames(
  as.character(
    coverage_summary$value
  ),
  coverage_summary$item
)

required_coverage_items <- c(
  "Exact_signature_genes_present",
  "Exact_signature_genes_missing",
  "Exact_signature_coverage_fraction",
  "Samples_complete_for_all_available_signature_genes",
  "Available_signature_genes_with_nonfinite_values",
  "Available_signature_genes_with_zero_variance",
  "Completion_status"
)

assert_true(
  all(
    required_coverage_items %in%
      names(coverage_lookup)
  ),
  "The Script 10A coverage summary is missing required items."
)

assert_true(
  identical(
    coverage_lookup[["Completion_status"]],
    "COMPLETE"
  ),
  "The Script 10A coverage summary is not marked COMPLETE."
)

# ------------------------------
# 4. Read and validate accepted source objects
# ------------------------------
clinical_bundle <- readRDS(
  clinical_bundle_file
)
coverage_bundle <- readRDS(
  coverage_bundle_file
)

required_clinical_fields <- c(
  "script",
  "source_accession",
  "expression_matrix",
  "curated_clinical",
  "integrity_summary",
  "endpoint_policy"
)

assert_true(
  is.list(clinical_bundle) &&
    all(
      required_clinical_fields %in%
        names(clinical_bundle)
    ),
  "The Script 09B bundle is missing required fields."
)

assert_true(
  identical(
    as.character(clinical_bundle$script),
    "Script09B"
  ),
  "The clinical input bundle was not created by Script 09B."
)

assert_true(
  identical(
    as.character(
      clinical_bundle$source_accession
    ),
    "GSE31519"
  ),
  "The clinical input bundle is not for GSE31519."
)

required_coverage_fields <- c(
  "script",
  "source_accession",
  "source_script09b_bundle_md5",
  "source_expression_dimensions",
  "source_sample_ids",
  "signature_definition",
  "hub_gene_subset",
  "scoring_rule_lock",
  "signature_coverage_audit",
  "signature_expression_audit",
  "sample_signature_completeness",
  "integrity_summary",
  "policy"
)

assert_true(
  is.list(coverage_bundle) &&
    all(
      required_coverage_fields %in%
        names(coverage_bundle)
    ),
  "The Script 10A bundle is missing required fields."
)

assert_true(
  identical(
    as.character(coverage_bundle$script),
    "Script10A"
  ),
  "The coverage input bundle was not created by Script 10A."
)

assert_true(
  identical(
    as.character(
      coverage_bundle$source_accession
    ),
    "GSE31519"
  ),
  "The coverage input bundle is not for GSE31519."
)

assert_true(
  identical(
    tolower(
      as.character(
        coverage_bundle$source_script09b_bundle_md5
      )
    ),
    observed_clinical_md5
  ),
  paste0(
    "The accepted Script 10A bundle does not point to ",
    "the accepted Script 09B bundle."
  )
)

expr_gene <- clinical_bundle$expression_matrix
clinical <- clinical_bundle$curated_clinical

assert_true(
  is.matrix(expr_gene) &&
    is.numeric(expr_gene),
  "The gene-level expression object is not a numeric matrix."
)

assert_true(
  identical(
    dim(expr_gene),
    c(12650L, 579L)
  ),
  paste0(
    "Expected a 12,650 x 579 expression matrix, detected ",
    paste(
      dim(expr_gene),
      collapse = " x "
    ),
    "."
  )
)

assert_true(
  sum(
    !is.finite(expr_gene)
  ) == 0L,
  "The gene-level expression matrix contains non-finite values."
)

assert_true(
  !is.null(
    rownames(expr_gene)
  ) &&
    anyDuplicated(
      rownames(expr_gene)
    ) == 0L &&
    all(
      nzchar(
        rownames(expr_gene)
      )
    ),
  "Gene symbols are missing, blank or duplicated."
)

assert_true(
  !is.null(
    colnames(expr_gene)
  ) &&
    anyDuplicated(
      colnames(expr_gene)
    ) == 0L,
  "Expression sample IDs are missing or duplicated."
)

assert_true(
  is.data.frame(clinical) &&
    nrow(clinical) == 579L &&
    "sample_id" %in%
      colnames(clinical),
  "The curated clinical table is missing or malformed."
)

assert_true(
  identical(
    colnames(expr_gene),
    as.character(
      clinical$sample_id
    )
  ),
  "Expression columns and clinical rows are not identically ordered."
)

assert_true(
  identical(
    as.character(
      coverage_bundle$source_sample_ids
    ),
    colnames(expr_gene)
  ),
  "Script 10A sample IDs do not match the accepted expression matrix."
)

assert_true(
  identical(
    as.integer(
      coverage_bundle$source_expression_dimensions
    ),
    as.integer(
      dim(expr_gene)
    )
  ),
  "Script 10A source dimensions do not match the accepted expression matrix."
)

# ------------------------------
# 5. Recover and verify the locked signature
# ------------------------------
signature_definition <-
  coverage_bundle$signature_definition

coverage_audit <-
  coverage_bundle$signature_coverage_audit

assert_true(
  is.data.frame(signature_definition) &&
    all(c(
      "signature_order",
      "gene_symbol",
      "signature_name",
      "prespecified_gene_weight",
      "prespecified_gene_direction"
    ) %in% colnames(signature_definition)),
  "The locked signature definition is malformed."
)

assert_true(
  is.data.frame(coverage_audit) &&
    all(c(
      "signature_order",
      "requested_gene_symbol",
      "exact_symbol_present",
      "included_in_future_exact_match_score"
    ) %in% colnames(coverage_audit)),
  "The signature coverage audit is malformed."
)

signature_definition <-
  signature_definition[
    order(
      signature_definition$signature_order
    ),
    ,
    drop = FALSE
  ]

coverage_audit <-
  coverage_audit[
    order(
      coverage_audit$signature_order
    ),
    ,
    drop = FALSE
  ]

locked_signature_genes <- as.character(
  signature_definition$gene_symbol
)

expected_signature_genes <- c(
  "ESR1",
  "AR",
  "PGR",
  "THRA",
  "THRB",
  "CAT",
  "BCL2",
  "BAX",
  "PARP1",
  "IL6",
  "ABCB1",
  "ABCG2",
  "FASN",
  "SCD",
  "TWIST1",
  "PPARG",
  "EGFR",
  "MMP9",
  "JUN",
  "FOS",
  "ADRB2",
  "ERG",
  "H2AX",
  "MITF"
)

assert_true(
  identical(
    locked_signature_genes,
    expected_signature_genes
  ),
  "The locked 24-gene signature differs from the accepted project signature."
)

assert_true(
  length(
    locked_signature_genes
  ) == 24L &&
    anyDuplicated(
      locked_signature_genes
    ) == 0L,
  "The locked signature is not 24 unique genes."
)

assert_true(
  all(
    as.logical(
      coverage_audit$exact_symbol_present
    )
  ),
  "At least one locked signature gene is not an exact expression-matrix match."
)

assert_true(
  all(
    as.logical(
      coverage_audit$included_in_future_exact_match_score
    )
  ),
  "At least one locked signature gene was not approved for scoring."
)

assert_true(
  identical(
    as.character(
      coverage_audit$requested_gene_symbol
    ),
    locked_signature_genes
  ),
  "The coverage audit gene order differs from the locked signature definition."
)

assert_true(
  all(
    locked_signature_genes %in%
      rownames(expr_gene)
  ),
  "At least one locked signature gene is absent from the expression matrix."
)

signature_expr <- expr_gene[
  locked_signature_genes,
  ,
  drop = FALSE
]

assert_true(
  identical(
    dim(signature_expr),
    c(24L, 579L)
  ),
  "The locked signature expression submatrix is not 24 x 579."
)

assert_true(
  sum(
    !is.finite(signature_expr)
  ) == 0L,
  "The locked signature expression submatrix contains non-finite values."
)

signature_sd <- apply(
  signature_expr,
  1L,
  stats::sd
)

assert_true(
  all(
    is.finite(signature_sd)
  ) &&
    all(
      signature_sd > 0
    ),
  "At least one locked signature gene has zero or invalid variance."
)

# ------------------------------
# 6. Audit constant rows in the full input matrix
# ------------------------------
full_gene_sd <- apply(
  expr_gene,
  1L,
  stats::sd
)

assert_true(
  all(
    is.finite(full_gene_sd)
  ),
  "At least one full-matrix gene has an invalid standard deviation."
)

constant_gene_ids <- names(
  full_gene_sd
)[
  full_gene_sd == 0
]

constant_gene_audit <- data.frame(
  gene_symbol = constant_gene_ids,
  standard_deviation = if (
    length(constant_gene_ids) == 0L
  ) {
    numeric(0)
  } else {
    unname(
      full_gene_sd[
        constant_gene_ids
      ]
    )
  },
  member_of_locked_signature =
    constant_gene_ids %in%
      locked_signature_genes,
  manually_removed_before_GSVA = rep(
    FALSE,
    length(constant_gene_ids)
  ),
  expected_GSVA_internal_action =
    rep(
      "GSVA_INTERNAL_CONSTANT_ROW_FILTER",
      length(constant_gene_ids)
    ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  !any(
    locked_signature_genes %in%
      constant_gene_ids
  ),
  "A locked signature gene is constant in the full expression matrix."
)

# ------------------------------
# 7. Lock and record the exact GSVA call
# ------------------------------
gene_set <- list(
  Triclosan_activity =
    locked_signature_genes
)

parameter_lock <- data.frame(
  field = c(
    "GSVA_package_version",
    "BiocParallel_package_available",
    "BiocParallel_package_version",
    "Expression_input_class",
    "Expression_input_dimensions",
    "Expression_input_scope",
    "Gene_set_name",
    "Gene_set_size_before_internal_filtering",
    "Gene_identifier_matching",
    "Parameter_constructor_call",
    "Score_execution_call",
    "Method",
    "kcdf_rule",
    "kcdfNoneMinSampleSize_default",
    "tau_default",
    "maxDiff_default",
    "absRanking_default",
    "Minimum_gene_set_size_default",
    "Maximum_gene_set_size_default",
    "Manual_constant_gene_prefilter",
    "Automatic_alias_substitution",
    "Expression_renormalization",
    "Outcome_information_used",
    "High_low_cutoff_selected"
  ),
  value = c(
    gsva_version,
    as.character(
      biocparallel_available
    ),
    ifelse(
      is.na(biocparallel_version),
      "",
      biocparallel_version
    ),
    paste(
      class(expr_gene),
      collapse = ";"
    ),
    paste(
      dim(expr_gene),
      collapse = " x "
    ),
    "Full 12650-gene x 579-sample matrix",
    "Triclosan_activity",
    length(
      locked_signature_genes
    ),
    "Exact HGNC-like symbol matching; matrix plus list input",
    "GSVA::gsvaParam(expr_gene, gene_set)",
    "GSVA::gsva(gsva_parameter)",
    "Classical GSVA",
    "auto",
    "200",
    "1",
    "TRUE",
    "FALSE",
    "1",
    "No finite maximum by default",
    "FALSE",
    "FALSE",
    "FALSE",
    "FALSE",
    "FALSE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 8. Calculate the prespecified GSVA score
# ------------------------------
set.seed(20260710L)

gsva_parameter <- GSVA::gsvaParam(
  expr_gene,
  gene_set
)

stage_parameter_details_file <- file.path(
  stage_log_dir,
  "Script10B_GSVA_parameter_details.txt"
)

parameter_details <- tryCatch(
  capture.output(
    GSVA::details(
      gsva_parameter
    )
  ),
  error = function(e) {
    c(
      paste0(
        "GSVA::details() was unavailable: ",
        conditionMessage(e)
      ),
      paste0(
        "GSVA package version: ",
        gsva_version
      ),
      "Constructor: GSVA::gsvaParam(expr_gene, gene_set)"
    )
  }
)

writeLines(
  enc2utf8(
    parameter_details
  ),
  con = stage_parameter_details_file,
  useBytes = TRUE
)

score_result <- GSVA::gsva(
  gsva_parameter
)

score_matrix <- as_score_matrix(
  score_result
)

assert_true(
  is.matrix(score_matrix) &&
    is.numeric(score_matrix),
  "GSVA did not return a numeric score matrix."
)

assert_true(
  identical(
    dim(score_matrix),
    c(1L, 579L)
  ),
  paste0(
    "Expected a 1 x 579 GSVA score matrix, detected ",
    paste(
      dim(score_matrix),
      collapse = " x "
    ),
    "."
  )
)

assert_true(
  identical(
    rownames(score_matrix),
    "Triclosan_activity"
  ),
  "The GSVA result does not contain the expected Triclosan_activity row."
)

assert_true(
  identical(
    colnames(score_matrix),
    colnames(expr_gene)
  ),
  "The GSVA score sample order differs from the expression matrix."
)

triclosan_score <- as.numeric(
  score_matrix[
    "Triclosan_activity",
    ,
    drop = TRUE
  ]
)

names(triclosan_score) <- colnames(
  score_matrix
)

assert_true(
  same_numeric_values(
    triclosan_score,
    score_matrix["Triclosan_activity", , drop = TRUE],
    tolerance = 0
  ),
  "The extracted Triclosan activity vector differs from the GSVA score row."
)

assert_true(
  identical(
    names(triclosan_score),
    colnames(score_matrix)
  ),
  "The extracted Triclosan activity vector has incorrect sample names."
)

assert_true(
  length(triclosan_score) == 579L,
  "The Triclosan activity score does not contain 579 values."
)

assert_true(
  sum(
    !is.finite(triclosan_score)
  ) == 0L,
  "The Triclosan activity score contains non-finite values."
)

assert_true(
  stats::sd(
    triclosan_score
  ) > 0,
  "The Triclosan activity score has zero variance."
)

assert_true(
  length(
    unique(
      triclosan_score
    )
  ) > 1L,
  "The Triclosan activity score has only one unique value."
)

# ------------------------------
# 9. Build aligned sample-level score table
# ------------------------------
required_technical_columns <- c(
  "sample_order",
  "sample_id",
  "source_dataset_id",
  "array_type",
  "source_sample_accession",
  "biopsy_method_code_raw"
)

missing_technical_columns <- setdiff(
  required_technical_columns,
  colnames(clinical)
)

assert_true(
  length(
    missing_technical_columns
  ) == 0L,
  paste0(
    "The curated clinical table is missing required technical fields: ",
    paste(
      missing_technical_columns,
      collapse = ", "
    )
  )
)

score_table <- data.frame(
  sample_order = as.integer(
    clinical$sample_order
  ),
  sample_id = as.character(
    clinical$sample_id
  ),
  source_dataset_id = as.character(
    clinical$source_dataset_id
  ),
  array_type = as.character(
    clinical$array_type
  ),
  source_sample_accession = as.character(
    clinical$source_sample_accession
  ),
  biopsy_method_code_raw = as.character(
    clinical$biopsy_method_code_raw
  ),
  Triclosan_activity = triclosan_score,
  score_method = "Classical_GSVA",
  signature_gene_number = 24L,
  outcome_information_used = FALSE,
  high_low_group_created = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  identical(
    score_table$sample_id,
    colnames(expr_gene)
  ),
  "The score table is not aligned with expression samples."
)

assert_true(
  anyDuplicated(
    score_table$sample_id
  ) == 0L,
  "The score table contains duplicated sample IDs."
)

assert_true(
  same_numeric_values(
    score_table$Triclosan_activity,
    triclosan_score,
    tolerance = 0
  ),
  paste0(
    "The score table values differ numerically from the GSVA result. ",
    "Sample-name attributes are checked separately and are not part of this ",
    "numeric comparison."
  )
)

# ------------------------------
# 10. Descriptive score audits
# ------------------------------
overall_score_summary <-
  summarize_numeric_vector(
    triclosan_score
  )

overall_score_summary <- data.frame(
  score_name = "Triclosan_activity",
  method = "Classical_GSVA",
  overall_score_summary,
  outcome_information_used = FALSE,
  high_low_cutoff_selected = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

score_by_array_type <- summarize_by_group(
  score_table,
  "array_type"
)

score_by_source_dataset <- summarize_by_group(
  score_table,
  "source_dataset_id"
)

score_by_biopsy_method <- summarize_by_group(
  score_table,
  "biopsy_method_code_raw"
)

# No inferential test is performed here. These are descriptive technical audits.
technical_group_audit <- rbind(
  score_by_array_type,
  score_by_source_dataset,
  score_by_biopsy_method
)

rownames(
  technical_group_audit
) <- NULL

# ------------------------------
# 11. Build integrity summary
# ------------------------------
score_range <- range(
  triclosan_score
)

summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Source_Script09B_bundle_MD5",
    "Source_Script10A_bundle_MD5",
    "GSVA_package_version",
    "Gene_level_rows_supplied_to_GSVA",
    "Expression_samples_supplied_to_GSVA",
    "Locked_signature_gene_number",
    "Exact_signature_genes_used",
    "Full_matrix_constant_gene_number",
    "Constant_signature_gene_number",
    "Score_name",
    "Score_method",
    "GSVA_result_rows",
    "GSVA_result_samples",
    "Finite_score_number",
    "Nonfinite_score_number",
    "Unique_score_number",
    "Score_minimum",
    "Score_median",
    "Score_mean",
    "Score_maximum",
    "Score_standard_deviation",
    "Score_sample_order_identical_to_expression",
    "Expression_values_modified",
    "Expression_values_normalized_again",
    "Automatic_alias_substitution_performed",
    "Alternative_score_calculated",
    "Outcome_information_used",
    "High_low_group_created",
    "High_low_cutoff_selected",
    "Survival_model_fitted",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "10B",
    observed_clinical_md5,
    observed_coverage_md5,
    gsva_version,
    nrow(expr_gene),
    ncol(expr_gene),
    length(
      locked_signature_genes
    ),
    length(
      locked_signature_genes
    ),
    length(
      constant_gene_ids
    ),
    sum(
      locked_signature_genes %in%
        constant_gene_ids
    ),
    "Triclosan_activity",
    "Classical_GSVA",
    nrow(score_matrix),
    ncol(score_matrix),
    sum(
      is.finite(
        triclosan_score
      )
    ),
    sum(
      !is.finite(
        triclosan_score
      )
    ),
    length(
      unique(
        triclosan_score
      )
    ),
    score_range[1],
    stats::median(
      triclosan_score
    ),
    mean(
      triclosan_score
    ),
    score_range[2],
    stats::sd(
      triclosan_score
    ),
    identical(
      names(triclosan_score),
      colnames(expr_gene)
    ),
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 12. Save all outputs in staging
# ------------------------------
input_manifest <- make_manifest(
  required_inputs
)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script10B",
  created_at = format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  ),
  source_accession = "GSE31519",
  source_script09b_bundle_file =
    normalize_existing_path(
      clinical_bundle_file
    ),
  source_script09b_bundle_md5 =
    observed_clinical_md5,
  source_script10a_bundle_file =
    normalize_existing_path(
      coverage_bundle_file
    ),
  source_script10a_bundle_md5 =
    observed_coverage_md5,
  source_expression_dimensions =
    dim(expr_gene),
  source_sample_ids =
    colnames(expr_gene),
  signature_definition =
    signature_definition,
  signature_coverage_audit =
    coverage_audit,
  locked_signature_genes =
    locked_signature_genes,
  GSVA_package_version =
    gsva_version,
  GSVA_parameter_object =
    gsva_parameter,
  GSVA_parameter_details =
    parameter_details,
  GSVA_score_matrix =
    score_matrix,
  Triclosan_activity =
    triclosan_score,
  score_table =
    score_table,
  overall_score_summary =
    overall_score_summary,
  technical_group_audit =
    technical_group_audit,
  constant_gene_audit =
    constant_gene_audit,
  parameter_lock =
    parameter_lock,
  integrity_summary =
    summary_table,
  policy = list(
    score_name =
      "Triclosan_activity",
    score_method =
      "Classical GSVA",
    constructor_call =
      "GSVA::gsvaParam(expr_gene, gene_set)",
    execution_call =
      "GSVA::gsva(gsva_parameter)",
    full_expression_matrix_used =
      TRUE,
    exact_signature_gene_number =
      24L,
    automatic_alias_substitution =
      FALSE,
    expression_values_modified =
      FALSE,
    expression_values_normalized_again =
      FALSE,
    alternative_score_calculated =
      FALSE,
    outcome_information_used =
      FALSE,
    high_low_group_created =
      FALSE,
    high_low_cutoff_selected =
      FALSE,
    survival_model_fitted =
      FALSE,
    interpretation = paste0(
      "Higher values represent greater relative enrichment of the locked ",
      "24-gene set within this expression cohort. The score is not a direct ",
      "measurement of individual triclosan exposure."
    )
  ),
  provenance = list(
    accepted_script09b_bundle_md5 =
      accepted_script09b_bundle_md5,
    accepted_script10a_bundle_md5 =
      accepted_script10a_bundle_md5,
    previous_project_workflow =
      "gsvaParam(expr, gene_set) followed by gsva(param)",
    next_step_requires_review_of_score_and_technical_distributions =
      TRUE
  )
)

class(complete_bundle) <- c(
  "GSE31519_Triclosan_GSVA_score_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_Triclosan_GSVA_score_COMPLETE_bundle.rds"
)
stage_score_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_GSVA_score_all579.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_GSVA_score_summary.csv"
)
stage_technical_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_GSVA_score_technical_group_audit.csv"
)
stage_constant_file <- file.path(
  stage_audit_dir,
  "GSE31519_GSVA_constant_gene_audit.csv"
)
stage_parameter_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_GSVA_parameter_lock.csv"
)
stage_signature_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_GSVA_signature_used.csv"
)
stage_integrity_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_GSVA_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script10B_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script10B_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script10B_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script10B_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)

write_csv_utf8(
  score_table,
  stage_score_file
)
write_csv_utf8(
  overall_score_summary,
  stage_summary_file
)
write_csv_utf8(
  technical_group_audit,
  stage_technical_file
)
write_csv_utf8(
  constant_gene_audit,
  stage_constant_file
)
write_csv_utf8(
  parameter_lock,
  stage_parameter_file
)
write_csv_utf8(
  signature_definition,
  stage_signature_file
)
write_csv_utf8(
  summary_table,
  stage_integrity_file
)
write_csv_utf8(
  input_manifest,
  stage_input_manifest_file
)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# Independently read back the staged core object.
bundle_check <- readRDS(
  stage_bundle_file
)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "locked_signature_genes",
      "GSVA_score_matrix",
      "Triclosan_activity",
      "score_table",
      "overall_score_summary",
      "technical_group_audit",
      "constant_gene_audit",
      "parameter_lock",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "The staged Script 10B bundle cannot be read back with required fields."
)

assert_true(
  identical(
    as.character(
      bundle_check$locked_signature_genes
    ),
    locked_signature_genes
  ),
  "The locked signature changed while saving the Script 10B bundle."
)

assert_true(
  same_numeric_values(
    bundle_check$Triclosan_activity,
    triclosan_score,
    tolerance = 0
  ),
  paste0(
    "The score changed numerically while saving the Script 10B bundle. ",
    "Vector-name attributes are checked in the following independent assertion."
  )
)

assert_true(
  identical(
    names(
      bundle_check$Triclosan_activity
    ),
    colnames(expr_gene)
  ),
  "The saved score names do not match expression sample order."
)

assert_true(
  identical(
    as.character(
      bundle_check$score_table$sample_id
    ),
    colnames(expr_gene)
  ),
  "The saved score table is not aligned with expression sample order."
)

assert_true(
  isFALSE(
    bundle_check$policy$outcome_information_used
  ) &&
    isFALSE(
      bundle_check$policy$high_low_group_created
    ) &&
    isFALSE(
      bundle_check$policy$survival_model_fitted
    ),
  "The staged bundle incorrectly indicates an outcome analysis."
)

bundle_md5 <- md5_one(
  stage_bundle_file
)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 10B",
  "GSE31519 continuous Triclosan_activity GSVA score",
  "============================================================",
  paste0(
    "Completion time: ",
    format(
      Sys.time(),
      "%Y-%m-%d %H:%M:%S %Z"
    )
  ),
  paste0(
    "Source Script 09B bundle MD5: ",
    observed_clinical_md5
  ),
  paste0(
    "Source Script 10A bundle MD5: ",
    observed_coverage_md5
  ),
  paste0(
    "GSVA package version: ",
    gsva_version
  ),
  paste0(
    "Expression matrix supplied to GSVA: ",
    nrow(expr_gene),
    " genes x ",
    ncol(expr_gene),
    " samples"
  ),
  paste0(
    "Locked exact signature genes supplied: ",
    length(locked_signature_genes)
  ),
  paste0(
    "Constant full-matrix genes detected before GSVA: ",
    length(constant_gene_ids)
  ),
  "Manual constant-gene prefilter performed: FALSE",
  "Parameter constructor: GSVA::gsvaParam(expr_gene, gene_set)",
  "Score execution: GSVA::gsva(gsva_parameter)",
  paste0(
    "GSVA result dimensions: ",
    nrow(score_matrix),
    " x ",
    ncol(score_matrix)
  ),
  paste0(
    "Finite scores: ",
    sum(
      is.finite(
        triclosan_score
      )
    ),
    " / ",
    length(triclosan_score)
  ),
  paste0(
    "Unique score values: ",
    length(
      unique(
        triclosan_score
      )
    )
  ),
  paste0(
    "Score minimum: ",
    format(
      min(triclosan_score),
      digits = 12
    )
  ),
  paste0(
    "Score median: ",
    format(
      stats::median(
        triclosan_score
      ),
      digits = 12
    )
  ),
  paste0(
    "Score mean: ",
    format(
      mean(
        triclosan_score
      ),
      digits = 12
    )
  ),
  paste0(
    "Score maximum: ",
    format(
      max(triclosan_score),
      digits = 12
    )
  ),
  paste0(
    "Score standard deviation: ",
    format(
      stats::sd(
        triclosan_score
      ),
      digits = 12
    )
  ),
  paste0(
    "Score/expression sample order identical: ",
    identical(
      names(triclosan_score),
      colnames(expr_gene)
    )
  ),
  "Expression values modified: FALSE",
  "Expression values normalized again: FALSE",
  "Automatic alias substitution performed: FALSE",
  "Alternative score calculated: FALSE",
  "Outcome information used: FALSE",
  "High/low group created: FALSE",
  "High/low cutoff selected: FALSE",
  "Survival model fitted: FALSE",
  paste0(
    "GSVA score bundle MD5: ",
    bundle_md5
  ),
  "",
  "SCRIPT10B STATUS: COMPLETE",
  paste0(
    "A continuous unsupervised GSVA score was calculated for all 579 samples. ",
    "No outcome-guided operation was performed."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(
    report_lines
  ),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_score_file,
  stage_summary_file,
  stage_technical_file,
  stage_constant_file,
  stage_parameter_file,
  stage_signature_file,
  stage_integrity_file,
  stage_input_manifest_file,
  stage_parameter_details_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(
    file.exists(
      output_files_before_manifest
    )
  ),
  "At least one required staged Script 10B output file is missing."
)

assert_true(
  all(
    file.info(
      output_files_before_manifest
    )$size > 0
  ),
  "At least one required staged Script 10B output file is empty."
)

output_manifest <- make_manifest(
  output_files_before_manifest
)

write_csv_utf8(
  output_manifest,
  stage_output_manifest_file
)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) ==
    length(output_files_before_manifest),
  "The Script 10B output manifest has the wrong number of rows."
)

for (i in seq_along(
  output_files_before_manifest
)) {
  file_i <- output_files_before_manifest[i]

  manifest_row <- manifest_check[
    manifest_check$file_name ==
      basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(manifest_row) == 1L,
    paste0(
      "Output manifest row missing or duplicated for: ",
      basename(file_i)
    )
  )

  assert_true(
    identical(
      tolower(
        as.character(
          manifest_row$md5
        )
      ),
      tolower(
        md5_one(file_i)
      )
    ),
    paste0(
      "Output manifest MD5 mismatch for: ",
      basename(file_i)
    )
  )

  assert_true(
    as.numeric(
      manifest_row$size_bytes
    ) ==
      as.numeric(
        file.info(file_i)$size
      ),
    paste0(
      "Output manifest size mismatch for: ",
      basename(file_i)
    )
  )
}

# ------------------------------
# 13. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "The final Script 10B output directory appeared during staging."
)

rename_ok <- file.rename(
  stage_root,
  final_root
)

if (!isTRUE(rename_ok)) {
  dir.create(
    final_root,
    recursive = TRUE,
    showWarnings = FALSE
  )

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit the Script 10B staging directory to the final location."
  )

  unlink(
    stage_root,
    recursive = TRUE,
    force = TRUE
  )
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_Triclosan_GSVA_score_COMPLETE_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script10B_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script10B_output_manifest_with_MD5.csv"
)

assert_true(
  all(
    file.exists(c(
      final_bundle_file,
      final_report_file,
      final_manifest_file
    ))
  ),
  "The committed Script 10B output is incomplete."
)

assert_true(
  identical(
    md5_one(final_bundle_file),
    bundle_md5
  ),
  "The committed Script 10B bundle MD5 changed after commit."
)

assert_true(
  report_contains(
    final_report_file,
    "SCRIPT10B STATUS: COMPLETE"
  ),
  "The committed Script 10B report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 10B v3 completed successfully.\n")
cat(
  "GSVA package version: ",
  gsva_version,
  "\n",
  sep = ""
)
cat(
  "Expression matrix supplied: ",
  nrow(expr_gene),
  " x ",
  ncol(expr_gene),
  "\n",
  sep = ""
)
cat(
  "Locked signature genes used: ",
  length(locked_signature_genes),
  "\n",
  sep = ""
)
cat(
  "Continuous Triclosan_activity scores: ",
  length(triclosan_score),
  "\n",
  sep = ""
)
cat(
  "Finite scores: ",
  sum(
    is.finite(
      triclosan_score
    )
  ),
  "\n",
  sep = ""
)
cat(
  "Score range: ",
  format(
    min(triclosan_score),
    digits = 8
  ),
  " to ",
  format(
    max(triclosan_score),
    digits = 8
  ),
  "\n",
  sep = ""
)
cat("Outcome information used: FALSE\n")
cat("High/low group created: FALSE\n")
cat("Survival model fitted: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat(
  "Bundle MD5: ",
  md5_one(
    final_bundle_file
  ),
  "\n",
  sep = ""
)
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

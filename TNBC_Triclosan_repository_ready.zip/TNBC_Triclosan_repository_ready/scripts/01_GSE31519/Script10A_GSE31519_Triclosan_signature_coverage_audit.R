# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 10A
#
# Purpose:
#   Continue strictly from the accepted Script 09B curated clinical endpoint
#   bundle. Lock the pre-existing 24-gene Triclosan activity signature and audit
#   its exact coverage and expression properties in the GSE31519 gene-level
#   matrix before any score is calculated.
#
# Prespecified signature source:
#   The project previously used the following 24-gene intersection set as one
#   unweighted gene set named "Triclosan_activity":
#     ESR1, AR, PGR, THRA, THRB, CAT, BCL2, BAX, PARP1, IL6, ABCB1, ABCG2,
#     FASN, SCD, TWIST1, PPARG, EGFR, MMP9, JUN, FOS, ADRB2, ERG, H2AX, MITF.
#
#   The prior score implementation used a single-set classical GSVA workflow.
#   Script 10A records that rule but DOES NOT calculate the score.
#
# This script DOES:
#   - verify the accepted Script 09B bundle by report, manifest and fixed MD5;
#   - verify the 12,650 x 579 expression matrix and clinical alignment;
#   - lock the ordered 24-gene signature and six-gene hub subset;
#   - audit exact gene-symbol coverage without automatic alias substitution;
#   - audit finite values, variability and expression distributions;
#   - save a complete correlation audit for available signature genes;
#   - save RDS, CSV audit tables, MD5 manifests, report and sessionInfo.
#
# This script DOES NOT:
#   - rerun Scripts 07A-09B;
#   - alter or normalize expression values;
#   - replace gene symbols automatically;
#   - calculate GSVA, ssGSEA, z-score or any other activity score;
#   - select a high/low cutoff;
#   - use survival outcomes;
#   - fit a survival model or produce a figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(project_root, "Step2_GSE31519_external_validation")

input_root <- file.path(step_root, "06_curated_clinical_endpoint")
final_root <- file.path(step_root, "07_signature_coverage_audit")

input_bundle_file <- file.path(
  input_root,
  "objects",
  "GSE31519_curated_clinical_endpoint_COMPLETE_bundle.rds"
)
input_manifest_file <- file.path(
  input_root,
  "audit",
  "Script09B_output_manifest_with_MD5.csv"
)
input_report_file <- file.path(
  input_root,
  "logs",
  "Script09B_COMPLETE_report.txt"
)
input_summary_file <- file.path(
  input_root,
  "audit",
  "GSE31519_curated_clinical_endpoint_integrity_summary.csv"
)

required_inputs <- c(
  input_bundle_file,
  input_manifest_file,
  input_report_file,
  input_summary_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]
if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 10A cannot start because required Script 09B files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist: ", step_root, call. = FALSE)
}

# Never overwrite a completed or partially populated output directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty, so Script 10A ",
        "will not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script10A_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop("Unable to create Script 10A staging directories.", call. = FALSE)
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

md5_one <- function(path) {
  unname(tools::md5sum(path))
}

normalize_existing_path <- function(path) {
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(
    report_file,
    warn = FALSE,
    encoding = "UTF-8"
  )
  any(grepl(fixed_text, lines, fixed = TRUE))
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))

  info <- file.info(paths)

  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(path) {
        normalizePath(
          path,
          winslash = "/",
          mustWork = FALSE
        )
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  required_columns <- c("file_name", "size_bytes", "md5")

  assert_true(
    all(required_columns %in% colnames(manifest)),
    paste0("Malformed output manifest: ", manifest_file)
  )

  rows <- which(manifest$file_name == basename(target_file))

  assert_true(
    length(rows) == 1L,
    paste0(
      "The manifest must contain exactly one row for ",
      basename(target_file),
      ": ",
      manifest_file
    )
  )

  tolower(trimws(as.character(manifest$md5[rows])))
}

safe_quantile <- function(x, probability) {
  as.numeric(
    stats::quantile(
      x,
      probs = probability,
      na.rm = TRUE,
      names = FALSE,
      type = 7
    )
  )
}

make_long_correlation <- function(correlation_matrix) {
  if (length(correlation_matrix) == 0L) {
    return(data.frame(
      gene_1 = character(0),
      gene_2 = character(0),
      pearson_correlation = numeric(0),
      absolute_correlation = numeric(0),
      diagonal = logical(0),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ))
  }

  index <- expand.grid(
    gene_1 = rownames(correlation_matrix),
    gene_2 = colnames(correlation_matrix),
    stringsAsFactors = FALSE
  )

  index$pearson_correlation <- as.numeric(correlation_matrix)
  index$absolute_correlation <- abs(index$pearson_correlation)
  index$diagonal <- index$gene_1 == index$gene_2

  index
}

# ------------------------------
# 2. Verify accepted Script 09B identity
# ------------------------------
assert_true(
  report_contains(
    input_report_file,
    "SCRIPT09B STATUS: COMPLETE"
  ),
  "Script 09B completion status was not found in its report."
)

expected_bundle_md5 <- manifest_expected_md5(
  input_manifest_file,
  input_bundle_file
)
observed_bundle_md5 <- tolower(md5_one(input_bundle_file))

assert_true(
  identical(expected_bundle_md5, observed_bundle_md5),
  paste0(
    "Script 09B bundle MD5 mismatch.\n",
    "Expected from manifest: ",
    expected_bundle_md5,
    "\nObserved: ",
    observed_bundle_md5
  )
)

# This checksum was independently verified when Script 09B was accepted.
accepted_script09b_bundle_md5 <- "02606ffd117178bcd20571ab34740104"

assert_true(
  identical(
    observed_bundle_md5,
    accepted_script09b_bundle_md5
  ),
  paste0(
    "The Script 09B bundle does not match the independently accepted bundle.\n",
    "Expected: ",
    accepted_script09b_bundle_md5,
    "\nObserved: ",
    observed_bundle_md5
  )
)

input_summary <- read.csv(
  input_summary_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(c("item", "value") %in% colnames(input_summary)),
  "The Script 09B integrity summary is malformed."
)
assert_true(
  anyDuplicated(input_summary$item) == 0L,
  "The Script 09B integrity summary contains duplicated item names."
)

summary_lookup <- setNames(
  as.character(input_summary$value),
  input_summary$item
)

required_summary_items <- c(
  "Gene_level_rows_verified",
  "Total_samples_preserved",
  "Expression_phenotype_order_identical",
  "Complete_endpoint_records",
  "Positive_time_sensitivity_records",
  "Completion_status"
)

assert_true(
  all(required_summary_items %in% names(summary_lookup)),
  "The Script 09B integrity summary is missing required items."
)
assert_true(
  identical(summary_lookup[["Completion_status"]], "COMPLETE"),
  "The Script 09B integrity summary is not marked COMPLETE."
)

# ------------------------------
# 3. Read and independently validate the Script 09B bundle
# ------------------------------
source_bundle <- readRDS(input_bundle_file)

required_bundle_fields <- c(
  "project",
  "step",
  "script",
  "source_accession",
  "source_gene_bundle_md5",
  "source_clinical_audit_bundle_md5",
  "expression_matrix",
  "source_phenotype",
  "curated_clinical",
  "integrity_summary",
  "endpoint_policy",
  "provenance"
)

assert_true(
  is.list(source_bundle) &&
    all(required_bundle_fields %in% names(source_bundle)),
  "The Script 09B bundle is missing required fields."
)
assert_true(
  identical(as.character(source_bundle$script), "Script09B"),
  "The input bundle was not created by Script 09B."
)
assert_true(
  identical(as.character(source_bundle$source_accession), "GSE31519"),
  "The input bundle is not for GSE31519."
)

expr_gene <- source_bundle$expression_matrix
clinical <- source_bundle$curated_clinical

assert_true(
  is.matrix(expr_gene) &&
    is.numeric(expr_gene),
  "The gene-level expression object is not a numeric matrix."
)
assert_true(
  identical(dim(expr_gene), c(12650L, 579L)),
  paste0(
    "Expected a 12,650 x 579 gene-level matrix, but detected ",
    paste(dim(expr_gene), collapse = " x "),
    "."
  )
)
assert_true(
  sum(!is.finite(expr_gene)) == 0L,
  "The gene-level expression matrix contains non-finite values."
)
assert_true(
  !is.null(rownames(expr_gene)) &&
    length(rownames(expr_gene)) == nrow(expr_gene) &&
    anyDuplicated(rownames(expr_gene)) == 0L &&
    all(nzchar(rownames(expr_gene))),
  "Gene symbols are blank, missing or duplicated."
)
assert_true(
  !is.null(colnames(expr_gene)) &&
    length(colnames(expr_gene)) == ncol(expr_gene) &&
    anyDuplicated(colnames(expr_gene)) == 0L,
  "Expression sample IDs are missing or duplicated."
)
assert_true(
  is.data.frame(clinical) &&
    nrow(clinical) == 579L &&
    "sample_id" %in% colnames(clinical),
  "The curated clinical table is missing or malformed."
)
assert_true(
  identical(
    colnames(expr_gene),
    as.character(clinical$sample_id)
  ),
  "Expression columns and curated clinical rows are not identically ordered."
)

# ------------------------------
# 4. Lock the prespecified signature definitions
# ------------------------------
triclosan_signature_24 <- c(
  "ESR1",
  "AR",
  "PGR",
  "THRA",
  "THRB",
  "CAT",
  "BCL2",
  "BAX",
  "PARP1",
  "IL6",
  "ABCB1",
  "ABCG2",
  "FASN",
  "SCD",
  "TWIST1",
  "PPARG",
  "EGFR",
  "MMP9",
  "JUN",
  "FOS",
  "ADRB2",
  "ERG",
  "H2AX",
  "MITF"
)

hub_gene_subset_6 <- c(
  "AR",
  "THRB",
  "PGR",
  "PARP1",
  "ABCB1",
  "ADRB2"
)

assert_true(
  length(triclosan_signature_24) == 24L &&
    anyDuplicated(triclosan_signature_24) == 0L,
  "The locked Triclosan signature is not 24 unique genes."
)
assert_true(
  length(hub_gene_subset_6) == 6L &&
    anyDuplicated(hub_gene_subset_6) == 0L,
  "The locked hub subset is not six unique genes."
)
assert_true(
  all(hub_gene_subset_6 %in% triclosan_signature_24),
  "At least one hub gene is absent from the locked 24-gene signature."
)

signature_definition <- data.frame(
  signature_order = seq_along(triclosan_signature_24),
  gene_symbol = triclosan_signature_24,
  signature_name = "Triclosan_activity",
  membership_type = ifelse(
    triclosan_signature_24 %in% hub_gene_subset_6,
    "HUB_SUBSET_AND_24_GENE_SIGNATURE",
    "24_GENE_SIGNATURE_ONLY"
  ),
  prespecified_gene_weight = 1,
  prespecified_gene_direction = "UNSIGNED_SINGLE_GENE_SET",
  source_gene_symbol_modified = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

scoring_rule_lock <- data.frame(
  field = c(
    "Signature_name",
    "Signature_gene_number",
    "Signature_type",
    "Gene_weights",
    "Gene_direction",
    "Previous_project_method",
    "Primary_external_method_to_be_evaluated_after_10A",
    "Automatic_alias_substitution",
    "Outcome_guided_gene_selection",
    "Outcome_guided_parameter_selection",
    "High_low_cutoff_selected",
    "Score_calculated_in_Script10A"
  ),
  value = c(
    "Triclosan_activity",
    "24",
    "Single unweighted gene set",
    "All genes weight 1",
    "Unsigned; no up/down split in the previous project score",
    "Classical single-set GSVA using the locked 24 genes",
    paste0(
      "Use the same classical single-set GSVA rule only after coverage ",
      "and expression audits are accepted"
    ),
    "FALSE",
    "FALSE",
    "FALSE",
    "FALSE",
    "FALSE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 5. Audit exact symbol coverage
# ------------------------------
available_symbols <- rownames(expr_gene)

coverage_rows <- vector(
  "list",
  length(triclosan_signature_24)
)

# Audit-only legacy/alternative symbols. No replacement is performed.
alias_candidates <- list(
  H2AX = c("H2AFX")
)

for (i in seq_along(triclosan_signature_24)) {
  gene <- triclosan_signature_24[i]
  exact_present <- gene %in% available_symbols

  alternative_symbols <- alias_candidates[[gene]]

  if (is.null(alternative_symbols)) {
    alternative_symbols <- character(0)
  }

  alternative_present <- alternative_symbols[
    alternative_symbols %in% available_symbols
  ]

  coverage_rows[[i]] <- data.frame(
    signature_order = i,
    requested_gene_symbol = gene,
    exact_symbol_present = exact_present,
    exact_matrix_row = if (exact_present) gene else NA_character_,
    alternative_symbol_candidates = if (
      length(alternative_symbols) == 0L
    ) {
      ""
    } else {
      paste(alternative_symbols, collapse = ";")
    },
    alternative_symbols_present = if (
      length(alternative_present) == 0L
    ) {
      ""
    } else {
      paste(alternative_present, collapse = ";")
    },
    automatic_alias_substitution_performed = FALSE,
    included_in_future_exact_match_score = exact_present,
    membership_type = signature_definition$membership_type[i],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

signature_coverage_audit <- do.call(
  rbind,
  coverage_rows
)
rownames(signature_coverage_audit) <- NULL

present_signature_genes <- signature_coverage_audit$
  requested_gene_symbol[
    signature_coverage_audit$exact_symbol_present
  ]
missing_signature_genes <- signature_coverage_audit$
  requested_gene_symbol[
    !signature_coverage_audit$exact_symbol_present
  ]

present_hub_genes <- hub_gene_subset_6[
  hub_gene_subset_6 %in% available_symbols
]
missing_hub_genes <- hub_gene_subset_6[
  !hub_gene_subset_6 %in% available_symbols
]

# ------------------------------
# 6. Audit expression properties for available signature genes
# ------------------------------
if (length(present_signature_genes) > 0L) {
  signature_expression <- expr_gene[
    present_signature_genes,
    ,
    drop = FALSE
  ]

  expression_rows <- vector(
    "list",
    nrow(signature_expression)
  )

  for (i in seq_len(nrow(signature_expression))) {
    gene <- rownames(signature_expression)[i]
    values <- as.numeric(signature_expression[i, ])

    expression_rows[[i]] <- data.frame(
      signature_order = match(gene, triclosan_signature_24),
      gene_symbol = gene,
      sample_number = length(values),
      finite_value_number = sum(is.finite(values)),
      nonfinite_value_number = sum(!is.finite(values)),
      minimum = min(values),
      first_quartile = safe_quantile(values, 0.25),
      median = stats::median(values),
      mean = mean(values),
      third_quartile = safe_quantile(values, 0.75),
      maximum = max(values),
      standard_deviation = stats::sd(values),
      interquartile_range = stats::IQR(values),
      unique_value_number = length(unique(values)),
      zero_variance = isTRUE(all.equal(stats::sd(values), 0)),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  signature_expression_audit <- do.call(
    rbind,
    expression_rows
  )
  rownames(signature_expression_audit) <- NULL

  signature_correlation_matrix <- stats::cor(
    t(signature_expression),
    method = "pearson",
    use = "everything"
  )

  signature_correlation_long <- make_long_correlation(
    signature_correlation_matrix
  )
} else {
  signature_expression <- matrix(
    numeric(0),
    nrow = 0L,
    ncol = ncol(expr_gene),
    dimnames = list(
      character(0),
      colnames(expr_gene)
    )
  )

  signature_expression_audit <- data.frame(
    signature_order = integer(0),
    gene_symbol = character(0),
    sample_number = integer(0),
    finite_value_number = integer(0),
    nonfinite_value_number = integer(0),
    minimum = numeric(0),
    first_quartile = numeric(0),
    median = numeric(0),
    mean = numeric(0),
    third_quartile = numeric(0),
    maximum = numeric(0),
    standard_deviation = numeric(0),
    interquartile_range = numeric(0),
    unique_value_number = integer(0),
    zero_variance = logical(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  signature_correlation_matrix <- matrix(
    numeric(0),
    nrow = 0L,
    ncol = 0L
  )

  signature_correlation_long <- make_long_correlation(
    signature_correlation_matrix
  )
}

assert_true(
  nrow(signature_expression_audit) ==
    length(present_signature_genes),
  "The signature expression audit has an incorrect row count."
)

if (nrow(signature_expression_audit) > 0L) {
  assert_true(
    all(signature_expression_audit$nonfinite_value_number == 0L),
    "At least one available signature gene contains non-finite values."
  )
}

# Record, but do not automatically remove, zero-variance genes.
zero_variance_genes <- signature_expression_audit$gene_symbol[
  signature_expression_audit$zero_variance
]

# ------------------------------
# 7. Sample-level signature completeness audit
# ------------------------------
if (nrow(signature_expression) > 0L) {
  finite_matrix <- is.finite(signature_expression)

  sample_signature_completeness <- data.frame(
    sample_order = seq_len(ncol(signature_expression)),
    sample_id = colnames(signature_expression),
    available_signature_gene_number = nrow(signature_expression),
    finite_signature_value_number = colSums(finite_matrix),
    nonfinite_signature_value_number = colSums(!finite_matrix),
    complete_for_all_available_signature_genes =
      colSums(!finite_matrix) == 0L,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
} else {
  sample_signature_completeness <- data.frame(
    sample_order = seq_len(ncol(expr_gene)),
    sample_id = colnames(expr_gene),
    available_signature_gene_number = 0L,
    finite_signature_value_number = 0L,
    nonfinite_signature_value_number = 0L,
    complete_for_all_available_signature_genes = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

assert_true(
  identical(
    sample_signature_completeness$sample_id,
    colnames(expr_gene)
  ),
  "The sample-level signature audit is not aligned with expression samples."
)

# ------------------------------
# 8. Build audit summary
# ------------------------------
coverage_fraction <- length(present_signature_genes) /
  length(triclosan_signature_24)

hub_coverage_fraction <- length(present_hub_genes) /
  length(hub_gene_subset_6)

summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Source_Script09B_bundle_MD5",
    "Gene_level_rows_verified",
    "Expression_samples_verified",
    "Expression_clinical_order_identical",
    "Locked_signature_name",
    "Locked_signature_gene_number",
    "Exact_signature_genes_present",
    "Exact_signature_genes_missing",
    "Exact_signature_coverage_fraction",
    "Missing_signature_gene_symbols",
    "Locked_hub_subset_gene_number",
    "Exact_hub_genes_present",
    "Exact_hub_genes_missing",
    "Exact_hub_coverage_fraction",
    "Missing_hub_gene_symbols",
    "Available_signature_genes_with_nonfinite_values",
    "Available_signature_genes_with_zero_variance",
    "Zero_variance_signature_gene_symbols",
    "Samples_complete_for_all_available_signature_genes",
    "Automatic_alias_substitution_performed",
    "Expression_values_modified",
    "Expression_values_normalized_again",
    "Triclosan_score_calculated",
    "Survival_outcomes_used",
    "High_low_cutoff_selected",
    "Survival_model_fitted",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "10A",
    observed_bundle_md5,
    nrow(expr_gene),
    ncol(expr_gene),
    identical(
      colnames(expr_gene),
      as.character(clinical$sample_id)
    ),
    "Triclosan_activity",
    length(triclosan_signature_24),
    length(present_signature_genes),
    length(missing_signature_genes),
    coverage_fraction,
    if (length(missing_signature_genes) == 0L) {
      ""
    } else {
      paste(missing_signature_genes, collapse = ";")
    },
    length(hub_gene_subset_6),
    length(present_hub_genes),
    length(missing_hub_genes),
    hub_coverage_fraction,
    if (length(missing_hub_genes) == 0L) {
      ""
    } else {
      paste(missing_hub_genes, collapse = ";")
    },
    if (nrow(signature_expression_audit) == 0L) {
      0L
    } else {
      sum(
        signature_expression_audit$nonfinite_value_number > 0L
      )
    },
    length(zero_variance_genes),
    if (length(zero_variance_genes) == 0L) {
      ""
    } else {
      paste(zero_variance_genes, collapse = ";")
    },
    sum(
      sample_signature_completeness$
        complete_for_all_available_signature_genes
    ),
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 9. Save all outputs in staging
# ------------------------------
input_manifest <- make_manifest(required_inputs)

audit_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script10A",
  created_at = format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S %Z"
  ),
  source_accession = "GSE31519",
  source_script09b_bundle_file =
    normalize_existing_path(input_bundle_file),
  source_script09b_bundle_md5 = observed_bundle_md5,
  source_expression_dimensions = dim(expr_gene),
  source_sample_ids = colnames(expr_gene),
  signature_definition = signature_definition,
  hub_gene_subset = hub_gene_subset_6,
  scoring_rule_lock = scoring_rule_lock,
  signature_coverage_audit = signature_coverage_audit,
  signature_expression_audit = signature_expression_audit,
  signature_correlation_matrix = signature_correlation_matrix,
  signature_correlation_long = signature_correlation_long,
  sample_signature_completeness =
    sample_signature_completeness,
  integrity_summary = summary_table,
  policy = list(
    signature_name = "Triclosan_activity",
    locked_signature_genes = triclosan_signature_24,
    locked_hub_subset = hub_gene_subset_6,
    exact_symbol_matching_only = TRUE,
    automatic_alias_substitution = FALSE,
    previous_project_score_method =
      "Classical single-set GSVA",
    gene_specific_weights = FALSE,
    gene_specific_directions = FALSE,
    score_calculated = FALSE,
    high_low_cutoff_selected = FALSE,
    survival_outcomes_used = FALSE,
    survival_model_fitted = FALSE,
    expression_values_modified = FALSE
  ),
  provenance = list(
    accepted_script09b_bundle_md5 =
      accepted_script09b_bundle_md5,
    signature_origin =
      "Previously used TNBC_Triclosan 24-gene intersection set",
    previous_score_object_name =
      "Triclosan_activity",
    next_step_requires_review_of_coverage_audit = TRUE
  )
)

class(audit_bundle) <- c(
  "GSE31519_Triclosan_signature_coverage_audit_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_Triclosan_signature_coverage_AUDIT_bundle.rds"
)
stage_definition_file <- file.path(
  stage_audit_dir,
  "GSE31519_locked_Triclosan_signature_definition.csv"
)
stage_rule_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_scoring_rule_lock.csv"
)
stage_coverage_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_signature_coverage_audit.csv"
)
stage_expression_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_signature_expression_audit.csv"
)
stage_correlation_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_signature_gene_correlations.csv"
)
stage_sample_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_signature_sample_completeness.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_Triclosan_signature_coverage_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script10A_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script10A_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script10A_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script10A_COMPLETE_report.txt"
)

saveRDS(
  audit_bundle,
  stage_bundle_file,
  compress = "gzip"
)
write_csv_utf8(
  signature_definition,
  stage_definition_file
)
write_csv_utf8(
  scoring_rule_lock,
  stage_rule_file
)
write_csv_utf8(
  signature_coverage_audit,
  stage_coverage_file
)
write_csv_utf8(
  signature_expression_audit,
  stage_expression_file
)
write_csv_utf8(
  signature_correlation_long,
  stage_correlation_file
)
write_csv_utf8(
  sample_signature_completeness,
  stage_sample_file
)
write_csv_utf8(
  summary_table,
  stage_summary_file
)
write_csv_utf8(
  input_manifest,
  stage_input_manifest_file
)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# Independently read back the staged core object.
bundle_check <- readRDS(stage_bundle_file)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "signature_definition",
      "scoring_rule_lock",
      "signature_coverage_audit",
      "signature_expression_audit",
      "sample_signature_completeness",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "The staged Script 10A bundle cannot be read back with required fields."
)
assert_true(
  identical(
    as.character(
      bundle_check$signature_definition$gene_symbol
    ),
    triclosan_signature_24
  ),
  "The locked signature changed while saving the Script 10A bundle."
)
assert_true(
  identical(
    as.character(bundle_check$source_sample_ids),
    colnames(expr_gene)
  ),
  "The staged Script 10A bundle has incorrect source sample IDs."
)
assert_true(
  isFALSE(bundle_check$policy$score_calculated),
  "The staged Script 10A bundle incorrectly indicates that a score was calculated."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 10A",
  "GSE31519 Triclosan signature coverage audit",
  "============================================================",
  paste0(
    "Completion time: ",
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  ),
  paste0(
    "Source Script 09B bundle MD5: ",
    observed_bundle_md5
  ),
  paste0(
    "Verified gene-level matrix: ",
    nrow(expr_gene),
    " genes x ",
    ncol(expr_gene),
    " samples"
  ),
  "Locked signature name: Triclosan_activity",
  paste0(
    "Locked signature genes: ",
    length(triclosan_signature_24)
  ),
  paste0(
    "Exact signature genes present: ",
    length(present_signature_genes)
  ),
  paste0(
    "Exact signature genes missing: ",
    length(missing_signature_genes)
  ),
  paste0(
    "Exact signature coverage fraction: ",
    sprintf("%.6f", coverage_fraction)
  ),
  paste0(
    "Missing signature genes: ",
    if (length(missing_signature_genes) == 0L) {
      "NONE"
    } else {
      paste(missing_signature_genes, collapse = ";")
    }
  ),
  paste0(
    "Exact hub genes present: ",
    length(present_hub_genes),
    " / ",
    length(hub_gene_subset_6)
  ),
  paste0(
    "Available signature genes with zero variance: ",
    length(zero_variance_genes)
  ),
  paste0(
    "Samples complete for all available signature genes: ",
    sum(
      sample_signature_completeness$
        complete_for_all_available_signature_genes
    ),
    " / ",
    nrow(sample_signature_completeness)
  ),
  "Automatic alias substitution performed: FALSE",
  "Expression values modified: FALSE",
  "Expression values normalized again: FALSE",
  "Triclosan score calculated: FALSE",
  "Survival outcomes used: FALSE",
  "High/low cutoff selected: FALSE",
  "Survival model fitted: FALSE",
  paste0(
    "Signature coverage audit bundle MD5: ",
    bundle_md5
  ),
  "",
  "SCRIPT10A STATUS: COMPLETE",
  paste0(
    "Coverage and variability were audited only. No score or outcome ",
    "analysis was performed."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(report_lines),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_definition_file,
  stage_rule_file,
  stage_coverage_file,
  stage_expression_file,
  stage_correlation_file,
  stage_sample_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)),
  "At least one required staged Script 10A output file is missing."
)
assert_true(
  all(file.info(output_files_before_manifest)$size > 0),
  "At least one required staged Script 10A output file is empty."
)

output_manifest <- make_manifest(
  output_files_before_manifest
)

write_csv_utf8(
  output_manifest,
  stage_output_manifest_file
)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) ==
    length(output_files_before_manifest),
  "The Script 10A output manifest has the wrong number of rows."
)

for (i in seq_along(output_files_before_manifest)) {
  file_i <- output_files_before_manifest[i]

  manifest_row <- manifest_check[
    manifest_check$file_name == basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(manifest_row) == 1L,
    paste0(
      "Output manifest row missing or duplicated for: ",
      basename(file_i)
    )
  )
  assert_true(
    identical(
      tolower(as.character(manifest_row$md5)),
      tolower(md5_one(file_i))
    ),
    paste0(
      "Output manifest MD5 mismatch for: ",
      basename(file_i)
    )
  )
  assert_true(
    as.numeric(manifest_row$size_bytes) ==
      as.numeric(file.info(file_i)$size),
    paste0(
      "Output manifest size mismatch for: ",
      basename(file_i)
    )
  )
}

# ------------------------------
# 10. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "The final Script 10A output directory appeared during staging."
)

rename_ok <- file.rename(
  stage_root,
  final_root
)

if (!isTRUE(rename_ok)) {
  dir.create(
    final_root,
    recursive = TRUE,
    showWarnings = FALSE
  )

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit the Script 10A staging directory to the final location."
  )

  unlink(
    stage_root,
    recursive = TRUE,
    force = TRUE
  )
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_Triclosan_signature_coverage_AUDIT_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script10A_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script10A_output_manifest_with_MD5.csv"
)

assert_true(
  all(file.exists(c(
    final_bundle_file,
    final_report_file,
    final_manifest_file
  ))),
  "The committed Script 10A output is incomplete."
)
assert_true(
  identical(
    md5_one(final_bundle_file),
    bundle_md5
  ),
  "The committed Script 10A bundle MD5 changed after commit."
)
assert_true(
  report_contains(
    final_report_file,
    "SCRIPT10A STATUS: COMPLETE"
  ),
  "The committed Script 10A report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 10A completed successfully.\n")
cat(
  "Verified gene-level matrix: ",
  nrow(expr_gene),
  " x ",
  ncol(expr_gene),
  "\n",
  sep = ""
)
cat(
  "Locked Triclosan signature genes: ",
  length(triclosan_signature_24),
  "\n",
  sep = ""
)
cat(
  "Exact signature genes present: ",
  length(present_signature_genes),
  "\n",
  sep = ""
)
cat(
  "Exact signature genes missing: ",
  length(missing_signature_genes),
  "\n",
  sep = ""
)
cat(
  "Exact hub genes present: ",
  length(present_hub_genes),
  " / ",
  length(hub_gene_subset_6),
  "\n",
  sep = ""
)
cat(
  "Zero-variance available signature genes: ",
  length(zero_variance_genes),
  "\n",
  sep = ""
)
cat("Automatic alias substitution: FALSE\n")
cat("Triclosan score calculated: FALSE\n")
cat("Survival model fitted: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat(
  "Bundle MD5: ",
  md5_one(final_bundle_file),
  "\n",
  sep = ""
)
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

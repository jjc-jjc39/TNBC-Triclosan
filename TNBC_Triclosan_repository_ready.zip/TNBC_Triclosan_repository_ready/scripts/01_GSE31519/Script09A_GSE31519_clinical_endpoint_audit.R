# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 09A
#
# Purpose:
#   Continue strictly from the completed Script 08B gene-level expression bundle.
#   Audit the complete phenotype table, identify candidate clinical variables and
#   candidate survival time/event fields, quantify missingness and coding
#   structure, and save a review bundle for the next decision point.
#
# This script DOES NOT:
#   - rerun Scripts 07A-08B;
#   - modify the gene-level expression matrix;
#   - recode any clinical endpoint;
#   - infer which event level means an adverse event;
#   - convert survival time units;
#   - calculate a Triclosan score;
#   - fit a survival model or create a plot.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(project_root, "Step2_GSE31519_external_validation")
input_root <- file.path(step_root, "04_gene_level_expression")
final_root <- file.path(step_root, "05_clinical_endpoint_audit")

gene_bundle_file <- file.path(
  input_root,
  "objects",
  "GSE31519_gene_level_expression_COMPLETE_bundle.rds"
)
manifest_08b_file <- file.path(
  input_root,
  "audit",
  "Script08B_output_manifest_with_MD5.csv"
)
report_08b_file <- file.path(
  input_root,
  "logs",
  "Script08B_COMPLETE_report.txt"
)
integrity_08b_file <- file.path(
  input_root,
  "audit",
  "GSE31519_gene_level_integrity_summary.csv"
)

required_inputs <- c(
  gene_bundle_file,
  manifest_08b_file,
  report_08b_file,
  integrity_08b_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]
if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 09A cannot start because required completed inputs are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist: ", step_root, call. = FALSE)
}

# Never overwrite a completed or partially populated output directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )
  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty, so Script 09A will not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script09A_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(stage_object_dir, stage_audit_dir, stage_log_dir)))) {
  stop("Unable to create Script 09A staging directories.", call. = FALSE)
}

committed <- FALSE
on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

normalize_existing_path <- function(x) {
  normalizePath(x, winslash = "/", mustWork = TRUE)
}

md5_one <- function(x) {
  unname(tools::md5sum(x))
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)
  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(z) normalizePath(z, winslash = "/", mustWork = FALSE),
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  required_columns <- c("file_name", "size_bytes", "md5")
  assert_true(
    all(required_columns %in% colnames(manifest)),
    paste0("Malformed output manifest: ", manifest_file)
  )
  rows <- which(manifest$file_name == basename(target_file))
  assert_true(
    length(rows) == 1L,
    paste0(
      "The manifest must contain exactly one row for ",
      basename(target_file), ": ", manifest_file
    )
  )
  tolower(trimws(as.character(manifest$md5[rows])))
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(report_file, warn = FALSE, encoding = "UTF-8")
  any(grepl(fixed_text, lines, fixed = TRUE))
}

clean_text <- function(x) {
  x <- trimws(as.character(x))
  missing_tokens <- c(
    "", "NA", "N/A", "na", "n/a", "NaN", "NULL", "null",
    "Unknown", "UNKNOWN", "unknown",
    "Not available", "NOT AVAILABLE", "not available",
    "Not reported", "NOT REPORTED", "not reported"
  )
  x[x %in% missing_tokens] <- NA_character_
  x
}

safe_numeric <- function(x) {
  x <- clean_text(x)
  suppressWarnings(as.numeric(x))
}

collapse_top_counts <- function(x, maximum_levels = 10L) {
  x <- clean_text(x)
  x[is.na(x)] <- "<MISSING>"
  tab <- sort(table(x, useNA = "no"), decreasing = TRUE)
  if (length(tab) == 0L) return("")
  keep <- seq_len(min(length(tab), maximum_levels))
  text <- paste0(names(tab)[keep], " (n=", as.integer(tab[keep]), ")")
  if (length(tab) > maximum_levels) {
    text <- c(text, paste0("... +", length(tab) - maximum_levels, " more levels"))
  }
  paste(text, collapse = "; ")
}

join_unique <- function(x) {
  x <- clean_text(x)
  x <- unique(x[!is.na(x)])
  if (length(x) == 0L) "" else paste(x, collapse = ";")
}

detect_time_unit <- function(column_name) {
  nm <- tolower(column_name)
  if (grepl("day", nm)) return("DAYS_FROM_COLUMN_NAME")
  if (grepl("month|\\bmo\\b", nm)) return("MONTHS_FROM_COLUMN_NAME")
  if (grepl("year|\\byr\\b", nm)) return("YEARS_FROM_COLUMN_NAME")
  "UNKNOWN_NOT_CONVERTED"
}

detect_name_roles <- function(column_name) {
  nm <- tolower(column_name)
  roles <- character(0)

  if (grepl(
    "(^|[^a-z])(os|dfs|rfs|dmfs|dss|pfs|efs)([^a-z]|$)|surviv|follow.?up|time|day|month|year",
    nm,
    perl = TRUE
  )) {
    roles <- c(roles, "POSSIBLE_TIME_FIELD")
  }

  if (grepl(
    "event|status|death|dead|deceased|vital|relapse|recurr|metasta|progress",
    nm,
    perl = TRUE
  )) {
    roles <- c(roles, "POSSIBLE_EVENT_FIELD")
  }

  if (grepl(
    "patient|subject|case|participant|individual|sample|(^|_)id($|_)",
    nm,
    perl = TRUE
  )) {
    roles <- c(roles, "POSSIBLE_IDENTIFIER")
  }

  if (grepl("cohort|dataset|study|series|source|site|center|centre|platform|batch", nm)) {
    roles <- c(roles, "POSSIBLE_SOURCE_OR_BATCH")
  }

  if (grepl("age|grade|stage|size|node|lymph|menop|race|ethnic|histolog", nm)) {
    roles <- c(roles, "POSSIBLE_CLINICAL_COVARIATE")
  }

  if (grepl("treat|therapy|chemo|radio|surgery|regimen|adjuvant", nm)) {
    roles <- c(roles, "POSSIBLE_TREATMENT_FIELD")
  }

  if (length(roles) == 0L) "UNCLASSIFIED_BY_NAME" else paste(unique(roles), collapse = ";")
}

make_empty_pair_table <- function() {
  data.frame(
    time_column = character(0),
    event_column = character(0),
    time_unit_hint = character(0),
    complete_pair_number = integer(0),
    complete_pair_fraction = numeric(0),
    positive_time_number = integer(0),
    nonpositive_time_number = integer(0),
    event_unique_level_number = integer(0),
    event_levels_with_counts = character(0),
    event_binary_as_observed = logical(0),
    future_manual_review_candidate = logical(0),
    event_direction_inferred = logical(0),
    time_unit_converted = logical(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

# ------------------------------
# 2. Verify completed Script 08B identity
# ------------------------------
assert_true(
  report_contains(report_08b_file, "SCRIPT08B STATUS: COMPLETE"),
  "Script 08B completion status was not found in its report."
)

expected_bundle_md5_from_manifest <- manifest_expected_md5(
  manifest_08b_file,
  gene_bundle_file
)
observed_bundle_md5 <- tolower(md5_one(gene_bundle_file))

assert_true(
  identical(expected_bundle_md5_from_manifest, observed_bundle_md5),
  paste0(
    "Script 08B bundle MD5 mismatch.\nExpected from manifest: ",
    expected_bundle_md5_from_manifest,
    "\nObserved: ",
    observed_bundle_md5
  )
)

# This checksum was independently verified when Script 08B was accepted.
verified_script08b_bundle_md5 <- "08a6f0bed9aa9860112a65c8ef316657"
assert_true(
  identical(observed_bundle_md5, verified_script08b_bundle_md5),
  paste0(
    "The Script 08B bundle does not match the independently accepted bundle.\n",
    "Expected: ", verified_script08b_bundle_md5,
    "\nObserved: ", observed_bundle_md5
  )
)

integrity_08b <- read.csv(
  integrity_08b_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
assert_true(
  all(c("item", "value") %in% colnames(integrity_08b)),
  "Script 08B integrity summary is malformed."
)
assert_true(
  !anyDuplicated(integrity_08b$item),
  "Script 08B integrity summary contains duplicated item names."
)
integrity_lookup <- setNames(as.character(integrity_08b$value), integrity_08b$item)

required_integrity_items <- c(
  "Gene_level_rows",
  "Gene_level_samples",
  "Nonfinite_values_in_gene_matrix",
  "Expression_phenotype_order_identical",
  "Completion_status"
)
assert_true(
  all(required_integrity_items %in% names(integrity_lookup)),
  "Script 08B integrity summary is missing required items."
)
assert_true(
  identical(integrity_lookup[["Completion_status"]], "COMPLETE"),
  "Script 08B integrity summary is not marked COMPLETE."
)

# ------------------------------
# 3. Read and independently validate the Script 08B bundle
# ------------------------------
gene_bundle <- readRDS(gene_bundle_file)

required_bundle_fields <- c(
  "project",
  "step",
  "script",
  "source_accession",
  "source_clean_bundle_md5",
  "source_annotation_bundle_md5",
  "aggregation_policy",
  "expression_matrix",
  "phenotype",
  "probe_resolution_audit",
  "gene_aggregation_audit",
  "integrity_summary",
  "provenance"
)

assert_true(
  is.list(gene_bundle) &&
    all(required_bundle_fields %in% names(gene_bundle)),
  "The Script 08B bundle is missing required fields."
)
assert_true(
  identical(as.character(gene_bundle$source_accession), "GSE31519"),
  "The input bundle is not for GSE31519."
)
assert_true(
  identical(as.character(gene_bundle$script), "Script08B"),
  "The input bundle was not created by Script 08B."
)

expr_gene <- gene_bundle$expression_matrix
phenotype <- gene_bundle$phenotype

assert_true(
  is.matrix(expr_gene) && is.numeric(expr_gene),
  "The gene-level expression object is not a numeric matrix."
)
assert_true(
  identical(dim(expr_gene), c(12650L, 579L)),
  paste0(
    "Expected a 12,650 x 579 gene-level matrix, but detected ",
    paste(dim(expr_gene), collapse = " x "), "."
  )
)
assert_true(
  sum(!is.finite(expr_gene)) == 0L,
  "The gene-level expression matrix contains a non-finite value."
)
assert_true(
  !is.null(rownames(expr_gene)) &&
    length(rownames(expr_gene)) == 12650L &&
    anyDuplicated(rownames(expr_gene)) == 0L &&
    all(nzchar(rownames(expr_gene))),
  "Gene symbols are blank, missing or duplicated."
)
assert_true(
  !is.null(colnames(expr_gene)) &&
    length(colnames(expr_gene)) == 579L &&
    anyDuplicated(colnames(expr_gene)) == 0L,
  "Expression sample IDs are missing or duplicated."
)

assert_true(
  is.data.frame(phenotype) &&
    nrow(phenotype) == 579L &&
    "sample_id" %in% colnames(phenotype),
  "The phenotype table is missing, malformed or not 579 rows."
)
assert_true(
  anyDuplicated(as.character(phenotype$sample_id)) == 0L &&
    !anyNA(clean_text(phenotype$sample_id)),
  "Phenotype sample IDs are missing or duplicated."
)
assert_true(
  identical(colnames(expr_gene), as.character(phenotype$sample_id)),
  "Gene-level expression columns and phenotype rows are not identically ordered."
)

# Do not alter the source phenotype table.
phenotype_original <- phenotype

# ------------------------------
# 4. Build one-row-per-variable inventory
# ------------------------------
variable_rows <- vector("list", ncol(phenotype_original))

for (j in seq_along(phenotype_original)) {
  nm <- colnames(phenotype_original)[j]
  raw <- phenotype_original[[j]]
  cleaned <- clean_text(raw)
  parsed <- safe_numeric(cleaned)

  nonmissing_mask <- !is.na(cleaned)
  numeric_mask <- nonmissing_mask & !is.na(parsed)
  nonmissing_n <- sum(nonmissing_mask)
  numeric_n <- sum(numeric_mask)
  unique_n <- length(unique(cleaned[nonmissing_mask]))
  numeric_rate <- if (nonmissing_n == 0L) NA_real_ else numeric_n / nonmissing_n
  integer_like_n <- if (numeric_n == 0L) {
    0L
  } else {
    sum(abs(parsed[numeric_mask] - round(parsed[numeric_mask])) < 1e-8)
  }

  variable_rows[[j]] <- data.frame(
    column_order = j,
    column_name = nm,
    original_R_class = paste(class(raw), collapse = ";"),
    total_sample_number = length(raw),
    nonmissing_number = nonmissing_n,
    missing_number = length(raw) - nonmissing_n,
    missing_fraction = (length(raw) - nonmissing_n) / length(raw),
    unique_nonmissing_number = unique_n,
    numeric_parse_number = numeric_n,
    numeric_parse_fraction_among_nonmissing = numeric_rate,
    integer_like_number_among_numeric = integer_like_n,
    parsed_numeric_minimum = if (numeric_n == 0L) NA_real_ else min(parsed[numeric_mask]),
    parsed_numeric_median = if (numeric_n == 0L) NA_real_ else median(parsed[numeric_mask]),
    parsed_numeric_maximum = if (numeric_n == 0L) NA_real_ else max(parsed[numeric_mask]),
    detected_roles_from_column_name = detect_name_roles(nm),
    time_unit_hint_from_column_name = detect_time_unit(nm),
    top_observed_values = collapse_top_counts(cleaned, maximum_levels = 10L),
    source_value_modified = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

variable_inventory <- do.call(rbind, variable_rows)
rownames(variable_inventory) <- NULL

assert_true(
  nrow(variable_inventory) == ncol(phenotype_original),
  "The variable inventory does not contain one row per phenotype column."
)
assert_true(
  identical(
    as.character(variable_inventory$column_name),
    colnames(phenotype_original)
  ),
  "The variable inventory is not in the original phenotype-column order."
)

# ------------------------------
# 5. Build complete value-frequency audit
# ------------------------------
frequency_rows <- list()
frequency_index <- 0L

for (j in seq_along(phenotype_original)) {
  nm <- colnames(phenotype_original)[j]
  cleaned <- clean_text(phenotype_original[[j]])
  display <- cleaned
  display[is.na(display)] <- "<MISSING>"

  tab <- sort(table(display, useNA = "no"), decreasing = TRUE)
  if (length(tab) == 0L) next

  for (k in seq_along(tab)) {
    frequency_index <- frequency_index + 1L
    frequency_rows[[frequency_index]] <- data.frame(
      column_order = j,
      column_name = nm,
      level_order_by_frequency = k,
      observed_value = names(tab)[k],
      count = as.integer(tab[k]),
      fraction_of_all_samples = as.integer(tab[k]) / nrow(phenotype_original),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }
}

value_frequency_audit <- if (length(frequency_rows) == 0L) {
  data.frame(
    column_order = integer(0),
    column_name = character(0),
    level_order_by_frequency = integer(0),
    observed_value = character(0),
    count = integer(0),
    fraction_of_all_samples = numeric(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
} else {
  do.call(rbind, frequency_rows)
}
rownames(value_frequency_audit) <- NULL

# ------------------------------
# 6. Identify candidate time, event, identifier and source fields
# ------------------------------
role_text <- as.character(variable_inventory$detected_roles_from_column_name)

time_name_mask <- grepl("POSSIBLE_TIME_FIELD", role_text, fixed = TRUE)
event_name_mask <- grepl("POSSIBLE_EVENT_FIELD", role_text, fixed = TRUE)
identifier_name_mask <- grepl("POSSIBLE_IDENTIFIER", role_text, fixed = TRUE)
source_name_mask <- grepl("POSSIBLE_SOURCE_OR_BATCH", role_text, fixed = TRUE)

time_candidate_mask <- time_name_mask &
  !is.na(variable_inventory$numeric_parse_fraction_among_nonmissing) &
  variable_inventory$numeric_parse_fraction_among_nonmissing >= 0.80 &
  variable_inventory$unique_nonmissing_number >= 5L

event_candidate_mask <- event_name_mask &
  variable_inventory$unique_nonmissing_number >= 2L &
  variable_inventory$unique_nonmissing_number <= 20L

time_candidates <- as.character(
  variable_inventory$column_name[time_candidate_mask]
)
event_candidates <- as.character(
  variable_inventory$column_name[event_candidate_mask]
)
identifier_candidates <- unique(c(
  "sample_id",
  as.character(variable_inventory$column_name[identifier_name_mask])
))
identifier_candidates <- identifier_candidates[
  identifier_candidates %in% colnames(phenotype_original)
]
source_candidates <- as.character(
  variable_inventory$column_name[source_name_mask]
)

candidate_rows <- list()
candidate_index <- 0L

for (nm in time_candidates) {
  row <- variable_inventory[
    variable_inventory$column_name == nm,
    ,
    drop = FALSE
  ]
  candidate_index <- candidate_index + 1L
  candidate_rows[[candidate_index]] <- data.frame(
    candidate_type = "TIME",
    column_order = row$column_order,
    column_name = nm,
    nonmissing_number = row$nonmissing_number,
    missing_fraction = row$missing_fraction,
    unique_nonmissing_number = row$unique_nonmissing_number,
    numeric_parse_fraction_among_nonmissing =
      row$numeric_parse_fraction_among_nonmissing,
    time_unit_hint = row$time_unit_hint_from_column_name,
    observed_values_summary = row$top_observed_values,
    endpoint_selected = FALSE,
    event_direction_inferred = FALSE,
    time_unit_converted = FALSE,
    review_reason = paste0(
      "Column name suggests time/follow-up and at least 80% of non-missing ",
      "values parse numerically; requires manual endpoint review."
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

for (nm in event_candidates) {
  row <- variable_inventory[
    variable_inventory$column_name == nm,
    ,
    drop = FALSE
  ]
  candidate_index <- candidate_index + 1L
  candidate_rows[[candidate_index]] <- data.frame(
    candidate_type = "EVENT",
    column_order = row$column_order,
    column_name = nm,
    nonmissing_number = row$nonmissing_number,
    missing_fraction = row$missing_fraction,
    unique_nonmissing_number = row$unique_nonmissing_number,
    numeric_parse_fraction_among_nonmissing =
      row$numeric_parse_fraction_among_nonmissing,
    time_unit_hint = "NOT_APPLICABLE",
    observed_values_summary = row$top_observed_values,
    endpoint_selected = FALSE,
    event_direction_inferred = FALSE,
    time_unit_converted = FALSE,
    review_reason = paste0(
      "Column name suggests event/status and has 2-20 observed levels; ",
      "requires manual coding and adverse-event direction review."
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

endpoint_candidate_audit <- if (length(candidate_rows) == 0L) {
  data.frame(
    candidate_type = character(0),
    column_order = integer(0),
    column_name = character(0),
    nonmissing_number = integer(0),
    missing_fraction = numeric(0),
    unique_nonmissing_number = integer(0),
    numeric_parse_fraction_among_nonmissing = numeric(0),
    time_unit_hint = character(0),
    observed_values_summary = character(0),
    endpoint_selected = logical(0),
    event_direction_inferred = logical(0),
    time_unit_converted = logical(0),
    review_reason = character(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
} else {
  do.call(rbind, candidate_rows)
}
rownames(endpoint_candidate_audit) <- NULL

# ------------------------------
# 7. Audit every candidate time/event pair without selecting an endpoint
# ------------------------------
pair_audit <- make_empty_pair_table()

if (length(time_candidates) > 0L && length(event_candidates) > 0L) {
  pair_rows <- list()
  pair_index <- 0L

  for (time_nm in time_candidates) {
    time_value <- safe_numeric(phenotype_original[[time_nm]])

    for (event_nm in event_candidates) {
      event_value <- clean_text(phenotype_original[[event_nm]])
      complete_mask <- !is.na(time_value) & !is.na(event_value)

      complete_n <- sum(complete_mask)
      event_complete <- event_value[complete_mask]
      time_complete <- time_value[complete_mask]

      event_tab <- sort(table(event_complete, useNA = "no"), decreasing = TRUE)
      event_level_count <- length(event_tab)
      event_summary <- if (length(event_tab) == 0L) {
        ""
      } else {
        paste0(
          names(event_tab),
          " (n=",
          as.integer(event_tab),
          ")",
          collapse = "; "
        )
      }

      pair_index <- pair_index + 1L
      pair_rows[[pair_index]] <- data.frame(
        time_column = time_nm,
        event_column = event_nm,
        time_unit_hint = detect_time_unit(time_nm),
        complete_pair_number = complete_n,
        complete_pair_fraction = complete_n / nrow(phenotype_original),
        positive_time_number = sum(time_complete > 0, na.rm = TRUE),
        nonpositive_time_number = sum(time_complete <= 0, na.rm = TRUE),
        event_unique_level_number = event_level_count,
        event_levels_with_counts = event_summary,
        event_binary_as_observed = event_level_count == 2L,
        future_manual_review_candidate =
          complete_n >= 20L &&
          sum(time_complete > 0, na.rm = TRUE) >= 20L &&
          event_level_count >= 2L,
        event_direction_inferred = FALSE,
        time_unit_converted = FALSE,
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
  }

  pair_audit <- do.call(rbind, pair_rows)
  rownames(pair_audit) <- NULL
}

# ------------------------------
# 8. Identifier, duplicate-pattern and sample-missingness audits
# ------------------------------
identifier_rows <- list()

for (i in seq_along(identifier_candidates)) {
  nm <- identifier_candidates[i]
  x <- clean_text(phenotype_original[[nm]])
  nonmissing <- x[!is.na(x)]
  tab <- table(nonmissing, useNA = "no")
  duplicated_levels <- names(tab)[tab > 1L]

  identifier_rows[[i]] <- data.frame(
    column_name = nm,
    nonmissing_number = length(nonmissing),
    unique_nonmissing_number = length(unique(nonmissing)),
    missing_number = sum(is.na(x)),
    duplicated_value_number = length(duplicated_levels),
    samples_in_duplicated_values = sum(tab[tab > 1L]),
    duplicated_values_with_counts = if (length(duplicated_levels) == 0L) {
      ""
    } else {
      paste0(
        duplicated_levels,
        " (n=",
        as.integer(tab[duplicated_levels]),
        ")",
        collapse = "; "
      )
    },
    treated_as_patient_identifier = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

identifier_duplicate_audit <- if (length(identifier_rows) == 0L) {
  data.frame(
    column_name = character(0),
    nonmissing_number = integer(0),
    unique_nonmissing_number = integer(0),
    missing_number = integer(0),
    duplicated_value_number = integer(0),
    samples_in_duplicated_values = integer(0),
    duplicated_values_with_counts = character(0),
    treated_as_patient_identifier = logical(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
} else {
  do.call(rbind, identifier_rows)
}
rownames(identifier_duplicate_audit) <- NULL

non_id_columns <- setdiff(colnames(phenotype_original), "sample_id")
if (length(non_id_columns) == 0L) {
  missing_by_sample <- data.frame(
    sample_order = seq_len(nrow(phenotype_original)),
    sample_id = as.character(phenotype_original$sample_id),
    metadata_variable_number = 0L,
    missing_metadata_number = 0L,
    missing_metadata_fraction = 0,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
} else {
  missing_matrix <- vapply(
    phenotype_original[non_id_columns],
    function(x) is.na(clean_text(x)),
    logical(nrow(phenotype_original))
  )
  if (is.null(dim(missing_matrix))) {
    missing_matrix <- matrix(
      missing_matrix,
      ncol = 1L,
      dimnames = list(NULL, non_id_columns)
    )
  }

  missing_by_sample <- data.frame(
    sample_order = seq_len(nrow(phenotype_original)),
    sample_id = as.character(phenotype_original$sample_id),
    metadata_variable_number = length(non_id_columns),
    missing_metadata_number = rowSums(missing_matrix),
    missing_metadata_fraction = rowSums(missing_matrix) / length(non_id_columns),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

# Exact duplicate metadata profiles are audited but not interpreted as duplicate patients.
if (length(non_id_columns) > 0L) {
  profile_text <- apply(
    phenotype_original[non_id_columns],
    1L,
    function(z) {
      z <- clean_text(z)
      z[is.na(z)] <- "<MISSING>"
      paste(z, collapse = "\u001F")
    }
  )
  profile_tab <- table(profile_text)
  duplicate_profile_mask <- profile_text %in% names(profile_tab)[profile_tab > 1L]
  exact_duplicate_profile_sample_number <- sum(duplicate_profile_mask)
  exact_duplicate_profile_group_number <- sum(profile_tab > 1L)
} else {
  exact_duplicate_profile_sample_number <- 0L
  exact_duplicate_profile_group_number <- 0L
}

# ------------------------------
# 9. Summary table
# ------------------------------
source_candidate_summary <- if (length(source_candidates) == 0L) {
  ""
} else {
  paste(source_candidates, collapse = ";")
}

summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Source_Script08B_bundle_MD5",
    "Gene_level_rows_verified",
    "Expression_samples_verified",
    "Phenotype_rows_verified",
    "Phenotype_column_number",
    "Expression_phenotype_order_identical",
    "Phenotype_sample_ID_unique",
    "Candidate_time_field_number",
    "Candidate_event_field_number",
    "Candidate_time_event_pair_number",
    "Candidate_identifier_field_number",
    "Candidate_source_or_batch_field_number",
    "Candidate_source_or_batch_fields",
    "Exact_duplicate_metadata_profile_group_number",
    "Samples_in_exact_duplicate_metadata_profiles",
    "Clinical_value_recoding_performed",
    "Survival_endpoint_selected",
    "Event_direction_inferred",
    "Survival_time_unit_converted",
    "Survival_model_fitted",
    "Expression_values_modified",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "09A",
    observed_bundle_md5,
    nrow(expr_gene),
    ncol(expr_gene),
    nrow(phenotype_original),
    ncol(phenotype_original),
    identical(colnames(expr_gene), as.character(phenotype_original$sample_id)),
    anyDuplicated(as.character(phenotype_original$sample_id)) == 0L,
    length(time_candidates),
    length(event_candidates),
    nrow(pair_audit),
    length(identifier_candidates),
    length(source_candidates),
    source_candidate_summary,
    exact_duplicate_profile_group_number,
    exact_duplicate_profile_sample_number,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Save all outputs in staging
# ------------------------------
input_manifest <- make_manifest(required_inputs)

audit_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script09A",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_gene_bundle_file = normalize_existing_path(gene_bundle_file),
  source_gene_bundle_md5 = observed_bundle_md5,
  source_gene_dimensions = dim(expr_gene),
  source_sample_ids = colnames(expr_gene),
  phenotype = phenotype_original,
  variable_inventory = variable_inventory,
  value_frequency_audit = value_frequency_audit,
  endpoint_candidate_audit = endpoint_candidate_audit,
  time_event_pair_audit = pair_audit,
  identifier_duplicate_audit = identifier_duplicate_audit,
  missingness_by_sample = missing_by_sample,
  summary = summary_table,
  policy = list(
    phenotype_values_modified = FALSE,
    endpoint_selected = FALSE,
    event_direction_inferred = FALSE,
    time_unit_converted = FALSE,
    survival_model_fitted = FALSE,
    expression_values_modified = FALSE,
    next_step_requires_manual_review_of_saved_audits = TRUE
  )
)
class(audit_bundle) <- c("GSE31519_clinical_endpoint_audit_bundle", "list")

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_clinical_endpoint_AUDIT_bundle.rds"
)
stage_variable_file <- file.path(
  stage_audit_dir,
  "GSE31519_clinical_variable_inventory.csv"
)
stage_frequency_file <- file.path(
  stage_audit_dir,
  "GSE31519_clinical_value_frequency.csv"
)
stage_candidate_file <- file.path(
  stage_audit_dir,
  "GSE31519_survival_endpoint_candidate_audit.csv"
)
stage_pair_file <- file.path(
  stage_audit_dir,
  "GSE31519_time_event_pair_audit.csv"
)
stage_identifier_file <- file.path(
  stage_audit_dir,
  "GSE31519_identifier_duplicate_audit.csv"
)
stage_missing_file <- file.path(
  stage_audit_dir,
  "GSE31519_clinical_missingness_by_sample.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_clinical_endpoint_audit_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script09A_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script09A_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script09A_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script09A_COMPLETE_report.txt"
)

saveRDS(audit_bundle, stage_bundle_file, compress = "gzip")
write_csv_utf8(variable_inventory, stage_variable_file)
write_csv_utf8(value_frequency_audit, stage_frequency_file)
write_csv_utf8(endpoint_candidate_audit, stage_candidate_file)
write_csv_utf8(pair_audit, stage_pair_file)
write_csv_utf8(identifier_duplicate_audit, stage_identifier_file)
write_csv_utf8(missing_by_sample, stage_missing_file)
write_csv_utf8(summary_table, stage_summary_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# Independently read back the staged core object.
bundle_check <- readRDS(stage_bundle_file)
assert_true(
  is.list(bundle_check) &&
    all(c(
      "phenotype",
      "variable_inventory",
      "endpoint_candidate_audit",
      "time_event_pair_audit",
      "summary"
    ) %in% names(bundle_check)),
  "The staged Script 09A bundle cannot be read back with required fields."
)
assert_true(
  identical(bundle_check$phenotype, phenotype_original),
  "The phenotype table changed while saving the Script 09A audit bundle."
)
assert_true(
  identical(
    as.character(bundle_check$source_sample_ids),
    colnames(expr_gene)
  ),
  "The staged Script 09A bundle has incorrect source sample IDs."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 09A",
  "GSE31519 clinical-variable and survival-endpoint audit",
  "============================================================",
  paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Source Script 08B bundle MD5: ", observed_bundle_md5),
  paste0(
    "Verified gene-level matrix: ",
    nrow(expr_gene), " genes x ", ncol(expr_gene), " samples"
  ),
  paste0("Phenotype table: ", nrow(phenotype_original), " rows x ",
         ncol(phenotype_original), " columns"),
  paste0(
    "Expression/phenotype order identical: ",
    identical(colnames(expr_gene), as.character(phenotype_original$sample_id))
  ),
  paste0("Candidate time fields: ", length(time_candidates)),
  paste0("Candidate event fields: ", length(event_candidates)),
  paste0("Candidate time/event pairs audited: ", nrow(pair_audit)),
  paste0("Candidate identifier fields audited: ", length(identifier_candidates)),
  paste0(
    "Exact duplicate metadata profile groups: ",
    exact_duplicate_profile_group_number
  ),
  paste0(
    "Samples in exact duplicate metadata profiles: ",
    exact_duplicate_profile_sample_number
  ),
  "Clinical value recoding performed: FALSE",
  "Survival endpoint selected: FALSE",
  "Event direction inferred: FALSE",
  "Survival time unit converted: FALSE",
  "Survival model fitted: FALSE",
  "Expression values modified: FALSE",
  paste0("Clinical audit bundle MD5: ", bundle_md5),
  "",
  "SCRIPT09A STATUS: COMPLETE",
  paste0(
    "Candidate fields are screening results only. Endpoint identity, event ",
    "direction and time units require review of the saved audit tables."
  ),
  "============================================================"
)
writeLines(report_lines, con = stage_report_file, useBytes = TRUE)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_variable_file,
  stage_frequency_file,
  stage_candidate_file,
  stage_pair_file,
  stage_identifier_file,
  stage_missing_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)),
  "At least one required staged Script 09A output file is missing."
)
assert_true(
  all(file.info(output_files_before_manifest)$size > 0),
  "At least one required staged Script 09A output file is empty."
)

output_manifest <- make_manifest(output_files_before_manifest)
write_csv_utf8(output_manifest, stage_output_manifest_file)

# Verify every staged output against the newly written manifest.
manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
assert_true(
  nrow(manifest_check) == length(output_files_before_manifest),
  "The Script 09A output manifest has the wrong number of rows."
)

for (i in seq_along(output_files_before_manifest)) {
  file_i <- output_files_before_manifest[i]
  manifest_row <- manifest_check[
    manifest_check$file_name == basename(file_i),
    ,
    drop = FALSE
  ]
  assert_true(
    nrow(manifest_row) == 1L,
    paste0("Output manifest row missing or duplicated for: ", basename(file_i))
  )
  assert_true(
    identical(
      tolower(as.character(manifest_row$md5)),
      tolower(md5_one(file_i))
    ),
    paste0("Output manifest MD5 mismatch for: ", basename(file_i))
  )
  assert_true(
    as.numeric(manifest_row$size_bytes) == as.numeric(file.info(file_i)$size),
    paste0("Output manifest size mismatch for: ", basename(file_i))
  )
}

# ------------------------------
# 11. Commit staging directory atomically
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "The final Script 09A output directory appeared during staging."
)

rename_ok <- file.rename(stage_root, final_root)
if (!isTRUE(rename_ok)) {
  dir.create(final_root, recursive = TRUE, showWarnings = FALSE)
  copied <- file.copy(
    from = list.files(stage_root, full.names = TRUE, all.files = FALSE),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )
  assert_true(
    all(copied),
    "Unable to commit the Script 09A staging directory to the final location."
  )
  unlink(stage_root, recursive = TRUE, force = TRUE)
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_clinical_endpoint_AUDIT_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script09A_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script09A_output_manifest_with_MD5.csv"
)

assert_true(
  all(file.exists(c(final_bundle_file, final_report_file, final_manifest_file))),
  "The committed Script 09A output is incomplete."
)
assert_true(
  identical(md5_one(final_bundle_file), bundle_md5),
  "The committed Script 09A bundle MD5 changed after commit."
)
assert_true(
  report_contains(final_report_file, "SCRIPT09A STATUS: COMPLETE"),
  "The committed Script 09A report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 09A completed successfully.\n")
cat("Verified gene-level matrix: ", nrow(expr_gene), " x ", ncol(expr_gene), "\n", sep = "")
cat("Phenotype table: ", nrow(phenotype_original), " x ", ncol(phenotype_original), "\n", sep = "")
cat("Candidate time fields: ", length(time_candidates), "\n", sep = "")
cat("Candidate event fields: ", length(event_candidates), "\n", sep = "")
cat("Candidate time/event pairs audited: ", nrow(pair_audit), "\n", sep = "")
cat("Clinical values recoded: FALSE\n")
cat("Survival endpoint selected: FALSE\n")
cat("Survival model fitted: FALSE\n")
cat("Bundle: ", normalizePath(final_bundle_file, winslash = "/", mustWork = TRUE), "\n", sep = "")
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

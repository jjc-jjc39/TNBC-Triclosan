# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 11B v4 FINAL
#
# Purpose:
#   Continue strictly from the accepted Script 10C survival-design bundle and
#   Script 11A continuous Cox-model bundle.
#
#   Diagnose the score proportional-hazards signal observed in the clinically
#   adjusted models without using any optimized cutoff or outcome-driven sample
#   deletion.
#
# Diagnostic strategy:
#   1) Reconstruct the exact five Script 11A model datasets.
#   2) Refit the original proportional-hazards Cox models and verify that their
#      coefficients reproduce the accepted Script 11A results.
#   3) Fit a single prespecified time-varying score coefficient:
#
#        beta(t) = beta_24m +
#                  beta_time * [log(1 + t) - log(1 + 24)]
#
#      where t is follow-up time in months. The main score coefficient is thus
#      interpreted at 24 months. This is a post-model diagnostic sensitivity,
#      not a replacement primary model.
#   4) Report score HRs at 1, 6, 12, 24, 60 and 120 months with 95% CIs.
#   5) Audit score dfbetas for every included observation. Influential records
#      are flagged using |standardized dfbeta| > 2/sqrt(n), but no record is
#      deleted and no model is refitted after data-driven exclusion.
#
# This script DOES NOT:
#   - rerun Scripts 07A-11A;
#   - change the GSVA score or expression matrix;
#   - optimize a cutoff or form high/low groups;
#   - fit Kaplan-Meier curves;
#   - delete influential observations;
#   - select a time function by searching multiple alternatives;
#   - fit the dataset-level meta-analysis;
#   - claim that a time-varying diagnostic rescues a null primary result.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

SCRIPT_BUILD_ID <- "Script11B_v4_FINAL_20260710"
cat("============================================================\n")
cat("RUNNING: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat("Legacy direct fit$converged assertion: REMOVED\n")
cat("Robust multi-component coxph audit: ENABLED\n")
cat("Cross-version dfbetas extraction with fallback: ENABLED\n")
cat("============================================================\n")

# ------------------------------
# 0. Fixed paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step2_GSE31519_external_validation"
)

design_root <- file.path(
  step_root,
  "09_technical_confounding_and_survival_design"
)
model_root <- file.path(
  step_root,
  "10_primary_continuous_survival_models"
)
final_root <- file.path(
  step_root,
  "11_PH_and_influence_diagnostics"
)

design_bundle_file <- file.path(
  design_root,
  "objects",
  "GSE31519_technical_confounding_survival_design_COMPLETE_bundle.rds"
)
design_manifest_file <- file.path(
  design_root,
  "audit",
  "Script10C_output_manifest_with_MD5.csv"
)
design_report_file <- file.path(
  design_root,
  "logs",
  "Script10C_COMPLETE_report.txt"
)

model_bundle_file <- file.path(
  model_root,
  "objects",
  "GSE31519_continuous_survival_models_COMPLETE_bundle.rds"
)
model_manifest_file <- file.path(
  model_root,
  "audit",
  "Script11A_output_manifest_with_MD5.csv"
)
model_report_file <- file.path(
  model_root,
  "logs",
  "Script11A_COMPLETE_report.txt"
)

required_inputs <- c(
  design_bundle_file,
  design_manifest_file,
  design_report_file,
  model_bundle_file,
  model_manifest_file,
  model_report_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 11B cannot start because required accepted files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist.", call. = FALSE)
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 11B will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script11B_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop("Unable to create Script 11B staging directories.", call. = FALSE)
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

md5_one <- function(path) {
  unname(tools::md5sum(path))
}

normalize_existing_path <- function(path) {
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(report_file, warn = FALSE, encoding = "UTF-8")
  any(grepl(fixed_text, lines, fixed = TRUE))
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)

  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(path) {
        normalizePath(path, winslash = "/", mustWork = FALSE)
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c("file_name", "size_bytes", "md5") %in% colnames(manifest)),
    paste0("Malformed manifest: ", manifest_file)
  )

  row_index <- which(manifest$file_name == basename(target_file))

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file)
    )
  )

  tolower(trimws(as.character(manifest$md5[row_index])))
}

capture_warnings <- function(expression) {
  warning_messages <- character(0)

  value <- withCallingHandlers(
    expression,
    warning = function(w) {
      warning_messages <<- c(
        warning_messages,
        conditionMessage(w)
      )
      invokeRestart("muffleWarning")
    }
  )

  list(
    value = value,
    warnings = unique(warning_messages)
  )
}

collapse_messages <- function(x) {
  x <- unique(trimws(as.character(x)))
  x <- x[nzchar(x)]
  if (length(x) == 0L) "" else paste(x, collapse = " | ")
}

# survival::coxph objects do not consistently expose a $converged field across
# package versions. Convergence is therefore assessed from stable object
# components rather than treating a missing $converged field as failure.
audit_coxph_convergence <- function(fit) {
  is_coxph <- inherits(fit, "coxph")

  coefficient_values <- tryCatch(
    as.numeric(stats::coef(fit)),
    error = function(e) numeric(0)
  )
  coefficients_finite <- length(coefficient_values) > 0L &&
    all(is.finite(coefficient_values))

  log_likelihood_values <- tryCatch(
    as.numeric(fit$loglik),
    error = function(e) numeric(0)
  )
  log_likelihood_finite <- length(log_likelihood_values) >= 2L &&
    all(is.finite(log_likelihood_values))

  iteration_values <- tryCatch(
    as.numeric(fit$iter),
    error = function(e) numeric(0)
  )
  iterations_valid <- length(iteration_values) == 0L ||
    all(is.finite(iteration_values) & iteration_values >= 0)

  failure_text <- if (is.null(fit$fail)) {
    ""
  } else {
    paste(as.character(fit$fail), collapse = " | ")
  }
  failure_text <- trimws(failure_text)
  no_failure_marker <- !nzchar(failure_text) ||
    identical(toupper(failure_text), "NA")

  explicit_converged_available <- !is.null(fit$converged)
  explicit_converged_value <- if (explicit_converged_available) {
    isTRUE(fit$converged)
  } else {
    NA
  }

  converged <- is_coxph &&
    coefficients_finite &&
    log_likelihood_finite &&
    iterations_valid &&
    no_failure_marker &&
    !identical(explicit_converged_value, FALSE)

  list(
    converged = converged,
    is_coxph = is_coxph,
    coefficients_finite = coefficients_finite,
    log_likelihood_finite = log_likelihood_finite,
    iterations_valid = iterations_valid,
    no_failure_marker = no_failure_marker,
    failure_text = failure_text,
    explicit_converged_available = explicit_converged_available,
    explicit_converged_value = explicit_converged_value
  )
}

extract_named_row <- function(matrix_object, row_name) {
  assert_true(
    row_name %in% rownames(matrix_object),
    paste0("Required coefficient row is absent: ", row_name)
  )

  matrix_object[
    row_name,
    ,
    drop = FALSE
  ]
}

time_basis <- function(time_months) {
  log1p(pmax(time_months, 0)) - log1p(24)
}

calculate_time_specific_effect <- function(
  beta_main,
  beta_time,
  covariance_matrix,
  time_months
) {
  g <- time_basis(time_months)

  log_hr <- beta_main + beta_time * g

  variance <- covariance_matrix["score_z", "score_z"] +
    (g^2) * covariance_matrix["tt(score_z)", "tt(score_z)"] +
    2 * g * covariance_matrix["score_z", "tt(score_z)"]

  assert_true(
    is.finite(variance) && variance >= 0,
    "Time-specific log-HR variance is invalid."
  )

  standard_error <- sqrt(variance)

  data.frame(
    time_months = time_months,
    time_basis_log1p_centered_24m = g,
    log_hazard_ratio = log_hr,
    standard_error = standard_error,
    hazard_ratio = exp(log_hr),
    confidence_lower_95 = exp(log_hr - 1.96 * standard_error),
    confidence_upper_95 = exp(log_hr + 1.96 * standard_error),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

make_dfbeta_matrix <- function(fit) {
  coefficient_names <- names(stats::coef(fit))
  coefficient_number <- length(coefficient_names)

  assert_true(
    coefficient_number >= 1L &&
      all(nzchar(coefficient_names)) &&
      anyDuplicated(coefficient_names) == 0L,
    "The fitted Cox model has invalid coefficient names."
  )

  normalize_residual_matrix <- function(raw, residual_type) {
    if (is.null(dim(raw))) {
      assert_true(
        coefficient_number == 1L,
        paste0(
          residual_type,
          " returned a vector although the model has ",
          coefficient_number,
          " coefficients."
        )
      )

      raw <- matrix(
        as.numeric(raw),
        ncol = 1L
      )
      colnames(raw) <- coefficient_names
    } else {
      raw <- as.matrix(raw)

      assert_true(
        ncol(raw) == coefficient_number,
        paste0(
          residual_type,
          " returned ",
          ncol(raw),
          " columns, but the model has ",
          coefficient_number,
          " coefficients."
        )
      )

      if (is.null(colnames(raw))) {
        colnames(raw) <- coefficient_names
      } else if (
        all(coefficient_names %in% colnames(raw))
      ) {
        raw <- raw[
          ,
          coefficient_names,
          drop = FALSE
        ]
      } else {
        stop(
          paste0(
            residual_type,
            " column names do not match the fitted-model coefficients. ",
            "Residual columns: ",
            paste(colnames(raw), collapse = ";"),
            "; coefficient names: ",
            paste(coefficient_names, collapse = ";")
          ),
          call. = FALSE
        )
      }
    }

    storage.mode(raw) <- "double"

    assert_true(
      all(is.finite(raw)),
      paste0(residual_type, " contains non-finite values.")
    )

    raw
  }

  # Preferred route: request standardized dfbeta residuals directly.
  # The collapse argument is deliberately omitted because survival versions
  # differ in how an explicitly supplied logical FALSE is handled.
  primary_error <- ""

  primary_result <- tryCatch(
    stats::residuals(
      fit,
      type = "dfbetas"
    ),
    error = function(e) {
      primary_error <<- conditionMessage(e)
      NULL
    }
  )

  if (!is.null(primary_result)) {
    standardized <- normalize_residual_matrix(
      primary_result,
      "dfbetas"
    )

    attr(standardized, "dfbeta_extraction_method") <-
      "DIRECT_DFBETAS_WITHOUT_COLLAPSE_ARGUMENT"
    attr(standardized, "dfbetas_primary_error") <- ""

    return(standardized)
  }

  # Cross-version fallback:
  # dfbetas are reconstructed as dfbeta divided by each coefficient SE.
  fallback_result <- tryCatch(
    stats::residuals(
      fit,
      type = "dfbeta"
    ),
    error = function(e) {
      stop(
        paste0(
          "Direct dfbetas extraction failed: ",
          primary_error,
          "\nFallback dfbeta extraction also failed: ",
          conditionMessage(e)
        ),
        call. = FALSE
      )
    }
  )

  dfbeta_raw <- normalize_residual_matrix(
    fallback_result,
    "dfbeta"
  )

  covariance_matrix <- stats::vcov(fit)

  assert_true(
    is.matrix(covariance_matrix) &&
      all(coefficient_names %in% rownames(covariance_matrix)) &&
      all(coefficient_names %in% colnames(covariance_matrix)),
    "The Cox-model covariance matrix does not match coefficient names."
  )

  covariance_matrix <- covariance_matrix[
    coefficient_names,
    coefficient_names,
    drop = FALSE
  ]

  coefficient_standard_errors <- sqrt(
    diag(covariance_matrix)
  )

  assert_true(
    length(coefficient_standard_errors) == coefficient_number &&
      all(is.finite(coefficient_standard_errors)) &&
      all(coefficient_standard_errors > 0),
    "The Cox-model coefficient standard errors are invalid."
  )

  standardized <- sweep(
    dfbeta_raw,
    MARGIN = 2L,
    STATS = coefficient_standard_errors,
    FUN = "/"
  )

  standardized <- normalize_residual_matrix(
    standardized,
    "reconstructed dfbetas"
  )

  attr(standardized, "dfbeta_extraction_method") <-
    "DFBETA_DIVIDED_BY_COEFFICIENT_STANDARD_ERROR"
  attr(standardized, "dfbetas_primary_error") <- primary_error

  standardized
}

# ------------------------------
# 2. Package preflight
# ------------------------------
if (!requireNamespace("survival", quietly = TRUE)) {
  stop(
    paste0(
      "Required package 'survival' is not installed.\n",
      "Install it once with: install.packages('survival')"
    ),
    call. = FALSE
  )
}

survival_version <- as.character(
  utils::packageVersion("survival")
)

# ------------------------------
# 3. Verify accepted input identities
# ------------------------------
assert_true(
  report_contains(design_report_file, "SCRIPT10C STATUS: COMPLETE"),
  "Script 10C completion marker was not found."
)
assert_true(
  report_contains(model_report_file, "SCRIPT11A STATUS: COMPLETE"),
  "Script 11A completion marker was not found."
)

expected_design_md5 <- manifest_expected_md5(
  design_manifest_file,
  design_bundle_file
)
observed_design_md5 <- tolower(md5_one(design_bundle_file))
accepted_design_md5 <- "19a5f27976ba1cf82f15ad1f3f304f74"

assert_true(
  identical(expected_design_md5, observed_design_md5),
  "Script 10C bundle MD5 differs from its manifest."
)
assert_true(
  identical(observed_design_md5, accepted_design_md5),
  "Script 10C bundle differs from the independently accepted bundle."
)

expected_model_md5 <- manifest_expected_md5(
  model_manifest_file,
  model_bundle_file
)
observed_model_md5 <- tolower(md5_one(model_bundle_file))
accepted_model_md5 <- "2e62fb7ca5f8085e4ee2730c6e3d8691"

assert_true(
  identical(expected_model_md5, observed_model_md5),
  "Script 11A bundle MD5 differs from its manifest."
)
assert_true(
  identical(observed_model_md5, accepted_model_md5),
  "Script 11A bundle differs from the independently accepted bundle."
)

# ------------------------------
# 4. Read and validate accepted objects
# ------------------------------
design_bundle <- readRDS(design_bundle_file)
model_bundle <- readRDS(model_bundle_file)

assert_true(
  is.list(design_bundle) &&
    all(c(
      "script",
      "source_accession",
      "analysis_table",
      "survival_design_lock",
      "policy"
    ) %in% names(design_bundle)),
  "Script 10C bundle is missing required fields."
)
assert_true(
  identical(as.character(design_bundle$script), "Script10C"),
  "Design bundle was not created by Script 10C."
)

assert_true(
  is.list(model_bundle) &&
    all(c(
      "script",
      "source_accession",
      "source_script10c_bundle_md5",
      "model_specifications",
      "model_fit_summary",
      "score_effects",
      "proportional_hazards_tests",
      "model_diagnostics",
      "model_sample_inclusion_audit",
      "cox_model_objects",
      "policy"
    ) %in% names(model_bundle)),
  "Script 11A bundle is missing required fields."
)
assert_true(
  identical(as.character(model_bundle$script), "Script11A"),
  "Model bundle was not created by Script 11A."
)
assert_true(
  identical(
    tolower(as.character(model_bundle$source_script10c_bundle_md5)),
    observed_design_md5
  ),
  "Script 11A bundle does not point to the accepted Script 10C bundle."
)

analysis_table <- design_bundle$analysis_table
accepted_score_effects <- model_bundle$score_effects
accepted_ph_tests <- model_bundle$proportional_hazards_tests
accepted_model_specs <- model_bundle$model_specifications

required_analysis_columns <- c(
  "sample_order",
  "sample_id",
  "source_dataset_id",
  "age_years",
  "nodal_status",
  "tumor_size_group",
  "histologic_grade_group",
  "adjuvant_chemotherapy",
  "efs_time_months",
  "efs_event",
  "efs_complete_public_set",
  "efs_positive_time_sensitivity_set",
  "score_z_EFS383",
  "score_z_EFS379",
  "Triclosan_activity"
)

assert_true(
  is.data.frame(analysis_table) &&
    nrow(analysis_table) == 579L &&
    all(required_analysis_columns %in% colnames(analysis_table)),
  "Script 10C analysis table is missing required rows or columns."
)
assert_true(
  anyDuplicated(as.character(analysis_table$sample_id)) == 0L,
  "Analysis table contains duplicated sample IDs."
)
assert_true(
  nrow(accepted_score_effects) == 5L,
  "Accepted Script 11A score-effect table does not contain five models."
)
assert_true(
  nrow(accepted_model_specs) == 5L,
  "Accepted Script 11A model specification table does not contain five models."
)

# Confirm the exact diagnostic trigger.
adjusted_model_ids <- c(
  "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED",
  "M4_SENSITIVITY_EFS379_CLINICAL_ADJUSTED_STRATIFIED",
  "M5_EFS383_TREATMENT_ADDED_STRATIFIED"
)

adjusted_score_ph <- accepted_ph_tests[
  accepted_ph_tests$model_id %in% adjusted_model_ids &
    accepted_ph_tests$term == "score_z",
  ,
  drop = FALSE
]

assert_true(
  nrow(adjusted_score_ph) == 3L,
  "Accepted PH table lacks the three adjusted score tests."
)
assert_true(
  all(adjusted_score_ph$p_value < 0.05),
  paste0(
    "Script 11B was designed for the accepted adjusted-model score PH signal, ",
    "but at least one accepted score PH P value is not below 0.05."
  )
)

# ------------------------------
# 5. Reconstruct exact model datasets
# ------------------------------
efs383_mask <- as.logical(
  analysis_table$efs_complete_public_set
)
efs379_mask <- as.logical(
  analysis_table$efs_positive_time_sensitivity_set
)

clinical_covariates <- c(
  "age_years",
  "nodal_status",
  "tumor_size_group",
  "histologic_grade_group"
)
treatment_covariates <- c(
  clinical_covariates,
  "adjuvant_chemotherapy"
)

build_model_data <- function(model_id) {
  if (model_id == "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED") {
    eligible <- efs383_mask
    score_column <- "score_z_EFS383"
    required_covariates <- character(0)
  } else if (
    model_id == "M2_SENSITIVITY_EFS379_UNADJUSTED_STRATIFIED"
  ) {
    eligible <- efs379_mask
    score_column <- "score_z_EFS379"
    required_covariates <- character(0)
  } else if (
    model_id == "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED"
  ) {
    eligible <- efs383_mask
    score_column <- "score_z_EFS383"
    required_covariates <- clinical_covariates
  } else if (
    model_id == "M4_SENSITIVITY_EFS379_CLINICAL_ADJUSTED_STRATIFIED"
  ) {
    eligible <- efs379_mask
    score_column <- "score_z_EFS379"
    required_covariates <- clinical_covariates
  } else if (
    model_id == "M5_EFS383_TREATMENT_ADDED_STRATIFIED"
  ) {
    eligible <- efs383_mask
    score_column <- "score_z_EFS383"
    required_covariates <- treatment_covariates
  } else {
    stop("Unknown model_id: ", model_id, call. = FALSE)
  }

  required_columns <- c(
    "efs_time_months",
    "efs_event",
    "source_dataset_id",
    score_column,
    required_covariates
  )

  complete_mask <- eligible &
    stats::complete.cases(
      analysis_table[, required_columns, drop = FALSE]
    )

  d <- analysis_table[
    complete_mask,
    ,
    drop = FALSE
  ]

  d$score_z <- as.numeric(d[[score_column]])
  d$age_per_10_years <- as.numeric(d$age_years) / 10
  d$source_dataset_id <- factor(
    as.character(d$source_dataset_id)
  )

  if ("nodal_status" %in% required_covariates) {
    d$nodal_status <- factor(
      as.character(d$nodal_status),
      levels = c("NODE_NEGATIVE", "NODE_POSITIVE")
    )
  }

  if ("tumor_size_group" %in% required_covariates) {
    d$tumor_size_group <- factor(
      as.character(d$tumor_size_group),
      levels = c("T1", "T2_T4_OR_REST")
    )
  }

  if ("histologic_grade_group" %in% required_covariates) {
    d$histologic_grade_group <- factor(
      as.character(d$histologic_grade_group),
      levels = c("GRADE_1_2", "GRADE_3")
    )
  }

  if ("adjuvant_chemotherapy" %in% required_covariates) {
    d$adjuvant_chemotherapy <- factor(
      as.character(d$adjuvant_chemotherapy),
      levels = c("NO", "YES")
    )
  }

  d <- droplevels(d)

  list(
    data = d,
    score_column = score_column,
    required_covariates = required_covariates
  )
}

base_formula_for_model <- function(model_id) {
  if (model_id %in% c(
    "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED",
    "M2_SENSITIVITY_EFS379_UNADJUSTED_STRATIFIED"
  )) {
    return(
      survival::Surv(efs_time_months, efs_event) ~
        score_z +
        strata(source_dataset_id)
    )
  }

  if (model_id %in% c(
    "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED",
    "M4_SENSITIVITY_EFS379_CLINICAL_ADJUSTED_STRATIFIED"
  )) {
    return(
      survival::Surv(efs_time_months, efs_event) ~
        score_z +
        age_per_10_years +
        nodal_status +
        tumor_size_group +
        histologic_grade_group +
        strata(source_dataset_id)
    )
  }

  if (model_id == "M5_EFS383_TREATMENT_ADDED_STRATIFIED") {
    return(
      survival::Surv(efs_time_months, efs_event) ~
        score_z +
        age_per_10_years +
        nodal_status +
        tumor_size_group +
        histologic_grade_group +
        adjuvant_chemotherapy +
        strata(source_dataset_id)
    )
  }

  stop("Unknown model_id: ", model_id, call. = FALSE)
}

time_varying_formula_for_model <- function(model_id) {
  if (model_id %in% c(
    "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED",
    "M2_SENSITIVITY_EFS379_UNADJUSTED_STRATIFIED"
  )) {
    return(
      survival::Surv(efs_time_months, efs_event) ~
        score_z +
        tt(score_z) +
        strata(source_dataset_id)
    )
  }

  if (model_id %in% c(
    "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED",
    "M4_SENSITIVITY_EFS379_CLINICAL_ADJUSTED_STRATIFIED"
  )) {
    return(
      survival::Surv(efs_time_months, efs_event) ~
        score_z +
        tt(score_z) +
        age_per_10_years +
        nodal_status +
        tumor_size_group +
        histologic_grade_group +
        strata(source_dataset_id)
    )
  }

  if (model_id == "M5_EFS383_TREATMENT_ADDED_STRATIFIED") {
    return(
      survival::Surv(efs_time_months, efs_event) ~
        score_z +
        tt(score_z) +
        age_per_10_years +
        nodal_status +
        tumor_size_group +
        histologic_grade_group +
        adjuvant_chemotherapy +
        strata(source_dataset_id)
    )
  }

  stop("Unknown model_id: ", model_id, call. = FALSE)
}

# ------------------------------
# 6. Fit diagnostic models
# ------------------------------
model_ids <- as.character(
  accepted_model_specs$model_id[
    order(accepted_model_specs$model_order)
  ]
)

evaluation_times_months <- c(
  1,
  6,
  12,
  24,
  60,
  120
)

base_refit_objects <- list()
time_varying_fit_objects <- list()
reproduction_rows <- list()
interaction_rows <- list()
time_effect_rows <- list()
influence_rows <- list()
warning_rows <- list()

for (i in seq_along(model_ids)) {
  model_id <- model_ids[i]
  built <- build_model_data(model_id)
  d <- built$data

  base_formula <- base_formula_for_model(model_id)
  tv_formula <- time_varying_formula_for_model(model_id)

  base_result <- capture_warnings(
    survival::coxph(
      formula = base_formula,
      data = d,
      ties = "efron",
      singular.ok = FALSE,
      model = TRUE,
      x = TRUE,
      y = TRUE
    )
  )

  base_fit <- base_result$value
  base_warnings <- base_result$warnings

  base_convergence <- audit_coxph_convergence(base_fit)

  assert_true(
    isTRUE(base_convergence$converged),
    paste0(
      model_id,
      " base refit failed the robust convergence audit. ",
      "Failure marker: ",
      if (nzchar(base_convergence$failure_text)) {
        base_convergence$failure_text
      } else {
        "NONE"
      },
      "; coefficients finite: ",
      base_convergence$coefficients_finite,
      "; log-likelihood finite: ",
      base_convergence$log_likelihood_finite,
      "; iterations valid: ",
      base_convergence$iterations_valid,
      "; explicit $converged available: ",
      base_convergence$explicit_converged_available
    )
  )
  assert_true(
    "score_z" %in% names(stats::coef(base_fit)),
    paste0(model_id, " base refit lacks score_z.")
  )

  accepted_row <- accepted_score_effects[
    accepted_score_effects$model_id == model_id,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(accepted_row) == 1L,
    paste0(model_id, " accepted score effect is missing or duplicated.")
  )

  reproduced_log_hr <- unname(stats::coef(base_fit)["score_z"])
  accepted_log_hr <- as.numeric(accepted_row$coefficient_log_HR)
  absolute_difference <- abs(reproduced_log_hr - accepted_log_hr)

  assert_true(
    is.finite(absolute_difference) &&
      absolute_difference <= 1e-10,
    paste0(
      model_id,
      " base score coefficient did not reproduce Script 11A. Difference: ",
      format(absolute_difference, scientific = TRUE)
    )
  )

  base_refit_objects[[model_id]] <- base_fit

  reproduction_rows[[i]] <- data.frame(
    model_order = i,
    model_id = model_id,
    sample_number = nrow(d),
    event_number = sum(d$efs_event == 1L),
    accepted_score_log_HR = accepted_log_hr,
    reproduced_score_log_HR = reproduced_log_hr,
    absolute_difference = absolute_difference,
    reproduced_within_tolerance_1e_10 =
      absolute_difference <= 1e-10,
    robust_convergence_passed = base_convergence$converged,
    explicit_converged_field_available =
      base_convergence$explicit_converged_available,
    explicit_converged_field_value =
      base_convergence$explicit_converged_value,
    coefficient_values_finite =
      base_convergence$coefficients_finite,
    log_likelihood_values_finite =
      base_convergence$log_likelihood_finite,
    no_failure_marker =
      base_convergence$no_failure_marker,
    base_refit_warning_number = length(base_warnings),
    base_refit_warning_messages = collapse_messages(base_warnings),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  tv_result <- capture_warnings(
    survival::coxph(
      formula = tv_formula,
      data = d,
      ties = "efron",
      singular.ok = FALSE,
      x = TRUE,
      y = TRUE,
      tt = function(x, t, ...) {
        x * time_basis(t)
      }
    )
  )

  tv_fit <- tv_result$value
  tv_warnings <- tv_result$warnings

  tv_convergence <- audit_coxph_convergence(tv_fit)

  assert_true(
    isTRUE(tv_convergence$converged),
    paste0(
      model_id,
      " time-varying diagnostic model failed the robust convergence audit. ",
      "Failure marker: ",
      if (nzchar(tv_convergence$failure_text)) {
        tv_convergence$failure_text
      } else {
        "NONE"
      },
      "; coefficients finite: ",
      tv_convergence$coefficients_finite,
      "; log-likelihood finite: ",
      tv_convergence$log_likelihood_finite,
      "; iterations valid: ",
      tv_convergence$iterations_valid,
      "; explicit $converged available: ",
      tv_convergence$explicit_converged_available
    )
  )
  assert_true(
    all(c("score_z", "tt(score_z)") %in% names(stats::coef(tv_fit))),
    paste0(model_id, " time-varying model lacks required score terms.")
  )
  assert_true(
    all(is.finite(stats::coef(tv_fit))),
    paste0(model_id, " time-varying model has non-finite coefficients.")
  )

  time_varying_fit_objects[[model_id]] <- tv_fit

  tv_summary <- summary(tv_fit)
  tv_coef <- tv_summary$coefficients
  beta_main <- unname(stats::coef(tv_fit)["score_z"])
  beta_time <- unname(stats::coef(tv_fit)["tt(score_z)"])
  covariance_matrix <- stats::vcov(tv_fit)[
    c("score_z", "tt(score_z)"),
    c("score_z", "tt(score_z)"),
    drop = FALSE
  ]

  interaction_row <- extract_named_row(
    tv_coef,
    "tt(score_z)"
  )

  loglik_base <- as.numeric(base_fit$loglik[2])
  loglik_tv <- as.numeric(tv_fit$loglik[2])
  lrt_chisq <- 2 * (loglik_tv - loglik_base)

  assert_true(
    is.finite(lrt_chisq) && lrt_chisq >= -1e-8,
    paste0(model_id, " time-varying LRT statistic is invalid.")
  )

  lrt_chisq <- max(lrt_chisq, 0)
  lrt_p <- stats::pchisq(
    lrt_chisq,
    df = 1,
    lower.tail = FALSE
  )

  interaction_rows[[i]] <- data.frame(
    model_order = i,
    model_id = model_id,
    sample_number = nrow(d),
    event_number = sum(d$efs_event == 1L),
    reference_time_months = 24,
    time_basis =
      "log(1+t)-log(1+24)",
    score_log_HR_at_24_months = beta_main,
    score_HR_at_24_months = exp(beta_main),
    time_interaction_coefficient = beta_time,
    time_interaction_standard_error =
      as.numeric(interaction_row[, "se(coef)"]),
    time_interaction_z =
      as.numeric(interaction_row[, "z"]),
    time_interaction_p_value =
      as.numeric(interaction_row[, "Pr(>|z|)"]),
    base_model_log_likelihood = loglik_base,
    time_varying_model_log_likelihood = loglik_tv,
    likelihood_ratio_chisq_1df = lrt_chisq,
    likelihood_ratio_p_value = lrt_p,
    time_varying_model_converged = tv_convergence$converged,
    explicit_converged_field_available =
      tv_convergence$explicit_converged_available,
    explicit_converged_field_value =
      tv_convergence$explicit_converged_value,
    coefficient_values_finite =
      tv_convergence$coefficients_finite,
    log_likelihood_values_finite =
      tv_convergence$log_likelihood_finite,
    no_failure_marker =
      tv_convergence$no_failure_marker,
    base_warning_number = length(base_warnings),
    time_varying_warning_number = length(tv_warnings),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  time_specific <- do.call(
    rbind,
    lapply(
      evaluation_times_months,
      function(time_i) {
        calculate_time_specific_effect(
          beta_main = beta_main,
          beta_time = beta_time,
          covariance_matrix = covariance_matrix,
          time_months = time_i
        )
      }
    )
  )

  time_effect_rows[[i]] <- data.frame(
    model_order = i,
    model_id = model_id,
    sample_number = nrow(d),
    event_number = sum(d$efs_event == 1L),
    time_specific,
    diagnostic_only = TRUE,
    primary_result_replaced = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  dfbeta_matrix <- make_dfbeta_matrix(base_fit)

  dfbeta_extraction_method <- as.character(
    attr(
      dfbeta_matrix,
      "dfbeta_extraction_method"
    )
  )
  dfbetas_primary_error <- as.character(
    attr(
      dfbeta_matrix,
      "dfbetas_primary_error"
    )
  )

  if (
    length(dfbeta_extraction_method) != 1L ||
      is.na(dfbeta_extraction_method) ||
      !nzchar(dfbeta_extraction_method)
  ) {
    dfbeta_extraction_method <- "UNKNOWN"
  }

  if (
    length(dfbetas_primary_error) != 1L ||
      is.na(dfbetas_primary_error)
  ) {
    dfbetas_primary_error <- ""
  }

  assert_true(
    nrow(dfbeta_matrix) == nrow(d),
    paste0(model_id, " dfbeta row count differs from model data.")
  )
  assert_true(
    "score_z" %in% colnames(dfbeta_matrix),
    paste0(model_id, " dfbeta matrix lacks score_z.")
  )

  score_dfbetas <- as.numeric(
    dfbeta_matrix[, "score_z"]
  )

  assert_true(
    length(score_dfbetas) == nrow(d) &&
      all(is.finite(score_dfbetas)),
    paste0(model_id, " score dfbetas are incomplete or non-finite.")
  )

  influence_threshold <- 2 / sqrt(nrow(d))

  influence_rows[[i]] <- data.frame(
    model_order = i,
    model_id = model_id,
    model_row_order = seq_len(nrow(d)),
    sample_order = d$sample_order,
    sample_id = as.character(d$sample_id),
    source_dataset_id = as.character(d$source_dataset_id),
    efs_time_months = d$efs_time_months,
    efs_event = d$efs_event,
    score_z = d$score_z,
    score_standardized_dfbeta = score_dfbetas,
    absolute_score_standardized_dfbeta = abs(score_dfbetas),
    dfbeta_extraction_method = rep(
      dfbeta_extraction_method,
      nrow(d)
    ),
    direct_dfbetas_error = rep(
      dfbetas_primary_error,
      nrow(d)
    ),
    influence_flag_threshold = influence_threshold,
    exceeds_2_over_sqrt_n =
      abs(score_dfbetas) > influence_threshold,
    sample_deleted = FALSE,
    sensitivity_refit_after_deletion = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  warning_rows[[i]] <- data.frame(
    model_order = i,
    model_id = model_id,
    base_refit_warning_number = length(base_warnings),
    base_refit_warning_messages = collapse_messages(base_warnings),
    time_varying_warning_number = length(tv_warnings),
    time_varying_warning_messages = collapse_messages(tv_warnings),
    dfbeta_extraction_method = dfbeta_extraction_method,
    direct_dfbetas_error = dfbetas_primary_error,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

reproduction_audit <- do.call(rbind, reproduction_rows)
time_interaction_tests <- do.call(rbind, interaction_rows)
time_specific_score_effects <- do.call(rbind, time_effect_rows)
score_influence_audit <- do.call(rbind, influence_rows)
warning_audit <- do.call(rbind, warning_rows)

rownames(reproduction_audit) <- NULL
rownames(time_interaction_tests) <- NULL
rownames(time_specific_score_effects) <- NULL
rownames(score_influence_audit) <- NULL
rownames(warning_audit) <- NULL

# ------------------------------
# 7. Summarize influence audit
# ------------------------------
influence_summary_rows <- lapply(
  model_ids,
  function(model_id) {
    d <- score_influence_audit[
      score_influence_audit$model_id == model_id,
      ,
      drop = FALSE
    ]

    max_row <- d[
      which.max(d$absolute_score_standardized_dfbeta),
      ,
      drop = FALSE
    ]

    data.frame(
      model_id = model_id,
      sample_number = nrow(d),
      influence_threshold_2_over_sqrt_n =
        unique(d$influence_flag_threshold),
      flagged_sample_number =
        sum(d$exceeds_2_over_sqrt_n),
      flagged_sample_fraction =
        mean(d$exceeds_2_over_sqrt_n),
      maximum_absolute_score_standardized_dfbeta =
        max_row$absolute_score_standardized_dfbeta,
      maximum_influence_sample_id =
        max_row$sample_id,
      maximum_influence_source_dataset_id =
        max_row$source_dataset_id,
      samples_deleted = 0L,
      sensitivity_refit_after_deletion = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }
)

influence_summary <- do.call(
  rbind,
  influence_summary_rows
)
rownames(influence_summary) <- NULL

# ------------------------------
# 8. Integrity checks
# ------------------------------
assert_true(
  nrow(reproduction_audit) == 5L &&
    all(reproduction_audit$reproduced_within_tolerance_1e_10),
  "Not all five Script 11A base models were reproduced."
)
assert_true(
  nrow(time_interaction_tests) == 5L &&
    all(time_interaction_tests$time_varying_model_converged),
  "Not all five time-varying diagnostic models converged."
)
assert_true(
  nrow(time_specific_score_effects) ==
    5L * length(evaluation_times_months),
  "Time-specific score-effect table has an unexpected row count."
)
assert_true(
  all(
    time_specific_score_effects$confidence_lower_95 > 0 &
      time_specific_score_effects$confidence_upper_95 > 0
  ),
  "At least one time-specific confidence interval is invalid."
)
assert_true(
  nrow(score_influence_audit) ==
    sum(reproduction_audit$sample_number),
  "Influence audit row count does not equal total model observations."
)
assert_true(
  !any(score_influence_audit$sample_deleted),
  "A sample was unexpectedly marked as deleted."
)
assert_true(
  !any(score_influence_audit$sensitivity_refit_after_deletion),
  "An influence-based refit was unexpectedly performed."
)

# ------------------------------
# 9. Build summary
# ------------------------------
primary_interaction <- time_interaction_tests[
  time_interaction_tests$model_id ==
    "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED",
  ,
  drop = FALSE
]

adjusted_interaction <- time_interaction_tests[
  time_interaction_tests$model_id ==
    "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED",
  ,
  drop = FALSE
]

summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Script_build_ID",
    "Source_Script10C_bundle_MD5",
    "Source_Script11A_bundle_MD5",
    "Survival_package_version",
    "Base_models_reproduced",
    "Time_varying_diagnostic_models_fitted",
    "Time_function",
    "Time_reference_months",
    "Primary_M1_time_interaction_coefficient",
    "Primary_M1_time_interaction_p_value",
    "Primary_M1_time_interaction_LRT_p_value",
    "Adjusted_M3_time_interaction_coefficient",
    "Adjusted_M3_time_interaction_p_value",
    "Adjusted_M3_time_interaction_LRT_p_value",
    "Models_with_at_least_one_flagged_influence_record",
    "Total_flagged_model_observations",
    "Samples_deleted_for_influence",
    "Influence_based_model_refit",
    "Optimized_cutoff_selected",
    "High_low_group_created",
    "Kaplan_Meier_fitted",
    "Dataset_meta_analysis_fitted",
    "Primary_result_replaced",
    "Expression_values_modified",
    "GSVA_recomputed",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "11B",
    SCRIPT_BUILD_ID,
    observed_design_md5,
    observed_model_md5,
    survival_version,
    sum(reproduction_audit$reproduced_within_tolerance_1e_10),
    nrow(time_interaction_tests),
    "log(1+t)-log(1+24)",
    24,
    primary_interaction$time_interaction_coefficient,
    primary_interaction$time_interaction_p_value,
    primary_interaction$likelihood_ratio_p_value,
    adjusted_interaction$time_interaction_coefficient,
    adjusted_interaction$time_interaction_p_value,
    adjusted_interaction$likelihood_ratio_p_value,
    sum(influence_summary$flagged_sample_number > 0L),
    sum(influence_summary$flagged_sample_number),
    0,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Save staging outputs
# ------------------------------
input_manifest <- make_manifest(required_inputs)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script11B",
  script_build_id = SCRIPT_BUILD_ID,
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_script10c_bundle_file =
    normalize_existing_path(design_bundle_file),
  source_script10c_bundle_md5 = observed_design_md5,
  source_script11a_bundle_file =
    normalize_existing_path(model_bundle_file),
  source_script11a_bundle_md5 = observed_model_md5,
  survival_package_version = survival_version,
  diagnostic_time_function =
    "log(1+t)-log(1+24)",
  reference_time_months = 24,
  evaluation_times_months = evaluation_times_months,
  reproduction_audit = reproduction_audit,
  time_interaction_tests = time_interaction_tests,
  time_specific_score_effects = time_specific_score_effects,
  score_influence_audit = score_influence_audit,
  influence_summary = influence_summary,
  warning_audit = warning_audit,
  base_refit_objects = base_refit_objects,
  time_varying_fit_objects = time_varying_fit_objects,
  integrity_summary = summary_table,
  policy = list(
    analysis_role =
      "Post-model PH and influence diagnostic sensitivity",
    primary_result_replaced = FALSE,
    time_function_search_performed = FALSE,
    time_function =
      "log(1+t)-log(1+24)",
    reference_time_months = 24,
    optimized_cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    Kaplan_Meier_fitted = FALSE,
    samples_deleted_for_influence = FALSE,
    influence_based_model_refit = FALSE,
    dataset_meta_analysis_fitted = FALSE,
    expression_values_modified = FALSE,
    GSVA_recomputed = FALSE
  ),
  provenance = list(
    accepted_script10c_bundle_md5 = accepted_design_md5,
    accepted_script11a_bundle_md5 = accepted_model_md5,
    diagnostic_trigger =
      "Adjusted score cox.zph P values below 0.05 in Script 11A",
    next_step_requires_review_of =
      c(
        "time_interaction_tests",
        "time_specific_score_effects",
        "influence_summary"
      )
  )
)

class(complete_bundle) <- c(
  "GSE31519_PH_influence_diagnostics_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_PH_influence_diagnostics_COMPLETE_bundle.rds"
)
stage_reproduction_file <- file.path(
  stage_audit_dir,
  "GSE31519_Script11A_model_reproduction_audit.csv"
)
stage_interaction_file <- file.path(
  stage_audit_dir,
  "GSE31519_score_time_interaction_tests.csv"
)
stage_time_effect_file <- file.path(
  stage_audit_dir,
  "GSE31519_time_specific_score_effects.csv"
)
stage_influence_file <- file.path(
  stage_audit_dir,
  "GSE31519_score_influence_audit_all_model_observations.csv"
)
stage_influence_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_score_influence_summary.csv"
)
stage_warning_file <- file.path(
  stage_audit_dir,
  "GSE31519_PH_influence_diagnostic_warnings.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_PH_influence_diagnostics_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script11B_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script11B_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script11B_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script11B_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)

write_csv_utf8(reproduction_audit, stage_reproduction_file)
write_csv_utf8(time_interaction_tests, stage_interaction_file)
write_csv_utf8(time_specific_score_effects, stage_time_effect_file)
write_csv_utf8(score_influence_audit, stage_influence_file)
write_csv_utf8(influence_summary, stage_influence_summary_file)
write_csv_utf8(warning_audit, stage_warning_file)
write_csv_utf8(summary_table, stage_summary_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

bundle_check <- readRDS(stage_bundle_file)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "script_build_id",
      "reproduction_audit",
      "time_interaction_tests",
      "time_specific_score_effects",
      "score_influence_audit",
      "influence_summary",
      "warning_audit",
      "base_refit_objects",
      "time_varying_fit_objects",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 11B bundle is missing required fields."
)
assert_true(
  identical(as.character(bundle_check$script_build_id), SCRIPT_BUILD_ID),
  "Staged Script 11B bundle build ID is incorrect."
)
assert_true(
  all(
    bundle_check$reproduction_audit$
      reproduced_within_tolerance_1e_10
  ),
  "Saved Script 11B bundle contains a failed base-model reproduction."
)
assert_true(
  nrow(bundle_check$time_interaction_tests) == 5L,
  "Saved Script 11B bundle lacks five time-interaction tests."
)
assert_true(
  isFALSE(bundle_check$policy$primary_result_replaced) &&
    isFALSE(bundle_check$policy$samples_deleted_for_influence) &&
    isFALSE(bundle_check$policy$optimized_cutoff_selected),
  "Saved Script 11B policy incorrectly indicates result replacement, deletion or cutoff."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 11B",
  "Proportional-hazards and influence diagnostics",
  paste0("Script build ID: ", SCRIPT_BUILD_ID),
  "============================================================",
  paste0(
    "Completion time: ",
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  ),
  paste0("Source Script 10C bundle MD5: ", observed_design_md5),
  paste0("Source Script 11A bundle MD5: ", observed_model_md5),
  paste0("survival package version: ", survival_version),
  paste0(
    "Base Script 11A models reproduced: ",
    sum(reproduction_audit$reproduced_within_tolerance_1e_10),
    " / 5"
  ),
  "Diagnostic time function: log(1+t)-log(1+24)",
  "Reference time: 24 months",
  paste0(
    "Time-varying diagnostic models converged: ",
    sum(time_interaction_tests$time_varying_model_converged),
    " / 5"
  ),
  "",
  paste0(
    "M1 primary time-interaction coefficient: ",
    format(
      primary_interaction$time_interaction_coefficient,
      digits = 10
    )
  ),
  paste0(
    "M1 primary time-interaction P value: ",
    format(
      primary_interaction$time_interaction_p_value,
      digits = 10
    )
  ),
  paste0(
    "M1 primary LRT P value: ",
    format(
      primary_interaction$likelihood_ratio_p_value,
      digits = 10
    )
  ),
  "",
  paste0(
    "M3 adjusted time-interaction coefficient: ",
    format(
      adjusted_interaction$time_interaction_coefficient,
      digits = 10
    )
  ),
  paste0(
    "M3 adjusted time-interaction P value: ",
    format(
      adjusted_interaction$time_interaction_p_value,
      digits = 10
    )
  ),
  paste0(
    "M3 adjusted LRT P value: ",
    format(
      adjusted_interaction$likelihood_ratio_p_value,
      digits = 10
    )
  ),
  "",
  paste0(
    "Models with at least one flagged score-influence record: ",
    sum(influence_summary$flagged_sample_number > 0L)
  ),
  paste0(
    "Total flagged model observations: ",
    sum(influence_summary$flagged_sample_number)
  ),
  "Samples deleted for influence: 0",
  "Influence-based model refit: FALSE",
  "Primary result replaced: FALSE",
  "Time-function search performed: FALSE",
  "Optimized cutoff selected: FALSE",
  "High/low group created: FALSE",
  "Kaplan-Meier fitted: FALSE",
  "Dataset meta-analysis fitted: FALSE",
  "Expression values modified: FALSE",
  "GSVA recomputed: FALSE",
  paste0("Script 11B bundle MD5: ", bundle_md5),
  "",
  "SCRIPT11B STATUS: COMPLETE",
  paste0(
    "The accepted primary null Cox result remains primary. Time-varying score ",
    "effects and influence metrics are diagnostic sensitivities only."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(report_lines),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_reproduction_file,
  stage_interaction_file,
  stage_time_effect_file,
  stage_influence_file,
  stage_influence_summary_file,
  stage_warning_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)),
  "At least one staged Script 11B output is missing."
)
assert_true(
  all(file.info(output_files_before_manifest)$size > 0),
  "At least one staged Script 11B output is empty."
)

output_manifest <- make_manifest(output_files_before_manifest)
write_csv_utf8(output_manifest, stage_output_manifest_file)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) == length(output_files_before_manifest),
  "Script 11B output manifest has an incorrect row count."
)

for (i in seq_along(output_files_before_manifest)) {
  file_i <- output_files_before_manifest[i]
  row_i <- manifest_check[
    manifest_check$file_name == basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0("Missing or duplicated manifest row: ", basename(file_i))
  )
  assert_true(
    identical(
      tolower(as.character(row_i$md5)),
      tolower(md5_one(file_i))
    ),
    paste0("Manifest MD5 mismatch: ", basename(file_i))
  )
  assert_true(
    as.numeric(row_i$size_bytes) ==
      as.numeric(file.info(file_i)$size),
    paste0("Manifest size mismatch: ", basename(file_i))
  )
}

# ------------------------------
# 11. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 11B directory appeared during staging."
)

rename_ok <- file.rename(stage_root, final_root)

if (!isTRUE(rename_ok)) {
  dir.create(final_root, recursive = TRUE, showWarnings = FALSE)

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 11B staging directory."
  )

  unlink(stage_root, recursive = TRUE, force = TRUE)
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_PH_influence_diagnostics_COMPLETE_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script11B_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script11B_output_manifest_with_MD5.csv"
)

assert_true(
  all(file.exists(c(
    final_bundle_file,
    final_report_file,
    final_manifest_file
  ))),
  "Committed Script 11B output is incomplete."
)
assert_true(
  identical(md5_one(final_bundle_file), bundle_md5),
  "Committed Script 11B bundle MD5 changed after commit."
)
assert_true(
  report_contains(
    final_report_file,
    "SCRIPT11B STATUS: COMPLETE"
  ),
  "Committed Script 11B report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 11B completed successfully.\n")
cat("Script build ID: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat(
  "Base Script 11A models reproduced: ",
  sum(reproduction_audit$reproduced_within_tolerance_1e_10),
  " / 5\n",
  sep = ""
)
cat(
  "Time-varying diagnostic models converged: ",
  sum(time_interaction_tests$time_varying_model_converged),
  " / 5\n",
  sep = ""
)
cat(
  "M1 time-interaction P: ",
  format(
    primary_interaction$time_interaction_p_value,
    digits = 7
  ),
  "\n",
  sep = ""
)
cat(
  "M3 time-interaction P: ",
  format(
    adjusted_interaction$time_interaction_p_value,
    digits = 7
  ),
  "\n",
  sep = ""
)
cat(
  "Models with flagged score-influence records: ",
  sum(influence_summary$flagged_sample_number > 0L),
  "\n",
  sep = ""
)
cat(
  "DFBETAS extraction methods: ",
  paste(
    sort(unique(warning_audit$dfbeta_extraction_method)),
    collapse = ";"
  ),
  "\n",
  sep = ""
)
cat("Samples deleted for influence: 0\n")
cat("Primary result replaced: FALSE\n")
cat("Optimized cutoff selected: FALSE\n")
cat("Kaplan-Meier fitted: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

# ==============================================================================
# TNBC_Triclosan project
# Step 2 - Script 07C v2
#
# GSE31519 ONE-SHOT format repair, sample matching, invalid-value audit,
# controlled imputation, and final data locking.
#
# This script starts entirely from the two files already downloaded to disk.
# It does NOT depend on objects remaining in the current R session.
#
# It replaces/supersedes Script 07B and Script 07B2.
#
# Outputs:
#   - analysis-ready probeset expression matrix
#   - original matrix retaining invalid values
#   - aligned/transposed metadata
#   - complete sample/probeset/missing-value audits
#   - reproducibility bundle and session information
# ==============================================================================


# ------------------------------------------------------------------------------
# 0. Global settings
# ------------------------------------------------------------------------------

options(
  stringsAsFactors = FALSE,
  timeout = max(3600, getOption("timeout")),
  scipen = 999,
  warn = 1,
  max.print = 200
)

set.seed(20260710)

EXPECTED_SAMPLE_NUMBER <- 579L
EXPECTED_PROBESET_NUMBER <- 22283L

# Pre-specified safety thresholds for automatic repair
MAX_OVERALL_INVALID_FRACTION <- 0.001   # 0.10% of all matrix cells
MAX_SAMPLE_INVALID_FRACTION  <- 0.05    # 5.00% within any sample
MAX_PROBE_INVALID_FRACTION   <- 0.20    # 20.00% within any probeset


# ------------------------------------------------------------------------------
# 1. Locate the project and create directories
# ------------------------------------------------------------------------------

detect_project_root <- function() {

  fixed_path <- "C:/Users/14351/Documents/TNBC_Triclosan"

  if (dir.exists(fixed_path)) {
    return(
      normalizePath(
        fixed_path,
        winslash = "/",
        mustWork = TRUE
      )
    )
  }

  if (
    requireNamespace("rstudioapi", quietly = TRUE) &&
    rstudioapi::isAvailable()
  ) {

    active_project <- tryCatch(
      rstudioapi::getActiveProject(),
      error = function(e) NULL
    )

    if (
      !is.null(active_project) &&
      nzchar(active_project) &&
      dir.exists(active_project)
    ) {

      return(
        normalizePath(
          active_project,
          winslash = "/",
          mustWork = TRUE
        )
      )
    }
  }

  current_directory <- normalizePath(
    getwd(),
    winslash = "/",
    mustWork = TRUE
  )

  if (
    dir.exists(
      file.path(
        current_directory,
        "Step2_GSE31519_external_validation"
      )
    )
  ) {
    return(current_directory)
  }

  possible_child <- file.path(
    current_directory,
    "TNBC_Triclosan"
  )

  if (dir.exists(possible_child)) {
    return(
      normalizePath(
        possible_child,
        winslash = "/",
        mustWork = TRUE
      )
    )
  }

  stop(
    paste0(
      "无法定位TNBC_Triclosan项目目录。\n",
      "预期目录：C:/Users/14351/Documents/TNBC_Triclosan"
    ),
    call. = FALSE
  )
}


PROJECT_DIR <- detect_project_root()

STEP2_DIR <- file.path(
  PROJECT_DIR,
  "Step2_GSE31519_external_validation"
)

RAW_DIR <- file.path(
  STEP2_DIR,
  "01_raw_download"
)

OBJECT_DIR <- file.path(
  STEP2_DIR,
  "02_data_objects"
)

METADATA_DIR <- file.path(
  STEP2_DIR,
  "03_metadata"
)

PREFLIGHT_DIR <- file.path(
  STEP2_DIR,
  "00_preflight"
)

TABLE_DIR <- file.path(
  STEP2_DIR,
  "tables"
)

LOG_DIR <- file.path(
  STEP2_DIR,
  "logs"
)

invisible(
  lapply(
    c(
      STEP2_DIR,
      RAW_DIR,
      OBJECT_DIR,
      METADATA_DIR,
      PREFLIGHT_DIR,
      TABLE_DIR,
      LOG_DIR
    ),
    dir.create,
    recursive = TRUE,
    showWarnings = FALSE
  )
)


# ------------------------------------------------------------------------------
# 2. Install and load the only required package
# ------------------------------------------------------------------------------

if (
  !requireNamespace(
    "data.table",
    quietly = TRUE
  )
) {
  install.packages(
    "data.table",
    dependencies = TRUE
  )
}

if (
  !requireNamespace(
    "data.table",
    quietly = TRUE
  )
) {
  stop(
    "data.table安装后仍无法使用。",
    call. = FALSE
  )
}


# ------------------------------------------------------------------------------
# 3. Locate the two already-downloaded official files
# ------------------------------------------------------------------------------

find_existing_file <- function(
    directory,
    exact_filename
) {

  candidates <- list.files(
    directory,
    pattern = paste0(
      "^",
      gsub(
        "\\.",
        "\\\\.",
        exact_filename
      ),
      "$"
    ),
    full.names = TRUE,
    recursive = TRUE
  )

  if (length(candidates) == 0L) {
    stop(
      paste0(
        "没有找到已下载文件：\n",
        exact_filename,
        "\n搜索目录：",
        directory
      ),
      call. = FALSE
    )
  }

  if (length(candidates) > 1L) {
    candidate_sizes <- file.info(candidates)$size
    candidates <- candidates[which.max(candidate_sizes)]
  }

  normalizePath(
    candidates,
    winslash = "/",
    mustWork = TRUE
  )
}


SAMPLE_INFO_FILE <- find_existing_file(
  RAW_DIR,
  "GSE31519_TNBC_SampleInfo_BCR.txt.gz"
)

EXPRESSION_FILE <- find_existing_file(
  RAW_DIR,
  "GSE31519_complete_dataset.txt.gz"
)


input_manifest <- data.frame(
  file_name = basename(
    c(
      SAMPLE_INFO_FILE,
      EXPRESSION_FILE
    )
  ),
  absolute_path = c(
    SAMPLE_INFO_FILE,
    EXPRESSION_FILE
  ),
  size_bytes = unname(
    file.info(
      c(
        SAMPLE_INFO_FILE,
        EXPRESSION_FILE
      )
    )$size
  ),
  md5 = unname(
    tools::md5sum(
      c(
        SAMPLE_INFO_FILE,
        EXPRESSION_FILE
      )
    )
  ),
  stringsAsFactors = FALSE
)


write.csv(
  input_manifest,
  file.path(
    PREFLIGHT_DIR,
    "Script07C_input_manifest_with_MD5.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


# ------------------------------------------------------------------------------
# 4. Utility functions
# ------------------------------------------------------------------------------

normalize_identifier <- function(x) {

  x <- trimws(
    as.character(x)
  )

  x <- toupper(x)

  gsub(
    "[^A-Z0-9]",
    "",
    x
  )
}


clean_character_vector <- function(x) {

  x <- trimws(
    as.character(x)
  )

  missing_tokens <- c(
    "",
    "NA",
    "N/A",
    "NAN",
    "NULL",
    "NONE",
    "."
  )

  x[
    toupper(x) %in%
      missing_tokens
  ] <- NA_character_

  x
}


safe_name <- function(x) {

  x <- trimws(
    as.character(x)
  )

  x[
    is.na(x) |
      !nzchar(x)
  ] <- "unnamed_metadata_field"

  make.unique(
    x,
    sep = "_duplicate_"
  )
}


# ------------------------------------------------------------------------------
# 5. Read and transpose the horizontal sample-information file
# ------------------------------------------------------------------------------

sample_info_horizontal <- data.table::fread(
  input = SAMPLE_INFO_FILE,
  sep = "\t",
  header = TRUE,
  quote = "",
  fill = TRUE,
  check.names = FALSE,
  data.table = FALSE,
  na.strings = c(
    "",
    "NA",
    "N/A",
    "NaN",
    "NULL",
    "null"
  ),
  showProgress = FALSE
)


if (
  nrow(sample_info_horizontal) != 11L ||
  ncol(sample_info_horizontal) != 580L
) {
  stop(
    paste0(
      "样本信息文件维度不是预期的11 x 580，而是",
      nrow(sample_info_horizontal),
      " x ",
      ncol(sample_info_horizontal),
      "。"
    ),
    call. = FALSE
  )
}


metadata_field_names <- safe_name(
  sample_info_horizontal[[1]]
)

metadata_field_names[
  tolower(metadata_field_names) ==
    "sample_id"
] <- "metadata_sample_id"


canonical_sample_ids <- clean_character_vector(
  colnames(
    sample_info_horizontal
  )[-1]
)


if (
  length(canonical_sample_ids) !=
    EXPECTED_SAMPLE_NUMBER ||
  anyNA(canonical_sample_ids) ||
  any(!nzchar(canonical_sample_ids)) ||
  anyDuplicated(canonical_sample_ids)
) {
  stop(
    "样本信息文件的579个列标题不是唯一、有效的样本ID。",
    call. = FALSE
  )
}


metadata_matrix <- t(
  as.matrix(
    sample_info_horizontal[
      ,
      -1,
      drop = FALSE
    ]
  )
)

colnames(metadata_matrix) <- (
  metadata_field_names
)

sample_metadata <- data.frame(
  sample_id = canonical_sample_ids,
  metadata_matrix,
  row.names = NULL,
  check.names = FALSE,
  stringsAsFactors = FALSE
)


for (
  current_column in seq_along(
    sample_metadata
  )
) {
  sample_metadata[[current_column]] <- clean_character_vector(
    sample_metadata[[current_column]]
  )
}


if (
  nrow(sample_metadata) !=
    EXPECTED_SAMPLE_NUMBER
) {
  stop(
    "转置后的metadata不是579个样本。",
    call. = FALSE
  )
}


# ------------------------------------------------------------------------------
# 6. Build all valid candidate sample-ID vectors from the metadata file
# ------------------------------------------------------------------------------

candidate_id_vectors <- list(
  COLUMN_HEADERS = canonical_sample_ids
)


for (
  metadata_row_index in seq_len(
    nrow(sample_info_horizontal)
  )
) {

  current_candidate <- clean_character_vector(
    unlist(
      sample_info_horizontal[
        metadata_row_index,
        -1,
        drop = TRUE
      ],
      use.names = FALSE
    )
  )

  current_nonmissing <- current_candidate[
    !is.na(current_candidate) &
      nzchar(current_candidate)
  ]

  if (
    length(current_candidate) ==
      EXPECTED_SAMPLE_NUMBER &&
    length(current_nonmissing) >=
      0.95 * EXPECTED_SAMPLE_NUMBER &&
    length(unique(current_nonmissing)) >=
      0.95 * EXPECTED_SAMPLE_NUMBER
  ) {

    candidate_name <- paste0(
      "METADATA_ROW__",
      metadata_field_names[
        metadata_row_index
      ]
    )

    candidate_id_vectors[[
      candidate_name
    ]] <- current_candidate
  }
}


# ------------------------------------------------------------------------------
# 7. Detect the true expression header by explicit sample-ID overlap
# ------------------------------------------------------------------------------

expression_connection <- gzfile(
  EXPRESSION_FILE,
  open = "rt"
)

top_expression_lines <- readLines(
  expression_connection,
  n = 100L,
  warn = FALSE
)

close(expression_connection)


if (length(top_expression_lines) < 2L) {
  stop(
    "表达文件开头内容不足，文件可能损坏。",
    call. = FALSE
  )
}


header_candidate_rows <- list()
header_counter <- 0L


for (
  line_index in seq_along(
    top_expression_lines
  )
) {

  current_fields <- strsplit(
    top_expression_lines[line_index],
    split = "\t",
    fixed = TRUE
  )[[1]]

  current_fields_normalized <- normalize_identifier(
    current_fields
  )


  for (
    candidate_name in names(
      candidate_id_vectors
    )
  ) {

    current_candidate <- candidate_id_vectors[[
      candidate_name
    ]]

    current_candidate_normalized <- normalize_identifier(
      current_candidate
    )

    valid_candidate_mask <- (
      !is.na(current_candidate) &
        nzchar(current_candidate) &
        nzchar(current_candidate_normalized)
    )

    overlap_number <- sum(
      current_candidate_normalized[
        valid_candidate_mask
      ] %in%
        current_fields_normalized
    )

    header_counter <- header_counter + 1L

    header_candidate_rows[[
      header_counter
    ]] <- data.frame(
      line_number = line_index,
      field_number = length(current_fields),
      candidate_ID_source = candidate_name,
      candidate_valid_ID_number = sum(
        valid_candidate_mask
      ),
      overlap_number = overlap_number,
      overlap_fraction = overlap_number /
        EXPECTED_SAMPLE_NUMBER,
      line_preview = substr(
        top_expression_lines[line_index],
        1,
        300
      ),
      stringsAsFactors = FALSE
    )
  }
}


header_detection_audit <- do.call(
  rbind,
  header_candidate_rows
)

rownames(header_detection_audit) <- NULL

header_detection_audit <- header_detection_audit[
  order(
    -header_detection_audit$overlap_number,
    -header_detection_audit$field_number,
    header_detection_audit$line_number,
    method = "radix"
  ),
  ,
  drop = FALSE
]


best_header_record <- header_detection_audit[
  1,
  ,
  drop = FALSE
]

TRUE_HEADER_LINE <- as.integer(
  best_header_record$line_number
)

SELECTED_ID_SOURCE <- as.character(
  best_header_record$candidate_ID_source
)

HEADER_SAMPLE_OVERLAP <- as.integer(
  best_header_record$overlap_number
)


write.csv(
  header_detection_audit,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_expression_header_and_sample_ID_detection_audit.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


if (
  HEADER_SAMPLE_OVERLAP !=
    EXPECTED_SAMPLE_NUMBER
) {
  stop(
    paste0(
      "无法在表达表头中完整匹配579个样本ID。\n",
      "最佳匹配为",
      HEADER_SAMPLE_OVERLAP,
      "/579；候选来源：",
      SELECTED_ID_SOURCE,
      "；表头行：",
      TRUE_HEADER_LINE,
      "。"
    ),
    call. = FALSE
  )
}


selected_expression_IDs <- candidate_id_vectors[[
  SELECTED_ID_SOURCE
]]


# ------------------------------------------------------------------------------
# 8. Read the expression table from the detected true header
# ------------------------------------------------------------------------------

cat(
  "\n正在读取GSE31519表达文件，请等待……\n"
)


expression_raw <- data.table::fread(
  input = EXPRESSION_FILE,
  sep = "\t",
  skip = TRUE_HEADER_LINE - 1L,
  header = TRUE,
  quote = "",
  fill = TRUE,
  check.names = FALSE,
  data.table = FALSE,
  na.strings = c(
    "",
    "NA",
    "N/A",
    "NaN",
    "NULL",
    "null",
    "#N/A"
  ),
  showProgress = TRUE
)


if (
  nrow(expression_raw) <
    EXPECTED_PROBESET_NUMBER ||
  ncol(expression_raw) <
    EXPECTED_SAMPLE_NUMBER + 1L
) {
  stop(
    paste0(
      "按真实表头读取后维度仍异常：",
      nrow(expression_raw),
      " x ",
      ncol(expression_raw),
      "。"
    ),
    call. = FALSE
  )
}


# ------------------------------------------------------------------------------
# 9. Identify exactly 22,283 Affymetrix GPL96 probesets
# ------------------------------------------------------------------------------

probe_test_rows <- seq_len(
  min(
    5000L,
    nrow(expression_raw)
  )
)


probe_pattern_fraction <- vapply(
  expression_raw,
  function(current_column) {

    current_values <- toupper(
      trimws(
        as.character(
          current_column[
            probe_test_rows
          ]
        )
      )
    )

    mean(
      grepl(
        "_AT$",
        current_values
      ),
      na.rm = TRUE
    )
  },
  numeric(1)
)


PROBE_ID_COLUMN <- names(
  which.max(
    probe_pattern_fraction
  )
)

BEST_PROBE_PATTERN_FRACTION <- max(
  probe_pattern_fraction
)


if (
  !is.finite(
    BEST_PROBE_PATTERN_FRACTION
  ) ||
  BEST_PROBE_PATTERN_FRACTION <
    0.95
) {
  stop(
    paste0(
      "无法可靠识别Affymetrix探针ID列；最高匹配率为",
      sprintf(
        "%.6f",
        BEST_PROBE_PATTERN_FRACTION
      ),
      "。"
    ),
    call. = FALSE
  )
}


feature_ids_all <- trimws(
  as.character(
    expression_raw[[
      PROBE_ID_COLUMN
    ]]
  )
)


valid_probe_rows <- (
  !is.na(feature_ids_all) &
    nzchar(feature_ids_all) &
    grepl(
      "_AT$",
      toupper(feature_ids_all)
    )
)


VALID_PROBE_NUMBER <- sum(
  valid_probe_rows
)


if (
  VALID_PROBE_NUMBER !=
    EXPECTED_PROBESET_NUMBER
) {
  stop(
    paste0(
      "识别到",
      VALID_PROBE_NUMBER,
      "个有效GPL96探针；预期为22,283个。"
    ),
    call. = FALSE
  )
}


feature_ids <- feature_ids_all[
  valid_probe_rows
]


if (
  anyDuplicated(feature_ids)
) {
  stop(
    paste0(
      "有效探针中存在",
      sum(
        duplicated(feature_ids)
      ),
      "个重复ID。"
    ),
    call. = FALSE
  )
}


# ------------------------------------------------------------------------------
# 10. Match all 579 samples explicitly and align metadata
# ------------------------------------------------------------------------------

expression_column_names <- colnames(
  expression_raw
)

expression_column_normalized <- normalize_identifier(
  expression_column_names
)

selected_IDs_normalized <- normalize_identifier(
  selected_expression_IDs
)


if (
  anyNA(selected_expression_IDs) ||
  any(!nzchar(selected_expression_IDs)) ||
  anyDuplicated(selected_IDs_normalized)
) {
  stop(
    paste0(
      "用于表达列匹配的样本ID向量无效：",
      SELECTED_ID_SOURCE
    ),
    call. = FALSE
  )
}


sample_column_positions <- match(
  selected_IDs_normalized,
  expression_column_normalized
)


if (
  anyNA(sample_column_positions) ||
  length(
    unique(
      sample_column_positions
    )
  ) !=
    EXPECTED_SAMPLE_NUMBER
) {
  stop(
    "真实表头修复后仍无法唯一匹配全部579个表达样本。",
    call. = FALSE
  )
}


expression_sample_columns <- expression_column_names[
  sample_column_positions
]


sample_metadata$expression_sample_id <- (
  selected_expression_IDs
)

sample_metadata$expression_column_name <- (
  expression_sample_columns
)

sample_metadata$metadata_sample_order <- seq_len(
  nrow(sample_metadata)
)


sample_matching_audit <- data.frame(
  metadata_sample_id =
    sample_metadata$sample_id,
  selected_ID_source =
    SELECTED_ID_SOURCE,
  selected_expression_ID =
    selected_expression_IDs,
  matched_expression_column =
    expression_sample_columns,
  normalized_selected_ID =
    selected_IDs_normalized,
  normalized_expression_column =
    expression_column_normalized[
      sample_column_positions
    ],
  exact_normalized_match =
    selected_IDs_normalized ==
      expression_column_normalized[
        sample_column_positions
      ],
  stringsAsFactors = FALSE
)


if (
  !all(
    sample_matching_audit$
      exact_normalized_match
  )
) {
  stop(
    "579个样本中存在标准化ID不一致。",
    call. = FALSE
  )
}


write.csv(
  sample_matching_audit,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_all579_sample_ID_matching_audit.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


# ------------------------------------------------------------------------------
# 11. Construct the numeric matrix and retain all invalid raw tokens
# ------------------------------------------------------------------------------

cat(
  "正在构建22,283 x 579表达矩阵并审核异常值……\n"
)


expression_matrix_original <- matrix(
  NA_real_,
  nrow = EXPECTED_PROBESET_NUMBER,
  ncol = EXPECTED_SAMPLE_NUMBER,
  dimnames = list(
    feature_ids,
    canonical_sample_ids
  )
)


invalid_cell_rows <- list()
invalid_cell_counter <- 0L


for (
  sample_index in seq_len(
    EXPECTED_SAMPLE_NUMBER
  )
) {

  current_expression_column <- (
    expression_sample_columns[
      sample_index
    ]
  )

  current_raw_values <- as.character(
    expression_raw[[
      current_expression_column
    ]][
      valid_probe_rows
    ]
  )

  current_trimmed_values <- trimws(
    current_raw_values
  )

  current_numeric_values <- suppressWarnings(
    as.numeric(
      current_trimmed_values
    )
  )

  expression_matrix_original[
    ,
    sample_index
  ] <- current_numeric_values

  current_invalid_positions <- which(
    !is.finite(
      current_numeric_values
    )
  )

  if (
    length(
      current_invalid_positions
    ) > 0L
  ) {

    invalid_cell_counter <- invalid_cell_counter + 1L

    current_raw_tokens <- current_trimmed_values[
      current_invalid_positions
    ]

    current_raw_tokens[
      is.na(current_raw_tokens)
    ] <- "<NA>"

    current_raw_tokens[
      !is.na(current_raw_tokens) &
        !nzchar(current_raw_tokens)
    ] <- "<EMPTY_STRING>"

    invalid_cell_rows[[
      invalid_cell_counter
    ]] <- data.frame(
      probeset_id =
        feature_ids[
          current_invalid_positions
        ],
      sample_id =
        canonical_sample_ids[
          sample_index
        ],
      expression_sample_id =
        selected_expression_IDs[
          sample_index
        ],
      expression_column =
        current_expression_column,
      matrix_row =
        current_invalid_positions,
      matrix_column =
        sample_index,
      raw_token =
        current_raw_tokens,
      stringsAsFactors = FALSE
    )
  }
}


if (
  !identical(
    dim(
      expression_matrix_original
    ),
    c(
      EXPECTED_PROBESET_NUMBER,
      EXPECTED_SAMPLE_NUMBER
    )
  )
) {
  stop(
    "构建后的表达矩阵维度不正确。",
    call. = FALSE
  )
}


invalid_mask <- !is.finite(
  expression_matrix_original
)

INVALID_VALUE_NUMBER <- sum(
  invalid_mask
)

TOTAL_VALUE_NUMBER <- length(
  expression_matrix_original
)

OVERALL_INVALID_FRACTION <- (
  INVALID_VALUE_NUMBER /
    TOTAL_VALUE_NUMBER
)


if (INVALID_VALUE_NUMBER > 0L) {

  invalid_cell_audit <- do.call(
    rbind,
    invalid_cell_rows
  )

  rownames(invalid_cell_audit) <- NULL

} else {

  invalid_cell_audit <- data.frame(
    probeset_id = character(0),
    sample_id = character(0),
    expression_sample_id = character(0),
    expression_column = character(0),
    matrix_row = integer(0),
    matrix_column = integer(0),
    raw_token = character(0),
    stringsAsFactors = FALSE
  )
}


write.csv(
  invalid_cell_audit,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_invalid_expression_cells_FULL_AUDIT.csv"
  ),
  row.names = FALSE,
  na = "",
  fileEncoding = "UTF-8"
)


if (nrow(invalid_cell_audit) > 0L) {

  invalid_token_counts <- sort(
    table(
      invalid_cell_audit$raw_token,
      useNA = "ifany"
    ),
    decreasing = TRUE
  )

  invalid_token_frequency <- data.frame(
    raw_token = names(
      invalid_token_counts
    ),
    cell_number = as.integer(
      invalid_token_counts
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

} else {

  invalid_token_frequency <- data.frame(
    raw_token = character(0),
    cell_number = integer(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}


write.csv(
  invalid_token_frequency,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_invalid_raw_token_frequency.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


# ------------------------------------------------------------------------------
# 12. Quantify invalid values by probeset and sample
# ------------------------------------------------------------------------------

invalid_by_probe <- rowSums(
  invalid_mask
)

invalid_by_sample <- colSums(
  invalid_mask
)


probe_invalid_audit <- data.frame(
  probeset_id =
    rownames(
      expression_matrix_original
    ),
  invalid_value_number =
    invalid_by_probe,
  invalid_fraction =
    invalid_by_probe /
      ncol(
        expression_matrix_original
      ),
  stringsAsFactors = FALSE
)

probe_invalid_audit <- probe_invalid_audit[
  order(
    -probe_invalid_audit$
      invalid_value_number,
    probe_invalid_audit$
      probeset_id,
    method = "radix"
  ),
  ,
  drop = FALSE
]


sample_invalid_audit <- data.frame(
  sample_id =
    colnames(
      expression_matrix_original
    ),
  invalid_value_number =
    invalid_by_sample,
  invalid_fraction =
    invalid_by_sample /
      nrow(
        expression_matrix_original
      ),
  stringsAsFactors = FALSE
)


metadata_index_for_audit <- match(
  sample_invalid_audit$sample_id,
  sample_metadata$sample_id
)

sample_invalid_audit <- cbind(
  sample_invalid_audit,
  sample_metadata[
    metadata_index_for_audit,
    setdiff(
      colnames(sample_metadata),
      "sample_id"
    ),
    drop = FALSE
  ]
)

sample_invalid_audit <- sample_invalid_audit[
  order(
    -sample_invalid_audit$
      invalid_value_number,
    sample_invalid_audit$
      sample_id,
    method = "radix"
  ),
  ,
  drop = FALSE
]


write.csv(
  probe_invalid_audit,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_invalid_values_by_probeset.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  sample_invalid_audit,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_invalid_values_by_sample.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


AFFECTED_PROBE_NUMBER <- sum(
  invalid_by_probe > 0L
)

AFFECTED_SAMPLE_NUMBER <- sum(
  invalid_by_sample > 0L
)

MAX_INVALID_PER_PROBE <- if (
  length(invalid_by_probe) > 0L
) {
  max(invalid_by_probe)
} else {
  0L
}

MAX_INVALID_PER_SAMPLE <- if (
  length(invalid_by_sample) > 0L
) {
  max(invalid_by_sample)
} else {
  0L
}

MAX_PROBE_INVALID_FRACTION_OBSERVED <- if (
  length(invalid_by_probe) > 0L
) {
  max(
    invalid_by_probe /
      ncol(
        expression_matrix_original
      )
  )
} else {
  0
}

MAX_SAMPLE_INVALID_FRACTION_OBSERVED <- if (
  length(invalid_by_sample) > 0L
) {
  max(
    invalid_by_sample /
      nrow(
        expression_matrix_original
      )
  )
} else {
  0
}


# ------------------------------------------------------------------------------
# 13. Apply strict automatic-repair safety criteria
# ------------------------------------------------------------------------------

overall_fraction_pass <- (
  OVERALL_INVALID_FRACTION <=
    MAX_OVERALL_INVALID_FRACTION
)

sample_fraction_pass <- (
  MAX_SAMPLE_INVALID_FRACTION_OBSERVED <=
    MAX_SAMPLE_INVALID_FRACTION
)

probe_fraction_pass <- (
  MAX_PROBE_INVALID_FRACTION_OBSERVED <=
    MAX_PROBE_INVALID_FRACTION
)

no_all_invalid_sample <- (
  sum(
    invalid_by_sample ==
      nrow(
        expression_matrix_original
      )
  ) == 0L
)

no_all_invalid_probe <- (
  sum(
    invalid_by_probe ==
      ncol(
        expression_matrix_original
      )
  ) == 0L
)


CONTROLLED_REPAIR_ALLOWED <- all(
  overall_fraction_pass,
  sample_fraction_pass,
  probe_fraction_pass,
  no_all_invalid_sample,
  no_all_invalid_probe
)


repair_safety_table <- data.frame(
  criterion = c(
    "Overall invalid fraction <= 0.001",
    "Maximum sample invalid fraction <= 0.05",
    "Maximum probeset invalid fraction <= 0.20",
    "No completely invalid sample",
    "No completely invalid probeset"
  ),
  observed_value = c(
    OVERALL_INVALID_FRACTION,
    MAX_SAMPLE_INVALID_FRACTION_OBSERVED,
    MAX_PROBE_INVALID_FRACTION_OBSERVED,
    sum(
      invalid_by_sample ==
        nrow(
          expression_matrix_original
        )
    ),
    sum(
      invalid_by_probe ==
        ncol(
          expression_matrix_original
        )
    )
  ),
  passed = c(
    overall_fraction_pass,
    sample_fraction_pass,
    probe_fraction_pass,
    no_all_invalid_sample,
    no_all_invalid_probe
  ),
  stringsAsFactors = FALSE
)


write.csv(
  repair_safety_table,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_controlled_repair_safety_check.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


if (!CONTROLLED_REPAIR_ALLOWED) {

  emergency_report <- c(
    "============================================================",
    "TNBC_Triclosan Step 2 - Script 07C v2",
    "ONE-SHOT repair stopped by the prespecified safety gate",
    "============================================================",
    paste0(
      "Invalid values: ",
      INVALID_VALUE_NUMBER
    ),
    paste0(
      "Overall invalid fraction: ",
      sprintf(
        "%.8f",
        OVERALL_INVALID_FRACTION
      )
    ),
    paste0(
      "Maximum sample invalid fraction: ",
      sprintf(
        "%.8f",
        MAX_SAMPLE_INVALID_FRACTION_OBSERVED
      )
    ),
    paste0(
      "Maximum probeset invalid fraction: ",
      sprintf(
        "%.8f",
        MAX_PROBE_INVALID_FRACTION_OBSERVED
      )
    ),
    "CONTROLLED REPAIR STATUS: NOT_ALLOWED",
    "No value was imputed.",
    "All audit files were saved.",
    "============================================================"
  )

  writeLines(
    emergency_report,
    file.path(
      PREFLIGHT_DIR,
      "Script07C_SAFETY_GATE_STOP_report.txt"
    ),
    useBytes = TRUE
  )

  cat(
    "\n",
    paste(
      emergency_report,
      collapse = "\n"
    ),
    "\n",
    sep = ""
  )

  stop(
    paste0(
      "异常值分布未通过预设安全阈值。",
      "脚本已保存全部审核结果并停止，未修改数据。"
    ),
    call. = FALSE
  )
}


# ------------------------------------------------------------------------------
# 14. Perform probeset-wise median imputation when permitted
# ------------------------------------------------------------------------------

expression_matrix_final <- (
  expression_matrix_original
)

imputation_rows <- list()
imputation_counter <- 0L


if (INVALID_VALUE_NUMBER > 0L) {

  affected_probe_indices <- which(
    invalid_by_probe > 0L
  )


  for (
    probe_index in affected_probe_indices
  ) {

    current_values <- expression_matrix_final[
      probe_index,
      ,
      drop = TRUE
    ]

    finite_values <- current_values[
      is.finite(
        current_values
      )
    ]

    if (length(finite_values) == 0L) {
      stop(
        paste0(
          "探针",
          rownames(
            expression_matrix_final
          )[probe_index],
          "没有可用于填补的有限值。"
        ),
        call. = FALSE
      )
    }

    probe_median <- median(
      finite_values,
      na.rm = TRUE
    )

    invalid_columns <- which(
      !is.finite(
        current_values
      )
    )

    expression_matrix_final[
      probe_index,
      invalid_columns
    ] <- probe_median

    imputation_counter <- imputation_counter + 1L

    imputation_rows[[
      imputation_counter
    ]] <- data.frame(
      probeset_id =
        rownames(
          expression_matrix_final
        )[probe_index],
      imputed_cell_number =
        length(invalid_columns),
      probeset_median_used =
        probe_median,
      stringsAsFactors = FALSE
    )
  }


  imputation_summary <- do.call(
    rbind,
    imputation_rows
  )

  rownames(imputation_summary) <- NULL

} else {

  imputation_summary <- data.frame(
    probeset_id = character(0),
    imputed_cell_number = integer(0),
    probeset_median_used = numeric(0),
    stringsAsFactors = FALSE
  )
}


IMPUTED_VALUE_NUMBER <- if (
  nrow(imputation_summary) > 0L
) {
  sum(
    imputation_summary$
      imputed_cell_number
  )
} else {
  0L
}


write.csv(
  imputation_summary,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_probeset_median_imputation_summary.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


# ------------------------------------------------------------------------------
# 15. Validate that repair changed only originally invalid cells
# ------------------------------------------------------------------------------

if (
  anyNA(
    expression_matrix_final
  ) ||
  any(
    !is.finite(
      expression_matrix_final
    )
  )
) {
  stop(
    "修复后的表达矩阵仍存在NA或非有限值。",
    call. = FALSE
  )
}


if (
  !identical(
    dim(
      expression_matrix_final
    ),
    c(
      EXPECTED_PROBESET_NUMBER,
      EXPECTED_SAMPLE_NUMBER
    )
  )
) {
  stop(
    "修复后表达矩阵维度发生变化。",
    call. = FALSE
  )
}


if (
  !identical(
    dimnames(
      expression_matrix_final
    ),
    dimnames(
      expression_matrix_original
    )
  )
) {
  stop(
    "修复改变了表达矩阵的探针名或样本名。",
    call. = FALSE
  )
}


NORMAL_VALUES_UNCHANGED <- isTRUE(
  all.equal(
    expression_matrix_original[
      !invalid_mask
    ],
    expression_matrix_final[
      !invalid_mask
    ],
    tolerance = 0,
    check.attributes = FALSE
  )
)


if (!NORMAL_VALUES_UNCHANGED) {
  stop(
    "修复过程意外改变了原本正常的表达值。",
    call. = FALSE
  )
}


if (
  IMPUTED_VALUE_NUMBER !=
    INVALID_VALUE_NUMBER
) {
  stop(
    paste0(
      "异常值数量与填补数量不一致：",
      INVALID_VALUE_NUMBER,
      " vs ",
      IMPUTED_VALUE_NUMBER,
      "。"
    ),
    call. = FALSE
  )
}


# ------------------------------------------------------------------------------
# 16. Audit metadata fields and low-cardinality variables
# ------------------------------------------------------------------------------

metadata_field_audit_rows <- lapply(
  colnames(sample_metadata),
  function(current_column) {

    current_values <- clean_character_vector(
      sample_metadata[[
        current_column
      ]]
    )

    nonmissing_values <- current_values[
      !is.na(current_values) &
        nzchar(current_values)
    ]

    unique_values <- unique(
      nonmissing_values
    )

    data.frame(
      metadata_column =
        current_column,
      non_missing_number =
        length(nonmissing_values),
      missing_number =
        nrow(sample_metadata) -
          length(nonmissing_values),
      unique_non_missing_number =
        length(unique_values),
      example_values =
        paste(
          head(
            unique_values,
            8L
          ),
          collapse = " | "
        ),
      stringsAsFactors = FALSE
    )
  }
)


metadata_field_audit <- do.call(
  rbind,
  metadata_field_audit_rows
)

rownames(metadata_field_audit) <- NULL


cohort_pattern <- paste(
  c(
    "cohort",
    "dataset",
    "study",
    "source",
    "series",
    "batch",
    "site",
    "center",
    "centre",
    "institution",
    "hospital",
    "origin",
    "bcr"
  ),
  collapse = "|"
)

clinical_pattern <- paste(
  c(
    "survival",
    "follow",
    "time",
    "event",
    "death",
    "relapse",
    "recurrence",
    "metast",
    "age",
    "grade",
    "node",
    "stage",
    "tumor",
    "tumour",
    "size",
    "therapy",
    "response",
    "pam50",
    "basal"
  ),
  collapse = "|"
)


cohort_candidate_fields <- colnames(
  sample_metadata
)[
  grepl(
    cohort_pattern,
    colnames(sample_metadata),
    ignore.case = TRUE
  )
]

clinical_candidate_fields <- colnames(
  sample_metadata
)[
  grepl(
    clinical_pattern,
    colnames(sample_metadata),
    ignore.case = TRUE
  )
]


low_cardinality_fields <- metadata_field_audit$
  metadata_column[
    metadata_field_audit$
      unique_non_missing_number >= 2L &
      metadata_field_audit$
        unique_non_missing_number <= 50L
  ]


metadata_frequency_rows <- list()
frequency_counter <- 0L


for (
  current_field in low_cardinality_fields
) {

  current_counts <- table(
    sample_metadata[[
      current_field
    ]],
    useNA = "ifany"
  )

  current_frequency <- data.frame(
    value = names(
      current_counts
    ),
    sample_number = as.integer(
      current_counts
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  current_frequency$metadata_column <- (
    current_field
  )

  frequency_counter <- frequency_counter + 1L

  metadata_frequency_rows[[
    frequency_counter
  ]] <- current_frequency[
    ,
    c(
      "metadata_column",
      "value",
      "sample_number"
    ),
    drop = FALSE
  ]
}


if (
  length(
    metadata_frequency_rows
  ) > 0L
) {

  metadata_frequency_table <- do.call(
    rbind,
    metadata_frequency_rows
  )

  rownames(metadata_frequency_table) <- NULL

} else {

  metadata_frequency_table <- data.frame(
    metadata_column = character(0),
    value = character(0),
    sample_number = integer(0),
    stringsAsFactors = FALSE
  )
}


write.csv(
  metadata_field_audit,
  file.path(
    METADATA_DIR,
    "GSE31519_metadata_field_audit_AFTER_transposition.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  metadata_frequency_table,
  file.path(
    METADATA_DIR,
    "GSE31519_low_cardinality_metadata_frequency_tables.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


# ------------------------------------------------------------------------------
# 17. Save all final and audit objects
# ------------------------------------------------------------------------------

ORIGINAL_MATRIX_FILE <- file.path(
  OBJECT_DIR,
  "GSE31519_processed_probeset_expression_matrix_WITH_ORIGINAL_INVALID_VALUES.rds"
)

FINAL_MATRIX_FILE <- file.path(
  OBJECT_DIR,
  "GSE31519_processed_probeset_expression_matrix.rds"
)

METADATA_RDS_FILE <- file.path(
  OBJECT_DIR,
  "GSE31519_sample_information_aligned_to_expression_columns.rds"
)

METADATA_CSV_FILE <- file.path(
  METADATA_DIR,
  "GSE31519_sample_information_aligned_to_expression_columns.csv"
)


saveRDS(
  expression_matrix_original,
  ORIGINAL_MATRIX_FILE,
  compress = "gzip"
)

saveRDS(
  expression_matrix_final,
  FINAL_MATRIX_FILE,
  compress = "gzip"
)

saveRDS(
  sample_metadata,
  METADATA_RDS_FILE,
  compress = "gzip"
)

write.csv(
  sample_metadata,
  METADATA_CSV_FILE,
  row.names = FALSE,
  na = "",
  fileEncoding = "UTF-8"
)


expression_value_summary <- data.frame(
  statistic = c(
    "minimum",
    "first_quartile",
    "median",
    "mean",
    "third_quartile",
    "maximum",
    "standard_deviation"
  ),
  value = c(
    min(expression_matrix_final),
    unname(
      quantile(
        expression_matrix_final,
        0.25
      )
    ),
    median(expression_matrix_final),
    mean(expression_matrix_final),
    unname(
      quantile(
        expression_matrix_final,
        0.75
      )
    ),
    max(expression_matrix_final),
    sd(
      as.numeric(
        expression_matrix_final
      )
    )
  ),
  stringsAsFactors = FALSE
)


write.csv(
  expression_value_summary,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_final_expression_value_summary.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


complete_bundle <- list(
  project_directory =
    PROJECT_DIR,
  input_manifest =
    input_manifest,
  sample_information_original_dimensions =
    dim(sample_info_horizontal),
  selected_expression_ID_source =
    SELECTED_ID_SOURCE,
  detected_expression_header_line =
    TRUE_HEADER_LINE,
  header_sample_overlap =
    HEADER_SAMPLE_OVERLAP,
  expression_table_dimensions =
    dim(expression_raw),
  probe_ID_column =
    PROBE_ID_COLUMN,
  probe_pattern_fraction =
    BEST_PROBE_PATTERN_FRACTION,
  valid_probe_number =
    VALID_PROBE_NUMBER,
  sample_matching_audit =
    sample_matching_audit,
  sample_metadata =
    sample_metadata,
  original_expression_matrix_with_invalid_values =
    expression_matrix_original,
  invalid_cell_audit =
    invalid_cell_audit,
  invalid_token_frequency =
    invalid_token_frequency,
  probe_invalid_audit =
    probe_invalid_audit,
  sample_invalid_audit =
    sample_invalid_audit,
  repair_safety_table =
    repair_safety_table,
  controlled_repair_allowed =
    CONTROLLED_REPAIR_ALLOWED,
  imputation_method =
    "Probeset-wise median of all finite values",
  imputation_summary =
    imputation_summary,
  final_expression_matrix =
    expression_matrix_final,
  metadata_field_audit =
    metadata_field_audit,
  metadata_frequency_table =
    metadata_frequency_table,
  cohort_candidate_fields =
    cohort_candidate_fields,
  clinical_candidate_fields =
    clinical_candidate_fields,
  session_info =
    sessionInfo()
)


COMPLETE_BUNDLE_FILE <- file.path(
  OBJECT_DIR,
  "Script07C_v2_GSE31519_ONE_SHOT_repair_COMPLETE_bundle.rds"
)


saveRDS(
  complete_bundle,
  COMPLETE_BUNDLE_FILE,
  compress = "gzip"
)


writeLines(
  capture.output(
    sessionInfo()
  ),
  file.path(
    LOG_DIR,
    "Script07C_v2_GSE31519_ONE_SHOT_repair_sessionInfo.txt"
  ),
  useBytes = TRUE
)


# ------------------------------------------------------------------------------
# 18. Final integrity check
# ------------------------------------------------------------------------------

required_outputs <- c(
  ORIGINAL_MATRIX_FILE,
  FINAL_MATRIX_FILE,
  METADATA_RDS_FILE,
  METADATA_CSV_FILE,
  COMPLETE_BUNDLE_FILE,
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_all579_sample_ID_matching_audit.csv"
  ),
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_invalid_expression_cells_FULL_AUDIT.csv"
  ),
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_invalid_values_by_probeset.csv"
  ),
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_invalid_values_by_sample.csv"
  ),
  file.path(
    PREFLIGHT_DIR,
    "GSE31519_probeset_median_imputation_summary.csv"
  )
)


missing_outputs <- required_outputs[
  !file.exists(
    required_outputs
  )
]


if (length(missing_outputs) > 0L) {
  stop(
    paste0(
      "以下关键输出没有成功保存：\n",
      paste(
        missing_outputs,
        collapse = "\n"
      )
    ),
    call. = FALSE
  )
}


# ------------------------------------------------------------------------------
# 19. Final report
# ------------------------------------------------------------------------------

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 07C v2",
  "GSE31519 ONE-SHOT format repair and data locking",
  "============================================================",
  "",
  paste0(
    "Original sample-information dimensions: ",
    nrow(sample_info_horizontal),
    " rows x ",
    ncol(sample_info_horizontal),
    " columns"
  ),
  paste0(
    "Transposed metadata dimensions: ",
    nrow(sample_metadata),
    " samples x ",
    ncol(sample_metadata),
    " columns"
  ),
  paste0(
    "Selected sample-ID source: ",
    SELECTED_ID_SOURCE
  ),
  paste0(
    "Detected expression header line: ",
    TRUE_HEADER_LINE
  ),
  paste0(
    "Header sample-ID overlap: ",
    HEADER_SAMPLE_OVERLAP,
    "/",
    EXPECTED_SAMPLE_NUMBER
  ),
  paste0(
    "Expression table after header repair: ",
    nrow(expression_raw),
    " rows x ",
    ncol(expression_raw),
    " columns"
  ),
  paste0(
    "Detected probeset-ID column: ",
    PROBE_ID_COLUMN
  ),
  paste0(
    "Affymetrix-ID fraction: ",
    sprintf(
      "%.6f",
      BEST_PROBE_PATTERN_FRACTION
    )
  ),
  paste0(
    "Valid GPL96 probesets: ",
    VALID_PROBE_NUMBER
  ),
  paste0(
    "Expression samples matched explicitly by ID: ",
    length(expression_sample_columns)
  ),
  paste0(
    "All 579 normalized sample-ID matches exact: ",
    all(
      sample_matching_audit$
        exact_normalized_match
    )
  ),
  "",
  paste0(
    "Invalid value number before repair: ",
    INVALID_VALUE_NUMBER
  ),
  paste0(
    "Overall invalid fraction: ",
    sprintf(
      "%.8f",
      OVERALL_INVALID_FRACTION
    ),
    " (",
    sprintf(
      "%.5f%%",
      100 *
        OVERALL_INVALID_FRACTION
    ),
    ")"
  ),
  paste0(
    "Affected probesets: ",
    AFFECTED_PROBE_NUMBER
  ),
  paste0(
    "Affected samples: ",
    AFFECTED_SAMPLE_NUMBER
  ),
  paste0(
    "Maximum invalid values in one probeset: ",
    MAX_INVALID_PER_PROBE
  ),
  paste0(
    "Maximum probeset invalid fraction: ",
    sprintf(
      "%.8f",
      MAX_PROBE_INVALID_FRACTION_OBSERVED
    )
  ),
  paste0(
    "Maximum invalid values in one sample: ",
    MAX_INVALID_PER_SAMPLE
  ),
  paste0(
    "Maximum sample invalid fraction: ",
    sprintf(
      "%.8f",
      MAX_SAMPLE_INVALID_FRACTION_OBSERVED
    )
  ),
  paste0(
    "Controlled repair safety check: ",
    CONTROLLED_REPAIR_ALLOWED
  ),
  paste0(
    "Imputation method: probeset-wise median"
  ),
  paste0(
    "Imputed value number: ",
    IMPUTED_VALUE_NUMBER
  ),
  paste0(
    "Originally finite values unchanged: ",
    NORMAL_VALUES_UNCHANGED
  ),
  "",
  paste0(
    "Final expression dimensions: ",
    nrow(expression_matrix_final),
    " probesets x ",
    ncol(expression_matrix_final),
    " samples"
  ),
  paste0(
    "Final all expression values finite: ",
    all(
      is.finite(
        expression_matrix_final
      )
    )
  ),
  paste0(
    "Duplicate probeset IDs: ",
    sum(
      duplicated(
        rownames(
          expression_matrix_final
        )
      )
    )
  ),
  paste0(
    "Duplicate sample IDs: ",
    sum(
      duplicated(
        colnames(
          expression_matrix_final
        )
      )
    )
  ),
  paste0(
    "Metadata fields: ",
    paste(
      colnames(sample_metadata),
      collapse = " | "
    )
  ),
  paste0(
    "Cohort/source candidate fields: ",
    if (
      length(
        cohort_candidate_fields
      ) > 0L
    ) {
      paste(
        cohort_candidate_fields,
        collapse = " | "
      )
    } else {
      "NONE_BY_FIELD_NAME"
    }
  ),
  paste0(
    "Clinical candidate fields: ",
    if (
      length(
        clinical_candidate_fields
      ) > 0L
    ) {
      paste(
        clinical_candidate_fields,
        collapse = " | "
      )
    } else {
      "NONE_BY_FIELD_NAME"
    }
  ),
  "",
  "CONTROLLED REPAIR STATUS: PASSED",
  "FORMAT REPAIR STATUS: PASSED",
  "DATA LOCK STATUS: PASSED",
  "============================================================"
)


REPORT_FILE <- file.path(
  PREFLIGHT_DIR,
  "Script07C_v2_GSE31519_ONE_SHOT_repair_report.txt"
)


writeLines(
  report_lines,
  REPORT_FILE,
  useBytes = TRUE
)


cat(
  "\n",
  paste(
    report_lines,
    collapse = "\n"
  ),
  "\n\n",
  sep = ""
)


cat(
  "异常原始字符频数：\n"
)

print(
  invalid_token_frequency,
  row.names = FALSE
)


cat(
  "\n缺失最多的前10个样本：\n"
)

print(
  head(
    sample_invalid_audit[
      ,
      c(
        "sample_id",
        "invalid_value_number",
        "invalid_fraction"
      ),
      drop = FALSE
    ],
    10L
  ),
  row.names = FALSE
)


cat(
  "\nMetadata字段审核：\n"
)

print(
  metadata_field_audit,
  row.names = FALSE
)


cat(
  "\nSCRIPT 07C v2 COMPLETED SUCCESSFULLY\n"
)


if (
  identical(
    .Platform$OS.type,
    "windows"
  )
) {

  try(
    shell.exec(
      normalizePath(
        PREFLIGHT_DIR,
        winslash = "\\",
        mustWork = TRUE
      )
    ),
    silent = TRUE
  )
}


invisible(
  gc(
    verbose = FALSE
  )
)

# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 08B
#
# Purpose:
#   Continue strictly from the completed Script 07D clean-expression bundle and
#   the completed Script 08A v2 probe-annotation audit. Resolve probesets to
#   gene symbols with an explicit, auditable rule and construct the primary
#   gene-level expression matrix.
#
# Resolution policy fixed from the Script 08A v2 audit:
#   1. Exclude the 53 retained AFFX control probesets from the gene matrix.
#   2. Exclude 1,169 probesets without a valid gene symbol.
#   3. Exclude 836 probesets mapped to multiple valid gene symbols, because
#      duplicating one measured probeset across several genes would create
#      non-independent expression values.
#   4. Retain 20,210 probesets mapped to exactly one valid gene symbol.
#   5. For a gene represented by one eligible probeset, retain that expression
#      vector unchanged.
#   6. For a gene represented by multiple eligible probesets, calculate the
#      sample-wise median across those probesets.
#
# This script DOES NOT:
#   - rerun Scripts 07A-08A;
#   - re-normalize or impute the expression data;
#   - use outcome data to select probesets;
#   - calculate a Triclosan score;
#   - perform survival analysis, pathway analysis or plotting.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(project_root, "Step2_GSE31519_external_validation")
clean_root <- file.path(step_root, "02_clean_expression")
annotation_root <- file.path(step_root, "03_probe_annotation_audit")
final_root <- file.path(step_root, "04_gene_level_expression")

clean_bundle_file <- file.path(
  clean_root,
  "objects",
  "GSE31519_clean_expression_COMPLETE_bundle.rds"
)
manifest_07d_file <- file.path(
  clean_root,
  "audit",
  "Script07D_output_manifest_with_MD5.csv"
)
report_07d_file <- file.path(
  clean_root,
  "logs",
  "Script07D_COMPLETE_report.txt"
)

annotation_bundle_file <- file.path(
  annotation_root,
  "objects",
  "GSE31519_probe_annotation_AUDIT_bundle.rds"
)
manifest_08a_file <- file.path(
  annotation_root,
  "audit",
  "Script08A_output_manifest_with_MD5.csv"
)
summary_08a_file <- file.path(
  annotation_root,
  "audit",
  "GSE31519_annotation_summary.csv"
)
report_08a_file <- file.path(
  annotation_root,
  "logs",
  "Script08A_COMPLETE_report.txt"
)

required_inputs <- c(
  clean_bundle_file,
  manifest_07d_file,
  report_07d_file,
  annotation_bundle_file,
  manifest_08a_file,
  summary_08a_file,
  report_08a_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]
if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 08B cannot start because required completed inputs are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist: ", step_root, call. = FALSE)
}

# Never overwrite an existing final output directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )
  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty, so Script 08B will not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

# Build all outputs in a staging directory and commit only after every check passes.
stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script08B_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(stage_object_dir, stage_audit_dir, stage_log_dir)))) {
  stop("Unable to create Script 08B staging directories.", call. = FALSE)
}

committed <- FALSE
on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

normalize_existing_path <- function(x) {
  normalizePath(x, winslash = "/", mustWork = TRUE)
}

md5_one <- function(x) {
  unname(tools::md5sum(x))
}

clean_character <- function(x) {
  x <- trimws(as.character(x))
  x[x == ""] <- NA_character_
  x
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)
  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(z) normalizePath(z, winslash = "/", mustWork = FALSE),
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  required_columns <- c("file_name", "size_bytes", "md5")
  assert_true(
    all(required_columns %in% colnames(manifest)),
    paste0("Malformed output manifest: ", manifest_file)
  )
  rows <- which(manifest$file_name == basename(target_file))
  assert_true(
    length(rows) == 1L,
    paste0(
      "The manifest must contain exactly one row for ",
      basename(target_file), ": ", manifest_file
    )
  )
  tolower(trimws(as.character(manifest$md5[rows])))
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(report_file, warn = FALSE, encoding = "UTF-8")
  any(grepl(fixed_text, lines, fixed = TRUE))
}

join_sorted_unique <- function(x) {
  x <- clean_character(x)
  x <- sort(unique(x[!is.na(x)]), method = "radix")
  if (length(x) == 0L) "" else paste(x, collapse = ";")
}

# ------------------------------
# 2. Verify completed input identities by report status and MD5
# ------------------------------
assert_true(
  report_contains(report_07d_file, "SCRIPT07D STATUS: COMPLETE"),
  "Script 07D completion status was not found in its report."
)
assert_true(
  report_contains(report_08a_file, "SCRIPT08A_V2 STATUS: COMPLETE"),
  "Script 08A v2 completion status was not found in its report."
)

expected_clean_md5 <- manifest_expected_md5(
  manifest_07d_file,
  clean_bundle_file
)
observed_clean_md5 <- tolower(md5_one(clean_bundle_file))
assert_true(
  identical(expected_clean_md5, observed_clean_md5),
  paste0(
    "Script 07D clean bundle MD5 mismatch.\nExpected: ",
    expected_clean_md5,
    "\nObserved: ",
    observed_clean_md5
  )
)

expected_annotation_md5 <- manifest_expected_md5(
  manifest_08a_file,
  annotation_bundle_file
)
observed_annotation_md5 <- tolower(md5_one(annotation_bundle_file))
assert_true(
  identical(expected_annotation_md5, observed_annotation_md5),
  paste0(
    "Script 08A annotation bundle MD5 mismatch.\nExpected: ",
    expected_annotation_md5,
    "\nObserved: ",
    observed_annotation_md5
  )
)

summary_08a <- read.csv(
  summary_08a_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
assert_true(
  all(c("item", "value") %in% colnames(summary_08a)),
  "Script 08A annotation summary is malformed."
)
assert_true(
  !anyDuplicated(summary_08a$item),
  "Script 08A annotation summary contains duplicated item names."
)
summary_lookup <- setNames(as.character(summary_08a$value), summary_08a$item)

required_summary_items <- c(
  "Source_clean_matrix_probeset_number",
  "Retained_complete_AFFX_controls",
  "Non_AFFX_probesets_submitted_for_annotation",
  "Probesets_with_exactly_one_valid_symbol",
  "Probesets_with_multiple_valid_symbols",
  "Probesets_without_valid_symbol",
  "Completion_status"
)
assert_true(
  all(required_summary_items %in% names(summary_lookup)),
  "Script 08A annotation summary is missing required audit items."
)
assert_true(
  identical(summary_lookup[["Completion_status"]], "COMPLETE"),
  "Script 08A annotation summary is not marked COMPLETE."
)

# ------------------------------
# 3. Read and independently validate both completed RDS bundles
# ------------------------------
clean_bundle <- readRDS(clean_bundle_file)
annotation_bundle <- readRDS(annotation_bundle_file)

required_clean_fields <- c(
  "project",
  "step",
  "script",
  "source_accession",
  "expression_matrix",
  "phenotype",
  "removed_AFFX_control_probes",
  "postfilter_summary",
  "sample_alignment_audit",
  "provenance"
)
assert_true(
  is.list(clean_bundle) &&
    all(required_clean_fields %in% names(clean_bundle)),
  "The Script 07D clean bundle is missing required fields."
)

required_annotation_fields <- c(
  "project",
  "step",
  "script",
  "source_accession",
  "source_clean_bundle_md5",
  "source_expression_dimensions",
  "source_expression_probeset_ids",
  "removed_affx_control_probeset_ids",
  "retained_complete_affx_control_audit",
  "annotation_input_non_affx_probeset_ids",
  "source_sample_ids",
  "annotation_package_versions",
  "annotation_database_metadata",
  "full_probe_annotation",
  "probe_annotation_status",
  "unmapped_probes",
  "multisymbol_probe_annotation",
  "valid_probe_symbol_pairs",
  "gene_probe_multiplicity",
  "annotation_summary",
  "decision_status"
)
assert_true(
  is.list(annotation_bundle) &&
    all(required_annotation_fields %in% names(annotation_bundle)),
  "The Script 08A annotation bundle is missing required fields."
)

assert_true(
  identical(as.character(clean_bundle$source_accession), "GSE31519") &&
    identical(as.character(annotation_bundle$source_accession), "GSE31519"),
  "At least one input bundle is not for GSE31519."
)
assert_true(
  identical(
    tolower(as.character(annotation_bundle$source_clean_bundle_md5)),
    observed_clean_md5
  ),
  "The Script 08A bundle does not point to the verified Script 07D clean bundle."
)

expr_probe <- clean_bundle$expression_matrix
phenotype <- clean_bundle$phenotype

assert_true(is.matrix(expr_probe), "Clean expression_matrix is not a matrix.")
assert_true(is.numeric(expr_probe), "Clean expression_matrix is not numeric.")
assert_true(
  identical(dim(expr_probe), c(22268L, 579L)),
  paste0(
    "Unexpected clean expression dimensions: ",
    paste(dim(expr_probe), collapse = " x "),
    ". Expected 22268 x 579."
  )
)
assert_true(
  !is.null(rownames(expr_probe)) && !anyDuplicated(rownames(expr_probe)),
  "Clean expression probeset IDs are missing or duplicated."
)
assert_true(
  !is.null(colnames(expr_probe)) && !anyDuplicated(colnames(expr_probe)),
  "Clean expression sample IDs are missing or duplicated."
)
assert_true(
  sum(!is.finite(expr_probe)) == 0L,
  "Clean expression matrix contains a non-finite value."
)
assert_true(
  is.data.frame(phenotype) &&
    nrow(phenotype) == 579L &&
    "sample_id" %in% colnames(phenotype),
  "The phenotype table is missing, malformed or not 579 rows."
)
assert_true(
  identical(colnames(expr_probe), as.character(phenotype$sample_id)),
  "Clean expression columns and phenotype rows are not identically ordered."
)
assert_true(
  identical(
    as.character(annotation_bundle$source_expression_probeset_ids),
    rownames(expr_probe)
  ),
  "Script 08A source probeset order differs from the verified clean matrix."
)
assert_true(
  identical(
    as.character(annotation_bundle$source_sample_ids),
    colnames(expr_probe)
  ),
  "Script 08A source sample order differs from the verified clean matrix."
)
assert_true(
  identical(
    as.integer(annotation_bundle$source_expression_dimensions),
    as.integer(dim(expr_probe))
  ),
  "Script 08A source dimensions differ from the verified clean matrix."
)

# ------------------------------
# 4. Reconstruct the one-row-per-probeset resolution from the audit bundle
# ------------------------------
probe_ids <- rownames(expr_probe)
affx_mask <- grepl("^AFFX-", probe_ids, ignore.case = FALSE)
retained_affx_ids <- probe_ids[affx_mask]
non_affx_ids <- probe_ids[!affx_mask]

assert_true(
  length(retained_affx_ids) == 53L,
  paste0(
    "Unexpected retained complete AFFX count: ",
    length(retained_affx_ids),
    ". Expected 53."
  )
)
assert_true(
  length(non_affx_ids) == 22215L,
  paste0(
    "Unexpected non-AFFX probeset count: ",
    length(non_affx_ids),
    ". Expected 22,215."
  )
)
assert_true(
  identical(
    as.character(annotation_bundle$annotation_input_non_affx_probeset_ids),
    non_affx_ids
  ),
  "Script 08A annotation-input probeset order differs from the clean matrix."
)

probe_status <- annotation_bundle$probe_annotation_status
valid_pairs <- annotation_bundle$valid_probe_symbol_pairs

assert_true(
  is.data.frame(probe_status) &&
    nrow(probe_status) == 22215L &&
    all(
      c(
        "input_probe_order",
        "probeset_id",
        "valid_gene_symbol_number",
        "annotation_status"
      ) %in% colnames(probe_status)
    ),
  "Script 08A one-row-per-probeset status table is malformed."
)
assert_true(
  !anyDuplicated(probe_status$probeset_id),
  "Script 08A status table contains duplicated probeset IDs."
)
assert_true(
  identical(as.character(probe_status$probeset_id), non_affx_ids),
  "Script 08A status-table probeset order differs from the clean matrix."
)

allowed_status <- c(
  "UNIQUE_GENE_SYMBOL",
  "MULTIPLE_GENE_SYMBOLS",
  "UNMAPPED_NO_VALID_SYMBOL"
)
assert_true(
  all(probe_status$annotation_status %in% allowed_status),
  "Script 08A status table contains an unrecognized annotation status."
)

n_unique_probe <- sum(
  probe_status$annotation_status == "UNIQUE_GENE_SYMBOL"
)
n_multisymbol_probe <- sum(
  probe_status$annotation_status == "MULTIPLE_GENE_SYMBOLS"
)
n_unmapped_probe <- sum(
  probe_status$annotation_status == "UNMAPPED_NO_VALID_SYMBOL"
)

assert_true(
  n_unique_probe == 20210L,
  paste0(
    "Unexpected uniquely mapped probeset count: ",
    n_unique_probe,
    ". Expected 20,210."
  )
)
assert_true(
  n_multisymbol_probe == 836L,
  paste0(
    "Unexpected multi-symbol probeset count: ",
    n_multisymbol_probe,
    ". Expected 836."
  )
)
assert_true(
  n_unmapped_probe == 1169L,
  paste0(
    "Unexpected unmapped probeset count: ",
    n_unmapped_probe,
    ". Expected 1,169."
  )
)
assert_true(
  n_unique_probe + n_multisymbol_probe + n_unmapped_probe == 22215L,
  "Non-AFFX annotation-status counts do not sum to 22,215."
)

assert_true(
  is.data.frame(valid_pairs) &&
    all(c("probeset_id", "gene_symbol") %in% colnames(valid_pairs)),
  "Script 08A valid probe-symbol table is malformed."
)
valid_pairs$probeset_id <- clean_character(valid_pairs$probeset_id)
valid_pairs$gene_symbol <- clean_character(valid_pairs$gene_symbol)
valid_pairs <- unique(
  valid_pairs[
    !is.na(valid_pairs$probeset_id) &
      !is.na(valid_pairs$gene_symbol),
    c("probeset_id", "gene_symbol"),
    drop = FALSE
  ]
)

eligible_status <- probe_status[
  probe_status$annotation_status == "UNIQUE_GENE_SYMBOL",
  ,
  drop = FALSE
]
eligible_ids <- as.character(eligible_status$probeset_id)

pair_count_for_eligible <- table(
  valid_pairs$probeset_id[valid_pairs$probeset_id %in% eligible_ids]
)
assert_true(
  length(pair_count_for_eligible) == length(eligible_ids) &&
    all(pair_count_for_eligible == 1L),
  "At least one uniquely mapped probeset does not have exactly one valid symbol pair."
)

pair_index <- match(eligible_ids, valid_pairs$probeset_id)
assert_true(
  !anyNA(pair_index),
  "At least one uniquely mapped probeset is absent from the valid symbol-pair table."
)

eligible_map <- data.frame(
  input_probe_order = as.integer(eligible_status$input_probe_order),
  source_matrix_row = match(eligible_ids, probe_ids),
  probeset_id = eligible_ids,
  gene_symbol = as.character(valid_pairs$gene_symbol[pair_index]),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(eligible_map) == 20210L &&
    !anyDuplicated(eligible_map$probeset_id) &&
    !anyNA(eligible_map$source_matrix_row) &&
    !anyNA(eligible_map$gene_symbol),
  "Eligible one-probeset-to-one-symbol mapping is incomplete or duplicated."
)
assert_true(
  all(eligible_map$probeset_id %in% rownames(expr_probe)),
  "An eligible probeset is absent from the clean expression matrix."
)

# ------------------------------
# 5. Build a complete one-row-per-source-probeset resolution audit
# ------------------------------
candidate_symbols_by_probe <- split(
  valid_pairs$gene_symbol,
  valid_pairs$probeset_id
)

resolution_audit <- data.frame(
  source_matrix_row = seq_along(probe_ids),
  probeset_id = probe_ids,
  annotation_status = NA_character_,
  valid_gene_symbol_number = NA_integer_,
  candidate_gene_symbols = "",
  gene_symbol_used = "",
  action_in_script08b = NA_character_,
  reason = NA_character_,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

resolution_audit$annotation_status[affx_mask] <- "AFFX_CONTROL"
resolution_audit$valid_gene_symbol_number[affx_mask] <- NA_integer_
resolution_audit$action_in_script08b[affx_mask] <- "EXCLUDED"
resolution_audit$reason[affx_mask] <- paste0(
  "Complete AFFX platform-control probeset retained in the Script 07D clean ",
  "matrix but excluded from biological gene-level expression."
)

non_affx_rows <- match(non_affx_ids, probe_ids)
resolution_audit$annotation_status[non_affx_rows] <-
  as.character(probe_status$annotation_status)
resolution_audit$valid_gene_symbol_number[non_affx_rows] <-
  as.integer(probe_status$valid_gene_symbol_number)

for (i in seq_along(non_affx_ids)) {
  probe_id <- non_affx_ids[i]
  source_row <- non_affx_rows[i]
  symbols <- candidate_symbols_by_probe[[probe_id]]
  resolution_audit$candidate_gene_symbols[source_row] <-
    join_sorted_unique(symbols)
}

unique_rows <- match(eligible_ids, probe_ids)
resolution_audit$gene_symbol_used[unique_rows] <- eligible_map$gene_symbol
resolution_audit$action_in_script08b[unique_rows] <- "INCLUDED"
resolution_audit$reason[unique_rows] <- paste0(
  "Probeset maps to exactly one valid gene symbol and is eligible for ",
  "gene-level aggregation."
)

multisymbol_ids <- as.character(
  probe_status$probeset_id[
    probe_status$annotation_status == "MULTIPLE_GENE_SYMBOLS"
  ]
)
multisymbol_rows <- match(multisymbol_ids, probe_ids)
resolution_audit$action_in_script08b[multisymbol_rows] <- "EXCLUDED"
resolution_audit$reason[multisymbol_rows] <- paste0(
  "Probeset maps to multiple valid gene symbols; excluded to avoid assigning ",
  "one measured expression vector to several genes."
)

unmapped_ids <- as.character(
  probe_status$probeset_id[
    probe_status$annotation_status == "UNMAPPED_NO_VALID_SYMBOL"
  ]
)
unmapped_rows <- match(unmapped_ids, probe_ids)
resolution_audit$action_in_script08b[unmapped_rows] <- "EXCLUDED"
resolution_audit$reason[unmapped_rows] <- paste0(
  "No valid gene symbol was available in the verified Script 08A annotation."
)

assert_true(
  nrow(resolution_audit) == 22268L &&
    !anyDuplicated(resolution_audit$probeset_id),
  "The complete probeset-resolution audit is incomplete or duplicated."
)
assert_true(
  !anyNA(resolution_audit$action_in_script08b) &&
    !anyNA(resolution_audit$reason),
  "At least one probeset lacks a final Script 08B action or reason."
)
assert_true(
  sum(resolution_audit$action_in_script08b == "INCLUDED") == 20210L,
  "The probeset-resolution audit does not contain exactly 20,210 included probesets."
)
assert_true(
  sum(resolution_audit$action_in_script08b == "EXCLUDED") == 2058L,
  "The probeset-resolution audit does not contain exactly 2,058 excluded probesets."
)

# ------------------------------
# 6. Construct the primary gene-level expression matrix
# ------------------------------
gene_first_order <- aggregate(
  eligible_map$input_probe_order,
  by = list(gene_symbol = eligible_map$gene_symbol),
  FUN = min
)
colnames(gene_first_order)[2] <- "first_input_probe_order"
gene_first_order <- gene_first_order[
  order(
    gene_first_order$first_input_probe_order,
    gene_first_order$gene_symbol,
    method = "radix"
  ),
  ,
  drop = FALSE
]
rownames(gene_first_order) <- NULL
gene_order <- as.character(gene_first_order$gene_symbol)

assert_true(
  length(gene_order) == 12650L && !anyDuplicated(gene_order),
  paste0(
    "Unexpected eligible unique gene-symbol count: ",
    length(gene_order),
    ". Expected 12,650."
  )
)

probe_ids_by_gene <- split(
  eligible_map$probeset_id,
  factor(eligible_map$gene_symbol, levels = gene_order)
)
probe_count_by_gene <- lengths(probe_ids_by_gene)

assert_true(
  sum(probe_count_by_gene) == 20210L,
  "Eligible probeset counts across genes do not sum to 20,210."
)
assert_true(
  sum(probe_count_by_gene == 1L) == 8067L,
  paste0(
    "Unexpected one-probeset gene count: ",
    sum(probe_count_by_gene == 1L),
    ". Expected 8,067."
  )
)
assert_true(
  sum(probe_count_by_gene > 1L) == 4583L,
  paste0(
    "Unexpected multi-probeset gene count: ",
    sum(probe_count_by_gene > 1L),
    ". Expected 4,583."
  )
)
assert_true(
  max(probe_count_by_gene) == 13L,
  paste0(
    "Unexpected maximum eligible probesets per gene: ",
    max(probe_count_by_gene),
    ". Expected 13."
  )
)

expr_gene <- matrix(
  NA_real_,
  nrow = length(gene_order),
  ncol = ncol(expr_probe),
  dimnames = list(gene_order, colnames(expr_probe))
)

for (i in seq_along(gene_order)) {
  probes <- as.character(probe_ids_by_gene[[i]])
  if (length(probes) == 1L) {
    expr_gene[i, ] <- expr_probe[probes, ]
  } else {
    expr_gene[i, ] <- apply(
      expr_probe[probes, , drop = FALSE],
      2L,
      median
    )
  }
}

storage.mode(expr_gene) <- "double"

assert_true(
  identical(dim(expr_gene), c(12650L, 579L)),
  paste0(
    "Unexpected gene-level matrix dimensions: ",
    paste(dim(expr_gene), collapse = " x "),
    ". Expected 12650 x 579."
  )
)
assert_true(
  !is.null(rownames(expr_gene)) && !anyDuplicated(rownames(expr_gene)),
  "Gene-level matrix row names are missing or duplicated."
)
assert_true(
  identical(rownames(expr_gene), gene_order),
  "Gene-level matrix row order differs from the audited gene order."
)
assert_true(
  identical(colnames(expr_gene), colnames(expr_probe)),
  "Gene-level matrix sample columns differ from the source clean matrix."
)
assert_true(
  identical(colnames(expr_gene), as.character(phenotype$sample_id)),
  "Gene-level matrix sample columns are not aligned to the phenotype table."
)
assert_true(
  sum(!is.finite(expr_gene)) == 0L,
  "Gene-level matrix contains a non-finite value."
)

# Confirm that every one-probeset gene was transferred without numeric alteration.
single_gene_names <- gene_order[probe_count_by_gene == 1L]
single_gene_probe_ids <- vapply(
  probe_ids_by_gene[single_gene_names],
  function(x) as.character(x[[1L]]),
  character(1)
)
single_gene_check <- vapply(
  seq_along(single_gene_names),
  function(i) {
    identical(
      as.numeric(expr_gene[single_gene_names[i], ]),
      as.numeric(expr_probe[single_gene_probe_ids[i], ])
    )
  },
  logical(1)
)
assert_true(
  all(single_gene_check),
  "At least one one-probeset gene was numerically altered."
)

# ------------------------------
# 7. Build gene aggregation and integrity audits
# ------------------------------
gene_aggregation_audit <- data.frame(
  gene_matrix_row = seq_along(gene_order),
  gene_symbol = gene_order,
  first_input_probe_order = as.integer(
    gene_first_order$first_input_probe_order
  ),
  probeset_number = as.integer(probe_count_by_gene),
  aggregation_method = ifelse(
    probe_count_by_gene == 1L,
    "SINGLE_PROBESET_UNCHANGED",
    "SAMPLE_WISE_MEDIAN_ACROSS_PROBESETS"
  ),
  probeset_ids = vapply(
    probe_ids_by_gene,
    function(x) paste(as.character(x), collapse = ";"),
    character(1)
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(gene_aggregation_audit) == 12650L &&
    !anyDuplicated(gene_aggregation_audit$gene_symbol),
  "Gene aggregation audit is incomplete or duplicated."
)
assert_true(
  identical(
    as.character(gene_aggregation_audit$gene_symbol),
    rownames(expr_gene)
  ),
  "Gene aggregation audit order differs from the gene-level matrix."
)

integrity_summary <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Source_clean_bundle_MD5",
    "Source_annotation_bundle_MD5",
    "Source_probeset_rows",
    "Source_samples",
    "Retained_complete_AFFX_controls_excluded",
    "Unmapped_probesets_excluded",
    "Multisymbol_probesets_excluded",
    "Unique_symbol_probesets_included",
    "Total_excluded_source_rows",
    "Total_resolved_source_rows",
    "Gene_level_rows",
    "Gene_level_samples",
    "Genes_from_one_probeset",
    "Genes_from_multiple_probesets",
    "Maximum_eligible_probesets_per_gene",
    "Multi_probe_aggregation_rule",
    "Outcome_guided_probe_selection",
    "Additional_normalization_performed",
    "Expression_value_imputation_performed",
    "Nonfinite_values_in_gene_matrix",
    "Expression_phenotype_order_identical",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "08B",
    observed_clean_md5,
    observed_annotation_md5,
    nrow(expr_probe),
    ncol(expr_probe),
    length(retained_affx_ids),
    n_unmapped_probe,
    n_multisymbol_probe,
    n_unique_probe,
    sum(resolution_audit$action_in_script08b == "EXCLUDED"),
    nrow(resolution_audit),
    nrow(expr_gene),
    ncol(expr_gene),
    sum(probe_count_by_gene == 1L),
    sum(probe_count_by_gene > 1L),
    max(probe_count_by_gene),
    "Sample-wise median across eligible uniquely mapped probesets",
    "FALSE",
    "FALSE",
    "FALSE",
    sum(!is.finite(expr_gene)),
    identical(colnames(expr_gene), as.character(phenotype$sample_id)),
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 8. Save the complete gene-level bundle and audit files in staging
# ------------------------------
input_manifest <- make_manifest(required_inputs)

gene_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script08B",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_clean_bundle_file = normalize_existing_path(clean_bundle_file),
  source_clean_bundle_md5 = observed_clean_md5,
  source_annotation_bundle_file = normalize_existing_path(
    annotation_bundle_file
  ),
  source_annotation_bundle_md5 = observed_annotation_md5,
  aggregation_policy = list(
    retained_affx_controls = "Excluded from biological gene matrix",
    unmapped_probesets = "Excluded",
    multisymbol_probesets = paste0(
      "Excluded; no duplication of one probeset expression vector across ",
      "multiple genes"
    ),
    unique_symbol_probesets = "Included",
    one_probeset_per_gene = "Expression vector retained unchanged",
    multiple_probesets_per_gene = "Sample-wise median",
    outcome_guided_selection = FALSE,
    additional_normalization = FALSE,
    value_imputation = FALSE
  ),
  expression_matrix = expr_gene,
  phenotype = phenotype,
  probe_resolution_audit = resolution_audit,
  gene_aggregation_audit = gene_aggregation_audit,
  annotation_package_versions =
    annotation_bundle$annotation_package_versions,
  annotation_database_metadata =
    annotation_bundle$annotation_database_metadata,
  integrity_summary = integrity_summary,
  provenance = list(
    source_probe_dimensions = dim(expr_probe),
    final_gene_dimensions = dim(expr_gene),
    included_probeset_number = n_unique_probe,
    excluded_affx_control_number = length(retained_affx_ids),
    excluded_unmapped_probeset_number = n_unmapped_probe,
    excluded_multisymbol_probeset_number = n_multisymbol_probe,
    gene_symbol_number = nrow(expr_gene),
    nonfinite_value_number = sum(!is.finite(expr_gene))
  )
)
class(gene_bundle) <- c("GSE31519_gene_level_bundle", "list")

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_gene_level_expression_COMPLETE_bundle.rds"
)
stage_resolution_file <- file.path(
  stage_audit_dir,
  "GSE31519_probe_resolution_audit.csv"
)
stage_aggregation_file <- file.path(
  stage_audit_dir,
  "GSE31519_gene_aggregation_audit.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_gene_level_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script08B_input_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script08B_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script08B_COMPLETE_report.txt"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script08B_output_manifest_with_MD5.csv"
)

saveRDS(gene_bundle, stage_bundle_file, compress = "gzip")
write_csv_utf8(resolution_audit, stage_resolution_file)
write_csv_utf8(gene_aggregation_audit, stage_aggregation_file)
write_csv_utf8(integrity_summary, stage_summary_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)

session_lines <- capture.output(sessionInfo())
writeLines(
  enc2utf8(session_lines),
  con = stage_session_file,
  useBytes = TRUE
)

# Independently read back and verify the staged core bundle before commit.
bundle_check <- readRDS(stage_bundle_file)
assert_true(
  is.list(bundle_check) &&
    all(
      c(
        "expression_matrix",
        "phenotype",
        "probe_resolution_audit",
        "gene_aggregation_audit",
        "integrity_summary"
      ) %in% names(bundle_check)
    ),
  "The staged Script 08B bundle cannot be read back with required fields."
)
assert_true(
  identical(dim(bundle_check$expression_matrix), c(12650L, 579L)),
  "The staged Script 08B bundle has incorrect expression dimensions."
)
assert_true(
  sum(!is.finite(bundle_check$expression_matrix)) == 0L,
  "The staged Script 08B bundle contains a non-finite expression value."
)
assert_true(
  identical(
    colnames(bundle_check$expression_matrix),
    as.character(bundle_check$phenotype$sample_id)
  ),
  "The staged Script 08B bundle has expression/phenotype misalignment."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 08B",
  "GSE31519 gene-level expression matrix construction",
  "============================================================",
  paste0(
    "Completion time: ",
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  ),
  paste0("Source Script 07D bundle MD5: ", observed_clean_md5),
  paste0("Source Script 08A bundle MD5: ", observed_annotation_md5),
  paste0(
    "Source clean matrix: ",
    nrow(expr_probe),
    " probesets x ",
    ncol(expr_probe),
    " samples"
  ),
  paste0("Retained complete AFFX controls excluded: ", length(retained_affx_ids)),
  paste0("Unmapped probesets excluded: ", n_unmapped_probe),
  paste0("Multi-symbol probesets excluded: ", n_multisymbol_probe),
  paste0("Uniquely mapped probesets included: ", n_unique_probe),
  paste0(
    "Gene-level matrix: ",
    nrow(expr_gene),
    " genes x ",
    ncol(expr_gene),
    " samples"
  ),
  paste0("Genes represented by one probeset: ", sum(probe_count_by_gene == 1L)),
  paste0(
    "Genes represented by multiple probesets: ",
    sum(probe_count_by_gene > 1L)
  ),
  paste0(
    "Maximum eligible probesets for one gene: ",
    max(probe_count_by_gene)
  ),
  paste0(
    "Multi-probe aggregation: sample-wise median across uniquely mapped probesets"
  ),
  "Outcome-guided probe selection: FALSE",
  "Additional normalization: FALSE",
  "Expression value imputation: FALSE",
  paste0(
    "Non-finite values in gene-level matrix: ",
    sum(!is.finite(expr_gene))
  ),
  paste0(
    "Expression/phenotype order identical: ",
    identical(colnames(expr_gene), as.character(phenotype$sample_id))
  ),
  paste0("Gene-level bundle MD5: ", bundle_md5),
  "",
  "SCRIPT08B STATUS: COMPLETE",
  "No Triclosan score, survival model, pathway analysis or plot was produced.",
  "============================================================"
)
writeLines(
  enc2utf8(report_lines),
  con = stage_report_file,
  useBytes = TRUE
)

manifest_paths <- c(
  stage_bundle_file,
  stage_resolution_file,
  stage_aggregation_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)
manifest_display_paths <- c(
  file.path(
    final_root,
    "objects",
    basename(stage_bundle_file)
  ),
  file.path(
    final_root,
    "audit",
    basename(stage_resolution_file)
  ),
  file.path(
    final_root,
    "audit",
    basename(stage_aggregation_file)
  ),
  file.path(
    final_root,
    "audit",
    basename(stage_summary_file)
  ),
  file.path(
    final_root,
    "audit",
    basename(stage_input_manifest_file)
  ),
  file.path(
    final_root,
    "logs",
    basename(stage_session_file)
  ),
  file.path(
    final_root,
    "logs",
    basename(stage_report_file)
  )
)
output_manifest <- make_manifest(
  manifest_paths,
  manifest_display_paths
)
write_csv_utf8(output_manifest, stage_output_manifest_file)

required_stage_outputs <- c(
  manifest_paths,
  stage_output_manifest_file
)
assert_true(
  all(file.exists(required_stage_outputs)),
  "At least one required Script 08B staged output is missing."
)
assert_true(
  all(file.info(required_stage_outputs)$size > 0),
  "At least one required Script 08B staged output is empty."
)

# ------------------------------
# 9. Commit the completed staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 08B output directory unexpectedly appeared before commit."
)

commit_ok <- file.rename(stage_root, final_root)
assert_true(
  isTRUE(commit_ok) && dir.exists(final_root),
  paste0(
    "All Script 08B analyses completed, but the staging directory could not ",
    "be committed to:\n",
    final_root
  )
)
committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_gene_level_expression_COMPLETE_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script08B_COMPLETE_report.txt"
)

assert_true(
  file.exists(final_bundle_file) &&
    file.exists(final_report_file),
  "Script 08B final output verification failed after commit."
)

cat("============================================================\n")
cat("Script 08B completed successfully.\n")
cat("Source probesets: ", nrow(expr_probe), "\n", sep = "")
cat("Source samples: ", ncol(expr_probe), "\n", sep = "")
cat("AFFX controls excluded: ", length(retained_affx_ids), "\n", sep = "")
cat("Unmapped probesets excluded: ", n_unmapped_probe, "\n", sep = "")
cat("Multi-symbol probesets excluded: ", n_multisymbol_probe, "\n", sep = "")
cat("Unique-symbol probesets included: ", n_unique_probe, "\n", sep = "")
cat("Gene-level genes: ", nrow(expr_gene), "\n", sep = "")
cat("Gene-level samples: ", ncol(expr_gene), "\n", sep = "")
cat(
  "Single-probeset genes: ",
  sum(probe_count_by_gene == 1L),
  "\n",
  sep = ""
)
cat(
  "Median-collapsed multi-probeset genes: ",
  sum(probe_count_by_gene > 1L),
  "\n",
  sep = ""
)
cat("Non-finite values: ", sum(!is.finite(expr_gene)), "\n", sep = "")
cat(
  "Expression/phenotype order identical: ",
  identical(colnames(expr_gene), as.character(phenotype$sample_id)),
  "\n",
  sep = ""
)
cat(
  "Bundle: ",
  normalizePath(final_bundle_file, winslash = "/", mustWork = TRUE),
  "\n",
  sep = ""
)
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("✅ 已完成\n")

# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 09B
#
# Purpose:
#   Continue strictly from the accepted Script 08B gene-level expression bundle
#   and Script 09A clinical audit bundle.
#
#   Curate the documented GSE31519 120-month event-free survival endpoint:
#     - fu_120: follow-up time in months, administratively censored at 120 months;
#     - ev120: 1 = event, 0 = censored;
#     - endpoint type: pooled EFS using the available RFS or DMFS endpoint for
#       each source cohort, as described in the source publication.
#
#   Preserve all 579 samples and all raw clinical values.
#   Create:
#     1) the public-data-complete EFS set (expected n = 383);
#     2) a positive-time sensitivity EFS set (expected n = 379), excluding only
#        the four records with fu_120 == 0 while retaining them in the full table.
#
# This script DOES NOT:
#   - rerun Scripts 07A-09A;
#   - modify expression values;
#   - impute clinical values;
#   - fit Cox, Kaplan-Meier, ROC or any other outcome model;
#   - calculate a Triclosan score;
#   - select a score cutoff;
#   - delete any source sample or source clinical record.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed project paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(project_root, "Step2_GSE31519_external_validation")

gene_root <- file.path(step_root, "04_gene_level_expression")
audit09a_root <- file.path(step_root, "05_clinical_endpoint_audit")
final_root <- file.path(step_root, "06_curated_clinical_endpoint")

gene_bundle_file <- file.path(
  gene_root,
  "objects",
  "GSE31519_gene_level_expression_COMPLETE_bundle.rds"
)
gene_manifest_file <- file.path(
  gene_root,
  "audit",
  "Script08B_output_manifest_with_MD5.csv"
)
gene_report_file <- file.path(
  gene_root,
  "logs",
  "Script08B_COMPLETE_report.txt"
)

audit09a_bundle_file <- file.path(
  audit09a_root,
  "objects",
  "GSE31519_clinical_endpoint_AUDIT_bundle.rds"
)
audit09a_manifest_file <- file.path(
  audit09a_root,
  "audit",
  "Script09A_output_manifest_with_MD5.csv"
)
audit09a_report_file <- file.path(
  audit09a_root,
  "logs",
  "Script09A_COMPLETE_report.txt"
)

required_inputs <- c(
  gene_bundle_file,
  gene_manifest_file,
  gene_report_file,
  audit09a_bundle_file,
  audit09a_manifest_file,
  audit09a_report_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]
if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 09B cannot start because required completed inputs are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist: ", step_root, call. = FALSE)
}

# Never overwrite an existing output directory.
if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )
  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty, so Script 09B ",
        "will not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script09B_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(stage_object_dir, stage_audit_dir, stage_log_dir)))) {
  stop("Unable to create Script 09B staging directories.", call. = FALSE)
}

committed <- FALSE
on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

normalize_existing_path <- function(x) {
  normalizePath(x, winslash = "/", mustWork = TRUE)
}

md5_one <- function(x) {
  unname(tools::md5sum(x))
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(report_file, warn = FALSE, encoding = "UTF-8")
  any(grepl(fixed_text, lines, fixed = TRUE))
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)
  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(z) normalizePath(z, winslash = "/", mustWork = FALSE),
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  required_columns <- c("file_name", "size_bytes", "md5")
  assert_true(
    all(required_columns %in% colnames(manifest)),
    paste0("Malformed output manifest: ", manifest_file)
  )
  rows <- which(manifest$file_name == basename(target_file))
  assert_true(
    length(rows) == 1L,
    paste0(
      "The manifest must contain exactly one row for ",
      basename(target_file), ": ", manifest_file
    )
  )
  tolower(trimws(as.character(manifest$md5[rows])))
}

clean_character <- function(x) {
  y <- trimws(as.character(x))
  missing_tokens <- c(
    "", "NA", "N/A", "na", "n/a", "NaN", "NULL", "null",
    "Unknown", "UNKNOWN", "unknown",
    "Not available", "NOT AVAILABLE", "not available",
    "Not reported", "NOT REPORTED", "not reported"
  )
  y[y %in% missing_tokens] <- NA_character_
  y
}

safe_numeric <- function(x) {
  suppressWarnings(as.numeric(clean_character(x)))
}

safe_integer <- function(x) {
  y <- safe_numeric(x)
  nonmissing <- !is.na(y)
  assert_true(
    all(abs(y[nonmissing] - round(y[nonmissing])) < 1e-8),
    "A value expected to be integer-like is not integer-like."
  )
  as.integer(round(y))
}

collapse_unique <- function(x) {
  y <- unique(clean_character(x))
  y <- sort(y[!is.na(y)])
  if (length(y) == 0L) "" else paste(y, collapse = ";")
}

format_count_fraction <- function(n, denominator) {
  if (denominator == 0L) return("0/0")
  paste0(n, "/", denominator, " (", sprintf("%.4f", n / denominator), ")")
}

build_dataset_audit <- function(clinical_table) {
  dataset_ids <- sort(unique(clinical_table$source_dataset_id))
  rows <- vector("list", length(dataset_ids))

  for (i in seq_along(dataset_ids)) {
    dataset_id <- dataset_ids[i]
    d <- clinical_table[
      clinical_table$source_dataset_id == dataset_id,
      ,
      drop = FALSE
    ]

    endpoint_d <- d[d$efs_complete_public_set, , drop = FALSE]
    positive_d <- d[d$efs_positive_time_sensitivity_set, , drop = FALSE]

    rows[[i]] <- data.frame(
      source_dataset_id = dataset_id,
      total_sample_number = nrow(d),
      array_types = collapse_unique(d$array_type),
      biopsy_method_codes = collapse_unique(d$biopsy_method_code_raw),
      endpoint_complete_number = sum(d$efs_complete_public_set),
      endpoint_missing_number = sum(d$efs_missing_both),
      endpoint_complete_fraction = mean(d$efs_complete_public_set),
      event_number_complete_set = sum(
        endpoint_d$efs_event == 1L,
        na.rm = TRUE
      ),
      censored_number_complete_set = sum(
        endpoint_d$efs_event == 0L,
        na.rm = TRUE
      ),
      zero_time_number_complete_set = sum(
        endpoint_d$efs_zero_time,
        na.rm = TRUE
      ),
      positive_time_sensitivity_number = nrow(positive_d),
      event_fraction_among_complete = if (nrow(endpoint_d) == 0L) {
        NA_real_
      } else {
        mean(endpoint_d$efs_event == 1L)
      },
      minimum_time_months_complete = if (nrow(endpoint_d) == 0L) {
        NA_real_
      } else {
        min(endpoint_d$efs_time_months)
      },
      median_time_months_complete = if (nrow(endpoint_d) == 0L) {
        NA_real_
      } else {
        median(endpoint_d$efs_time_months)
      },
      maximum_time_months_complete = if (nrow(endpoint_d) == 0L) {
        NA_real_
      } else {
        max(endpoint_d$efs_time_months)
      },
      all_complete_cases_are_events = if (nrow(endpoint_d) == 0L) {
        FALSE
      } else {
        all(endpoint_d$efs_event == 1L)
      },
      all_complete_cases_are_censored = if (nrow(endpoint_d) == 0L) {
        FALSE
      } else {
        all(endpoint_d$efs_event == 0L)
      },
      expression_or_outcome_model_fitted = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  do.call(rbind, rows)
}

build_covariate_availability <- function(clinical_table) {
  set_definitions <- list(
    ALL_579 = rep(TRUE, nrow(clinical_table)),
    EFS_COMPLETE_PUBLIC_383 = clinical_table$efs_complete_public_set,
    EFS_POSITIVE_TIME_SENSITIVITY_379 =
      clinical_table$efs_positive_time_sensitivity_set
  )

  variables <- c(
    "age_years",
    "nodal_status",
    "tumor_size_group",
    "histologic_grade_group",
    "adjuvant_chemotherapy",
    "source_dataset_id",
    "array_type",
    "biopsy_method_code_raw"
  )

  rows <- list()
  index <- 0L

  for (set_name in names(set_definitions)) {
    mask <- set_definitions[[set_name]]
    denominator <- sum(mask)

    for (variable_name in variables) {
      index <- index + 1L
      x <- clinical_table[[variable_name]][mask]
      nonmissing <- sum(!is.na(x))
      rows[[index]] <- data.frame(
        analysis_set = set_name,
        variable_name = variable_name,
        analysis_set_sample_number = denominator,
        nonmissing_number = nonmissing,
        missing_number = denominator - nonmissing,
        nonmissing_fraction = if (denominator == 0L) {
          NA_real_
        } else {
          nonmissing / denominator
        },
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
  }

  do.call(rbind, rows)
}

build_candidate_complete_case_audit <- function(clinical_table) {
  models <- list(
    AGE = c("age_years"),
    NODAL = c("nodal_status"),
    AGE_NODAL = c("age_years", "nodal_status"),
    AGE_NODAL_SIZE_GRADE = c(
      "age_years",
      "nodal_status",
      "tumor_size_group",
      "histologic_grade_group"
    ),
    AGE_NODAL_SIZE_GRADE_CHEMO = c(
      "age_years",
      "nodal_status",
      "tumor_size_group",
      "histologic_grade_group",
      "adjuvant_chemotherapy"
    )
  )

  set_definitions <- list(
    EFS_COMPLETE_PUBLIC_383 = clinical_table$efs_complete_public_set,
    EFS_POSITIVE_TIME_SENSITIVITY_379 =
      clinical_table$efs_positive_time_sensitivity_set
  )

  rows <- list()
  index <- 0L

  for (set_name in names(set_definitions)) {
    set_mask <- set_definitions[[set_name]]
    set_n <- sum(set_mask)

    for (model_name in names(models)) {
      variables <- models[[model_name]]
      complete_mask <- set_mask &
        complete.cases(clinical_table[, variables, drop = FALSE])

      index <- index + 1L
      rows[[index]] <- data.frame(
        analysis_set = set_name,
        candidate_covariate_set = model_name,
        candidate_covariates = paste(variables, collapse = ";"),
        analysis_set_sample_number = set_n,
        complete_covariate_number = sum(complete_mask),
        incomplete_covariate_number = set_n - sum(complete_mask),
        complete_covariate_fraction = if (set_n == 0L) {
          NA_real_
        } else {
          sum(complete_mask) / set_n
        },
        model_fitted = FALSE,
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
  }

  do.call(rbind, rows)
}

# ------------------------------
# 2. Verify accepted input identities
# ------------------------------
assert_true(
  report_contains(gene_report_file, "SCRIPT08B STATUS: COMPLETE"),
  "Script 08B completion status was not found in its report."
)
assert_true(
  report_contains(audit09a_report_file, "SCRIPT09A STATUS: COMPLETE"),
  "Script 09A completion status was not found in its report."
)

expected_gene_md5 <- manifest_expected_md5(
  gene_manifest_file,
  gene_bundle_file
)
observed_gene_md5 <- tolower(md5_one(gene_bundle_file))

assert_true(
  identical(expected_gene_md5, observed_gene_md5),
  paste0(
    "Script 08B bundle MD5 mismatch.\nExpected from manifest: ",
    expected_gene_md5,
    "\nObserved: ",
    observed_gene_md5
  )
)

accepted_gene_bundle_md5 <- "08a6f0bed9aa9860112a65c8ef316657"
assert_true(
  identical(observed_gene_md5, accepted_gene_bundle_md5),
  paste0(
    "The Script 08B bundle does not match the accepted bundle.\nExpected: ",
    accepted_gene_bundle_md5,
    "\nObserved: ",
    observed_gene_md5
  )
)

expected_09a_md5 <- manifest_expected_md5(
  audit09a_manifest_file,
  audit09a_bundle_file
)
observed_09a_md5 <- tolower(md5_one(audit09a_bundle_file))

assert_true(
  identical(expected_09a_md5, observed_09a_md5),
  paste0(
    "Script 09A bundle MD5 mismatch.\nExpected from manifest: ",
    expected_09a_md5,
    "\nObserved: ",
    observed_09a_md5
  )
)

accepted_09a_bundle_md5 <- "e230a2796b3ea70c8b9ec26c4de27904"
assert_true(
  identical(observed_09a_md5, accepted_09a_bundle_md5),
  paste0(
    "The Script 09A bundle does not match the accepted bundle.\nExpected: ",
    accepted_09a_bundle_md5,
    "\nObserved: ",
    observed_09a_md5
  )
)

# ------------------------------
# 3. Read and validate source objects
# ------------------------------
gene_bundle <- readRDS(gene_bundle_file)
audit09a_bundle <- readRDS(audit09a_bundle_file)

required_gene_fields <- c(
  "script",
  "source_accession",
  "expression_matrix",
  "phenotype"
)
assert_true(
  is.list(gene_bundle) &&
    all(required_gene_fields %in% names(gene_bundle)),
  "The Script 08B bundle is missing required fields."
)
assert_true(
  identical(as.character(gene_bundle$script), "Script08B"),
  "The gene-level input bundle was not created by Script 08B."
)
assert_true(
  identical(as.character(gene_bundle$source_accession), "GSE31519"),
  "The gene-level input bundle is not for GSE31519."
)

required_09a_fields <- c(
  "script",
  "source_accession",
  "source_gene_bundle_md5",
  "source_sample_ids",
  "phenotype",
  "summary",
  "policy"
)
assert_true(
  is.list(audit09a_bundle) &&
    all(required_09a_fields %in% names(audit09a_bundle)),
  "The Script 09A bundle is missing required fields."
)
assert_true(
  identical(as.character(audit09a_bundle$script), "Script09A"),
  "The clinical audit input bundle was not created by Script 09A."
)
assert_true(
  identical(as.character(audit09a_bundle$source_accession), "GSE31519"),
  "The clinical audit input bundle is not for GSE31519."
)
assert_true(
  identical(
    tolower(as.character(audit09a_bundle$source_gene_bundle_md5)),
    observed_gene_md5
  ),
  "The Script 09A bundle does not point to the accepted Script 08B bundle."
)

expr_gene <- gene_bundle$expression_matrix
phenotype_08b <- gene_bundle$phenotype
phenotype_09a <- audit09a_bundle$phenotype

assert_true(
  is.matrix(expr_gene) &&
    is.numeric(expr_gene) &&
    identical(dim(expr_gene), c(12650L, 579L)),
  "The accepted gene-level expression matrix is not 12,650 x 579."
)
assert_true(
  sum(!is.finite(expr_gene)) == 0L,
  "The gene-level expression matrix contains non-finite values."
)
assert_true(
  is.data.frame(phenotype_08b) &&
    is.data.frame(phenotype_09a) &&
    identical(phenotype_08b, phenotype_09a),
  "The phenotype table differs between the accepted 08B and 09A bundles."
)

phenotype <- phenotype_09a

required_phenotype_columns <- c(
  "sample_id",
  "datas_new09",
  "Array_type",
  "GSM_accession",
  "Biopsy_Method",
  "nodal",
  "age",
  "t1vsrest",
  "g12vs3",
  "fu_120",
  "ev120",
  "adjuvant_chemotherapy"
)
assert_true(
  all(required_phenotype_columns %in% colnames(phenotype)),
  paste0(
    "The phenotype table is missing required columns: ",
    paste(
      setdiff(required_phenotype_columns, colnames(phenotype)),
      collapse = ", "
    )
  )
)
assert_true(
  nrow(phenotype) == 579L,
  "The phenotype table does not contain 579 samples."
)
assert_true(
  identical(colnames(expr_gene), as.character(phenotype$sample_id)),
  "Expression columns and phenotype rows are not identically ordered."
)
assert_true(
  anyDuplicated(as.character(phenotype$sample_id)) == 0L,
  "Phenotype sample IDs are duplicated."
)

# ------------------------------
# 4. Parse endpoint and raw covariates without changing source values
# ------------------------------
source_dataset_id <- safe_integer(phenotype$datas_new09)
biopsy_method_code_raw <- safe_integer(phenotype$Biopsy_Method)
age_years <- safe_numeric(phenotype$age)
nodal_raw <- safe_integer(phenotype$nodal)
tumor_size_raw <- safe_integer(phenotype$t1vsrest)
grade_raw <- safe_integer(phenotype$g12vs3)
efs_time_months <- safe_numeric(phenotype$fu_120)
efs_event <- safe_integer(phenotype$ev120)
adjuvant_raw <- toupper(clean_character(phenotype$adjuvant_chemotherapy))

assert_true(
  all(na.omit(nodal_raw) %in% c(0L, 1L)),
  "The nodal column contains values outside 0/1."
)
assert_true(
  all(na.omit(tumor_size_raw) %in% c(1L, 2L)),
  "The t1vsrest column contains values outside 1/2."
)
assert_true(
  all(na.omit(grade_raw) %in% c(3L, 12L)),
  "The g12vs3 column contains values outside 3/12."
)
assert_true(
  all(na.omit(efs_event) %in% c(0L, 1L)),
  "The ev120 column contains values outside 0/1."
)
assert_true(
  all(na.omit(adjuvant_raw) %in% c("YES", "NO")),
  "The adjuvant_chemotherapy column contains values outside YES/NO."
)
assert_true(
  all(na.omit(efs_time_months) >= 0),
  "The fu_120 column contains a negative follow-up time."
)
assert_true(
  all(na.omit(efs_time_months) <= 120),
  "The fu_120 column contains a follow-up time above 120 months."
)

endpoint_time_missing <- is.na(efs_time_months)
endpoint_event_missing <- is.na(efs_event)

assert_true(
  identical(endpoint_time_missing, endpoint_event_missing),
  "fu_120 and ev120 missingness are not perfectly paired."
)

efs_complete_public_set <- !endpoint_time_missing & !endpoint_event_missing
efs_missing_both <- endpoint_time_missing & endpoint_event_missing
efs_zero_time <- efs_complete_public_set & efs_time_months == 0
efs_positive_time_sensitivity_set <-
  efs_complete_public_set & efs_time_months > 0

# Fixed expectations independently audited from the accepted 09A bundle.
assert_true(
  sum(efs_complete_public_set) == 383L,
  paste0(
    "Expected 383 complete EFS records, detected ",
    sum(efs_complete_public_set), "."
  )
)
assert_true(
  sum(efs_missing_both) == 196L,
  paste0(
    "Expected 196 samples missing both EFS fields, detected ",
    sum(efs_missing_both), "."
  )
)
assert_true(
  sum(efs_event[efs_complete_public_set] == 1L) == 169L,
  "Expected 169 events in the 383 complete EFS records."
)
assert_true(
  sum(efs_event[efs_complete_public_set] == 0L) == 214L,
  "Expected 214 censored records in the 383 complete EFS records."
)
assert_true(
  sum(efs_zero_time) == 4L,
  "Expected exactly four complete endpoint records with fu_120 == 0."
)
assert_true(
  sum(efs_zero_time & efs_event == 1L, na.rm = TRUE) == 3L,
  "Expected three zero-time records with an event."
)
assert_true(
  sum(efs_zero_time & efs_event == 0L, na.rm = TRUE) == 1L,
  "Expected one zero-time censored record."
)
assert_true(
  sum(efs_positive_time_sensitivity_set) == 379L,
  "Expected 379 positive-time endpoint records."
)
assert_true(
  max(efs_time_months, na.rm = TRUE) == 120,
  "The maximum follow-up time is not 120 months."
)
assert_true(
  sum(efs_time_months == 120, na.rm = TRUE) == 63L,
  "Expected 63 records at the 120-month administrative cap."
)

# ------------------------------
# 5. Create transparent derived clinical fields
# ------------------------------
nodal_status <- rep(NA_character_, nrow(phenotype))
nodal_status[nodal_raw == 0L] <- "NODE_NEGATIVE"
nodal_status[nodal_raw == 1L] <- "NODE_POSITIVE"

tumor_size_group <- rep(NA_character_, nrow(phenotype))
tumor_size_group[tumor_size_raw == 1L] <- "T1"
tumor_size_group[tumor_size_raw == 2L] <- "T2_T4_OR_REST"

histologic_grade_group <- rep(NA_character_, nrow(phenotype))
histologic_grade_group[grade_raw == 12L] <- "GRADE_1_2"
histologic_grade_group[grade_raw == 3L] <- "GRADE_3"

adjuvant_chemotherapy <- rep(NA_character_, nrow(phenotype))
adjuvant_chemotherapy[adjuvant_raw == "YES"] <- "YES"
adjuvant_chemotherapy[adjuvant_raw == "NO"] <- "NO"

efs_status_label <- rep(NA_character_, nrow(phenotype))
efs_status_label[efs_event == 0L] <- "CENSORED"
efs_status_label[efs_event == 1L] <- "EVENT"

endpoint_record_status <- rep(
  "EXCLUDED_MISSING_BOTH_ENDPOINT_FIELDS",
  nrow(phenotype)
)
endpoint_record_status[efs_complete_public_set & !efs_zero_time] <-
  "INCLUDED_COMPLETE_EFS_POSITIVE_TIME"
endpoint_record_status[efs_zero_time & efs_event == 0L] <-
  "INCLUDED_COMPLETE_EFS_ZERO_TIME_CENSORED"
endpoint_record_status[efs_zero_time & efs_event == 1L] <-
  "INCLUDED_COMPLETE_EFS_ZERO_TIME_EVENT"

clinical_curated <- data.frame(
  sample_order = seq_len(nrow(phenotype)),
  sample_id = as.character(phenotype$sample_id),
  source_dataset_id = source_dataset_id,
  array_type = clean_character(phenotype$Array_type),
  source_sample_accession = clean_character(phenotype$GSM_accession),
  biopsy_method_code_raw = biopsy_method_code_raw,
  age_years = age_years,
  nodal_raw = nodal_raw,
  nodal_status = nodal_status,
  tumor_size_raw_t1vsrest = tumor_size_raw,
  tumor_size_group = tumor_size_group,
  histologic_grade_raw_g12vs3 = grade_raw,
  histologic_grade_group = histologic_grade_group,
  adjuvant_chemotherapy_raw = adjuvant_raw,
  adjuvant_chemotherapy = adjuvant_chemotherapy,
  efs_time_months = efs_time_months,
  efs_event = efs_event,
  efs_status_label = efs_status_label,
  efs_complete_public_set = efs_complete_public_set,
  efs_zero_time = efs_zero_time,
  efs_positive_time_sensitivity_set =
    efs_positive_time_sensitivity_set,
  efs_missing_both = efs_missing_both,
  endpoint_record_status = endpoint_record_status,
  source_expression_value_modified = FALSE,
  source_clinical_value_modified = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  identical(clinical_curated$sample_id, colnames(expr_gene)),
  "The curated clinical table is not aligned with the expression matrix."
)
assert_true(
  nrow(clinical_curated) == 579L &&
    anyDuplicated(clinical_curated$sample_id) == 0L,
  "The curated clinical table does not contain 579 unique samples."
)

# ------------------------------
# 6. Build sample-level endpoint inclusion audit
# ------------------------------
endpoint_inclusion_audit <- clinical_curated[, c(
  "sample_order",
  "sample_id",
  "source_dataset_id",
  "array_type",
  "source_sample_accession",
  "efs_time_months",
  "efs_event",
  "efs_status_label",
  "efs_complete_public_set",
  "efs_zero_time",
  "efs_positive_time_sensitivity_set",
  "efs_missing_both",
  "endpoint_record_status"
), drop = FALSE]

zero_time_audit <- endpoint_inclusion_audit[
  endpoint_inclusion_audit$efs_zero_time,
  ,
  drop = FALSE
]
assert_true(
  nrow(zero_time_audit) == 4L,
  "The zero-time audit does not contain four records."
)

# ------------------------------
# 7. Build source-dataset and covariate audits
# ------------------------------
dataset_endpoint_audit <- build_dataset_audit(clinical_curated)

assert_true(
  nrow(dataset_endpoint_audit) ==
    length(unique(clinical_curated$source_dataset_id)),
  "The source-dataset endpoint audit has an incorrect row count."
)
assert_true(
  sum(dataset_endpoint_audit$total_sample_number) == 579L,
  "The source-dataset audit does not sum to 579 samples."
)
assert_true(
  sum(dataset_endpoint_audit$endpoint_complete_number) == 383L,
  "The source-dataset audit does not sum to 383 complete endpoints."
)
assert_true(
  sum(dataset_endpoint_audit$event_number_complete_set) == 169L,
  "The source-dataset audit does not sum to 169 events."
)
assert_true(
  sum(dataset_endpoint_audit$censored_number_complete_set) == 214L,
  "The source-dataset audit does not sum to 214 censored records."
)

covariate_availability_audit <- build_covariate_availability(
  clinical_curated
)
candidate_complete_case_audit <- build_candidate_complete_case_audit(
  clinical_curated
)

# Fixed checks for the accepted phenotype table.
lookup_model_count <- function(set_name, model_name) {
  row <- candidate_complete_case_audit[
    candidate_complete_case_audit$analysis_set == set_name &
      candidate_complete_case_audit$candidate_covariate_set == model_name,
    ,
    drop = FALSE
  ]
  assert_true(nrow(row) == 1L, "Candidate model audit lookup failed.")
  as.integer(row$complete_covariate_number)
}

assert_true(
  lookup_model_count(
    "EFS_COMPLETE_PUBLIC_383",
    "AGE_NODAL_SIZE_GRADE"
  ) == 261L,
  "Expected 261 complete cases for age + nodal + size + grade in EFS383."
)
assert_true(
  lookup_model_count(
    "EFS_POSITIVE_TIME_SENSITIVITY_379",
    "AGE_NODAL_SIZE_GRADE"
  ) == 260L,
  "Expected 260 complete cases for age + nodal + size + grade in EFS379."
)
assert_true(
  lookup_model_count(
    "EFS_COMPLETE_PUBLIC_383",
    "AGE_NODAL_SIZE_GRADE_CHEMO"
  ) == 237L,
  "Expected 237 complete cases for the candidate full covariate set in EFS383."
)
assert_true(
  lookup_model_count(
    "EFS_POSITIVE_TIME_SENSITIVITY_379",
    "AGE_NODAL_SIZE_GRADE_CHEMO"
  ) == 236L,
  "Expected 236 complete cases for the candidate full covariate set in EFS379."
)

# ------------------------------
# 8. Record coding rules and evidence
# ------------------------------
coding_dictionary <- data.frame(
  source_column = c(
    "datas_new09",
    "Array_type",
    "GSM_accession",
    "Biopsy_Method",
    "age",
    "nodal",
    "t1vsrest",
    "g12vs3",
    "adjuvant_chemotherapy",
    "fu_120",
    "ev120"
  ),
  derived_column = c(
    "source_dataset_id",
    "array_type",
    "source_sample_accession",
    "biopsy_method_code_raw",
    "age_years",
    "nodal_status",
    "tumor_size_group",
    "histologic_grade_group",
    "adjuvant_chemotherapy",
    "efs_time_months",
    "efs_event"
  ),
  source_values = c(
    "1-42 observed dataset codes",
    "GPL96; GPL570; GPL96 & GPL97",
    "Source sample/accession text",
    "1-4 observed raw codes",
    "28-88 years observed",
    "0;1",
    "1;2",
    "12;3",
    "NO;YES",
    "0-120",
    "0;1"
  ),
  derived_meaning = c(
    "Source dataset identifier; retained as a stratification/batch candidate",
    "Array/platform class retained unchanged",
    "Source sample/accession retained unchanged",
    "Raw biopsy method code retained; no biological label assigned here",
    "Age in years retained numerically",
    "0 = node negative; 1 = node positive",
    "1 = T1; 2 = T2-T4 or the remaining tumor-size categories",
    "12 = histologic grade 1/2; 3 = histologic grade 3",
    "NO/YES retained as categorical treatment availability",
    paste0(
      "Follow-up time from surgery in months, administratively capped at ",
      "120 months"
    ),
    paste0(
      "Event-free survival indicator: 1 = event; 0 = censored; endpoint is ",
      "the available RFS or DMFS endpoint pooled as EFS"
    )
  ),
  action = c(
    "RENAME_ONLY",
    "RENAME_ONLY",
    "RENAME_ONLY",
    "RENAME_ONLY_NO_INTERPRETATION",
    "RENAME_ONLY",
    "TRANSPARENT_LABEL_MAPPING",
    "TRANSPARENT_LABEL_MAPPING",
    "TRANSPARENT_LABEL_MAPPING",
    "STANDARDIZE_CASE_ONLY",
    "RENAME_ONLY_NO_UNIT_CONVERSION",
    "TRANSPARENT_BINARY_LABEL_MAPPING"
  ),
  source_value_overwritten = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

endpoint_definition_sources <- data.frame(
  source_type = c(
    "GEO_ACCESSION",
    "PRIMARY_SOURCE_PUBLICATION"
  ),
  source_identifier = c(
    "GSE31519",
    "Karn et al., PLOS ONE 2011; DOI 10.1371/journal.pone.0028403"
  ),
  relevant_definition = c(
    paste0(
      "GSE31519 is a pooled collection of 579 TNBC samples assembled from ",
      "multiple Affymetrix cohorts."
    ),
    paste0(
      "Survival intervals were measured from surgery. Available RFS or DMFS ",
      "endpoints were pooled as event-free survival. Event-free patients were ",
      "censored at last follow-up or 120 months."
    )
  ),
  internet_retrieval_performed_by_script = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 9. Build integrity summary
# ------------------------------
summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Source_Script08B_bundle_MD5",
    "Source_Script09A_bundle_MD5",
    "Gene_level_rows_verified",
    "Total_samples_preserved",
    "Expression_phenotype_order_identical",
    "Endpoint_name",
    "Endpoint_time_source_column",
    "Endpoint_event_source_column",
    "Endpoint_time_unit",
    "Endpoint_administrative_cap_months",
    "Complete_endpoint_records",
    "Missing_both_endpoint_fields",
    "Events_complete_set",
    "Censored_complete_set",
    "Zero_time_complete_records",
    "Zero_time_events",
    "Zero_time_censored",
    "Positive_time_sensitivity_records",
    "Records_at_120_month_cap",
    "Source_dataset_number",
    "Source_clinical_rows_deleted",
    "Source_clinical_values_imputed",
    "Source_clinical_values_overwritten",
    "Expression_values_modified",
    "Survival_model_fitted",
    "Triclosan_score_calculated",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "09B",
    observed_gene_md5,
    observed_09a_md5,
    nrow(expr_gene),
    nrow(clinical_curated),
    identical(clinical_curated$sample_id, colnames(expr_gene)),
    "120-month pooled event-free survival (available RFS or DMFS)",
    "fu_120",
    "ev120",
    "months",
    120,
    sum(clinical_curated$efs_complete_public_set),
    sum(clinical_curated$efs_missing_both),
    sum(clinical_curated$efs_event == 1L, na.rm = TRUE),
    sum(clinical_curated$efs_event == 0L, na.rm = TRUE),
    sum(clinical_curated$efs_zero_time),
    sum(
      clinical_curated$efs_zero_time &
        clinical_curated$efs_event == 1L,
      na.rm = TRUE
    ),
    sum(
      clinical_curated$efs_zero_time &
        clinical_curated$efs_event == 0L,
      na.rm = TRUE
    ),
    sum(clinical_curated$efs_positive_time_sensitivity_set),
    sum(clinical_curated$efs_time_months == 120, na.rm = TRUE),
    length(unique(clinical_curated$source_dataset_id)),
    0,
    0,
    0,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Save all outputs in staging
# ------------------------------
input_manifest <- make_manifest(required_inputs)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script09B",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_gene_bundle_file = normalize_existing_path(gene_bundle_file),
  source_gene_bundle_md5 = observed_gene_md5,
  source_clinical_audit_bundle_file =
    normalize_existing_path(audit09a_bundle_file),
  source_clinical_audit_bundle_md5 = observed_09a_md5,
  expression_matrix = expr_gene,
  source_phenotype = phenotype,
  curated_clinical = clinical_curated,
  endpoint_inclusion_audit = endpoint_inclusion_audit,
  zero_time_audit = zero_time_audit,
  dataset_endpoint_audit = dataset_endpoint_audit,
  covariate_availability_audit = covariate_availability_audit,
  candidate_complete_case_audit = candidate_complete_case_audit,
  coding_dictionary = coding_dictionary,
  endpoint_definition_sources = endpoint_definition_sources,
  integrity_summary = summary_table,
  endpoint_policy = list(
    endpoint_name =
      "120-month pooled event-free survival (available RFS or DMFS)",
    time_column = "fu_120",
    event_column = "ev120",
    time_unit = "months",
    event_code = 1L,
    censored_code = 0L,
    complete_public_set_sample_number = 383L,
    complete_public_set_includes_zero_time_records = TRUE,
    positive_time_sensitivity_sample_number = 379L,
    positive_time_sensitivity_excludes_zero_time_records = TRUE,
    source_records_deleted = FALSE,
    source_values_imputed = FALSE,
    source_values_overwritten = FALSE,
    model_fitted = FALSE
  ),
  provenance = list(
    script08b_bundle_md5 = observed_gene_md5,
    script09a_bundle_md5 = observed_09a_md5,
    source_publication_doi = "10.1371/journal.pone.0028403"
  )
)
class(complete_bundle) <- c(
  "GSE31519_curated_clinical_endpoint_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_curated_clinical_endpoint_COMPLETE_bundle.rds"
)
stage_clinical_file <- file.path(
  stage_audit_dir,
  "GSE31519_curated_clinical_table_all579.csv"
)
stage_endpoint_file <- file.path(
  stage_audit_dir,
  "GSE31519_EFS_endpoint_inclusion_audit_all579.csv"
)
stage_zero_file <- file.path(
  stage_audit_dir,
  "GSE31519_EFS_zero_time_records.csv"
)
stage_dataset_file <- file.path(
  stage_audit_dir,
  "GSE31519_EFS_by_source_dataset_audit.csv"
)
stage_covariate_file <- file.path(
  stage_audit_dir,
  "GSE31519_clinical_covariate_availability_audit.csv"
)
stage_model_case_file <- file.path(
  stage_audit_dir,
  "GSE31519_candidate_multivariable_complete_case_audit.csv"
)
stage_dictionary_file <- file.path(
  stage_audit_dir,
  "GSE31519_clinical_coding_dictionary.csv"
)
stage_source_file <- file.path(
  stage_audit_dir,
  "GSE31519_endpoint_definition_sources.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_curated_clinical_endpoint_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script09B_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script09B_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script09B_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script09B_COMPLETE_report.txt"
)

saveRDS(complete_bundle, stage_bundle_file, compress = "gzip")
write_csv_utf8(clinical_curated, stage_clinical_file)
write_csv_utf8(endpoint_inclusion_audit, stage_endpoint_file)
write_csv_utf8(zero_time_audit, stage_zero_file)
write_csv_utf8(dataset_endpoint_audit, stage_dataset_file)
write_csv_utf8(
  covariate_availability_audit,
  stage_covariate_file
)
write_csv_utf8(
  candidate_complete_case_audit,
  stage_model_case_file
)
write_csv_utf8(coding_dictionary, stage_dictionary_file)
write_csv_utf8(endpoint_definition_sources, stage_source_file)
write_csv_utf8(summary_table, stage_summary_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

# Independently read back the staged core object.
bundle_check <- readRDS(stage_bundle_file)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "expression_matrix",
      "source_phenotype",
      "curated_clinical",
      "endpoint_inclusion_audit",
      "zero_time_audit",
      "dataset_endpoint_audit",
      "integrity_summary",
      "endpoint_policy"
    ) %in% names(bundle_check)),
  "The staged Script 09B bundle cannot be read back with required fields."
)
assert_true(
  identical(bundle_check$expression_matrix, expr_gene),
  "The expression matrix changed while saving the Script 09B bundle."
)
assert_true(
  identical(bundle_check$source_phenotype, phenotype),
  "The source phenotype table changed while saving the Script 09B bundle."
)
assert_true(
  identical(
    bundle_check$curated_clinical$sample_id,
    colnames(bundle_check$expression_matrix)
  ),
  "The staged bundle has misaligned clinical and expression samples."
)
assert_true(
  sum(bundle_check$curated_clinical$efs_complete_public_set) == 383L,
  "The staged bundle no longer has 383 complete EFS records."
)
assert_true(
  sum(
    bundle_check$curated_clinical$
      efs_positive_time_sensitivity_set
  ) == 379L,
  "The staged bundle no longer has 379 positive-time sensitivity records."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 09B",
  "GSE31519 curated clinical endpoint bundle",
  "============================================================",
  paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Source Script 08B bundle MD5: ", observed_gene_md5),
  paste0("Source Script 09A bundle MD5: ", observed_09a_md5),
  paste0(
    "Verified gene-level matrix: ",
    nrow(expr_gene), " genes x ", ncol(expr_gene), " samples"
  ),
  paste0("Total samples preserved: ", nrow(clinical_curated)),
  paste0(
    "Expression/clinical order identical: ",
    identical(clinical_curated$sample_id, colnames(expr_gene))
  ),
  paste0(
    "Endpoint: 120-month pooled event-free survival ",
    "(available RFS or DMFS)"
  ),
  "Time column: fu_120",
  "Event column: ev120",
  "Time unit: months",
  "Event coding: 1 = event; 0 = censored",
  paste0(
    "Complete public-data EFS set: ",
    sum(clinical_curated$efs_complete_public_set)
  ),
  paste0(
    "Events in complete EFS set: ",
    sum(clinical_curated$efs_event == 1L, na.rm = TRUE)
  ),
  paste0(
    "Censored in complete EFS set: ",
    sum(clinical_curated$efs_event == 0L, na.rm = TRUE)
  ),
  paste0(
    "Samples missing both endpoint fields: ",
    sum(clinical_curated$efs_missing_both)
  ),
  paste0(
    "Complete records with zero follow-up time: ",
    sum(clinical_curated$efs_zero_time)
  ),
  paste0(
    "Positive-time sensitivity EFS set: ",
    sum(clinical_curated$efs_positive_time_sensitivity_set)
  ),
  paste0(
    "Records at the 120-month cap: ",
    sum(clinical_curated$efs_time_months == 120, na.rm = TRUE)
  ),
  paste0(
    "Source dataset identifiers represented: ",
    length(unique(clinical_curated$source_dataset_id))
  ),
  "Source clinical rows deleted: 0",
  "Source clinical values imputed: 0",
  "Source clinical values overwritten: 0",
  "Expression values modified: FALSE",
  "Survival model fitted: FALSE",
  "Triclosan score calculated: FALSE",
  paste0("Curated endpoint bundle MD5: ", bundle_md5),
  "",
  "SCRIPT09B STATUS: COMPLETE",
  paste0(
    "Both the 383-record complete endpoint set and the 379-record ",
    "positive-time sensitivity set were preserved for later prespecified ",
    "survival analyses."
  ),
  "============================================================"
)
writeLines(report_lines, con = stage_report_file, useBytes = TRUE)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_clinical_file,
  stage_endpoint_file,
  stage_zero_file,
  stage_dataset_file,
  stage_covariate_file,
  stage_model_case_file,
  stage_dictionary_file,
  stage_source_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)),
  "At least one required staged Script 09B output file is missing."
)
assert_true(
  all(file.info(output_files_before_manifest)$size > 0),
  "At least one required staged Script 09B output file is empty."
)

output_manifest <- make_manifest(output_files_before_manifest)
write_csv_utf8(output_manifest, stage_output_manifest_file)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
assert_true(
  nrow(manifest_check) == length(output_files_before_manifest),
  "The Script 09B output manifest has the wrong number of rows."
)

for (i in seq_along(output_files_before_manifest)) {
  file_i <- output_files_before_manifest[i]
  manifest_row <- manifest_check[
    manifest_check$file_name == basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(manifest_row) == 1L,
    paste0(
      "Output manifest row missing or duplicated for: ",
      basename(file_i)
    )
  )
  assert_true(
    identical(
      tolower(as.character(manifest_row$md5)),
      tolower(md5_one(file_i))
    ),
    paste0("Output manifest MD5 mismatch for: ", basename(file_i))
  )
  assert_true(
    as.numeric(manifest_row$size_bytes) ==
      as.numeric(file.info(file_i)$size),
    paste0("Output manifest size mismatch for: ", basename(file_i))
  )
}

# ------------------------------
# 11. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "The final Script 09B output directory appeared during staging."
)

rename_ok <- file.rename(stage_root, final_root)

if (!isTRUE(rename_ok)) {
  dir.create(final_root, recursive = TRUE, showWarnings = FALSE)

  copied <- file.copy(
    from = list.files(stage_root, full.names = TRUE, all.files = FALSE),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit the Script 09B staging directory to the final location."
  )

  unlink(stage_root, recursive = TRUE, force = TRUE)
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_curated_clinical_endpoint_COMPLETE_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script09B_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script09B_output_manifest_with_MD5.csv"
)

assert_true(
  all(file.exists(c(
    final_bundle_file,
    final_report_file,
    final_manifest_file
  ))),
  "The committed Script 09B output is incomplete."
)
assert_true(
  identical(md5_one(final_bundle_file), bundle_md5),
  "The committed Script 09B bundle MD5 changed after commit."
)
assert_true(
  report_contains(final_report_file, "SCRIPT09B STATUS: COMPLETE"),
  "The committed Script 09B report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 09B completed successfully.\n")
cat(
  "Verified gene-level matrix: ",
  nrow(expr_gene), " x ", ncol(expr_gene), "\n",
  sep = ""
)
cat("Total samples preserved: ", nrow(clinical_curated), "\n", sep = "")
cat(
  "Complete public-data EFS set: ",
  sum(clinical_curated$efs_complete_public_set), "\n",
  sep = ""
)
cat(
  "Events / censored: ",
  sum(clinical_curated$efs_event == 1L, na.rm = TRUE),
  " / ",
  sum(clinical_curated$efs_event == 0L, na.rm = TRUE),
  "\n",
  sep = ""
)
cat(
  "Zero-time complete records: ",
  sum(clinical_curated$efs_zero_time), "\n",
  sep = ""
)
cat(
  "Positive-time sensitivity EFS set: ",
  sum(clinical_curated$efs_positive_time_sensitivity_set), "\n",
  sep = ""
)
cat("Clinical values imputed: 0\n")
cat("Expression values modified: FALSE\n")
cat("Survival model fitted: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(final_bundle_file, winslash = "/", mustWork = TRUE),
  "\n",
  sep = ""
)
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 11C FINAL
#
# Dataset-level meta-analysis sensitivity for the continuous Triclosan_activity
# score.
#
# Scientific role:
#   This is a prespecified sensitivity analysis following:
#     - Script 10C technical-confounding audit and survival-design lock;
#     - Script 11A source-stratified continuous Cox models;
#     - Script 11B proportional-hazards and influence diagnostics.
#
# Primary dataset-level analysis:
#   - Endpoint set: EFS383.
#   - Eligible source datasets are inherited from Script 10C:
#       n >= 10, events >= 3, censored >= 3, non-zero score variance.
#   - Within each source dataset, the continuous score is standardized to one
#     dataset-specific SD before fitting:
#       Surv(efs_time_months, efs_event) ~ score_z_within_dataset
#   - Cox ties method: Efron.
#   - Pooled summaries:
#       inverse-variance fixed effect;
#       REML random effect;
#       modified Hartung-Knapp interval;
#       heterogeneity Q, I2 and tau2;
#       leave-one-dataset-out REML sensitivity.
#
# Positive-time sensitivity:
#   - Repeat the same workflow in EFS379.
#
# This script DOES NOT:
#   - rerun earlier preprocessing or GSVA;
#   - search for a cutoff;
#   - form high/low groups;
#   - delete influential samples;
#   - use dataset significance to decide inclusion;
#   - fit Kaplan-Meier curves;
#   - create manuscript figures;
#   - reinterpret the primary null stratified Cox result as positive.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

SCRIPT_BUILD_ID <- "Script11C_FINAL_20260710"

cat("============================================================\n")
cat("RUNNING: ", SCRIPT_BUILD_ID, "\n", sep = "")
cat("Dataset-level Cox plus fixed/REML meta-analysis: ENABLED\n")
cat("Optimized cutoff search: DISABLED\n")
cat("Influence-based sample deletion: DISABLED\n")
cat("============================================================\n")

# ------------------------------
# 0. Fixed paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step2_GSE31519_external_validation"
)

design_root <- file.path(
  step_root,
  "09_technical_confounding_and_survival_design"
)
model_root <- file.path(
  step_root,
  "10_primary_continuous_survival_models"
)
diagnostic_root <- file.path(
  step_root,
  "11_PH_and_influence_diagnostics"
)
final_root <- file.path(
  step_root,
  "12_dataset_level_meta_analysis_sensitivity"
)

design_bundle_file <- file.path(
  design_root,
  "objects",
  "GSE31519_technical_confounding_survival_design_COMPLETE_bundle.rds"
)
design_manifest_file <- file.path(
  design_root,
  "audit",
  "Script10C_output_manifest_with_MD5.csv"
)
design_report_file <- file.path(
  design_root,
  "logs",
  "Script10C_COMPLETE_report.txt"
)

model_bundle_file <- file.path(
  model_root,
  "objects",
  "GSE31519_continuous_survival_models_COMPLETE_bundle.rds"
)
model_manifest_file <- file.path(
  model_root,
  "audit",
  "Script11A_output_manifest_with_MD5.csv"
)
model_report_file <- file.path(
  model_root,
  "logs",
  "Script11A_COMPLETE_report.txt"
)

diagnostic_bundle_file <- file.path(
  diagnostic_root,
  "objects",
  "GSE31519_PH_influence_diagnostics_COMPLETE_bundle.rds"
)
diagnostic_manifest_file <- file.path(
  diagnostic_root,
  "audit",
  "Script11B_output_manifest_with_MD5.csv"
)
diagnostic_report_file <- file.path(
  diagnostic_root,
  "logs",
  "Script11B_COMPLETE_report.txt"
)

required_inputs <- c(
  design_bundle_file,
  design_manifest_file,
  design_report_file,
  model_bundle_file,
  model_manifest_file,
  model_report_file,
  diagnostic_bundle_file,
  diagnostic_manifest_file,
  diagnostic_report_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 11C cannot start because required accepted files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist.", call. = FALSE)
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 11C will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script11C_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop("Unable to create Script 11C staging directories.", call. = FALSE)
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. General helpers
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

md5_one <- function(path) {
  unname(tools::md5sum(path))
}

normalize_existing_path <- function(path) {
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(report_file, warn = FALSE, encoding = "UTF-8")
  any(grepl(fixed_text, lines, fixed = TRUE))
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)

  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(path) {
        normalizePath(path, winslash = "/", mustWork = FALSE)
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c("file_name", "size_bytes", "md5") %in% colnames(manifest)),
    paste0("Malformed manifest: ", manifest_file)
  )

  row_index <- which(manifest$file_name == basename(target_file))

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file)
    )
  )

  tolower(trimws(as.character(manifest$md5[row_index])))
}

capture_warnings <- function(expression) {
  warning_messages <- character(0)

  value <- withCallingHandlers(
    expression,
    warning = function(w) {
      warning_messages <<- c(
        warning_messages,
        conditionMessage(w)
      )
      invokeRestart("muffleWarning")
    }
  )

  list(
    value = value,
    warnings = unique(warning_messages)
  )
}

collapse_messages <- function(x) {
  x <- unique(trimws(as.character(x)))
  x <- x[nzchar(x)]
  if (length(x) == 0L) "" else paste(x, collapse = " | ")
}

safe_numeric <- function(x) {
  suppressWarnings(as.numeric(as.character(x)))
}

audit_coxph_fit <- function(fit, warnings = character(0)) {
  if (is.null(fit) || !inherits(fit, "coxph")) {
    return(list(
      valid = FALSE,
      reason = "NO_COXPH_OBJECT",
      coefficients_finite = FALSE,
      standard_errors_valid = FALSE,
      log_likelihood_finite = FALSE,
      no_failure_marker = FALSE,
      no_infinite_coefficient_warning = FALSE
    ))
  }

  coefficient_values <- tryCatch(
    as.numeric(stats::coef(fit)),
    error = function(e) numeric(0)
  )

  covariance_matrix <- tryCatch(
    stats::vcov(fit),
    error = function(e) NULL
  )

  coefficient_standard_errors <- if (
    is.matrix(covariance_matrix) &&
      nrow(covariance_matrix) > 0L
  ) {
    sqrt(diag(covariance_matrix))
  } else {
    numeric(0)
  }

  log_likelihood_values <- tryCatch(
    as.numeric(fit$loglik),
    error = function(e) numeric(0)
  )

  failure_text <- if (is.null(fit$fail)) {
    ""
  } else {
    trimws(paste(as.character(fit$fail), collapse = " | "))
  }

  warning_text <- tolower(collapse_messages(warnings))
  infinite_warning <- grepl(
    "coefficient may be infinite|loglik converged before variable",
    warning_text
  )

  coefficients_finite <- length(coefficient_values) >= 1L &&
    all(is.finite(coefficient_values))

  standard_errors_valid <-
    length(coefficient_standard_errors) ==
      length(coefficient_values) &&
    all(is.finite(coefficient_standard_errors)) &&
    all(coefficient_standard_errors > 0)

  log_likelihood_finite <-
    length(log_likelihood_values) >= 2L &&
    all(is.finite(log_likelihood_values))

  no_failure_marker <- !nzchar(failure_text) ||
    identical(toupper(failure_text), "NA")

  no_infinite_coefficient_warning <- !infinite_warning

  valid <- coefficients_finite &&
    standard_errors_valid &&
    log_likelihood_finite &&
    no_failure_marker &&
    no_infinite_coefficient_warning

  reason_parts <- character(0)

  if (!coefficients_finite) {
    reason_parts <- c(reason_parts, "NONFINITE_COEFFICIENT")
  }
  if (!standard_errors_valid) {
    reason_parts <- c(reason_parts, "INVALID_STANDARD_ERROR")
  }
  if (!log_likelihood_finite) {
    reason_parts <- c(reason_parts, "NONFINITE_LOG_LIKELIHOOD")
  }
  if (!no_failure_marker) {
    reason_parts <- c(
      reason_parts,
      paste0("FAILURE_MARKER:", failure_text)
    )
  }
  if (!no_infinite_coefficient_warning) {
    reason_parts <- c(
      reason_parts,
      "POSSIBLY_INFINITE_COEFFICIENT_WARNING"
    )
  }

  list(
    valid = valid,
    reason = if (length(reason_parts) == 0L) {
      "VALID"
    } else {
      paste(reason_parts, collapse = ";")
    },
    coefficients_finite = coefficients_finite,
    standard_errors_valid = standard_errors_valid,
    log_likelihood_finite = log_likelihood_finite,
    no_failure_marker = no_failure_marker,
    no_infinite_coefficient_warning =
      no_infinite_coefficient_warning
  )
}

# ------------------------------
# 2. Meta-analysis helpers
# ------------------------------
meta_reml_tau2 <- function(yi, vi) {
  yi <- as.numeric(yi)
  vi <- as.numeric(vi)

  assert_true(
    length(yi) == length(vi) &&
      length(yi) >= 2L &&
      all(is.finite(yi)) &&
      all(is.finite(vi)) &&
      all(vi > 0),
    "Invalid yi/vi input to REML tau-squared estimation."
  )

  objective <- function(tau2) {
    marginal_variance <- vi + tau2
    weights <- 1 / marginal_variance
    pooled_mean <- sum(weights * yi) / sum(weights)

    0.5 * (
      sum(log(marginal_variance)) +
        log(sum(weights)) +
        sum(weights * (yi - pooled_mean)^2)
    )
  }

  empirical_variance <- if (length(yi) >= 2L) {
    stats::var(yi)
  } else {
    0
  }

  upper <- max(
    empirical_variance,
    max(vi),
    1e-4
  ) * 4

  optimization <- NULL

  for (iteration in seq_len(20L)) {
    optimization <- stats::optimize(
      f = objective,
      interval = c(0, upper),
      tol = 1e-12
    )

    if (
      optimization$minimum < 0.98 * upper ||
        upper >= 1e6
    ) {
      break
    }

    upper <- upper * 4
  }

  assert_true(
    !is.null(optimization) &&
      is.finite(optimization$minimum) &&
      optimization$minimum >= 0,
    "REML tau-squared optimization failed."
  )

  max(0, as.numeric(optimization$minimum))
}

compute_meta_summary <- function(dataset_effects, analysis_set) {
  valid <- dataset_effects[
    dataset_effects$analysis_set == analysis_set &
      dataset_effects$fit_valid,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(valid) >= 2L,
    paste0(
      "Fewer than two valid dataset effects are available for ",
      analysis_set,
      "."
    )
  )

  yi <- as.numeric(valid$log_HR_per_within_dataset_SD)
  sei <- as.numeric(valid$standard_error)
  vi <- sei^2
  k <- length(yi)

  fixed_weights <- 1 / vi
  fixed_log_hr <- sum(fixed_weights * yi) / sum(fixed_weights)
  fixed_se <- sqrt(1 / sum(fixed_weights))
  fixed_z <- fixed_log_hr / fixed_se
  fixed_p <- 2 * stats::pnorm(abs(fixed_z), lower.tail = FALSE)

  Q <- sum(fixed_weights * (yi - fixed_log_hr)^2)
  Q_df <- k - 1L
  Q_p <- stats::pchisq(Q, df = Q_df, lower.tail = FALSE)

  I2 <- if (Q > 0) {
    max(0, (Q - Q_df) / Q) * 100
  } else {
    0
  }

  C_value <- sum(fixed_weights) -
    sum(fixed_weights^2) / sum(fixed_weights)

  tau2_DL <- if (
    is.finite(C_value) &&
      C_value > 0
  ) {
    max(0, (Q - Q_df) / C_value)
  } else {
    0
  }

  tau2_REML <- meta_reml_tau2(yi, vi)
  random_weights <- 1 / (vi + tau2_REML)
  random_log_hr <- sum(random_weights * yi) / sum(random_weights)
  random_se_normal <- sqrt(1 / sum(random_weights))
  random_z <- random_log_hr / random_se_normal
  random_p_normal <- 2 * stats::pnorm(
    abs(random_z),
    lower.tail = FALSE
  )

  HKSJ_q_raw <- sum(
    random_weights * (yi - random_log_hr)^2
  ) / (k - 1L)

  HKSJ_q_modified <- max(1, HKSJ_q_raw)
  HKSJ_se_modified <- sqrt(
    HKSJ_q_modified / sum(random_weights)
  )
  HKSJ_t <- random_log_hr / HKSJ_se_modified
  HKSJ_df <- k - 1L
  HKSJ_p <- 2 * stats::pt(
    abs(HKSJ_t),
    df = HKSJ_df,
    lower.tail = FALSE
  )
  HKSJ_critical <- stats::qt(
    0.975,
    df = HKSJ_df
  )

  prediction_critical <- if (k > 2L) {
    stats::qt(0.975, df = k - 2L)
  } else {
    stats::qnorm(0.975)
  }

  prediction_se <- sqrt(
    tau2_REML + random_se_normal^2
  )

  summary_rows <- rbind(
    data.frame(
      analysis_set = analysis_set,
      pooling_method = "FIXED_INVERSE_VARIANCE",
      dataset_number = k,
      pooled_log_HR = fixed_log_hr,
      pooled_standard_error = fixed_se,
      hazard_ratio = exp(fixed_log_hr),
      confidence_lower_95 =
        exp(fixed_log_hr - 1.96 * fixed_se),
      confidence_upper_95 =
        exp(fixed_log_hr + 1.96 * fixed_se),
      test_statistic = fixed_z,
      test_distribution = "NORMAL",
      test_degrees_of_freedom = NA_real_,
      p_value = fixed_p,
      tau2 = 0,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      analysis_set = analysis_set,
      pooling_method = "RANDOM_REML_NORMAL",
      dataset_number = k,
      pooled_log_HR = random_log_hr,
      pooled_standard_error = random_se_normal,
      hazard_ratio = exp(random_log_hr),
      confidence_lower_95 =
        exp(random_log_hr - 1.96 * random_se_normal),
      confidence_upper_95 =
        exp(random_log_hr + 1.96 * random_se_normal),
      test_statistic = random_z,
      test_distribution = "NORMAL",
      test_degrees_of_freedom = NA_real_,
      p_value = random_p_normal,
      tau2 = tau2_REML,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      analysis_set = analysis_set,
      pooling_method = "RANDOM_REML_MODIFIED_HARTUNG_KNAPP",
      dataset_number = k,
      pooled_log_HR = random_log_hr,
      pooled_standard_error = HKSJ_se_modified,
      hazard_ratio = exp(random_log_hr),
      confidence_lower_95 =
        exp(random_log_hr - HKSJ_critical * HKSJ_se_modified),
      confidence_upper_95 =
        exp(random_log_hr + HKSJ_critical * HKSJ_se_modified),
      test_statistic = HKSJ_t,
      test_distribution = "T",
      test_degrees_of_freedom = HKSJ_df,
      p_value = HKSJ_p,
      tau2 = tau2_REML,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  heterogeneity <- data.frame(
    analysis_set = analysis_set,
    dataset_number = k,
    Cochran_Q = Q,
    Cochran_Q_df = Q_df,
    Cochran_Q_p_value = Q_p,
    I2_percent = I2,
    tau2_DerSimonian_Laird = tau2_DL,
    tau2_REML = tau2_REML,
    HKSJ_q_raw = HKSJ_q_raw,
    HKSJ_q_modified = HKSJ_q_modified,
    prediction_interval_lower_95 =
      exp(random_log_hr - prediction_critical * prediction_se),
    prediction_interval_upper_95 =
      exp(random_log_hr + prediction_critical * prediction_se),
    positive_log_HR_dataset_number = sum(yi > 0),
    negative_log_HR_dataset_number = sum(yi < 0),
    zero_log_HR_dataset_number = sum(yi == 0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(
    summary = summary_rows,
    heterogeneity = heterogeneity
  )
}

compute_leave_one_out <- function(dataset_effects, analysis_set) {
  valid <- dataset_effects[
    dataset_effects$analysis_set == analysis_set &
      dataset_effects$fit_valid,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(valid) >= 3L,
    paste0(
      "At least three valid datasets are required for leave-one-out analysis: ",
      analysis_set
    )
  )

  rows <- vector("list", nrow(valid))

  for (i in seq_len(nrow(valid))) {
    reduced <- valid[-i, , drop = FALSE]

    meta_i <- compute_meta_summary(
      reduced,
      analysis_set
    )$summary

    reml_i <- meta_i[
      meta_i$pooling_method ==
        "RANDOM_REML_MODIFIED_HARTUNG_KNAPP",
      ,
      drop = FALSE
    ]

    rows[[i]] <- data.frame(
      analysis_set = analysis_set,
      omitted_source_dataset_id =
        as.character(valid$source_dataset_id[i]),
      retained_dataset_number = nrow(reduced),
      pooled_log_HR = reml_i$pooled_log_HR,
      hazard_ratio = reml_i$hazard_ratio,
      confidence_lower_95 = reml_i$confidence_lower_95,
      confidence_upper_95 = reml_i$confidence_upper_95,
      p_value = reml_i$p_value,
      tau2_REML = reml_i$tau2,
      pooling_method =
        "RANDOM_REML_MODIFIED_HARTUNG_KNAPP",
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  result <- do.call(rbind, rows)
  rownames(result) <- NULL
  result
}

# ------------------------------
# 3. Package preflight
# ------------------------------
if (!requireNamespace("survival", quietly = TRUE)) {
  stop(
    paste0(
      "Required package 'survival' is not installed.\n",
      "Install it once with: install.packages('survival')"
    ),
    call. = FALSE
  )
}

survival_version <- as.character(
  utils::packageVersion("survival")
)

# ------------------------------
# 4. Verify accepted input identities
# ------------------------------
assert_true(
  report_contains(design_report_file, "SCRIPT10C STATUS: COMPLETE"),
  "Script 10C completion marker was not found."
)
assert_true(
  report_contains(model_report_file, "SCRIPT11A STATUS: COMPLETE"),
  "Script 11A completion marker was not found."
)
assert_true(
  report_contains(diagnostic_report_file, "SCRIPT11B STATUS: COMPLETE"),
  "Script 11B completion marker was not found."
)
assert_true(
  report_contains(
    diagnostic_report_file,
    "Script build ID: Script11B_v4_FINAL_20260710"
  ),
  "The accepted Script 11B report is not from v4 FINAL."
)

expected_design_md5 <- manifest_expected_md5(
  design_manifest_file,
  design_bundle_file
)
observed_design_md5 <- tolower(md5_one(design_bundle_file))
accepted_design_md5 <- "19a5f27976ba1cf82f15ad1f3f304f74"

assert_true(
  identical(expected_design_md5, observed_design_md5),
  "Script 10C bundle MD5 differs from its manifest."
)
assert_true(
  identical(observed_design_md5, accepted_design_md5),
  "Script 10C bundle differs from the accepted bundle."
)

expected_model_md5 <- manifest_expected_md5(
  model_manifest_file,
  model_bundle_file
)
observed_model_md5 <- tolower(md5_one(model_bundle_file))
accepted_model_md5 <- "2e62fb7ca5f8085e4ee2730c6e3d8691"

assert_true(
  identical(expected_model_md5, observed_model_md5),
  "Script 11A bundle MD5 differs from its manifest."
)
assert_true(
  identical(observed_model_md5, accepted_model_md5),
  "Script 11A bundle differs from the accepted bundle."
)

expected_diagnostic_md5 <- manifest_expected_md5(
  diagnostic_manifest_file,
  diagnostic_bundle_file
)
observed_diagnostic_md5 <- tolower(md5_one(diagnostic_bundle_file))
accepted_diagnostic_md5 <- "83844735cd7417e36c4fe205cbf400c4"

assert_true(
  identical(expected_diagnostic_md5, observed_diagnostic_md5),
  "Script 11B bundle MD5 differs from its manifest."
)
assert_true(
  identical(observed_diagnostic_md5, accepted_diagnostic_md5),
  "Script 11B bundle differs from the accepted v4 bundle."
)

# ------------------------------
# 5. Read and validate accepted objects
# ------------------------------
design_bundle <- readRDS(design_bundle_file)
model_bundle <- readRDS(model_bundle_file)
diagnostic_bundle <- readRDS(diagnostic_bundle_file)

assert_true(
  is.list(design_bundle) &&
    all(c(
      "script",
      "analysis_table",
      "source_dataset_survival_audit",
      "policy"
    ) %in% names(design_bundle)),
  "Script 10C bundle is missing required fields."
)
assert_true(
  identical(as.character(design_bundle$script), "Script10C"),
  "Design bundle was not created by Script 10C."
)

assert_true(
  is.list(model_bundle) &&
    all(c(
      "script",
      "score_effects",
      "policy"
    ) %in% names(model_bundle)),
  "Script 11A bundle is missing required fields."
)
assert_true(
  identical(as.character(model_bundle$script), "Script11A"),
  "Model bundle was not created by Script 11A."
)

assert_true(
  is.list(diagnostic_bundle) &&
    all(c(
      "script",
      "time_interaction_tests",
      "influence_summary",
      "policy"
    ) %in% names(diagnostic_bundle)),
  "Script 11B bundle is missing required fields."
)
assert_true(
  identical(as.character(diagnostic_bundle$script), "Script11B"),
  "Diagnostic bundle was not created by Script 11B."
)
assert_true(
  identical(
    as.character(diagnostic_bundle$script_build_id),
    "Script11B_v4_FINAL_20260710"
  ),
  "Diagnostic bundle is not from Script 11B v4 FINAL."
)

analysis_table <- design_bundle$analysis_table
eligibility_audit <- design_bundle$source_dataset_survival_audit
accepted_score_effects <- model_bundle$score_effects

required_analysis_columns <- c(
  "sample_order",
  "sample_id",
  "source_dataset_id",
  "efs_time_months",
  "efs_event",
  "efs_complete_public_set",
  "efs_positive_time_sensitivity_set",
  "Triclosan_activity"
)

assert_true(
  is.data.frame(analysis_table) &&
    nrow(analysis_table) == 579L &&
    all(required_analysis_columns %in% colnames(analysis_table)),
  "Script 10C analysis table is malformed."
)
assert_true(
  anyDuplicated(as.character(analysis_table$sample_id)) == 0L,
  "Analysis table contains duplicated sample IDs."
)
assert_true(
  all(is.finite(analysis_table$Triclosan_activity)),
  "Triclosan_activity contains non-finite values."
)

assert_true(
  is.data.frame(eligibility_audit) &&
    all(c(
      "source_dataset_id",
      "complete_EFS_number",
      "positive_time_EFS_number",
      "event_number",
      "censored_number",
      "eligible_for_dataset_meta_analysis"
    ) %in% colnames(eligibility_audit)),
  "Source-dataset eligibility audit is malformed."
)

eligible_source_ids <- as.character(
  eligibility_audit$source_dataset_id[
    as.logical(
      eligibility_audit$eligible_for_dataset_meta_analysis
    )
  ]
)

eligible_source_ids <- eligible_source_ids[
  order(safe_numeric(eligible_source_ids))
]

expected_eligible_source_ids <- c(
  "2", "3", "4", "6", "7",
  "12", "17", "20", "25", "29", "40"
)

assert_true(
  identical(
    eligible_source_ids,
    expected_eligible_source_ids
  ),
  paste0(
    "Eligible source datasets differ from the accepted Script 10C design.\n",
    "Observed: ",
    paste(eligible_source_ids, collapse = ";"),
    "\nExpected: ",
    paste(expected_eligible_source_ids, collapse = ";")
  )
)

assert_true(
  length(eligible_source_ids) == 11L,
  "Expected 11 eligible source datasets."
)

# ------------------------------
# 6. Fit each eligible source dataset
# ------------------------------
analysis_set_definitions <- list(
  EFS383 = as.logical(
    analysis_table$efs_complete_public_set
  ),
  EFS379 = as.logical(
    analysis_table$efs_positive_time_sensitivity_set
  )
)

assert_true(
  sum(analysis_set_definitions$EFS383) == 383L,
  "EFS383 does not contain 383 records."
)
assert_true(
  sum(analysis_set_definitions$EFS379) == 379L,
  "EFS379 does not contain 379 records."
)

fit_rows <- list()
sample_rows <- list()
fit_objects <- list()
fit_index <- 0L
sample_index <- 0L

for (analysis_set_name in names(analysis_set_definitions)) {
  endpoint_mask <- analysis_set_definitions[[analysis_set_name]]

  for (source_id in eligible_source_ids) {
    fit_index <- fit_index + 1L

    dataset_mask <- endpoint_mask &
      as.character(analysis_table$source_dataset_id) == source_id

    d <- analysis_table[
      dataset_mask,
      ,
      drop = FALSE
    ]

    dataset_n <- nrow(d)
    event_n <- sum(d$efs_event == 1L, na.rm = TRUE)
    censored_n <- sum(d$efs_event == 0L, na.rm = TRUE)
    score_mean <- mean(d$Triclosan_activity)
    score_sd <- stats::sd(d$Triclosan_activity)

    eligibility_by_counts <- dataset_n >= 10L &&
      event_n >= 3L &&
      censored_n >= 3L &&
      is.finite(score_sd) &&
      score_sd > 0

    d$score_z_within_dataset <-
      (d$Triclosan_activity - score_mean) / score_sd

    sample_index <- sample_index + 1L
    sample_rows[[sample_index]] <- data.frame(
      analysis_set = analysis_set_name,
      source_dataset_id = source_id,
      sample_order = d$sample_order,
      sample_id = as.character(d$sample_id),
      efs_time_months = d$efs_time_months,
      efs_event = d$efs_event,
      Triclosan_activity = d$Triclosan_activity,
      dataset_score_mean = score_mean,
      dataset_score_SD = score_sd,
      score_z_within_dataset =
        d$score_z_within_dataset,
      included_in_dataset_cox =
        rep(eligibility_by_counts, dataset_n),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )

    fit_error <- ""
    fit_warnings <- character(0)
    fit <- NULL

    if (eligibility_by_counts) {
      fitted <- tryCatch(
        capture_warnings(
          survival::coxph(
            formula = survival::Surv(
              efs_time_months,
              efs_event
            ) ~ score_z_within_dataset,
            data = d,
            ties = "efron",
            singular.ok = FALSE,
            model = TRUE,
            x = TRUE,
            y = TRUE,
            control = survival::coxph.control(
              eps = 1e-09,
              toler.chol = 1e-09,
              iter.max = 100L,
              timefix = TRUE
            )
          )
        ),
        error = function(e) {
          fit_error <<- conditionMessage(e)
          NULL
        }
      )

      if (!is.null(fitted)) {
        fit <- fitted$value
        fit_warnings <- fitted$warnings
      }
    } else {
      fit_error <- "FAILED_PRESPECIFIED_ELIGIBILITY_AFTER_SET_RECONSTRUCTION"
    }

    fit_audit <- audit_coxph_fit(
      fit,
      warnings = fit_warnings
    )

    fit_valid <- eligibility_by_counts &&
      isTRUE(fit_audit$valid)

    coefficient <- NA_real_
    standard_error <- NA_real_
    z_statistic <- NA_real_
    p_value <- NA_real_
    HR <- NA_real_
    CI_lower <- NA_real_
    CI_upper <- NA_real_
    loglik_null <- NA_real_
    loglik_fitted <- NA_real_
    iteration_number <- NA_integer_

    if (fit_valid) {
      fit_summary <- summary(fit)
      coefficient_matrix <- fit_summary$coefficients
      confidence_matrix <- fit_summary$conf.int

      assert_true(
        nrow(coefficient_matrix) == 1L &&
          nrow(confidence_matrix) == 1L &&
          identical(
            rownames(coefficient_matrix),
            "score_z_within_dataset"
          ) &&
          identical(
            rownames(confidence_matrix),
            "score_z_within_dataset"
          ),
        paste0(
          analysis_set_name,
          " dataset ",
          source_id,
          " returned an unexpected coefficient table."
        )
      )

      coefficient <- as.numeric(
        coefficient_matrix[1, "coef"]
      )
      standard_error <- as.numeric(
        coefficient_matrix[1, "se(coef)"]
      )
      z_statistic <- as.numeric(
        coefficient_matrix[1, "z"]
      )
      p_value <- as.numeric(
        coefficient_matrix[1, "Pr(>|z|)"]
      )
      HR <- as.numeric(
        confidence_matrix[1, "exp(coef)"]
      )
      CI_lower <- as.numeric(
        confidence_matrix[1, "lower .95"]
      )
      CI_upper <- as.numeric(
        confidence_matrix[1, "upper .95"]
      )
      loglik_null <- as.numeric(fit$loglik[1])
      loglik_fitted <- as.numeric(fit$loglik[2])
      iteration_number <- if (
        length(fit$iter) == 0L
      ) {
        NA_integer_
      } else {
        as.integer(fit$iter[1])
      }

      assert_true(
        all(is.finite(c(
          coefficient,
          standard_error,
          z_statistic,
          p_value,
          HR,
          CI_lower,
          CI_upper,
          loglik_null,
          loglik_fitted
        ))) &&
          standard_error > 0 &&
          HR > 0 &&
          CI_lower > 0 &&
          CI_upper > 0 &&
          CI_lower <= HR &&
          HR <= CI_upper,
        paste0(
          analysis_set_name,
          " dataset ",
          source_id,
          " produced an invalid valid-fit result."
        )
      )

      fit_objects[[
        paste0(analysis_set_name, "_DATASET_", source_id)
      ]] <- fit
    }

    fit_rows[[fit_index]] <- data.frame(
      analysis_set = analysis_set_name,
      source_dataset_id = source_id,
      sample_number = dataset_n,
      event_number = event_n,
      censored_number = censored_n,
      zero_time_number =
        sum(d$efs_time_months == 0, na.rm = TRUE),
      raw_score_mean = score_mean,
      raw_score_SD = score_sd,
      prespecified_eligibility_passed =
        eligibility_by_counts,
      fit_object_created = inherits(fit, "coxph"),
      fit_valid = fit_valid,
      fit_validity_reason = if (fit_valid) {
        "VALID"
      } else if (nzchar(fit_error)) {
        paste0("FIT_ERROR:", fit_error)
      } else {
        fit_audit$reason
      },
      log_HR_per_within_dataset_SD = coefficient,
      standard_error = standard_error,
      variance = standard_error^2,
      hazard_ratio_per_within_dataset_SD = HR,
      confidence_lower_95 = CI_lower,
      confidence_upper_95 = CI_upper,
      z_statistic = z_statistic,
      p_value = p_value,
      null_log_likelihood = loglik_null,
      fitted_log_likelihood = loglik_fitted,
      iteration_number = iteration_number,
      warning_number = length(fit_warnings),
      warning_messages = collapse_messages(fit_warnings),
      coefficients_finite =
        fit_audit$coefficients_finite,
      standard_errors_valid =
        fit_audit$standard_errors_valid,
      log_likelihood_finite =
        fit_audit$log_likelihood_finite,
      no_failure_marker =
        fit_audit$no_failure_marker,
      no_infinite_coefficient_warning =
        fit_audit$no_infinite_coefficient_warning,
      cutoff_used = FALSE,
      sample_deleted = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }
}

dataset_effects <- do.call(rbind, fit_rows)
dataset_sample_audit <- do.call(rbind, sample_rows)

rownames(dataset_effects) <- NULL
rownames(dataset_sample_audit) <- NULL

assert_true(
  nrow(dataset_effects) == 22L,
  "Expected 22 dataset-by-analysis-set effect rows."
)
assert_true(
  all(
    dataset_effects$source_dataset_id %in%
      eligible_source_ids
  ),
  "Dataset effect table contains an unapproved source dataset."
)
assert_true(
  !any(dataset_effects$cutoff_used) &&
    !any(dataset_effects$sample_deleted),
  "A cutoff or sample deletion was unexpectedly used."
)

valid_fit_counts <- aggregate(
  fit_valid ~ analysis_set,
  data = dataset_effects,
  FUN = sum
)

assert_true(
  all(valid_fit_counts$fit_valid >= 5L),
  paste0(
    "Fewer than five valid dataset-level Cox models were available in at ",
    "least one analysis set. Inspect the saved fit audit."
  )
)

# ------------------------------
# 7. Pool dataset effects
# ------------------------------
meta_primary <- compute_meta_summary(
  dataset_effects,
  "EFS383"
)
meta_sensitivity <- compute_meta_summary(
  dataset_effects,
  "EFS379"
)

meta_summary <- rbind(
  meta_primary$summary,
  meta_sensitivity$summary
)
heterogeneity_summary <- rbind(
  meta_primary$heterogeneity,
  meta_sensitivity$heterogeneity
)

rownames(meta_summary) <- NULL
rownames(heterogeneity_summary) <- NULL

leave_one_out <- rbind(
  compute_leave_one_out(
    dataset_effects,
    "EFS383"
  ),
  compute_leave_one_out(
    dataset_effects,
    "EFS379"
  )
)
rownames(leave_one_out) <- NULL

# ------------------------------
# 8. Compare with accepted stratified Cox results
# ------------------------------
comparison_rows <- list()

comparison_mapping <- data.frame(
  analysis_set = c("EFS383", "EFS379"),
  accepted_model_id = c(
    "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED",
    "M2_SENSITIVITY_EFS379_UNADJUSTED_STRATIFIED"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

for (i in seq_len(nrow(comparison_mapping))) {
  set_name <- comparison_mapping$analysis_set[i]
  model_id <- comparison_mapping$accepted_model_id[i]

  accepted_row <- accepted_score_effects[
    accepted_score_effects$model_id == model_id,
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(accepted_row) == 1L,
    paste0("Accepted Script 11A score effect is missing: ", model_id)
  )

  reml_row <- meta_summary[
    meta_summary$analysis_set == set_name &
      meta_summary$pooling_method ==
        "RANDOM_REML_MODIFIED_HARTUNG_KNAPP",
    ,
    drop = FALSE
  ]

  fixed_row <- meta_summary[
    meta_summary$analysis_set == set_name &
      meta_summary$pooling_method ==
        "FIXED_INVERSE_VARIANCE",
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(reml_row) == 1L &&
      nrow(fixed_row) == 1L,
    paste0("Meta summary lookup failed for ", set_name)
  )

  comparison_rows[[i]] <- rbind(
    data.frame(
      analysis_set = set_name,
      method = "ACCEPTED_SOURCE_STRATIFIED_COX",
      dataset_number = NA_integer_,
      hazard_ratio = accepted_row$hazard_ratio_per_1_SD,
      confidence_lower_95 = accepted_row$confidence_lower_95,
      confidence_upper_95 = accepted_row$confidence_upper_95,
      p_value = accepted_row$p_value,
      interpretation_role = "PRIMARY_OR_PRESPECIFIED_SENSITIVITY",
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      analysis_set = set_name,
      method = "DATASET_META_FIXED",
      dataset_number = fixed_row$dataset_number,
      hazard_ratio = fixed_row$hazard_ratio,
      confidence_lower_95 = fixed_row$confidence_lower_95,
      confidence_upper_95 = fixed_row$confidence_upper_95,
      p_value = fixed_row$p_value,
      interpretation_role =
        "DATASET_LEVEL_SENSITIVITY",
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      analysis_set = set_name,
      method = "DATASET_META_REML_MODIFIED_HK",
      dataset_number = reml_row$dataset_number,
      hazard_ratio = reml_row$hazard_ratio,
      confidence_lower_95 = reml_row$confidence_lower_95,
      confidence_upper_95 = reml_row$confidence_upper_95,
      p_value = reml_row$p_value,
      interpretation_role =
        "DATASET_LEVEL_SENSITIVITY",
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )
}

method_comparison <- do.call(rbind, comparison_rows)
rownames(method_comparison) <- NULL

# ------------------------------
# 9. Integrity summary
# ------------------------------
primary_reml <- meta_summary[
  meta_summary$analysis_set == "EFS383" &
    meta_summary$pooling_method ==
      "RANDOM_REML_MODIFIED_HARTUNG_KNAPP",
  ,
  drop = FALSE
]

sensitivity_reml <- meta_summary[
  meta_summary$analysis_set == "EFS379" &
    meta_summary$pooling_method ==
      "RANDOM_REML_MODIFIED_HARTUNG_KNAPP",
  ,
  drop = FALSE
]

primary_heterogeneity <- heterogeneity_summary[
  heterogeneity_summary$analysis_set == "EFS383",
  ,
  drop = FALSE
]

summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Script_build_ID",
    "Source_Script10C_bundle_MD5",
    "Source_Script11A_bundle_MD5",
    "Source_Script11B_v4_bundle_MD5",
    "Survival_package_version",
    "Prespecified_eligible_source_datasets",
    "Valid_dataset_Cox_models_EFS383",
    "Valid_dataset_Cox_models_EFS379",
    "Primary_meta_method",
    "Primary_meta_HR_per_within_dataset_SD",
    "Primary_meta_CI_lower_95",
    "Primary_meta_CI_upper_95",
    "Primary_meta_p_value",
    "Primary_meta_I2_percent",
    "Primary_meta_tau2_REML",
    "Positive_time_meta_HR_per_within_dataset_SD",
    "Positive_time_meta_CI_lower_95",
    "Positive_time_meta_CI_upper_95",
    "Positive_time_meta_p_value",
    "Leave_one_out_rows",
    "Optimized_cutoff_selected",
    "High_low_group_created",
    "Influence_based_sample_deletion",
    "Kaplan_Meier_fitted",
    "Expression_values_modified",
    "GSVA_recomputed",
    "Primary_stratified_Cox_result_replaced",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "11C",
    SCRIPT_BUILD_ID,
    observed_design_md5,
    observed_model_md5,
    observed_diagnostic_md5,
    survival_version,
    length(eligible_source_ids),
    sum(
      dataset_effects$analysis_set == "EFS383" &
        dataset_effects$fit_valid
    ),
    sum(
      dataset_effects$analysis_set == "EFS379" &
        dataset_effects$fit_valid
    ),
    "RANDOM_REML_MODIFIED_HARTUNG_KNAPP",
    primary_reml$hazard_ratio,
    primary_reml$confidence_lower_95,
    primary_reml$confidence_upper_95,
    primary_reml$p_value,
    primary_heterogeneity$I2_percent,
    primary_heterogeneity$tau2_REML,
    sensitivity_reml$hazard_ratio,
    sensitivity_reml$confidence_lower_95,
    sensitivity_reml$confidence_upper_95,
    sensitivity_reml$p_value,
    nrow(leave_one_out),
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Save staging outputs
# ------------------------------
input_manifest <- make_manifest(required_inputs)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script11C",
  script_build_id = SCRIPT_BUILD_ID,
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_script10c_bundle_file =
    normalize_existing_path(design_bundle_file),
  source_script10c_bundle_md5 = observed_design_md5,
  source_script11a_bundle_file =
    normalize_existing_path(model_bundle_file),
  source_script11a_bundle_md5 = observed_model_md5,
  source_script11b_bundle_file =
    normalize_existing_path(diagnostic_bundle_file),
  source_script11b_bundle_md5 = observed_diagnostic_md5,
  survival_package_version = survival_version,
  eligible_source_dataset_ids = eligible_source_ids,
  dataset_effects = dataset_effects,
  dataset_sample_audit = dataset_sample_audit,
  meta_summary = meta_summary,
  heterogeneity_summary = heterogeneity_summary,
  leave_one_out = leave_one_out,
  method_comparison = method_comparison,
  dataset_cox_fit_objects = fit_objects,
  integrity_summary = summary_table,
  policy = list(
    primary_analysis_set = "EFS383",
    positive_time_sensitivity_set = "EFS379",
    eligibility_rule =
      "n>=10, events>=3, censored>=3, nonzero score variance",
    predictor_scale =
      "One within-source-dataset SD of continuous Triclosan_activity",
    dataset_model =
      "Cox PH with Efron ties",
    primary_pooling =
      "REML random effect with modified Hartung-Knapp interval",
    fixed_effect_also_reported = TRUE,
    leave_one_dataset_out_reported = TRUE,
    optimized_cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    influence_based_sample_deletion = FALSE,
    Kaplan_Meier_fitted = FALSE,
    expression_values_modified = FALSE,
    GSVA_recomputed = FALSE,
    primary_stratified_Cox_result_replaced = FALSE
  ),
  provenance = list(
    accepted_script10c_bundle_md5 = accepted_design_md5,
    accepted_script11a_bundle_md5 = accepted_model_md5,
    accepted_script11b_v4_bundle_md5 =
      accepted_diagnostic_md5,
    next_step_requires_review_of = c(
      "dataset_effects",
      "meta_summary",
      "heterogeneity_summary",
      "leave_one_out"
    )
  )
)

class(complete_bundle) <- c(
  "GSE31519_dataset_level_meta_analysis_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_dataset_level_meta_analysis_COMPLETE_bundle.rds"
)
stage_effect_file <- file.path(
  stage_audit_dir,
  "GSE31519_dataset_level_continuous_score_effects.csv"
)
stage_sample_file <- file.path(
  stage_audit_dir,
  "GSE31519_dataset_level_meta_sample_audit.csv"
)
stage_meta_file <- file.path(
  stage_audit_dir,
  "GSE31519_dataset_level_meta_pooled_summary.csv"
)
stage_heterogeneity_file <- file.path(
  stage_audit_dir,
  "GSE31519_dataset_level_meta_heterogeneity.csv"
)
stage_leave_one_out_file <- file.path(
  stage_audit_dir,
  "GSE31519_dataset_level_meta_leave_one_out.csv"
)
stage_comparison_file <- file.path(
  stage_audit_dir,
  "GSE31519_stratified_Cox_vs_dataset_meta_comparison.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_dataset_level_meta_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script11C_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script11C_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script11C_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script11C_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)

write_csv_utf8(dataset_effects, stage_effect_file)
write_csv_utf8(dataset_sample_audit, stage_sample_file)
write_csv_utf8(meta_summary, stage_meta_file)
write_csv_utf8(heterogeneity_summary, stage_heterogeneity_file)
write_csv_utf8(leave_one_out, stage_leave_one_out_file)
write_csv_utf8(method_comparison, stage_comparison_file)
write_csv_utf8(summary_table, stage_summary_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

bundle_check <- readRDS(stage_bundle_file)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "script_build_id",
      "dataset_effects",
      "dataset_sample_audit",
      "meta_summary",
      "heterogeneity_summary",
      "leave_one_out",
      "method_comparison",
      "dataset_cox_fit_objects",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 11C bundle is missing required fields."
)
assert_true(
  identical(
    as.character(bundle_check$script_build_id),
    SCRIPT_BUILD_ID
  ),
  "Saved Script 11C build ID is incorrect."
)
assert_true(
  nrow(bundle_check$dataset_effects) == 22L,
  "Saved dataset-effects table does not contain 22 rows."
)
assert_true(
  isFALSE(bundle_check$policy$optimized_cutoff_selected) &&
    isFALSE(
      bundle_check$policy$influence_based_sample_deletion
    ) &&
    isFALSE(
      bundle_check$policy$primary_stratified_Cox_result_replaced
    ),
  "Saved Script 11C policy incorrectly indicates cutoff, deletion or replacement."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 11C",
  "Dataset-level continuous-score meta-analysis sensitivity",
  paste0("Script build ID: ", SCRIPT_BUILD_ID),
  "============================================================",
  paste0(
    "Completion time: ",
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  ),
  paste0("Source Script 10C bundle MD5: ", observed_design_md5),
  paste0("Source Script 11A bundle MD5: ", observed_model_md5),
  paste0(
    "Source Script 11B v4 bundle MD5: ",
    observed_diagnostic_md5
  ),
  paste0("survival package version: ", survival_version),
  paste0(
    "Prespecified eligible source datasets: ",
    paste(eligible_source_ids, collapse = ";")
  ),
  paste0(
    "Valid dataset Cox models EFS383: ",
    sum(
      dataset_effects$analysis_set == "EFS383" &
        dataset_effects$fit_valid
    ),
    " / 11"
  ),
  paste0(
    "Valid dataset Cox models EFS379: ",
    sum(
      dataset_effects$analysis_set == "EFS379" &
        dataset_effects$fit_valid
    ),
    " / 11"
  ),
  "",
  paste0(
    "Primary EFS383 REML modified-HK HR per within-dataset SD: ",
    format(primary_reml$hazard_ratio, digits = 10)
  ),
  paste0(
    "Primary EFS383 95% CI: ",
    format(primary_reml$confidence_lower_95, digits = 10),
    " to ",
    format(primary_reml$confidence_upper_95, digits = 10)
  ),
  paste0(
    "Primary EFS383 P value: ",
    format(primary_reml$p_value, digits = 10)
  ),
  paste0(
    "Primary EFS383 I2: ",
    format(primary_heterogeneity$I2_percent, digits = 8),
    "%"
  ),
  paste0(
    "Primary EFS383 tau2 REML: ",
    format(primary_heterogeneity$tau2_REML, digits = 10)
  ),
  "",
  paste0(
    "Positive-time EFS379 REML modified-HK HR: ",
    format(sensitivity_reml$hazard_ratio, digits = 10)
  ),
  paste0(
    "Positive-time EFS379 95% CI: ",
    format(sensitivity_reml$confidence_lower_95, digits = 10),
    " to ",
    format(sensitivity_reml$confidence_upper_95, digits = 10)
  ),
  paste0(
    "Positive-time EFS379 P value: ",
    format(sensitivity_reml$p_value, digits = 10)
  ),
  paste0(
    "Leave-one-dataset-out rows: ",
    nrow(leave_one_out)
  ),
  "Optimized cutoff selected: FALSE",
  "High/low group created: FALSE",
  "Influence-based sample deletion: FALSE",
  "Kaplan-Meier fitted: FALSE",
  "Expression values modified: FALSE",
  "GSVA recomputed: FALSE",
  "Primary stratified Cox result replaced: FALSE",
  paste0("Script 11C bundle MD5: ", bundle_md5),
  "",
  "SCRIPT11C STATUS: COMPLETE",
  paste0(
    "Dataset-level pooling is a sensitivity analysis. The accepted source-",
    "stratified continuous Cox result remains primary."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(report_lines),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_effect_file,
  stage_sample_file,
  stage_meta_file,
  stage_heterogeneity_file,
  stage_leave_one_out_file,
  stage_comparison_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)),
  "At least one staged Script 11C output is missing."
)
assert_true(
  all(file.info(output_files_before_manifest)$size > 0),
  "At least one staged Script 11C output is empty."
)

output_manifest <- make_manifest(output_files_before_manifest)
write_csv_utf8(output_manifest, stage_output_manifest_file)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) == length(output_files_before_manifest),
  "Script 11C output manifest has an incorrect row count."
)

for (i in seq_along(output_files_before_manifest)) {
  file_i <- output_files_before_manifest[i]
  row_i <- manifest_check[
    manifest_check$file_name == basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0("Missing or duplicated manifest row: ", basename(file_i))
  )
  assert_true(
    identical(
      tolower(as.character(row_i$md5)),
      tolower(md5_one(file_i))
    ),
    paste0("Manifest MD5 mismatch: ", basename(file_i))
  )
  assert_true(
    as.numeric(row_i$size_bytes) ==
      as.numeric(file.info(file_i)$size),
    paste0("Manifest size mismatch: ", basename(file_i))
  )
}

# ------------------------------
# 11. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 11C directory appeared during staging."
)

rename_ok <- file.rename(stage_root, final_root)

if (!isTRUE(rename_ok)) {
  dir.create(final_root, recursive = TRUE, showWarnings = FALSE)

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 11C staging directory."
  )

  unlink(stage_root, recursive = TRUE, force = TRUE)
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_dataset_level_meta_analysis_COMPLETE_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script11C_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script11C_output_manifest_with_MD5.csv"
)

assert_true(
  all(file.exists(c(
    final_bundle_file,
    final_report_file,
    final_manifest_file
  ))),
  "Committed Script 11C output is incomplete."
)
assert_true(
  identical(md5_one(final_bundle_file), bundle_md5),
  "Committed Script 11C bundle MD5 changed after commit."
)
assert_true(
  report_contains(
    final_report_file,
    "SCRIPT11C STATUS: COMPLETE"
  ),
  "Committed Script 11C report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 11C completed successfully.\n")
cat(
  "Valid dataset Cox models EFS383 / EFS379: ",
  sum(
    dataset_effects$analysis_set == "EFS383" &
      dataset_effects$fit_valid
  ),
  " / ",
  sum(
    dataset_effects$analysis_set == "EFS379" &
      dataset_effects$fit_valid
  ),
  "\n",
  sep = ""
)
cat(
  "Primary REML modified-HK HR (95% CI): ",
  format(primary_reml$hazard_ratio, digits = 7),
  " (",
  format(primary_reml$confidence_lower_95, digits = 7),
  " to ",
  format(primary_reml$confidence_upper_95, digits = 7),
  "), P=",
  format(primary_reml$p_value, digits = 7),
  "\n",
  sep = ""
)
cat(
  "Primary I2: ",
  format(primary_heterogeneity$I2_percent, digits = 6),
  "%\n",
  sep = ""
)
cat("Optimized cutoff selected: FALSE\n")
cat("Influence-based sample deletion: FALSE\n")
cat("Primary stratified Cox result replaced: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

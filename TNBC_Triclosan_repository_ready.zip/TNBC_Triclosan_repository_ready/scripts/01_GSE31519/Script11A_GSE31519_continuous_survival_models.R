# ==============================================================================
# TNBC_Triclosan
# Step 2 - GSE31519 external validation
# Script 11A
#
# Purpose:
#   Continue strictly from the accepted Script 10C technical-confounding and
#   survival-design bundle. Fit only the prespecified continuous-score Cox
#   proportional-hazards models and perform proportional-hazards diagnostics.
#
# Prespecified models:
#   M1 Primary:
#      EFS383; continuous Triclosan_activity per 1 SD;
#      baseline hazard stratified by source_dataset_id.
#
#   M2 Positive-time sensitivity:
#      EFS379; continuous Triclosan_activity per 1 SD;
#      baseline hazard stratified by source_dataset_id.
#
#   M3 Primary clinically adjusted:
#      EFS383 complete cases; score + age per 10 years + nodal status +
#      tumor-size group + histologic-grade group;
#      baseline hazard stratified by source_dataset_id.
#
#   M4 Adjusted positive-time sensitivity:
#      Same clinical adjustment in EFS379.
#
#   M5 Treatment-added sensitivity:
#      EFS383 complete cases; M3 covariates plus adjuvant chemotherapy;
#      baseline hazard stratified by source_dataset_id.
#
# This script DOES:
#   - verify the accepted Script 10C bundle by completion marker, manifest and
#     independently accepted MD5;
#   - reconstruct every model-specific analysis set from the saved analysis
#     table;
#   - preserve the prespecified score scaling from Script 10C;
#   - fit Cox models with ties = "efron";
#   - extract score HR per 1 SD, all coefficients, likelihood statistics,
#     concordance and proportional-hazards tests;
#   - save exact sample inclusion for every model;
#   - save RDS, CSV audits, MD5 manifests, report and sessionInfo.
#
# This script DOES NOT:
#   - rerun Scripts 07A-10C;
#   - recompute GSVA or alter expression values;
#   - optimize or search for a cutoff;
#   - create high/low groups or Kaplan-Meier curves;
#   - fit dataset-level meta-analysis models;
#   - select covariates by P value;
#   - impute clinical data;
#   - create manuscript figures.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

# ------------------------------
# 0. Fixed paths
# ------------------------------
project_root <- "C:/Users/14351/Documents/TNBC_Triclosan"
step_root <- file.path(
  project_root,
  "Step2_GSE31519_external_validation"
)

input_root <- file.path(
  step_root,
  "09_technical_confounding_and_survival_design"
)
final_root <- file.path(
  step_root,
  "10_primary_continuous_survival_models"
)

input_bundle_file <- file.path(
  input_root,
  "objects",
  "GSE31519_technical_confounding_survival_design_COMPLETE_bundle.rds"
)
input_manifest_file <- file.path(
  input_root,
  "audit",
  "Script10C_output_manifest_with_MD5.csv"
)
input_report_file <- file.path(
  input_root,
  "logs",
  "Script10C_COMPLETE_report.txt"
)
input_summary_file <- file.path(
  input_root,
  "audit",
  "GSE31519_technical_confounding_survival_design_summary.csv"
)
input_design_file <- file.path(
  input_root,
  "audit",
  "GSE31519_prespecified_survival_analysis_design.csv"
)

required_inputs <- c(
  input_bundle_file,
  input_manifest_file,
  input_report_file,
  input_summary_file,
  input_design_file
)

missing_inputs <- required_inputs[!file.exists(required_inputs)]

if (length(missing_inputs) > 0L) {
  stop(
    paste0(
      "Script 11A cannot start because required accepted files are missing:\n",
      paste0("- ", missing_inputs, collapse = "\n")
    ),
    call. = FALSE
  )
}

if (!dir.exists(step_root)) {
  stop("Step 2 project directory does not exist.", call. = FALSE)
}

if (dir.exists(final_root)) {
  existing_entries <- setdiff(
    list.files(final_root, all.files = TRUE),
    c(".", "..")
  )

  if (length(existing_entries) == 0L) {
    unlink(final_root, recursive = TRUE, force = TRUE)
  } else {
    stop(
      paste0(
        "Output directory already exists and is not empty; Script 11A will ",
        "not overwrite it:\n",
        final_root,
        "\nPlease inspect or archive the existing directory before rerunning."
      ),
      call. = FALSE
    )
  }
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
stage_root <- file.path(
  step_root,
  paste0(".Script11A_staging_", stamp, "_", Sys.getpid())
)
stage_object_dir <- file.path(stage_root, "objects")
stage_audit_dir <- file.path(stage_root, "audit")
stage_log_dir <- file.path(stage_root, "logs")

dir.create(stage_object_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(stage_log_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(dir.exists(c(
  stage_object_dir,
  stage_audit_dir,
  stage_log_dir
)))) {
  stop("Unable to create Script 11A staging directories.", call. = FALSE)
}

committed <- FALSE

on.exit({
  if (!committed && dir.exists(stage_root)) {
    unlink(stage_root, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

# ------------------------------
# 1. Helper functions
# ------------------------------
assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

md5_one <- function(path) {
  unname(tools::md5sum(path))
}

normalize_existing_path <- function(path) {
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

write_csv_utf8 <- function(x, path) {
  write.csv(
    x,
    file = path,
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

report_contains <- function(report_file, fixed_text) {
  lines <- readLines(report_file, warn = FALSE, encoding = "UTF-8")
  any(grepl(fixed_text, lines, fixed = TRUE))
}

make_manifest <- function(paths, displayed_paths = paths) {
  stopifnot(length(paths) == length(displayed_paths))
  info <- file.info(paths)

  data.frame(
    file_name = basename(displayed_paths),
    absolute_path = vapply(
      displayed_paths,
      function(path) {
        normalizePath(path, winslash = "/", mustWork = FALSE)
      },
      character(1)
    ),
    size_bytes = as.numeric(info$size),
    md5 = vapply(paths, md5_one, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

manifest_expected_md5 <- function(manifest_file, target_file) {
  manifest <- read.csv(
    manifest_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert_true(
    all(c("file_name", "size_bytes", "md5") %in% colnames(manifest)),
    paste0("Malformed manifest: ", manifest_file)
  )

  row_index <- which(manifest$file_name == basename(target_file))

  assert_true(
    length(row_index) == 1L,
    paste0(
      "Expected exactly one manifest row for ",
      basename(target_file)
    )
  )

  tolower(trimws(as.character(manifest$md5[row_index])))
}

capture_warnings <- function(expression) {
  warning_messages <- character(0)

  value <- withCallingHandlers(
    expression,
    warning = function(w) {
      warning_messages <<- c(
        warning_messages,
        conditionMessage(w)
      )
      invokeRestart("muffleWarning")
    }
  )

  list(
    value = value,
    warnings = unique(warning_messages)
  )
}

collapse_messages <- function(x) {
  x <- unique(trimws(as.character(x)))
  x <- x[nzchar(x)]
  if (length(x) == 0L) "" else paste(x, collapse = " | ")
}

safe_scalar <- function(x, default = NA_real_) {
  if (length(x) == 0L || is.null(x) || !is.finite(as.numeric(x)[1])) {
    return(default)
  }
  as.numeric(x)[1]
}

# ------------------------------
# 2. Package preflight
# ------------------------------
if (!requireNamespace("survival", quietly = TRUE)) {
  stop(
    paste0(
      "Required package 'survival' is not installed.\n",
      "Install it once with: install.packages('survival')"
    ),
    call. = FALSE
  )
}

survival_version <- as.character(
  utils::packageVersion("survival")
)

# ------------------------------
# 3. Verify accepted Script 10C identity
# ------------------------------
assert_true(
  report_contains(input_report_file, "SCRIPT10C STATUS: COMPLETE"),
  "Script 10C completion marker was not found."
)

expected_bundle_md5 <- manifest_expected_md5(
  input_manifest_file,
  input_bundle_file
)
observed_bundle_md5 <- tolower(md5_one(input_bundle_file))

assert_true(
  identical(expected_bundle_md5, observed_bundle_md5),
  paste0(
    "Script 10C bundle MD5 differs from its manifest.\n",
    "Expected: ", expected_bundle_md5,
    "\nObserved: ", observed_bundle_md5
  )
)

accepted_script10c_bundle_md5 <-
  "19a5f27976ba1cf82f15ad1f3f304f74"

assert_true(
  identical(observed_bundle_md5, accepted_script10c_bundle_md5),
  paste0(
    "Script 10C bundle differs from the independently accepted bundle.\n",
    "Expected: ", accepted_script10c_bundle_md5,
    "\nObserved: ", observed_bundle_md5
  )
)

input_summary <- read.csv(
  input_summary_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  all(c("item", "value") %in% colnames(input_summary)),
  "Script 10C summary is malformed."
)
assert_true(
  anyDuplicated(input_summary$item) == 0L,
  "Script 10C summary contains duplicated item names."
)

summary_lookup <- setNames(
  as.character(input_summary$value),
  input_summary$item
)

required_summary_items <- c(
  "Total_samples",
  "Complete_EFS_records",
  "Positive_time_EFS_records",
  "Events_complete_EFS",
  "Censored_complete_EFS",
  "Primary_predictor",
  "Primary_model_source_handling",
  "Optimized_cutoff_selected",
  "Survival_model_fitted",
  "Completion_status"
)

assert_true(
  all(required_summary_items %in% names(summary_lookup)),
  "Script 10C summary is missing required items."
)
assert_true(
  identical(summary_lookup[["Completion_status"]], "COMPLETE"),
  "Script 10C summary is not marked COMPLETE."
)
assert_true(
  identical(summary_lookup[["Optimized_cutoff_selected"]], "FALSE"),
  "Script 10C unexpectedly indicates an optimized cutoff."
)
assert_true(
  identical(summary_lookup[["Survival_model_fitted"]], "FALSE"),
  "Script 10C unexpectedly indicates a fitted survival model."
)

# ------------------------------
# 4. Read and validate Script 10C bundle
# ------------------------------
source_bundle <- readRDS(input_bundle_file)

required_bundle_fields <- c(
  "script",
  "source_accession",
  "source_script09b_bundle_md5",
  "source_script10b_bundle_md5",
  "locked_signature_genes",
  "analysis_table",
  "technical_global_tests",
  "source_dataset_survival_audit",
  "covariate_complete_case_audit",
  "survival_design_lock",
  "integrity_summary",
  "policy"
)

assert_true(
  is.list(source_bundle) &&
    all(required_bundle_fields %in% names(source_bundle)),
  "Script 10C bundle is missing required fields."
)
assert_true(
  identical(as.character(source_bundle$script), "Script10C"),
  "Input bundle was not created by Script 10C."
)
assert_true(
  identical(as.character(source_bundle$source_accession), "GSE31519"),
  "Input bundle is not for GSE31519."
)
assert_true(
  isFALSE(source_bundle$policy$optimized_cutoff_allowed),
  "Script 10C policy unexpectedly allows an optimized cutoff."
)
assert_true(
  isFALSE(source_bundle$policy$survival_model_fitted),
  "Script 10C policy unexpectedly indicates a fitted survival model."
)

analysis_table <- source_bundle$analysis_table

required_analysis_columns <- c(
  "sample_order",
  "sample_id",
  "source_dataset_id",
  "age_years",
  "nodal_status",
  "tumor_size_group",
  "histologic_grade_group",
  "adjuvant_chemotherapy",
  "efs_time_months",
  "efs_event",
  "efs_complete_public_set",
  "efs_positive_time_sensitivity_set",
  "score_z_EFS383",
  "score_z_EFS379",
  "Triclosan_activity"
)

assert_true(
  is.data.frame(analysis_table) &&
    nrow(analysis_table) == 579L &&
    all(required_analysis_columns %in% colnames(analysis_table)),
  "Script 10C analysis table is missing required rows or columns."
)
assert_true(
  anyDuplicated(as.character(analysis_table$sample_id)) == 0L,
  "Script 10C analysis table contains duplicated sample IDs."
)
assert_true(
  all(is.finite(analysis_table$Triclosan_activity)),
  "Continuous Triclosan activity contains non-finite values."
)

efs383_mask <- as.logical(
  analysis_table$efs_complete_public_set
)
efs379_mask <- as.logical(
  analysis_table$efs_positive_time_sensitivity_set
)

assert_true(sum(efs383_mask) == 383L, "EFS383 does not contain 383 records.")
assert_true(sum(efs379_mask) == 379L, "EFS379 does not contain 379 records.")
assert_true(
  sum(analysis_table$efs_event[efs383_mask] == 1L) == 169L,
  "EFS383 does not contain 169 events."
)
assert_true(
  sum(analysis_table$efs_event[efs383_mask] == 0L) == 214L,
  "EFS383 does not contain 214 censored records."
)
assert_true(
  sum(is.finite(analysis_table$score_z_EFS383)) == 383L,
  "score_z_EFS383 does not contain 383 finite values."
)
assert_true(
  sum(is.finite(analysis_table$score_z_EFS379)) == 379L,
  "score_z_EFS379 does not contain 379 finite values."
)

# ------------------------------
# 5. Lock model specifications
# ------------------------------
model_specifications <- data.frame(
  model_order = 1:5,
  model_id = c(
    "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED",
    "M2_SENSITIVITY_EFS379_UNADJUSTED_STRATIFIED",
    "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED",
    "M4_SENSITIVITY_EFS379_CLINICAL_ADJUSTED_STRATIFIED",
    "M5_EFS383_TREATMENT_ADDED_STRATIFIED"
  ),
  analysis_set = c(
    "EFS383",
    "EFS379",
    "EFS383_COMPLETE_CASE",
    "EFS379_COMPLETE_CASE",
    "EFS383_COMPLETE_CASE"
  ),
  score_source_column = c(
    "score_z_EFS383",
    "score_z_EFS379",
    "score_z_EFS383",
    "score_z_EFS379",
    "score_z_EFS383"
  ),
  covariate_set = c(
    "NONE",
    "NONE",
    "AGE_NODAL_SIZE_GRADE",
    "AGE_NODAL_SIZE_GRADE",
    "AGE_NODAL_SIZE_GRADE_CHEMO"
  ),
  formula_text = c(
    paste0(
      "Surv(efs_time_months, efs_event) ~ score_z + ",
      "strata(source_dataset_id)"
    ),
    paste0(
      "Surv(efs_time_months, efs_event) ~ score_z + ",
      "strata(source_dataset_id)"
    ),
    paste0(
      "Surv(efs_time_months, efs_event) ~ score_z + age_per_10_years + ",
      "nodal_status + tumor_size_group + histologic_grade_group + ",
      "strata(source_dataset_id)"
    ),
    paste0(
      "Surv(efs_time_months, efs_event) ~ score_z + age_per_10_years + ",
      "nodal_status + tumor_size_group + histologic_grade_group + ",
      "strata(source_dataset_id)"
    ),
    paste0(
      "Surv(efs_time_months, efs_event) ~ score_z + age_per_10_years + ",
      "nodal_status + tumor_size_group + histologic_grade_group + ",
      "adjuvant_chemotherapy + strata(source_dataset_id)"
    )
  ),
  expected_sample_number = c(383L, 379L, 261L, 260L, 237L),
  expected_event_number = c(169L, 166L, 87L, 87L, 81L),
  expected_censored_number = c(214L, 213L, 174L, 173L, 156L),
  ties_method = "efron",
  source_dataset_handling = "STRATIFIED_BASELINE_HAZARD",
  cutoff_used = FALSE,
  covariate_selected_by_p_value = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 6. Build model-specific data and inclusion audit
# ------------------------------
clinical_covariates <- c(
  "age_years",
  "nodal_status",
  "tumor_size_group",
  "histologic_grade_group"
)
treatment_covariates <- c(
  clinical_covariates,
  "adjuvant_chemotherapy"
)

build_model_data <- function(model_id) {
  if (model_id == "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED") {
    eligible <- efs383_mask
    score_column <- "score_z_EFS383"
    required_covariates <- character(0)
  } else if (
    model_id == "M2_SENSITIVITY_EFS379_UNADJUSTED_STRATIFIED"
  ) {
    eligible <- efs379_mask
    score_column <- "score_z_EFS379"
    required_covariates <- character(0)
  } else if (
    model_id == "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED"
  ) {
    eligible <- efs383_mask
    score_column <- "score_z_EFS383"
    required_covariates <- clinical_covariates
  } else if (
    model_id == "M4_SENSITIVITY_EFS379_CLINICAL_ADJUSTED_STRATIFIED"
  ) {
    eligible <- efs379_mask
    score_column <- "score_z_EFS379"
    required_covariates <- clinical_covariates
  } else if (
    model_id == "M5_EFS383_TREATMENT_ADDED_STRATIFIED"
  ) {
    eligible <- efs383_mask
    score_column <- "score_z_EFS383"
    required_covariates <- treatment_covariates
  } else {
    stop("Unknown model_id: ", model_id, call. = FALSE)
  }

  required_columns <- c(
    "efs_time_months",
    "efs_event",
    "source_dataset_id",
    score_column,
    required_covariates
  )

  complete_mask <- eligible &
    stats::complete.cases(
      analysis_table[, required_columns, drop = FALSE]
    )

  exclusion_reason <- rep("NOT_IN_ENDPOINT_ANALYSIS_SET", nrow(analysis_table))
  exclusion_reason[eligible] <- "INCLUDED"
  exclusion_reason[
    eligible &
      !stats::complete.cases(
        analysis_table[, required_columns, drop = FALSE]
      )
  ] <- "EXCLUDED_REQUIRED_COVARIATE_MISSING"

  d <- analysis_table[
    complete_mask,
    ,
    drop = FALSE
  ]

  d$score_z <- as.numeric(d[[score_column]])
  d$age_per_10_years <- as.numeric(d$age_years) / 10

  d$source_dataset_id <- factor(
    as.character(d$source_dataset_id)
  )

  if ("nodal_status" %in% required_covariates) {
    d$nodal_status <- factor(
      as.character(d$nodal_status),
      levels = c("NODE_NEGATIVE", "NODE_POSITIVE")
    )
  }

  if ("tumor_size_group" %in% required_covariates) {
    d$tumor_size_group <- factor(
      as.character(d$tumor_size_group),
      levels = c("T1", "T2_T4_OR_REST")
    )
  }

  if ("histologic_grade_group" %in% required_covariates) {
    d$histologic_grade_group <- factor(
      as.character(d$histologic_grade_group),
      levels = c("GRADE_1_2", "GRADE_3")
    )
  }

  if ("adjuvant_chemotherapy" %in% required_covariates) {
    d$adjuvant_chemotherapy <- factor(
      as.character(d$adjuvant_chemotherapy),
      levels = c("NO", "YES")
    )
  }

  d <- droplevels(d)

  inclusion <- data.frame(
    model_id = model_id,
    sample_order = analysis_table$sample_order,
    sample_id = as.character(analysis_table$sample_id),
    endpoint_set_eligible = eligible,
    included_in_model = complete_mask,
    exclusion_reason = exclusion_reason,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(
    data = d,
    inclusion = inclusion,
    score_column = score_column,
    required_covariates = required_covariates
  )
}

# ------------------------------
# 7. Fit models and extract audits
# ------------------------------
fit_objects <- list()
model_fit_rows <- list()
coefficient_rows <- list()
score_effect_rows <- list()
ph_rows <- list()
diagnostic_rows <- list()
inclusion_rows <- list()
warning_rows <- list()

for (i in seq_len(nrow(model_specifications))) {
  spec <- model_specifications[i, , drop = FALSE]
  model_id <- as.character(spec$model_id)

  built <- build_model_data(model_id)
  d <- built$data
  inclusion_rows[[i]] <- built$inclusion

  assert_true(
    nrow(d) == as.integer(spec$expected_sample_number),
    paste0(
      model_id,
      " expected ",
      spec$expected_sample_number,
      " samples but detected ",
      nrow(d),
      "."
    )
  )
  assert_true(
    sum(d$efs_event == 1L) == as.integer(spec$expected_event_number),
    paste0(model_id, " has an unexpected event count.")
  )
  assert_true(
    sum(d$efs_event == 0L) == as.integer(spec$expected_censored_number),
    paste0(model_id, " has an unexpected censored count.")
  )
  assert_true(
    all(is.finite(d$score_z)),
    paste0(model_id, " contains a non-finite score.")
  )
  assert_true(
    stats::sd(d$score_z) > 0,
    paste0(model_id, " score has zero variance.")
  )

  formula_i <- stats::as.formula(as.character(spec$formula_text))

  fitted <- capture_warnings(
    survival::coxph(
      formula = formula_i,
      data = d,
      ties = "efron",
      singular.ok = FALSE,
      model = TRUE,
      x = TRUE,
      y = TRUE
    )
  )

  fit <- fitted$value
  fit_warnings <- fitted$warnings

  assert_true(
    inherits(fit, "coxph"),
    paste0(model_id, " did not return a coxph object.")
  )
  hard_convergence_warning <- any(
    grepl(
      paste(
        c(
          "did not converge",
          "ran out of iterations",
          "infinite coefficient",
          "coefficient may be infinite",
          "loglik converged before variable"
        ),
        collapse = "|"
      ),
      fit_warnings,
      ignore.case = TRUE
    )
  )

  coefficient_finite <- all(is.finite(stats::coef(fit)))
  variance_finite <- all(is.finite(fit$var))
  variance_diagonal_positive <- all(diag(fit$var) > 0)

  model_converged <-
    !hard_convergence_warning &&
    coefficient_finite &&
    variance_finite &&
    variance_diagonal_positive

  assert_true(
    model_converged,
    paste0(
      model_id,
      " failed convergence/infinite-coefficient checks. Warnings: ",
      collapse_messages(fit_warnings)
    )
  )
  assert_true(
    coefficient_finite,
    paste0(model_id, " contains a non-finite coefficient.")
  )
  assert_true(
    "score_z" %in% names(stats::coef(fit)),
    paste0(model_id, " does not contain the score_z coefficient.")
  )

  fit_objects[[model_id]] <- fit

  fit_summary <- summary(fit)
  coef_matrix <- fit_summary$coefficients
  conf_matrix <- fit_summary$conf.int

  assert_true(
    nrow(coef_matrix) == nrow(conf_matrix),
    paste0(model_id, " coefficient and confidence tables differ in size.")
  )
  assert_true(
    identical(rownames(coef_matrix), rownames(conf_matrix)),
    paste0(model_id, " coefficient and confidence terms differ.")
  )

  model_coefficients <- data.frame(
    model_id = model_id,
    term = rownames(coef_matrix),
    coefficient_log_HR = as.numeric(coef_matrix[, "coef"]),
    hazard_ratio = as.numeric(conf_matrix[, "exp(coef)"]),
    standard_error = as.numeric(coef_matrix[, "se(coef)"]),
    z_statistic = as.numeric(coef_matrix[, "z"]),
    p_value = as.numeric(coef_matrix[, "Pr(>|z|)"]),
    confidence_level = 0.95,
    confidence_lower = as.numeric(conf_matrix[, "lower .95"]),
    confidence_upper = as.numeric(conf_matrix[, "upper .95"]),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  coefficient_rows[[i]] <- model_coefficients

  score_row <- model_coefficients[
    model_coefficients$term == "score_z",
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(score_row) == 1L,
    paste0(model_id, " does not have exactly one score effect row.")
  )

  score_effect_rows[[i]] <- data.frame(
    model_order = as.integer(spec$model_order),
    model_id = model_id,
    analysis_set = as.character(spec$analysis_set),
    score_scale = "PER_1_SD_IN_PRESPECIFIED_ENDPOINT_SET",
    sample_number = nrow(d),
    event_number = sum(d$efs_event == 1L),
    censored_number = sum(d$efs_event == 0L),
    source_stratum_number = nlevels(d$source_dataset_id),
    source_strata_with_at_least_one_event = length(unique(
      as.character(d$source_dataset_id[d$efs_event == 1L])
    )),
    hazard_ratio_per_1_SD = score_row$hazard_ratio,
    confidence_lower_95 = score_row$confidence_lower,
    confidence_upper_95 = score_row$confidence_upper,
    coefficient_log_HR = score_row$coefficient_log_HR,
    standard_error = score_row$standard_error,
    z_statistic = score_row$z_statistic,
    p_value = score_row$p_value,
    cutoff_used = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  concordance_value <- NA_real_
  concordance_se <- NA_real_

  if (!is.null(fit_summary$concordance)) {
    concordance_value <- safe_scalar(fit_summary$concordance[1])
    concordance_se <- safe_scalar(fit_summary$concordance[2])
  }

  model_fit_rows[[i]] <- data.frame(
    model_order = as.integer(spec$model_order),
    model_id = model_id,
    formula_text = paste(deparse(formula_i), collapse = ""),
    sample_number = nrow(d),
    event_number = sum(d$efs_event == 1L),
    censored_number = sum(d$efs_event == 0L),
    coefficient_number = length(stats::coef(fit)),
    source_stratum_number = nlevels(d$source_dataset_id),
    source_strata_with_at_least_one_event = length(unique(
      as.character(d$source_dataset_id[d$efs_event == 1L])
    )),
    converged = model_converged,
    iteration_number = if (length(fit$iter) == 0L) NA_integer_ else fit$iter,
    null_log_likelihood = safe_scalar(fit$loglik[1]),
    fitted_log_likelihood = safe_scalar(fit$loglik[2]),
    likelihood_ratio_chisq = safe_scalar(fit_summary$logtest["test"]),
    likelihood_ratio_df = safe_scalar(fit_summary$logtest["df"]),
    likelihood_ratio_p_value = safe_scalar(fit_summary$logtest["pvalue"]),
    Wald_chisq = safe_scalar(fit_summary$waldtest["test"]),
    Wald_df = safe_scalar(fit_summary$waldtest["df"]),
    Wald_p_value = safe_scalar(fit_summary$waldtest["pvalue"]),
    score_logrank_chisq = safe_scalar(fit_summary$sctest["test"]),
    score_logrank_df = safe_scalar(fit_summary$sctest["df"]),
    score_logrank_p_value = safe_scalar(fit_summary$sctest["pvalue"]),
    concordance = concordance_value,
    concordance_standard_error = concordance_se,
    AIC = stats::AIC(fit),
    warning_number = length(fit_warnings),
    warning_messages = collapse_messages(fit_warnings),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  zph_result <- capture_warnings(
    survival::cox.zph(
      fit,
      transform = "km",
      terms = TRUE,
      singledf = FALSE,
      global = TRUE
    )
  )

  zph <- zph_result$value
  zph_warnings <- zph_result$warnings
  zph_table <- as.data.frame(zph$table)
  zph_table$term <- rownames(zph$table)
  rownames(zph_table) <- NULL

  expected_zph_columns <- c("chisq", "df", "p")
  assert_true(
    all(expected_zph_columns %in% colnames(zph_table)),
    paste0(model_id, " cox.zph table is malformed.")
  )

  ph_rows[[i]] <- data.frame(
    model_id = model_id,
    term = as.character(zph_table$term),
    rho = if ("rho" %in% colnames(zph_table)) {
      as.numeric(zph_table$rho)
    } else {
      NA_real_
    },
    chisq = as.numeric(zph_table$chisq),
    degrees_of_freedom = as.numeric(zph_table$df),
    p_value = as.numeric(zph_table$p),
    transform = "km",
    warning_number = length(zph_warnings),
    warning_messages = collapse_messages(zph_warnings),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  score_ph_row <- ph_rows[[i]][
    ph_rows[[i]]$term == "score_z",
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(score_ph_row) == 1L,
    paste0(model_id, " lacks a score_z proportional-hazards test.")
  )

  global_ph_row <- ph_rows[[i]][
    ph_rows[[i]]$term == "GLOBAL",
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(global_ph_row) == 1L,
    paste0(model_id, " lacks a GLOBAL proportional-hazards test.")
  )

  linear_predictor <- stats::predict(
    fit,
    type = "lp",
    reference = "sample"
  )
  martingale_residual <- stats::residuals(
    fit,
    type = "martingale"
  )
  deviance_residual <- stats::residuals(
    fit,
    type = "deviance"
  )
  dfbeta_residual <- stats::residuals(
    fit,
    type = "dfbeta"
  )

  if (is.null(dim(dfbeta_residual))) {
    maximum_absolute_dfbeta <- max(abs(dfbeta_residual), na.rm = TRUE)
  } else {
    maximum_absolute_dfbeta <- max(abs(dfbeta_residual), na.rm = TRUE)
  }

  diagnostic_rows[[i]] <- data.frame(
    model_id = model_id,
    linear_predictor_minimum = min(linear_predictor),
    linear_predictor_maximum = max(linear_predictor),
    martingale_residual_minimum = min(martingale_residual),
    martingale_residual_maximum = max(martingale_residual),
    deviance_residual_minimum = min(deviance_residual),
    deviance_residual_maximum = max(deviance_residual),
    maximum_absolute_dfbeta = maximum_absolute_dfbeta,
    score_PH_p_value = score_ph_row$p_value,
    global_PH_p_value = global_ph_row$p_value,
    coefficient_all_finite = all(is.finite(stats::coef(fit))),
    standard_errors_all_positive =
      all(model_coefficients$standard_error > 0),
    cutoff_used = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  warning_rows[[i]] <- data.frame(
    model_id = model_id,
    fit_warning_number = length(fit_warnings),
    fit_warning_messages = collapse_messages(fit_warnings),
    cox_zph_warning_number = length(zph_warnings),
    cox_zph_warning_messages = collapse_messages(zph_warnings),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

model_fit_summary <- do.call(rbind, model_fit_rows)
all_coefficients <- do.call(rbind, coefficient_rows)
score_effects <- do.call(rbind, score_effect_rows)
proportional_hazards_tests <- do.call(rbind, ph_rows)
model_diagnostics <- do.call(rbind, diagnostic_rows)
model_sample_inclusion_audit <- do.call(rbind, inclusion_rows)
model_warning_audit <- do.call(rbind, warning_rows)

rownames(model_fit_summary) <- NULL
rownames(all_coefficients) <- NULL
rownames(score_effects) <- NULL
rownames(proportional_hazards_tests) <- NULL
rownames(model_diagnostics) <- NULL
rownames(model_sample_inclusion_audit) <- NULL
rownames(model_warning_audit) <- NULL

# ------------------------------
# 8. Cross-model integrity checks
# ------------------------------
assert_true(
  nrow(model_fit_summary) == 5L,
  "Model fit summary does not contain five models."
)
assert_true(
  nrow(score_effects) == 5L,
  "Score effects table does not contain five models."
)
assert_true(
  all(model_fit_summary$converged),
  "At least one Cox model did not converge."
)
assert_true(
  all(is.finite(score_effects$hazard_ratio_per_1_SD)) &&
    all(score_effects$hazard_ratio_per_1_SD > 0),
  "At least one score hazard ratio is invalid."
)
assert_true(
  all(is.finite(score_effects$confidence_lower_95)) &&
    all(is.finite(score_effects$confidence_upper_95)) &&
    all(score_effects$confidence_lower_95 > 0) &&
    all(score_effects$confidence_upper_95 > 0),
  "At least one score confidence interval is invalid."
)
assert_true(
  all(score_effects$confidence_lower_95 <=
        score_effects$hazard_ratio_per_1_SD) &&
    all(score_effects$hazard_ratio_per_1_SD <=
          score_effects$confidence_upper_95),
  "At least one score HR lies outside its confidence interval."
)
assert_true(
  !any(score_effects$cutoff_used),
  "A cutoff was unexpectedly used in a score-effect model."
)
assert_true(
  nrow(model_sample_inclusion_audit) == 5L * 579L,
  "Sample inclusion audit does not contain 5 x 579 rows."
)

# ------------------------------
# 9. Build final summary
# ------------------------------
primary_effect <- score_effects[
  score_effects$model_id ==
    "M1_PRIMARY_EFS383_UNADJUSTED_STRATIFIED",
  ,
  drop = FALSE
]
primary_adjusted_effect <- score_effects[
  score_effects$model_id ==
    "M3_PRIMARY_EFS383_CLINICAL_ADJUSTED_STRATIFIED",
  ,
  drop = FALSE
]

summary_table <- data.frame(
  item = c(
    "GEO_accession",
    "Script",
    "Source_Script10C_bundle_MD5",
    "Survival_package_version",
    "Model_number_fitted",
    "All_models_converged",
    "Primary_model_id",
    "Primary_model_samples",
    "Primary_model_events",
    "Primary_score_HR_per_1_SD",
    "Primary_score_CI_lower_95",
    "Primary_score_CI_upper_95",
    "Primary_score_p_value",
    "Primary_score_PH_p_value",
    "Primary_global_PH_p_value",
    "Primary_adjusted_model_id",
    "Primary_adjusted_samples",
    "Primary_adjusted_events",
    "Primary_adjusted_score_HR_per_1_SD",
    "Primary_adjusted_score_CI_lower_95",
    "Primary_adjusted_score_CI_upper_95",
    "Primary_adjusted_score_p_value",
    "Primary_adjusted_score_PH_p_value",
    "Primary_adjusted_global_PH_p_value",
    "Optimized_cutoff_selected",
    "High_low_group_created",
    "Kaplan_Meier_fitted",
    "Dataset_meta_analysis_fitted",
    "Clinical_values_imputed",
    "Expression_values_modified",
    "GSVA_recomputed",
    "Completion_status"
  ),
  value = c(
    "GSE31519",
    "11A",
    observed_bundle_md5,
    survival_version,
    nrow(model_fit_summary),
    all(model_fit_summary$converged),
    primary_effect$model_id,
    primary_effect$sample_number,
    primary_effect$event_number,
    primary_effect$hazard_ratio_per_1_SD,
    primary_effect$confidence_lower_95,
    primary_effect$confidence_upper_95,
    primary_effect$p_value,
    model_diagnostics$score_PH_p_value[
      model_diagnostics$model_id == primary_effect$model_id
    ],
    model_diagnostics$global_PH_p_value[
      model_diagnostics$model_id == primary_effect$model_id
    ],
    primary_adjusted_effect$model_id,
    primary_adjusted_effect$sample_number,
    primary_adjusted_effect$event_number,
    primary_adjusted_effect$hazard_ratio_per_1_SD,
    primary_adjusted_effect$confidence_lower_95,
    primary_adjusted_effect$confidence_upper_95,
    primary_adjusted_effect$p_value,
    model_diagnostics$score_PH_p_value[
      model_diagnostics$model_id == primary_adjusted_effect$model_id
    ],
    model_diagnostics$global_PH_p_value[
      model_diagnostics$model_id == primary_adjusted_effect$model_id
    ],
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    FALSE,
    "COMPLETE"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# ------------------------------
# 10. Save staging outputs
# ------------------------------
input_manifest <- make_manifest(required_inputs)

complete_bundle <- list(
  project = "TNBC_Triclosan",
  step = "Step2_GSE31519_external_validation",
  script = "Script11A",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  source_accession = "GSE31519",
  source_script10c_bundle_file =
    normalize_existing_path(input_bundle_file),
  source_script10c_bundle_md5 = observed_bundle_md5,
  survival_package_version = survival_version,
  model_specifications = model_specifications,
  model_fit_summary = model_fit_summary,
  score_effects = score_effects,
  all_coefficients = all_coefficients,
  proportional_hazards_tests = proportional_hazards_tests,
  model_diagnostics = model_diagnostics,
  model_warning_audit = model_warning_audit,
  model_sample_inclusion_audit = model_sample_inclusion_audit,
  cox_model_objects = fit_objects,
  integrity_summary = summary_table,
  policy = list(
    primary_predictor =
      "Continuous Triclosan_activity score per 1 SD",
    primary_endpoint_set = "EFS383",
    primary_model =
      "Cox proportional hazards stratified by source_dataset_id",
    primary_clinical_adjustment = clinical_covariates,
    positive_time_sensitivity_set = "EFS379",
    treatment_added_model_is_sensitivity_only = TRUE,
    ties_method = "efron",
    optimized_cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    Kaplan_Meier_fitted = FALSE,
    dataset_meta_analysis_fitted = FALSE,
    clinical_values_imputed = FALSE,
    expression_values_modified = FALSE,
    GSVA_recomputed = FALSE
  ),
  provenance = list(
    accepted_script10c_bundle_md5 =
      accepted_script10c_bundle_md5,
    next_step_requires_review_of =
      c(
        "score_effects",
        "proportional_hazards_tests",
        "model_diagnostics",
        "model_warning_audit"
      )
  )
)

class(complete_bundle) <- c(
  "GSE31519_continuous_survival_models_bundle",
  "list"
)

stage_bundle_file <- file.path(
  stage_object_dir,
  "GSE31519_continuous_survival_models_COMPLETE_bundle.rds"
)
stage_specification_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_model_specifications.csv"
)
stage_fit_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_model_fit_summary.csv"
)
stage_score_effect_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_score_effects.csv"
)
stage_coefficient_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_all_coefficients.csv"
)
stage_ph_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_PH_tests.csv"
)
stage_diagnostic_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_model_diagnostics.csv"
)
stage_warning_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_model_warnings.csv"
)
stage_inclusion_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_sample_inclusion_audit.csv"
)
stage_summary_file <- file.path(
  stage_audit_dir,
  "GSE31519_continuous_survival_integrity_summary.csv"
)
stage_input_manifest_file <- file.path(
  stage_audit_dir,
  "Script11A_input_manifest_with_MD5.csv"
)
stage_output_manifest_file <- file.path(
  stage_audit_dir,
  "Script11A_output_manifest_with_MD5.csv"
)
stage_session_file <- file.path(
  stage_log_dir,
  "Script11A_sessionInfo.txt"
)
stage_report_file <- file.path(
  stage_log_dir,
  "Script11A_COMPLETE_report.txt"
)

saveRDS(
  complete_bundle,
  stage_bundle_file,
  compress = "gzip"
)

write_csv_utf8(model_specifications, stage_specification_file)
write_csv_utf8(model_fit_summary, stage_fit_file)
write_csv_utf8(score_effects, stage_score_effect_file)
write_csv_utf8(all_coefficients, stage_coefficient_file)
write_csv_utf8(proportional_hazards_tests, stage_ph_file)
write_csv_utf8(model_diagnostics, stage_diagnostic_file)
write_csv_utf8(model_warning_audit, stage_warning_file)
write_csv_utf8(
  model_sample_inclusion_audit,
  stage_inclusion_file
)
write_csv_utf8(summary_table, stage_summary_file)
write_csv_utf8(input_manifest, stage_input_manifest_file)

capture.output(
  sessionInfo(),
  file = stage_session_file
)

bundle_check <- readRDS(stage_bundle_file)

assert_true(
  is.list(bundle_check) &&
    all(c(
      "model_specifications",
      "model_fit_summary",
      "score_effects",
      "all_coefficients",
      "proportional_hazards_tests",
      "model_diagnostics",
      "model_warning_audit",
      "model_sample_inclusion_audit",
      "cox_model_objects",
      "integrity_summary",
      "policy"
    ) %in% names(bundle_check)),
  "Staged Script 11A bundle is missing required fields."
)
assert_true(
  nrow(bundle_check$score_effects) == 5L,
  "Saved Script 11A score effects do not contain five models."
)
assert_true(
  all(bundle_check$model_fit_summary$converged),
  "Saved Script 11A bundle contains a non-converged model."
)
assert_true(
  isFALSE(bundle_check$policy$optimized_cutoff_selected) &&
    isFALSE(bundle_check$policy$high_low_group_created) &&
    isFALSE(bundle_check$policy$Kaplan_Meier_fitted),
  "Saved Script 11A policy incorrectly indicates a cutoff or KM analysis."
)

bundle_md5 <- md5_one(stage_bundle_file)

report_lines <- c(
  "============================================================",
  "TNBC_Triclosan Step 2 - Script 11A",
  "Prespecified continuous-score survival models",
  "============================================================",
  paste0(
    "Completion time: ",
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  ),
  paste0("Source Script 10C bundle MD5: ", observed_bundle_md5),
  paste0("survival package version: ", survival_version),
  paste0("Cox models fitted: ", nrow(model_fit_summary)),
  paste0("All Cox models converged: ", all(model_fit_summary$converged)),
  "",
  paste0(
    "Primary model: ",
    primary_effect$model_id
  ),
  paste0(
    "Primary n / events / censored: ",
    primary_effect$sample_number,
    " / ",
    primary_effect$event_number,
    " / ",
    primary_effect$censored_number
  ),
  paste0(
    "Primary score HR per 1 SD: ",
    format(primary_effect$hazard_ratio_per_1_SD, digits = 10)
  ),
  paste0(
    "Primary 95% CI: ",
    format(primary_effect$confidence_lower_95, digits = 10),
    " to ",
    format(primary_effect$confidence_upper_95, digits = 10)
  ),
  paste0(
    "Primary score P value: ",
    format(primary_effect$p_value, digits = 10)
  ),
  paste0(
    "Primary score PH P value: ",
    format(
      model_diagnostics$score_PH_p_value[
        model_diagnostics$model_id == primary_effect$model_id
      ],
      digits = 10
    )
  ),
  paste0(
    "Primary global PH P value: ",
    format(
      model_diagnostics$global_PH_p_value[
        model_diagnostics$model_id == primary_effect$model_id
      ],
      digits = 10
    )
  ),
  "",
  paste0(
    "Primary adjusted model: ",
    primary_adjusted_effect$model_id
  ),
  paste0(
    "Adjusted n / events / censored: ",
    primary_adjusted_effect$sample_number,
    " / ",
    primary_adjusted_effect$event_number,
    " / ",
    primary_adjusted_effect$censored_number
  ),
  paste0(
    "Adjusted score HR per 1 SD: ",
    format(
      primary_adjusted_effect$hazard_ratio_per_1_SD,
      digits = 10
    )
  ),
  paste0(
    "Adjusted 95% CI: ",
    format(
      primary_adjusted_effect$confidence_lower_95,
      digits = 10
    ),
    " to ",
    format(
      primary_adjusted_effect$confidence_upper_95,
      digits = 10
    )
  ),
  paste0(
    "Adjusted score P value: ",
    format(primary_adjusted_effect$p_value, digits = 10)
  ),
  paste0(
    "Adjusted score PH P value: ",
    format(
      model_diagnostics$score_PH_p_value[
        model_diagnostics$model_id ==
          primary_adjusted_effect$model_id
      ],
      digits = 10
    )
  ),
  paste0(
    "Adjusted global PH P value: ",
    format(
      model_diagnostics$global_PH_p_value[
        model_diagnostics$model_id ==
          primary_adjusted_effect$model_id
      ],
      digits = 10
    )
  ),
  "",
  paste0(
    "Models with fit warnings: ",
    sum(model_warning_audit$fit_warning_number > 0L)
  ),
  paste0(
    "Models with cox.zph warnings: ",
    sum(model_warning_audit$cox_zph_warning_number > 0L)
  ),
  "Optimized cutoff selected: FALSE",
  "High/low group created: FALSE",
  "Kaplan-Meier fitted: FALSE",
  "Dataset meta-analysis fitted: FALSE",
  "Clinical values imputed: FALSE",
  "Expression values modified: FALSE",
  "GSVA recomputed: FALSE",
  paste0("Script 11A bundle MD5: ", bundle_md5),
  "",
  "SCRIPT11A STATUS: COMPLETE",
  paste0(
    "Only prespecified continuous-score Cox models and proportional-hazards ",
    "diagnostics were fitted."
  ),
  "============================================================"
)

writeLines(
  enc2utf8(report_lines),
  con = stage_report_file,
  useBytes = TRUE
)

output_files_before_manifest <- c(
  stage_bundle_file,
  stage_specification_file,
  stage_fit_file,
  stage_score_effect_file,
  stage_coefficient_file,
  stage_ph_file,
  stage_diagnostic_file,
  stage_warning_file,
  stage_inclusion_file,
  stage_summary_file,
  stage_input_manifest_file,
  stage_session_file,
  stage_report_file
)

assert_true(
  all(file.exists(output_files_before_manifest)),
  "At least one staged Script 11A output is missing."
)
assert_true(
  all(file.info(output_files_before_manifest)$size > 0),
  "At least one staged Script 11A output is empty."
)

output_manifest <- make_manifest(output_files_before_manifest)
write_csv_utf8(output_manifest, stage_output_manifest_file)

manifest_check <- read.csv(
  stage_output_manifest_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

assert_true(
  nrow(manifest_check) == length(output_files_before_manifest),
  "Script 11A output manifest has an incorrect row count."
)

for (i in seq_along(output_files_before_manifest)) {
  file_i <- output_files_before_manifest[i]
  row_i <- manifest_check[
    manifest_check$file_name == basename(file_i),
    ,
    drop = FALSE
  ]

  assert_true(
    nrow(row_i) == 1L,
    paste0("Missing or duplicated manifest row: ", basename(file_i))
  )
  assert_true(
    identical(
      tolower(as.character(row_i$md5)),
      tolower(md5_one(file_i))
    ),
    paste0("Manifest MD5 mismatch: ", basename(file_i))
  )
  assert_true(
    as.numeric(row_i$size_bytes) ==
      as.numeric(file.info(file_i)$size),
    paste0("Manifest size mismatch: ", basename(file_i))
  )
}

# ------------------------------
# 11. Commit staging directory
# ------------------------------
assert_true(
  !dir.exists(final_root),
  "Final Script 11A directory appeared during staging."
)

rename_ok <- file.rename(stage_root, final_root)

if (!isTRUE(rename_ok)) {
  dir.create(final_root, recursive = TRUE, showWarnings = FALSE)

  copied <- file.copy(
    from = list.files(
      stage_root,
      full.names = TRUE,
      all.files = FALSE
    ),
    to = final_root,
    recursive = TRUE,
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )

  assert_true(
    all(copied),
    "Unable to commit Script 11A staging directory."
  )

  unlink(stage_root, recursive = TRUE, force = TRUE)
}

committed <- TRUE

final_bundle_file <- file.path(
  final_root,
  "objects",
  "GSE31519_continuous_survival_models_COMPLETE_bundle.rds"
)
final_report_file <- file.path(
  final_root,
  "logs",
  "Script11A_COMPLETE_report.txt"
)
final_manifest_file <- file.path(
  final_root,
  "audit",
  "Script11A_output_manifest_with_MD5.csv"
)

assert_true(
  all(file.exists(c(
    final_bundle_file,
    final_report_file,
    final_manifest_file
  ))),
  "Committed Script 11A output is incomplete."
)
assert_true(
  identical(md5_one(final_bundle_file), bundle_md5),
  "Committed Script 11A bundle MD5 changed after commit."
)
assert_true(
  report_contains(
    final_report_file,
    "SCRIPT11A STATUS: COMPLETE"
  ),
  "Committed Script 11A report is not marked COMPLETE."
)

cat("============================================================\n")
cat("Script 11A completed successfully.\n")
cat("Cox models fitted: ", nrow(model_fit_summary), "\n", sep = "")
cat(
  "All models converged: ",
  all(model_fit_summary$converged),
  "\n",
  sep = ""
)
cat(
  "Primary HR per 1 SD (95% CI): ",
  format(primary_effect$hazard_ratio_per_1_SD, digits = 7),
  " (",
  format(primary_effect$confidence_lower_95, digits = 7),
  " to ",
  format(primary_effect$confidence_upper_95, digits = 7),
  "), P=",
  format(primary_effect$p_value, digits = 7),
  "\n",
  sep = ""
)
cat(
  "Adjusted HR per 1 SD (95% CI): ",
  format(
    primary_adjusted_effect$hazard_ratio_per_1_SD,
    digits = 7
  ),
  " (",
  format(
    primary_adjusted_effect$confidence_lower_95,
    digits = 7
  ),
  " to ",
  format(
    primary_adjusted_effect$confidence_upper_95,
    digits = 7
  ),
  "), P=",
  format(primary_adjusted_effect$p_value, digits = 7),
  "\n",
  sep = ""
)
cat("Optimized cutoff selected: FALSE\n")
cat("Kaplan-Meier fitted: FALSE\n")
cat("Dataset meta-analysis fitted: FALSE\n")
cat(
  "Bundle: ",
  normalizePath(
    final_bundle_file,
    winslash = "/",
    mustWork = TRUE
  ),
  "\n",
  sep = ""
)
cat("Bundle MD5: ", md5_one(final_bundle_file), "\n", sep = "")
cat("============================================================\n")
cat("\u2705 \u5df2\u5b8c\u6210\n")

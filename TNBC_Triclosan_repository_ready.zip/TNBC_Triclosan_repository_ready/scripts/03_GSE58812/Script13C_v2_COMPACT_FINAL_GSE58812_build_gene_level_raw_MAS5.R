# ==============================================================================
# TNBC_Triclosan | GSE58812 | Script 13C COMPACT FINAL
# Build the gene-level expression matrix on the submitted raw MAS5 scale.
#
# Locked rule:
# - use only non-AFFX probes mapped to exactly one official human symbol;
# - one eligible probe: copy unchanged;
# - multiple eligible probes: sample-wise median;
# - retain all 107 samples in original order.
#
# No log2 transformation, renormalization, imputation, sample filtering,
# Triclosan scoring, survival analysis, cutoff, DEG, PCA, GSEA or figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13C_v2_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step4_GSE58812_external_validation")
PREFLIGHT_ROOT <- file.path(STEP_ROOT, "00_preflight")
ANNOTATION_ROOT <- file.path(STEP_ROOT, "01_probe_annotation_audit")
OUTPUT_ROOT <- file.path(STEP_ROOT, "02_gene_level_expression_raw_MAS5")

INPUTS <- c(
  preflight_bundle = file.path(PREFLIGHT_ROOT, "objects",
    "GSE58812_preflight_COMPLETE_bundle.rds"),
  annotation_bundle = file.path(ANNOTATION_ROOT, "objects",
    "GSE58812_probe_annotation_audit_COMPLETE_bundle.rds"),
  eligible_probes = file.path(ANNOTATION_ROOT, "audit",
    "GSE58812_eligible_unique_symbol_probes.csv"),
  multiplicity = file.path(ANNOTATION_ROOT, "audit",
    "GSE58812_gene_to_probe_multiplicity.csv"),
  signature_coverage = file.path(ANNOTATION_ROOT, "audit",
    "GSE58812_locked_24gene_platform_coverage.csv"),
  annotation_manifest = file.path(ANNOTATION_ROOT, "audit",
    "Script13B_output_manifest_with_MD5.csv"),
  annotation_report = file.path(ANNOTATION_ROOT, "logs",
    "Script13B_COMPLETE_report.txt")
)

EXPECTED_MD5 <- c(
  preflight_bundle = "10607fc74855b76b155713793442884f",
  annotation_bundle = "6770143a36015574ba501252a1bbb5f1",
  eligible_probes = "81621a1d72a8fb809a978cda1a00d219",
  multiplicity = "d2e3afa4295d01b76f06cc2b00184a8c",
  signature_coverage = "dd2a94ae587e36e1ba62be0cf5b34868",
  annotation_manifest = "0eb0adb35ab078d14d6d86ea1b1dde5f",
  annotation_report = "6461f32e2c0d8bc9d37af2eeeb560d80"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

normalize_text <- function(x) {
  y <- trimws(as.character(x))
  y[is.na(x) | !nzchar(y)] <- NA_character_
  y
}

same_column_values <- function(x, y) {
  if (length(x) != length(y)) return(FALSE)
  if (is.logical(x)) {
    return(identical(as.logical(y), as.logical(x)))
  }
  if (is.numeric(x)) {
    return(isTRUE(all.equal(
      as.numeric(y), as.numeric(x),
      tolerance = 0, check.attributes = FALSE
    )))
  }
  identical(normalize_text(y), normalize_text(x))
}

same_table_values <- function(x, y) {
  is.data.frame(x) && is.data.frame(y) &&
    identical(dim(x), dim(y)) &&
    identical(names(x), names(y)) &&
    all(vapply(seq_along(x), function(i) {
      same_column_values(x[[i]], y[[i]])
    }, logical(1)))
}

num_summary <- function(x) {
  x <- as.numeric(x)
  data.frame(
    n = length(x),
    finite_n = sum(is.finite(x)),
    nonfinite_n = sum(!is.finite(x)),
    min = min(x),
    q1 = unname(quantile(x, 0.25)),
    median = median(x),
    mean = mean(x),
    q3 = unname(quantile(x, 0.75)),
    max = max(x),
    sd = sd(x),
    unique_n = length(unique(x)),
    check.names = FALSE
  )
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path","size_bytes","md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))
  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(root, "objects",
      "GSE58812_gene_level_raw_MAS5_COMPLETE_bundle.rds"),
    matrix = file.path(root, "objects",
      "GSE58812_gene_level_raw_MAS5_matrix.rds"),
    manifest = file.path(root, "audit",
      "Script13C_output_manifest_with_MD5.csv"),
    report = file.path(root, "logs",
      "Script13C_COMPLETE_report.txt")
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) return(FALSE)
  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT13C STATUS: COMPLETE", report, fixed = TRUE))) return(FALSE)

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  x <- tryCatch(readRDS(key["matrix"]), error = function(e) NULL)
  is.list(b) &&
    identical(as.character(b$script), "Script13C") &&
    as.character(b$script_build_id) %in% c(
      "Script13C_COMPACT_FINAL_20260711",
      BUILD_ID
    ) &&
    identical(as.character(b$source_annotation_bundle_md5),
              unname(EXPECTED_MD5["annotation_bundle"])) &&
    is.matrix(x) && identical(dim(x), c(20823L, 107L)) &&
    identical(x, b$gene_level_expression_raw_MAS5) &&
    isFALSE(b$policy$log2_transformation_performed) &&
    isFALSE(b$policy$Triclosan_score_calculated)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))
  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }
  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13C output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }
  archive <- file.path(
    STEP_ROOT,
    paste0("02_gene_level_expression_raw_MAS5_INCOMPLETE_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Gene aggregation only; raw MAS5 scale is preserved.\n")
  cat("============================================================\n")

  assert(dir.exists(STEP_ROOT), "Step 4 directory does not exist:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted input(s):\n%s",
         paste(missing, collapse = "\n"))

  observed <- vapply(INPUTS, md5, character(1))
  assert(identical(observed, EXPECTED_MD5),
         "At least one accepted input MD5 differs.\n%s",
         paste(sprintf("%s: expected %s; observed %s",
                       names(EXPECTED_MD5), EXPECTED_MD5, observed),
               collapse = "\n"))
  assert(any(grepl("SCRIPT13B STATUS: COMPLETE",
                   readLines(INPUTS["annotation_report"], warn = FALSE),
                   fixed = TRUE)),
         "Script 13B completion marker is missing.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  preflight <- readRDS(INPUTS["preflight_bundle"])
  annotation <- readRDS(INPUTS["annotation_bundle"])
  eligible_csv <- read.csv(
    INPUTS["eligible_probes"], stringsAsFactors = FALSE, check.names = FALSE
  )
  multiplicity_csv <- read.csv(
    INPUTS["multiplicity"], stringsAsFactors = FALSE, check.names = FALSE
  )
  signature_csv <- read.csv(
    INPUTS["signature_coverage"], stringsAsFactors = FALSE, check.names = FALSE
  )

  assert(is.list(preflight) &&
         identical(as.character(preflight$script), "Script13A") &&
         identical(as.character(preflight$script_build_id),
                   "Script13A_COMPACT_FINAL_20260711"),
         "Accepted Script 13A bundle is malformed.")
  assert(is.list(annotation) &&
         identical(as.character(annotation$script), "Script13B") &&
         identical(as.character(annotation$script_build_id),
                   "Script13B_COMPACT_FINAL_20260711"),
         "Accepted Script 13B bundle is malformed.")

  expr <- preflight$expression_matrix
  pheno <- preflight$phenotype_raw
  eligible <- annotation$eligible_unique_symbol_probes
  multiplicity <- annotation$gene_to_probe_multiplicity
  signature_coverage <- annotation$locked_signature_coverage

  assert(is.matrix(expr) && is.numeric(expr) &&
         identical(dim(expr), c(54675L, 107L)) &&
         all(is.finite(expr)) &&
         !anyDuplicated(rownames(expr)) &&
         !anyDuplicated(colnames(expr)) &&
         is.data.frame(pheno) &&
         identical(rownames(pheno), colnames(expr)),
         "Accepted preflight expression or phenotype data are malformed.")

  assert(same_table_values(eligible, eligible_csv),
         paste0(
           "Eligible-probe RDS/CSV values, order or columns differ. ",
           "Column storage types alone are ignored."
         ))
  assert(same_table_values(multiplicity, multiplicity_csv),
         paste0(
           "Gene-multiplicity RDS/CSV values, order or columns differ. ",
           "Column storage types alone are ignored."
         ))
  assert(same_table_values(signature_coverage, signature_csv),
         paste0(
           "Signature-coverage RDS/CSV values, order or columns differ. ",
           "Column storage types alone are ignored."
         ))
  assert(is.data.frame(eligible) && nrow(eligible) == 43113L &&
         all(c("probe_order","probe_id","human_symbol") %in% names(eligible)) &&
         !anyDuplicated(eligible$probe_id) &&
         all(eligible$probe_id %in% rownames(expr)) &&
         all(nzchar(eligible$human_symbol)),
         "Eligible-probe table is malformed.")
  assert(is.data.frame(multiplicity) && nrow(multiplicity) == 20823L &&
         all(c("human_symbol","eligible_probe_number","eligible_probe_ids",
               "later_aggregation_rule") %in% names(multiplicity)) &&
         !anyDuplicated(multiplicity$human_symbol) &&
         sum(as.integer(multiplicity$eligible_probe_number)) == 43113L,
         "Gene-to-probe multiplicity table is malformed.")
  assert(is.data.frame(signature_coverage) &&
         nrow(signature_coverage) == 24L &&
         identical(as.character(signature_coverage$locked_human_symbol),
                   LOCKED24) &&
         all(as.logical(signature_coverage$platform_coverage)),
         "Locked 24-gene platform coverage is incomplete or reordered.")

  gene_order <- as.character(multiplicity$human_symbol)
  split_probes <- split(
    as.character(eligible$probe_id),
    factor(eligible$human_symbol, levels = gene_order)
  )
  assert(length(split_probes) == 20823L &&
         identical(names(split_probes), gene_order) &&
         identical(as.integer(lengths(split_probes)),
                   as.integer(multiplicity$eligible_probe_number)) &&
         identical(
           unname(vapply(split_probes, paste, collapse = ";", character(1))),
           unname(as.character(multiplicity$eligible_probe_ids))
         ),
         "Eligible probes do not reproduce the locked gene multiplicity table.")

  probe_index <- lapply(split_probes, match, table = rownames(expr))
  assert(all(vapply(probe_index, function(x) all(!is.na(x)), logical(1))),
         "At least one eligible probe is absent from the expression matrix.")

  gene_expr <- t(vapply(probe_index, function(idx) {
    if (length(idx) == 1L) {
      as.numeric(expr[idx, , drop = TRUE])
    } else {
      apply(expr[idx, , drop = FALSE], 2L, stats::median)
    }
  }, numeric(ncol(expr))))

  rownames(gene_expr) <- gene_order
  colnames(gene_expr) <- colnames(expr)

  assert(is.matrix(gene_expr) && is.numeric(gene_expr) &&
         identical(dim(gene_expr), c(20823L, 107L)) &&
         identical(rownames(gene_expr), gene_order) &&
         identical(colnames(gene_expr), colnames(expr)) &&
         !anyDuplicated(rownames(gene_expr)) &&
         all(is.finite(gene_expr)),
         "Gene-level matrix failed dimension, order, uniqueness or finite-value checks.")

  single_gene <- which(lengths(split_probes) == 1L)
  assert(length(single_gene) == 9780L &&
         all(vapply(single_gene, function(i) {
           identical(
             as.numeric(gene_expr[i, ]),
             as.numeric(expr[probe_index[[i]], , drop = TRUE])
           )
         }, logical(1))),
         "Single-probe genes were not copied unchanged.")

  multi_gene <- which(lengths(split_probes) > 1L)
  assert(length(multi_gene) == 11043L,
         "Expected 11,043 multi-probe genes.")
  audit_multi <- unique(round(seq(1L, length(multi_gene), length.out = 25L)))
  assert(all(vapply(multi_gene[audit_multi], function(i) {
    expected <- apply(expr[probe_index[[i]], , drop = FALSE], 2L, median)
    identical(as.numeric(gene_expr[i, ]), as.numeric(expected))
  }, logical(1))),
  "Deterministic multi-probe median audit failed.")

  signature_expr <- gene_expr[LOCKED24, , drop = FALSE]
  assert(identical(dim(signature_expr), c(24L, 107L)) &&
         identical(rownames(signature_expr), LOCKED24) &&
         all(is.finite(signature_expr)) &&
         all(apply(signature_expr, 1L, sd) > 0),
         "Locked 24-gene expression matrix is incomplete or invariant.")

  row_annotation <- data.frame(
    gene_order = seq_along(gene_order),
    human_symbol = gene_order,
    eligible_probe_number = as.integer(multiplicity$eligible_probe_number),
    eligible_probe_ids = as.character(multiplicity$eligible_probe_ids),
    aggregation_rule = ifelse(
      as.integer(multiplicity$eligible_probe_number) == 1L,
      "COPIED_SINGLE_PROBE_UNCHANGED",
      "SAMPLE_WISE_MEDIAN_ACROSS_ELIGIBLE_PROBES"
    ),
    source_scale = "SUBMITTED_UNLOGGED_MAS5_INTENSITY",
    log2_transformation_performed = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  signature_audit <- merge(
    data.frame(
      signature_order = seq_along(LOCKED24),
      locked_human_symbol = LOCKED24,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    row_annotation[, c(
      "human_symbol","eligible_probe_number","eligible_probe_ids",
      "aggregation_rule","source_scale","log2_transformation_performed"
    )],
    by.x = "locked_human_symbol",
    by.y = "human_symbol",
    all.x = TRUE,
    sort = FALSE
  )
  signature_audit <- signature_audit[
    match(LOCKED24, signature_audit$locked_human_symbol), , drop = FALSE
  ]
  signature_audit$gene_level_expression_available <-
    signature_audit$locked_human_symbol %in% rownames(gene_expr)
  assert(nrow(signature_audit) == 24L &&
         identical(signature_audit$locked_human_symbol, LOCKED24) &&
         all(signature_audit$gene_level_expression_available),
         "Locked signature audit is incomplete.")

  global_summary <- cbind(
    data.frame(
      GEO_accession = "GSE58812",
      platform = "GPL570",
      source_probe_number = nrow(expr),
      eligible_probe_number = nrow(eligible),
      gene_number = nrow(gene_expr),
      sample_number = ncol(gene_expr),
      one_probe_gene_number = sum(lengths(split_probes) == 1L),
      multi_probe_gene_number = sum(lengths(split_probes) > 1L),
      maximum_probe_number_per_gene = max(lengths(split_probes)),
      zero_variance_gene_number = sum(apply(gene_expr, 1L, sd) == 0),
      source_scale = "SUBMITTED_UNLOGGED_MAS5_INTENSITY",
      check.names = FALSE
    ),
    num_summary(as.numeric(gene_expr))
  )

  sample_summary <- do.call(rbind, lapply(seq_len(ncol(gene_expr)), function(i) {
    cbind(
      data.frame(
        sample_order = i,
        sample_id = colnames(gene_expr)[i],
        check.names = FALSE
      ),
      num_summary(gene_expr[, i])
    )
  }))
  rownames(sample_summary) <- NULL

  signature_csv_output <- data.frame(
    locked_human_symbol = LOCKED24,
    signature_expr,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    eligible_probe_rule =
      "NON_AFFX_AND_EXACTLY_ONE_OFFICIAL_HUMAN_SYMBOL",
    one_probe_rule = "COPY_UNCHANGED",
    multiple_probe_rule = "SAMPLE_WISE_MEDIAN",
    gene_aggregation_performed = TRUE,
    source_expression_scale = "SUBMITTED_UNLOGGED_MAS5_INTENSITY",
    expression_values_log2_transformed = FALSE,
    additional_normalization_performed = FALSE,
    expression_values_imputed = FALSE,
    samples_filtered = FALSE,
    outliers_removed = FALSE,
    Triclosan_score_calculated = FALSE,
    survival_endpoint_parsed = FALSE,
    survival_model_fitted = FALSE,
    cutoff_selected = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID",
      "Source_preflight_bundle_MD5","Source_annotation_bundle_MD5",
      "Source_probe_dimensions","Eligible_probe_number",
      "Gene_level_dimensions","Gene_symbols_unique",
      "Sample_order_preserved","Finite_gene_expression_values",
      "One_probe_gene_number","Multi_probe_gene_number",
      "Maximum_probe_number_per_gene",
      "Locked_signature_gene_number","Locked_signature_available_number",
      "Locked_signature_zero_variance_number",
      "Gene_aggregation_performed","Log2_transformation_performed",
      "Additional_normalization_performed","Expression_imputation_performed",
      "Samples_filtered","Outliers_removed","Triclosan_score_calculated",
      "Survival_endpoint_parsed","Survival_model_fitted","Cutoff_selected",
      "DEG_performed","PCA_performed","GSEA_performed",
      "Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "GSE58812","13C",BUILD_ID,EXPECTED_MD5["preflight_bundle"],
      EXPECTED_MD5["annotation_bundle"],paste(dim(expr), collapse = " x "),
      nrow(eligible),paste(dim(gene_expr), collapse = " x "),
      !anyDuplicated(rownames(gene_expr)),
      identical(colnames(gene_expr), colnames(expr)),
      sum(is.finite(gene_expr)),sum(lengths(split_probes) == 1L),
      sum(lengths(split_probes) > 1L),max(lengths(split_probes)),
      length(LOCKED24),nrow(signature_expr),
      sum(apply(signature_expr, 1L, sd) == 0),TRUE,FALSE,FALSE,FALSE,
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = c("Script13A", rep("Script13B", length(INPUTS) - 1L)),
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step4_GSE58812_external_validation",
    script = "Script13C",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE58812",
    source_platform = "GPL570",
    source_preflight_bundle_md5 = unname(EXPECTED_MD5["preflight_bundle"]),
    source_annotation_bundle_md5 = unname(EXPECTED_MD5["annotation_bundle"]),
    phenotype_raw = pheno,
    gene_level_expression_raw_MAS5 = gene_expr,
    gene_row_annotation = row_annotation,
    locked_signature_audit = signature_audit,
    locked_signature_expression_raw_MAS5 = signature_expr,
    matrix_summary = global_summary,
    sample_expression_summary = sample_summary,
    policy = policy,
    integrity_summary = integrity
  )
  class(bundle) <- c("GSE58812_gene_level_raw_MAS5_bundle", "list")

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script13C_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects","audit","logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(stage, "objects",
      "GSE58812_gene_level_raw_MAS5_COMPLETE_bundle.rds"),
    matrix = file.path(stage, "objects",
      "GSE58812_gene_level_raw_MAS5_matrix.rds"),
    signature_matrix = file.path(stage, "objects",
      "GSE58812_locked_24gene_raw_MAS5_matrix.rds"),
    rows = file.path(stage, "audit",
      "GSE58812_gene_level_row_annotation.csv"),
    signature_audit = file.path(stage, "audit",
      "GSE58812_locked_24gene_gene_level_availability.csv"),
    signature_values = file.path(stage, "audit",
      "GSE58812_locked_24gene_raw_MAS5_expression.csv"),
    matrix_summary = file.path(stage, "audit",
      "GSE58812_gene_level_raw_MAS5_summary.csv"),
    sample_summary = file.path(stage, "audit",
      "GSE58812_gene_level_raw_MAS5_sample_distribution.csv"),
    integrity = file.path(stage, "audit",
      "GSE58812_gene_level_raw_MAS5_integrity_summary.csv"),
    inputs = file.path(stage, "audit",
      "Script13C_input_manifest_with_MD5.csv"),
    session = file.path(stage, "logs", "Script13C_sessionInfo.txt"),
    report = file.path(stage, "logs", "Script13C_COMPLETE_report.txt")
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(gene_expr, files["matrix"], version = 3)
  saveRDS(signature_expr, files["signature_matrix"], version = 3)
  write_csv(row_annotation, files["rows"])
  write_csv(signature_audit, files["signature_audit"])
  write_csv(signature_csv_output, files["signature_values"])
  write_csv(global_summary, files["matrix_summary"])
  write_csv(sample_summary, files["sample_summary"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 4 - Script 13C",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "GEO accession: GSE58812",
    "Platform: GPL570",
    paste0("Source probe matrix: ", paste(dim(expr), collapse = " x ")),
    paste0("Eligible probes aggregated: ", nrow(eligible)),
    paste0("Gene-level matrix: ", paste(dim(gene_expr), collapse = " x ")),
    paste0("One-probe genes copied unchanged: ",
           sum(lengths(split_probes) == 1L)),
    paste0("Multi-probe genes aggregated by sample-wise median: ",
           sum(lengths(split_probes) > 1L)),
    paste0("Locked signature available: ", nrow(signature_expr), " / 24"),
    "Source/output scale: submitted unlogged MAS5 intensity",
    "Log2 transformation performed: FALSE",
    "Additional normalization or imputation performed: FALSE",
    "Samples filtered or outliers removed: FALSE",
    "Triclosan score or survival analysis performed: FALSE",
    "Cutoff/DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13C STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")
  b2 <- readRDS(files["bundle"])
  x2 <- readRDS(files["matrix"])
  s2 <- readRDS(files["signature_matrix"])
  assert(identical(x2, gene_expr) &&
         identical(s2, signature_expr) &&
         identical(b2$gene_level_expression_raw_MAS5, gene_expr) &&
         identical(b2$locked_signature_expression_raw_MAS5, signature_expr),
         "RDS save/read-back validation failed.")

  row2 <- read.csv(files["rows"], stringsAsFactors = FALSE, check.names = FALSE)
  sig2 <- read.csv(files["signature_audit"],
                   stringsAsFactors = FALSE, check.names = FALSE)
  assert(nrow(row2) == 20823L &&
         identical(as.character(row2$human_symbol), gene_order) &&
         nrow(sig2) == 24L &&
         identical(as.character(sig2$locked_human_symbol), LOCKED24),
         "CSV save/read-back validation failed.")

  output_manifest <- file.path(
    stage, "audit", "Script13C_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(stage, full.names = TRUE, all.files = TRUE, no.. = TRUE)
    copied <- file.copy(entries, OUTPUT_ROOT, recursive = TRUE,
                        copy.mode = TRUE, copy.date = TRUE)
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(manifest_ok(OUTPUT_ROOT, file.path(
      OUTPUT_ROOT, "audit", "Script13C_output_manifest_with_MD5.csv")),
      "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }
  committed <- TRUE
  assert(manifest_ok(OUTPUT_ROOT, file.path(
    OUTPUT_ROOT, "audit", "Script13C_output_manifest_with_MD5.csv")),
    "Post-commit manifest verification failed.")
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13C completed successfully.\n")
  cat("Gene-level matrix: 20823 x 107\n")
  cat("Log2 transformation performed: FALSE\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

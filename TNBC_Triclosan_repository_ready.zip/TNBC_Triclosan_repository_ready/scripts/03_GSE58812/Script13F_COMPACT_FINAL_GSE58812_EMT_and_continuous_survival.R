# ==============================================================================
# TNBC_Triclosan | GSE58812 | Script 13F COMPACT FINAL
# Decision-critical external validation.
#
# Primary endpoint:
# - continuous Spearman association between fixed 24-gene Triclosan_activity
#   and Hallmark EMT classical-GSVA score.
#
# Prespecified sensitivity analyses:
# - Hallmark EMT score after removing genes overlapping the locked 24 genes;
# - Pearson correlation;
# - continuous-score MFS and OS Cox models, univariable and age-adjusted.
#
# No cutoff, high/low group, Kaplan-Meier analysis, sample removal,
# alternative Triclosan score, DEG, PCA, GSEA or manuscript figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13F_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step4_GSE58812_external_validation")
MATRIX_ROOT <- file.path(STEP_ROOT, "03_gene_level_expression_log2_MAS5")
SCORE_ROOT <- file.path(STEP_ROOT, "04_Triclosan_GSVA_score")
OUTPUT_ROOT <- file.path(
  STEP_ROOT,
  "05_EMT_external_validation_and_continuous_survival"
)

INPUTS <- c(
  matrix_bundle = file.path(MATRIX_ROOT, "objects",
    "GSE58812_gene_level_log2_MAS5_COMPLETE_bundle.rds"),
  matrix = file.path(MATRIX_ROOT, "objects",
    "GSE58812_gene_level_log2_MAS5_matrix.rds"),
  matrix_manifest = file.path(MATRIX_ROOT, "audit",
    "Script13D_output_manifest_with_MD5.csv"),
  matrix_report = file.path(MATRIX_ROOT, "logs",
    "Script13D_COMPLETE_report.txt"),
  score_bundle = file.path(SCORE_ROOT, "objects",
    "GSE58812_Triclosan_24gene_GSVA_COMPLETE_bundle.rds"),
  score = file.path(SCORE_ROOT, "objects",
    "GSE58812_Triclosan_24gene_GSVA_score.rds"),
  score_csv = file.path(SCORE_ROOT, "audit",
    "GSE58812_Triclosan_24gene_GSVA_score_all107.csv"),
  score_manifest = file.path(SCORE_ROOT, "audit",
    "Script13E_output_manifest_with_MD5.csv"),
  score_report = file.path(SCORE_ROOT, "logs",
    "Script13E_COMPLETE_report.txt")
)

EXPECTED_MD5 <- c(
  matrix_bundle = "d85f687aa51b9f738936f28abcca4e97",
  matrix = "cbda0e1ba636856c6ca9cd6353c9b775",
  matrix_manifest = "51aa48cd007f8bbb24b6af4a0297c044",
  matrix_report = "c233f0388594adbdb98a3e23573aaf65",
  score_bundle = "86e33e3ae27d718ce932c1cecaa8bfd8",
  score = "1627558d0c93cd71faf09f61eebd7a6d",
  score_csv = "bb997f63968dd82dc06fa453f199ddce",
  score_manifest = "e798c0be870a783e8da3977a2c99ef2a",
  score_report = "faca63097281eaaa8f32638053bbc979"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)
EMT_NAME <- "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"
BOOTSTRAP_N <- 10000L
BOOTSTRAP_SEED <- 20260711L

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)
numeric_strict <- function(x, label) {
  y <- suppressWarnings(as.numeric(trimws(as.character(x))))
  assert(length(y) == length(x) && all(is.finite(y)),
         "%s contains missing or non-numeric values.", label)
  y
}
bool_value <- function(x) isTRUE(as.logical(x)[1L])

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path","size_bytes","md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}

bootstrap_spearman <- function(x, y, n_boot, seed) {
  set.seed(seed)
  n <- length(x)
  values <- replicate(n_boot, {
    i <- sample.int(n, n, replace = TRUE)
    suppressWarnings(cor(x[i], y[i], method = "spearman"))
  })
  values <- values[is.finite(values)]
  assert(length(values) >= 0.99 * n_boot,
         "Too many non-finite bootstrap Spearman estimates.")
  list(
    values = values,
    lower = unname(quantile(values, 0.025)),
    upper = unname(quantile(values, 0.975))
  )
}

cox_result <- function(time, event, score_z, age10, endpoint, adjusted) {
  d <- data.frame(
    time = time,
    event = event,
    score_z = score_z,
    age10 = age10
  )
  formula <- if (adjusted) {
    survival::Surv(time, event) ~ score_z + age10
  } else {
    survival::Surv(time, event) ~ score_z
  }

  fit <- survival::coxph(
    formula, data = d, ties = "efron",
    x = TRUE, y = TRUE, model = TRUE
  )
  s <- summary(fit)
  term <- "score_z"
  zph <- tryCatch(survival::cox.zph(fit), error = function(e) NULL)
  zph_table <- if (is.null(zph)) NULL else zph$table

  result <- data.frame(
    endpoint = endpoint,
    model = if (adjusted) "score_plus_age" else "score_only",
    score_unit = "per_1_SD_higher_Triclosan_activity",
    sample_number = nrow(d),
    event_number = sum(event),
    coefficient = unname(s$coefficients[term, "coef"]),
    hazard_ratio = unname(s$conf.int[term, "exp(coef)"]),
    confidence_level = 0.95,
    confidence_interval_lower = unname(s$conf.int[term, "lower .95"]),
    confidence_interval_upper = unname(s$conf.int[term, "upper .95"]),
    Wald_z = unname(s$coefficients[term, "z"]),
    two_sided_p = unname(s$coefficients[term, "Pr(>|z|)"]),
    concordance = unname(s$concordance[1L]),
    PH_score_term_p = if (!is.null(zph_table) &&
                           term %in% rownames(zph_table))
      unname(zph_table[term, "p"]) else NA_real_,
    PH_global_p = if (!is.null(zph_table) &&
                       "GLOBAL" %in% rownames(zph_table))
      unname(zph_table["GLOBAL", "p"]) else NA_real_,
    primary_analysis = FALSE,
    cutoff_used = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(fit = fit, result = result, zph = zph)
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(root, "objects",
      "GSE58812_EMT_and_continuous_survival_COMPLETE_bundle.rds"),
    manifest = file.path(root, "audit",
      "Script13F_output_manifest_with_MD5.csv"),
    report = file.path(root, "logs",
      "Script13F_COMPLETE_report.txt")
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) return(FALSE)

  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT13F STATUS: COMPLETE", report, fixed = TRUE))) return(FALSE)

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  is.list(b) &&
    identical(as.character(b$script), "Script13F") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    identical(as.character(b$source_script13e_bundle_md5),
              unname(EXPECTED_MD5["score_bundle"])) &&
    nrow(b$EMT_correlation_results) == 3L &&
    nrow(b$continuous_survival_results) == 4L &&
    isFALSE(b$policy$cutoff_selected) &&
    isFALSE(b$policy$high_low_group_created) &&
    isFALSE(b$policy$samples_filtered)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13F output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    STEP_ROOT,
    paste0(
      "05_EMT_external_validation_and_continuous_survival_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Primary EMT correlation and continuous survival sensitivity only.\n")
  cat("============================================================\n")

  packages <- c("GSVA", "msigdbr", "survival")
  missing_packages <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  assert(!length(missing_packages),
         paste0(
           "Missing package(s): ", paste(missing_packages, collapse = ", "),
           "\nInstall msigdbr with install.packages('msigdbr') and ",
           "Bioconductor packages with BiocManager when required."
         ))

  assert(dir.exists(STEP_ROOT), "Step 4 directory does not exist:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted input(s):\n%s",
         paste(missing, collapse = "\n"))

  observed <- vapply(INPUTS, md5, character(1))
  assert(identical(observed, EXPECTED_MD5),
         "At least one accepted input MD5 differs.\n%s",
         paste(sprintf("%s: expected %s; observed %s",
                       names(EXPECTED_MD5), EXPECTED_MD5, observed),
               collapse = "\n"))
  assert(any(grepl("SCRIPT13D STATUS: COMPLETE",
                   readLines(INPUTS["matrix_report"], warn = FALSE),
                   fixed = TRUE)),
         "Script 13D completion marker is missing.")
  assert(any(grepl("SCRIPT13E STATUS: COMPLETE",
                   readLines(INPUTS["score_report"], warn = FALSE),
                   fixed = TRUE)),
         "Script 13E completion marker is missing.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  matrix_bundle <- readRDS(INPUTS["matrix_bundle"])
  log_expr <- readRDS(INPUTS["matrix"])
  score_bundle <- readRDS(INPUTS["score_bundle"])
  triclosan_score <- readRDS(INPUTS["score"])
  score_csv <- read.csv(
    INPUTS["score_csv"], stringsAsFactors = FALSE, check.names = FALSE
  )

  assert(is.list(matrix_bundle) &&
         identical(as.character(matrix_bundle$script), "Script13D") &&
         identical(as.character(matrix_bundle$script_build_id),
                   "Script13D_COMPACT_FINAL_20260711"),
         "Accepted Script 13D bundle identity is incorrect.")
  assert(is.list(score_bundle) &&
         identical(as.character(score_bundle$script), "Script13E") &&
         identical(as.character(score_bundle$script_build_id),
                   "Script13E_COMPACT_FINAL_20260711"),
         "Accepted Script 13E bundle identity is incorrect.")

  assert(is.matrix(log_expr) && is.numeric(log_expr) &&
         identical(dim(log_expr), c(20823L, 107L)) &&
         identical(log_expr, matrix_bundle$gene_level_expression_log2_MAS5) &&
         all(is.finite(log_expr)) &&
         !anyDuplicated(rownames(log_expr)) &&
         !anyDuplicated(colnames(log_expr)) &&
         all(apply(log_expr, 1L, sd) > 0),
         "Accepted full log2 matrix failed identity or quality checks.")

  assert(is.numeric(triclosan_score) &&
         length(triclosan_score) == 107L &&
         all(is.finite(triclosan_score)) &&
         sd(triclosan_score) > 0 &&
         length(unique(triclosan_score)) == 107L &&
         identical(names(triclosan_score), colnames(log_expr)) &&
         identical(triclosan_score, score_bundle$Triclosan_activity) &&
         identical(as.numeric(score_bundle$score_matrix[1L, ]),
                   as.numeric(triclosan_score)),
         "Accepted Triclosan_activity score is malformed or inconsistent.")

  assert(nrow(score_csv) == 107L &&
         identical(as.character(score_csv$sample_id),
                   names(triclosan_score)) &&
         isTRUE(all.equal(
           score_csv$Triclosan_activity,
           as.numeric(triclosan_score),
           tolerance = 1e-14,
           check.attributes = FALSE
         )),
         "Script 13E score CSV differs from the accepted RDS score.")

  pheno <- score_bundle$phenotype_raw
  assert(is.data.frame(pheno) && nrow(pheno) == 107L &&
         identical(rownames(pheno), names(triclosan_score)),
         "Phenotype rows are not aligned with the score samples.")

  # ------------------------------
  # Hallmark EMT gene set
  # ------------------------------
  msig_formals <- names(formals(msigdbr::msigdbr))
  msig_args <- list(species = "Homo sapiens")
  if ("db_species" %in% msig_formals) msig_args$db_species <- "HS"
  if ("collection" %in% msig_formals) {
    msig_args$collection <- "H"
  } else {
    msig_args$category <- "H"
  }

  hallmark <- do.call(msigdbr::msigdbr, msig_args)
  assert(is.data.frame(hallmark) &&
         all(c("gs_name", "gene_symbol") %in% names(hallmark)),
         "msigdbr Hallmark output lacks gs_name or gene_symbol.")

  emt_all <- sort(unique(as.character(
    hallmark$gene_symbol[hallmark$gs_name == EMT_NAME]
  )))
  emt_all <- emt_all[nzchar(emt_all) & !is.na(emt_all)]
  assert(length(emt_all) >= 150L && length(emt_all) <= 250L,
         "Retrieved Hallmark EMT gene count is implausible: %d.",
         length(emt_all))

  emt_detected <- emt_all[emt_all %in% rownames(log_expr)]
  overlap_genes <- emt_detected[emt_detected %in% LOCKED24]
  emt_no_overlap <- emt_detected[!emt_detected %in% LOCKED24]

  assert(length(emt_detected) >= ceiling(0.80 * length(emt_all)),
         "Hallmark EMT platform coverage is below 80%%.")
  assert(length(emt_no_overlap) >= ceiling(0.80 * length(emt_detected)),
         "Overlap-removed Hallmark EMT set is unexpectedly small.")

  emt_gene_sets <- list(
    HALLMARK_EMT_FULL = emt_detected,
    HALLMARK_EMT_NO_TRICLOSAN_OVERLAP = emt_no_overlap
  )

  set.seed(20260711L)
  emt_parameter <- GSVA::gsvaParam(log_expr, emt_gene_sets)
  emt_object <- GSVA::gsva(emt_parameter)
  emt_matrix <- if (is.matrix(emt_object)) {
    emt_object
  } else if (inherits(emt_object, "SummarizedExperiment") &&
             requireNamespace("SummarizedExperiment", quietly = TRUE)) {
    as.matrix(SummarizedExperiment::assay(emt_object))
  } else {
    as.matrix(emt_object)
  }

  expected_rows <- names(emt_gene_sets)
  assert(is.matrix(emt_matrix) && is.numeric(emt_matrix) &&
         identical(dim(emt_matrix), c(2L, 107L)) &&
         identical(rownames(emt_matrix), expected_rows) &&
         identical(colnames(emt_matrix), colnames(log_expr)) &&
         all(is.finite(emt_matrix)) &&
         all(apply(emt_matrix, 1L, sd) > 0),
         "EMT GSVA output failed dimensions, names, finite-value or variance checks.")

  emt_full <- as.numeric(emt_matrix["HALLMARK_EMT_FULL", ])
  emt_no_overlap_score <- as.numeric(
    emt_matrix["HALLMARK_EMT_NO_TRICLOSAN_OVERLAP", ]
  )
  names(emt_full) <- colnames(emt_matrix)
  names(emt_no_overlap_score) <- colnames(emt_matrix)

  # ------------------------------
  # Correlation analyses
  # ------------------------------
  primary_test <- suppressWarnings(cor.test(
    triclosan_score, emt_full,
    method = "spearman", exact = FALSE
  ))
  no_overlap_test <- suppressWarnings(cor.test(
    triclosan_score, emt_no_overlap_score,
    method = "spearman", exact = FALSE
  ))
  pearson_test <- cor.test(
    triclosan_score, emt_full,
    method = "pearson"
  )

  primary_boot <- bootstrap_spearman(
    triclosan_score, emt_full,
    BOOTSTRAP_N, BOOTSTRAP_SEED
  )
  no_overlap_boot <- bootstrap_spearman(
    triclosan_score, emt_no_overlap_score,
    BOOTSTRAP_N, BOOTSTRAP_SEED + 1L
  )

  correlation_results <- data.frame(
    analysis = c(
      "Primary_Spearman_full_Hallmark_EMT",
      "Sensitivity_Spearman_EMT_without_locked24_overlap",
      "Sensitivity_Pearson_full_Hallmark_EMT"
    ),
    EMT_score = c(
      "HALLMARK_EMT_FULL",
      "HALLMARK_EMT_NO_TRICLOSAN_OVERLAP",
      "HALLMARK_EMT_FULL"
    ),
    method = c("Spearman", "Spearman", "Pearson"),
    sample_number = 107L,
    estimate = c(
      unname(primary_test$estimate),
      unname(no_overlap_test$estimate),
      unname(pearson_test$estimate)
    ),
    confidence_level = 0.95,
    confidence_interval_method = c(
      paste0("Percentile bootstrap; B=", BOOTSTRAP_N),
      paste0("Percentile bootstrap; B=", BOOTSTRAP_N),
      "Pearson cor.test"
    ),
    confidence_interval_lower = c(
      primary_boot$lower,
      no_overlap_boot$lower,
      unname(pearson_test$conf.int[1L])
    ),
    confidence_interval_upper = c(
      primary_boot$upper,
      no_overlap_boot$upper,
      unname(pearson_test$conf.int[2L])
    ),
    two_sided_p = c(
      primary_test$p.value,
      no_overlap_test$p.value,
      pearson_test$p.value
    ),
    expected_direction = "positive",
    direction_matches_TCGA = c(
      unname(primary_test$estimate) > 0,
      unname(no_overlap_test$estimate) > 0,
      unname(pearson_test$estimate) > 0
    ),
    primary_analysis = c(TRUE, FALSE, FALSE),
    cutoff_used = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  correlation_results$secondary_BH_adjusted_p <- c(
    NA_real_,
    p.adjust(correlation_results$two_sided_p[2:3], method = "BH")
  )

  emt_gene_audit <- data.frame(
    pathway = EMT_NAME,
    human_symbol = emt_all,
    present_in_GSE58812 = emt_all %in% emt_detected,
    overlaps_locked_24gene_signature = emt_all %in% overlap_genes,
    used_in_primary_EMT_score = emt_all %in% emt_detected,
    used_in_overlap_removed_EMT_score = emt_all %in% emt_no_overlap,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  emt_set_summary <- data.frame(
    pathway = EMT_NAME,
    msigdbr_version = as.character(packageVersion("msigdbr")),
    total_gene_number = length(emt_all),
    detected_gene_number = length(emt_detected),
    detected_fraction = length(emt_detected) / length(emt_all),
    locked24_overlap_gene_number = length(overlap_genes),
    locked24_overlap_genes = if (length(overlap_genes))
      paste(overlap_genes, collapse = ";") else "",
    overlap_removed_gene_number = length(emt_no_overlap),
    full_score_zero_variance = sd(emt_full) == 0,
    overlap_removed_score_zero_variance = sd(emt_no_overlap_score) == 0,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  # ------------------------------
  # Continuous MFS / OS sensitivity analyses
  # ------------------------------
  required_clinical <- c(
    "age at diag:ch1", "meta:ch1", "mfs (days):ch1",
    "death:ch1", "os (days):ch1"
  )
  assert(all(required_clinical %in% names(pheno)),
         "Required clinical fields are missing from GSE58812 phenotype data.")

  age <- numeric_strict(pheno[["age at diag:ch1"]], "Age")
  mfs_event <- numeric_strict(pheno[["meta:ch1"]], "MFS event")
  mfs_days <- numeric_strict(pheno[["mfs (days):ch1"]], "MFS time")
  os_event <- numeric_strict(pheno[["death:ch1"]], "OS event")
  os_days <- numeric_strict(pheno[["os (days):ch1"]], "OS time")

  assert(all(mfs_event %in% c(0, 1)) && all(os_event %in% c(0, 1)),
         "Survival event fields are not binary 0/1.")
  assert(all(mfs_days > 0) && all(os_days > 0),
         "Survival times must be strictly positive.")
  assert(sum(mfs_event) == 31L && sum(os_event) == 29L,
         "Observed MFS or OS event count differs from the accepted preflight.")

  score_z <- as.numeric(scale(triclosan_score))
  age10 <- (age - mean(age)) / 10

  mfs_uni <- cox_result(
    mfs_days, mfs_event, score_z, age10, "MFS", FALSE
  )
  mfs_age <- cox_result(
    mfs_days, mfs_event, score_z, age10, "MFS", TRUE
  )
  os_uni <- cox_result(
    os_days, os_event, score_z, age10, "OS", FALSE
  )
  os_age <- cox_result(
    os_days, os_event, score_z, age10, "OS", TRUE
  )

  survival_results <- do.call(rbind, list(
    mfs_uni$result, mfs_age$result,
    os_uni$result, os_age$result
  ))
  rownames(survival_results) <- NULL
  survival_results$BH_adjusted_p_across_four_models <- p.adjust(
    survival_results$two_sided_p, method = "BH"
  )

  survival_models <- list(
    MFS_score_only = mfs_uni$fit,
    MFS_score_plus_age = mfs_age$fit,
    OS_score_only = os_uni$fit,
    OS_score_plus_age = os_age$fit
  )
  proportional_hazards_objects <- list(
    MFS_score_only = mfs_uni$zph,
    MFS_score_plus_age = mfs_age$zph,
    OS_score_only = os_uni$zph,
    OS_score_plus_age = os_age$zph
  )

  endpoint_audit <- data.frame(
    endpoint = c("MFS", "OS"),
    time_field = c("mfs (days):ch1", "os (days):ch1"),
    event_field = c("meta:ch1", "death:ch1"),
    sample_number = 107L,
    event_number = c(sum(mfs_event), sum(os_event)),
    censored_number = c(sum(mfs_event == 0), sum(os_event == 0)),
    minimum_time_days = c(min(mfs_days), min(os_days)),
    median_time_days = c(median(mfs_days), median(os_days)),
    maximum_time_days = c(max(mfs_days), max(os_days)),
    missing_time_number = 0L,
    missing_event_number = 0L,
    cutoff_or_dichotomization_used = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  sample_table <- data.frame(
    sample_order = seq_along(triclosan_score),
    sample_id = names(triclosan_score),
    Triclosan_activity = as.numeric(triclosan_score),
    HALLMARK_EMT_FULL = emt_full,
    HALLMARK_EMT_NO_TRICLOSAN_OVERLAP = emt_no_overlap_score,
    age_at_diagnosis = age,
    MFS_event = mfs_event,
    MFS_days = mfs_days,
    OS_event = os_event,
    OS_days = os_days,
    score_z = score_z,
    age_centered_per_10_years = age10,
    samples_filtered = FALSE,
    cutoff_used = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  parameter_lock <- data.frame(
    field = c(
      "Primary_endpoint",
      "Primary_method",
      "Primary_test_sidedness",
      "Primary_confidence_interval",
      "EMT_gene_set",
      "EMT_source",
      "EMT_scoring_method",
      "EMT_expression_input",
      "Overlap_sensitivity",
      "Survival_role",
      "Survival_score_unit",
      "Survival_models",
      "Survival_ties_method",
      "Cutoff_or_high_low_group",
      "Sample_filtering",
      "DEG_PCA_GSEA_figure"
    ),
    value = c(
      "Triclosan_activity versus HALLMARK_EMT_FULL",
      "Spearman correlation",
      "Two-sided",
      paste0("Percentile bootstrap; B=", BOOTSTRAP_N,
             "; seed=", BOOTSTRAP_SEED),
      EMT_NAME,
      paste0("msigdbr ", packageVersion("msigdbr")),
      "Classical_GSVA",
      "Full 20823-gene x 107-sample log2 MAS5 matrix",
      "Remove any locked-24 genes from Hallmark EMT and rescore",
      "Secondary sensitivity only",
      "Per 1 SD higher continuous Triclosan_activity",
      "MFS and OS: score-only and score-plus-age",
      "Efron",
      "FALSE",
      "FALSE",
      "FALSE"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    primary_endpoint = "Continuous_Spearman_Triclosan_activity_vs_Hallmark_EMT",
    full_expression_matrix_used_for_EMT_GSVA = TRUE,
    alternative_Triclosan_score_calculated = FALSE,
    overlap_removed_EMT_sensitivity_performed = TRUE,
    survival_models_secondary_only = TRUE,
    samples_filtered = FALSE,
    outliers_removed = FALSE,
    cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    Kaplan_Meier_performed = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID",
      "Source_Script13D_bundle_MD5","Source_log2_matrix_MD5",
      "Source_Script13E_bundle_MD5","Source_Triclosan_score_MD5",
      "Expression_dimensions","Sample_number",
      "Finite_Triclosan_scores","Finite_EMT_scores",
      "Hallmark_EMT_total_genes","Hallmark_EMT_detected_genes",
      "Hallmark_EMT_overlap_locked24","Hallmark_EMT_no_overlap_genes",
      "Primary_correlation_test_number","Survival_model_number",
      "MFS_event_number","OS_event_number",
      "Samples_filtered","Outliers_removed","Alternative_score_calculated",
      "Cutoff_selected","High_low_group_created","Kaplan_Meier_performed",
      "DEG_performed","PCA_performed","GSEA_performed",
      "Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "GSE58812","13F",BUILD_ID,EXPECTED_MD5["matrix_bundle"],
      EXPECTED_MD5["matrix"],EXPECTED_MD5["score_bundle"],
      EXPECTED_MD5["score"],paste(dim(log_expr), collapse = " x "),
      length(triclosan_score),sum(is.finite(triclosan_score)),
      sum(is.finite(emt_matrix)),length(emt_all),length(emt_detected),
      length(overlap_genes),length(emt_no_overlap),
      sum(correlation_results$primary_analysis),nrow(survival_results),
      sum(mfs_event),sum(os_event),FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,FALSE,FALSE,FALSE,"COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = c(rep("Script13D", 4L), rep("Script13E", 5L)),
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  result_bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step4_GSE58812_external_validation",
    script = "Script13F",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE58812",
    source_platform = "GPL570",
    source_script13d_bundle_md5 = unname(EXPECTED_MD5["matrix_bundle"]),
    source_log2_matrix_md5 = unname(EXPECTED_MD5["matrix"]),
    source_script13e_bundle_md5 = unname(EXPECTED_MD5["score_bundle"]),
    source_Triclosan_score_md5 = unname(EXPECTED_MD5["score"]),
    Triclosan_activity = triclosan_score,
    EMT_score_matrix = emt_matrix,
    sample_level_scores_and_clinical = sample_table,
    EMT_gene_set_summary = emt_set_summary,
    EMT_gene_set_audit = emt_gene_audit,
    EMT_correlation_results = correlation_results,
    continuous_survival_results = survival_results,
    survival_endpoint_audit = endpoint_audit,
    parameter_lock = parameter_lock,
    integrity_summary = integrity,
    policy = policy
  )
  class(result_bundle) <- c(
    "GSE58812_EMT_and_continuous_survival_bundle", "list"
  )

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script13F_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects","audit","logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(stage, "objects",
      "GSE58812_EMT_and_continuous_survival_COMPLETE_bundle.rds"),
    EMT_scores = file.path(stage, "objects",
      "GSE58812_Hallmark_EMT_GSVA_scores.rds"),
    survival_models = file.path(stage, "objects",
      "GSE58812_continuous_survival_models.rds"),
    bootstrap = file.path(stage, "objects",
      "GSE58812_EMT_correlation_bootstrap_distributions.rds"),
    samples = file.path(stage, "audit",
      "GSE58812_Triclosan_EMT_scores_and_clinical_all107.csv"),
    EMT_gene_summary = file.path(stage, "audit",
      "GSE58812_Hallmark_EMT_gene_set_summary.csv"),
    EMT_gene_audit = file.path(stage, "audit",
      "GSE58812_Hallmark_EMT_gene_set_audit.csv"),
    correlations = file.path(stage, "audit",
      "GSE58812_Triclosan_EMT_continuous_correlation.csv"),
    survival = file.path(stage, "audit",
      "GSE58812_Triclosan_continuous_MFS_OS_Cox_results.csv"),
    endpoints = file.path(stage, "audit",
      "GSE58812_survival_endpoint_audit.csv"),
    parameters = file.path(stage, "audit",
      "GSE58812_EMT_and_survival_parameter_lock.csv"),
    packages = file.path(stage, "audit",
      "Script13F_package_audit.csv"),
    integrity = file.path(stage, "audit",
      "GSE58812_EMT_and_survival_integrity_summary.csv"),
    inputs = file.path(stage, "audit",
      "Script13F_input_manifest_with_MD5.csv"),
    GSVA_details = file.path(stage, "logs",
      "Script13F_EMT_GSVA_parameter_details.txt"),
    session = file.path(stage, "logs",
      "Script13F_sessionInfo.txt"),
    report = file.path(stage, "logs",
      "Script13F_COMPLETE_report.txt")
  )

  saveRDS(result_bundle, files["bundle"], version = 3)
  saveRDS(emt_matrix, files["EMT_scores"], version = 3)
  saveRDS(list(
    models = survival_models,
    proportional_hazards = proportional_hazards_objects
  ), files["survival_models"], version = 3)
  saveRDS(list(
    primary_full_EMT = primary_boot$values,
    sensitivity_no_overlap_EMT = no_overlap_boot$values,
    bootstrap_n = BOOTSTRAP_N,
    seeds = c(BOOTSTRAP_SEED, BOOTSTRAP_SEED + 1L)
  ), files["bootstrap"], version = 3)

  write_csv(sample_table, files["samples"])
  write_csv(emt_set_summary, files["EMT_gene_summary"])
  write_csv(emt_gene_audit, files["EMT_gene_audit"])
  write_csv(correlation_results, files["correlations"])
  write_csv(survival_results, files["survival"])
  write_csv(endpoint_audit, files["endpoints"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(data.frame(
    package = packages,
    version = vapply(
      packages, function(x) as.character(packageVersion(x)), character(1)
    ),
    available = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  ), files["packages"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  writeLines(capture.output(show(emt_parameter)),
             files["GSVA_details"], useBytes = TRUE)
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 4 - Script 13F",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "GEO accession: GSE58812",
    paste0("Hallmark EMT genes: ", length(emt_detected), " / ",
           length(emt_all), " detected"),
    paste0("Locked-24 overlap genes: ", length(overlap_genes),
           if (length(overlap_genes))
             paste0(" [", paste(overlap_genes, collapse = ";"), "]") else ""),
    paste0("Primary Spearman rho: ",
           format(unname(primary_test$estimate), digits = 16)),
    paste0("Primary two-sided p: ",
           format(primary_test$p.value, digits = 16)),
    paste0("Primary bootstrap 95% CI: ",
           format(primary_boot$lower, digits = 16), " to ",
           format(primary_boot$upper, digits = 16)),
    paste0("Overlap-removed Spearman rho: ",
           format(unname(no_overlap_test$estimate), digits = 16)),
    paste0("Overlap-removed two-sided p: ",
           format(no_overlap_test$p.value, digits = 16)),
    paste0("MFS events: ", sum(mfs_event), " / 107"),
    paste0("OS events: ", sum(os_event), " / 107"),
    "Survival models: continuous score only and score plus age",
    "Samples filtered or outliers removed: FALSE",
    "Alternative Triclosan score calculated: FALSE",
    "Cutoff/high-low/Kaplan-Meier performed: FALSE",
    "DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13F STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  e2 <- readRDS(files["EMT_scores"])
  c2 <- read.csv(files["correlations"],
                 stringsAsFactors = FALSE, check.names = FALSE)
  s2 <- read.csv(files["survival"],
                 stringsAsFactors = FALSE, check.names = FALSE)

  assert(identical(e2, emt_matrix) &&
         identical(b2$EMT_score_matrix, emt_matrix) &&
         nrow(c2) == 3L &&
         isTRUE(all.equal(
           c2$estimate, correlation_results$estimate,
           tolerance = 1e-14, check.attributes = FALSE
         )) &&
         isTRUE(all.equal(
           c2$two_sided_p, correlation_results$two_sided_p,
           tolerance = 1e-14, check.attributes = FALSE
         )) &&
         nrow(s2) == 4L &&
         isTRUE(all.equal(
           s2$hazard_ratio, survival_results$hazard_ratio,
           tolerance = 1e-14, check.attributes = FALSE
         )),
         "RDS/CSV save-read validation failed.")

  output_manifest <- file.path(
    stage, "audit", "Script13F_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(stage, full.names = TRUE, all.files = TRUE, no.. = TRUE)
    copied <- file.copy(entries, OUTPUT_ROOT, recursive = TRUE,
                        copy.mode = TRUE, copy.date = TRUE)
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(manifest_ok(OUTPUT_ROOT, file.path(
      OUTPUT_ROOT, "audit", "Script13F_output_manifest_with_MD5.csv")),
      "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(manifest_ok(OUTPUT_ROOT, file.path(
    OUTPUT_ROOT, "audit", "Script13F_output_manifest_with_MD5.csv")),
    "Post-commit manifest verification failed.")
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13F completed successfully.\n")
  cat("Primary EMT correlation sample number: 107\n")
  cat("Continuous survival models: 4\n")
  cat("Cutoff/high-low/Kaplan-Meier performed: FALSE\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

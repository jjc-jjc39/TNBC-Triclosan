# ==============================================================================
# TNBC_Triclosan | GSE58812 | Script 13A COMPACT FINAL
# Download and preflight audit only.
#
# This script:
# - downloads the public GSE58812 series matrix through GEOquery;
# - selects the GPL570 ExpressionSet;
# - verifies 107 samples, expression/phenotype alignment and finite values;
# - inventories phenotype fields and processed-expression distributions;
# - preserves downloaded source files, RDS objects, CSV audits and MD5s.
#
# It does NOT:
# - annotate probes, aggregate genes, normalize again or filter samples;
# - calculate Triclosan_activity;
# - parse or model survival;
# - select cutoffs, fit prognosis models, run DEG/PCA/GSEA or create figures.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1, timeout = 1800L)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13A_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step4_GSE58812_external_validation")
OUTPUT_ROOT <- file.path(STEP_ROOT, "00_preflight")
GEO_ACCESSION <- "GSE58812"
EXPECTED_PLATFORM <- "GPL570"
EXPECTED_SAMPLE_N <- 107L

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)
clean_text <- function(x) {
  y <- trimws(as.character(x))
  y[is.na(x) | !nzchar(y) | tolower(y) %in% c("na","n/a","null","none")] <- NA_character_
  y
}
top_values <- function(x, n = 8L) {
  y <- clean_text(x)
  y[is.na(y)] <- "<MISSING>"
  tab <- sort(table(y), decreasing = TRUE)
  if (!length(tab)) return("")
  tab <- head(tab, n)
  paste0(names(tab), " [", as.integer(tab), "]", collapse = " | ")
}
num_summary <- function(x) {
  x <- as.numeric(x)
  data.frame(
    n = length(x),
    finite_n = sum(is.finite(x)),
    nonfinite_n = sum(!is.finite(x)),
    min = min(x),
    q1 = unname(quantile(x, .25)),
    median = median(x),
    mean = mean(x),
    q3 = unname(quantile(x, .75)),
    max = max(x),
    sd = sd(x),
    check.names = FALSE
  )
}
make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "File is outside the staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))
  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}
manifest_ok <- function(root, file) {
  m <- tryCatch(read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
                error = function(e) NULL)
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path","size_bytes","md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}
existing_valid <- function(root) {
  key <- c(
    bundle = file.path(root, "objects", "GSE58812_preflight_COMPLETE_bundle.rds"),
    eset = file.path(root, "objects", "GSE58812_processed_ExpressionSet_SOURCE.rds"),
    manifest = file.path(root, "audit", "Script13A_output_manifest_with_MD5.csv"),
    report = file.path(root, "logs", "Script13A_COMPLETE_report.txt")
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) return(FALSE)
  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT13A STATUS: COMPLETE", report, fixed = TRUE))) return(FALSE)
  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  e <- tryCatch(readRDS(key["eset"]), error = function(e) NULL)
  is.list(b) &&
    identical(as.character(b$script), "Script13A") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    identical(as.character(b$source_accession), GEO_ACCESSION) &&
    identical(as.character(b$source_platform), EXPECTED_PLATFORM) &&
    inherits(e, "ExpressionSet") &&
    ncol(Biobase::exprs(e)) == EXPECTED_SAMPLE_N &&
    isFALSE(b$policy$Triclosan_score_calculated) &&
    isFALSE(b$policy$survival_model_fitted)
}
prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))
  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }
  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13A output is complete and valid.\n")
    cat("Nothing was overwritten or downloaded again.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }
  archive <- file.path(
    STEP_ROOT,
    paste0("00_preflight_INCOMPLETE_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing preflight directory is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Download and preflight only; scoring and survival analysis disabled.\n")
  cat("============================================================\n")

  assert(requireNamespace("GEOquery", quietly = TRUE),
         "Package GEOquery is missing. Install it with BiocManager::install('GEOquery').")
  assert(requireNamespace("Biobase", quietly = TRUE),
         "Package Biobase is missing. Install it with BiocManager::install('Biobase').")
  dir.create(STEP_ROOT, recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(STEP_ROOT), "Unable to create Step 4 directory.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script13A_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("downloads", "objects", "audit", "logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  geo <- GEOquery::getGEO(
    GEO_ACCESSION,
    GSEMatrix = TRUE,
    AnnotGPL = FALSE,
    getGPL = FALSE,
    destdir = file.path(stage, "downloads")
  )
  if (inherits(geo, "ExpressionSet")) geo <- list(geo)
  assert(is.list(geo) && length(geo) >= 1L,
         "GEOquery did not return an ExpressionSet list.")

  platform_ids <- vapply(geo, function(e) {
    annotation <- tryCatch(Biobase::annotation(e), error = function(x) "")
    if (!nzchar(annotation)) {
      annotation <- as.character(Biobase::experimentData(e)@other$platform_id)[1L]
    }
    annotation
  }, character(1))
  hit <- which(platform_ids == EXPECTED_PLATFORM)
  assert(length(hit) == 1L,
         "Expected exactly one %s ExpressionSet; detected platforms: %s",
         EXPECTED_PLATFORM, paste(platform_ids, collapse = ";"))
  eset <- geo[[hit]]
  expr <- Biobase::exprs(eset)
  pheno <- Biobase::pData(eset)
  feature <- Biobase::fData(eset)

  assert(is.matrix(expr) && is.numeric(expr) && nrow(expr) > 0L &&
         ncol(expr) == EXPECTED_SAMPLE_N,
         "Expected a non-empty numeric matrix with 107 samples; detected %s.",
         paste(dim(expr), collapse = " x "))
  assert(!is.null(rownames(expr)) && !is.null(colnames(expr)) &&
         all(nzchar(rownames(expr))) && all(nzchar(colnames(expr))) &&
         !anyDuplicated(rownames(expr)) && !anyDuplicated(colnames(expr)),
         "Expression feature or sample IDs are blank or duplicated.")
  assert(all(is.finite(expr)),
         "Processed expression matrix contains non-finite values.")
  assert(is.data.frame(pheno) && nrow(pheno) == EXPECTED_SAMPLE_N &&
         identical(rownames(pheno), colnames(expr)),
         "Phenotype rows are not exactly aligned with expression columns.")
  assert(is.data.frame(feature) && nrow(feature) == nrow(expr) &&
         identical(rownames(feature), rownames(expr)),
         "Feature-data rows are not exactly aligned with expression rows.")

  sample_summary <- do.call(rbind, lapply(seq_len(ncol(expr)), function(i) {
    cbind(
      data.frame(
        sample_order = i,
        sample_id = colnames(expr)[i],
        sample_title = if ("title" %in% names(pheno))
          as.character(pheno$title[i]) else "",
        check.names = FALSE
      ),
      num_summary(expr[, i])
    )
  }))
  rownames(sample_summary) <- NULL

  phenotype_inventory <- do.call(rbind, lapply(seq_along(pheno), function(i) {
    x <- pheno[[i]]
    cleaned <- clean_text(x)
    numeric_x <- suppressWarnings(as.numeric(cleaned))
    nonmissing <- !is.na(cleaned)
    numeric_ok <- nonmissing & !is.na(numeric_x)
    data.frame(
      column_order = i,
      column_name = names(pheno)[i],
      R_class = paste(class(x), collapse = ";"),
      sample_number = length(x),
      nonmissing_number = sum(nonmissing),
      missing_number = sum(!nonmissing),
      unique_nonmissing_number = length(unique(cleaned[nonmissing])),
      numeric_parse_number = sum(numeric_ok),
      numeric_parse_fraction = if (sum(nonmissing))
        sum(numeric_ok) / sum(nonmissing) else NA_real_,
      top_observed_values = top_values(x),
      source_value_modified = FALSE,
      check.names = FALSE
    )
  }))
  rownames(phenotype_inventory) <- NULL

  platform_audit <- data.frame(
    returned_object_order = seq_along(geo),
    platform_id = platform_ids,
    feature_number = vapply(geo, function(e) nrow(Biobase::exprs(e)), integer(1)),
    sample_number = vapply(geo, function(e) ncol(Biobase::exprs(e)), integer(1)),
    selected_for_GSE58812 = seq_along(geo) == hit,
    check.names = FALSE
  )

  expression_summary <- cbind(
    data.frame(
      GEO_accession = GEO_ACCESSION,
      platform_id = EXPECTED_PLATFORM,
      feature_number = nrow(expr),
      sample_number = ncol(expr),
      check.names = FALSE
    ),
    num_summary(as.numeric(expr))
  )

  downloaded <- list.files(
    file.path(stage, "downloads"),
    full.names = TRUE, recursive = TRUE, all.files = FALSE
  )
  downloaded <- downloaded[file.info(downloaded)$isdir %in% FALSE]
  assert(length(downloaded) >= 1L,
         "GEOquery produced no preserved source file in the download directory.")
  download_manifest <- data.frame(
    file_name = basename(downloaded),
    relative_path = substring(
      normalizePath(downloaded, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(stage, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(downloaded)$size),
    md5 = vapply(downloaded, md5, character(1)),
    check.names = FALSE
  )

  policy <- list(
    processed_expression_used_as_supplied = TRUE,
    expression_values_modified = FALSE,
    additional_normalization_performed = FALSE,
    probes_annotated = FALSE,
    gene_aggregation_performed = FALSE,
    samples_filtered = FALSE,
    Triclosan_score_calculated = FALSE,
    survival_endpoint_parsed = FALSE,
    survival_model_fitted = FALSE,
    cutoff_selected = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID","Selected_platform",
      "Expression_dimensions","Expression_nonfinite_values",
      "Expression_feature_IDs_unique","Expression_sample_IDs_unique",
      "Phenotype_rows","Feature_data_rows","Expression_phenotype_order_identical",
      "Expression_feature_order_identical","Downloaded_source_file_number",
      "Expression_values_modified","Additional_normalization_performed",
      "Samples_filtered","Triclosan_score_calculated",
      "Survival_endpoint_parsed","Survival_model_fitted","Cutoff_selected",
      "DEG_performed","PCA_performed","GSEA_performed",
      "Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      GEO_ACCESSION,"13A",BUILD_ID,EXPECTED_PLATFORM,
      paste(dim(expr), collapse = " x "),sum(!is.finite(expr)),
      !anyDuplicated(rownames(expr)),!anyDuplicated(colnames(expr)),
      nrow(pheno),nrow(feature),identical(rownames(pheno), colnames(expr)),
      identical(rownames(feature), rownames(expr)),length(downloaded),
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      "COMPLETE"
    )),
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step4_GSE58812_external_validation",
    script = "Script13A",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = GEO_ACCESSION,
    source_platform = EXPECTED_PLATFORM,
    expression_matrix = expr,
    phenotype_raw = pheno,
    feature_data_raw = feature,
    platform_audit = platform_audit,
    expression_summary = expression_summary,
    sample_expression_summary = sample_summary,
    phenotype_inventory = phenotype_inventory,
    download_manifest = download_manifest,
    policy = policy,
    integrity_summary = integrity
  )
  class(bundle) <- c("GSE58812_preflight_bundle", "list")

  files <- c(
    eset = file.path(stage, "objects",
      "GSE58812_processed_ExpressionSet_SOURCE.rds"),
    bundle = file.path(stage, "objects",
      "GSE58812_preflight_COMPLETE_bundle.rds"),
    phenotype = file.path(stage, "audit",
      "GSE58812_phenotype_raw.csv"),
    phenotype_inventory = file.path(stage, "audit",
      "GSE58812_phenotype_variable_inventory.csv"),
    platform = file.path(stage, "audit",
      "GSE58812_platform_selection_audit.csv"),
    expression = file.path(stage, "audit",
      "GSE58812_processed_expression_summary.csv"),
    samples = file.path(stage, "audit",
      "GSE58812_sample_expression_distribution.csv"),
    downloads = file.path(stage, "audit",
      "GSE58812_downloaded_source_files_with_MD5.csv"),
    packages = file.path(stage, "audit",
      "Script13A_package_audit.csv"),
    integrity = file.path(stage, "audit",
      "GSE58812_preflight_integrity_summary.csv"),
    session = file.path(stage, "logs", "Script13A_sessionInfo.txt"),
    report = file.path(stage, "logs", "Script13A_COMPLETE_report.txt")
  )

  saveRDS(eset, files["eset"], version = 3)
  saveRDS(bundle, files["bundle"], version = 3)
  write_csv(pheno, files["phenotype"])
  write_csv(phenotype_inventory, files["phenotype_inventory"])
  write_csv(platform_audit, files["platform"])
  write_csv(expression_summary, files["expression"])
  write_csv(sample_summary, files["samples"])
  write_csv(download_manifest, files["downloads"])
  write_csv(data.frame(
    package = c("GEOquery","Biobase"),
    version = c(as.character(packageVersion("GEOquery")),
                as.character(packageVersion("Biobase"))),
    available = TRUE,
    check.names = FALSE
  ), files["packages"])
  write_csv(integrity, files["integrity"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 4 - Script 13A",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("GEO accession: ", GEO_ACCESSION),
    paste0("Selected platform: ", EXPECTED_PLATFORM),
    paste0("Expression dimensions: ", paste(dim(expr), collapse = " x ")),
    paste0("Phenotype dimensions: ", paste(dim(pheno), collapse = " x ")),
    paste0("Downloaded source files: ", length(downloaded)),
    "Expression values modified: FALSE",
    "Additional normalization performed: FALSE",
    "Samples filtered: FALSE",
    "Probe annotation/gene aggregation performed: FALSE",
    "Triclosan score calculated: FALSE",
    "Survival endpoint parsed or modeled: FALSE",
    "Cutoff/DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13A STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")
  e2 <- readRDS(files["eset"])
  b2 <- readRDS(files["bundle"])
  assert(inherits(e2, "ExpressionSet") &&
         identical(Biobase::exprs(e2), expr) &&
         identical(b2$expression_matrix, expr) &&
         identical(b2$phenotype_raw, pheno),
         "RDS save/read-back validation failed.")

  output_manifest <- file.path(
    stage, "audit", "Script13A_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(stage, full.names = TRUE, all.files = TRUE, no.. = TRUE)
    copied <- file.copy(entries, OUTPUT_ROOT, recursive = TRUE,
                        copy.mode = TRUE, copy.date = TRUE)
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(manifest_ok(OUTPUT_ROOT, file.path(
      OUTPUT_ROOT, "audit", "Script13A_output_manifest_with_MD5.csv")),
      "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }
  committed <- TRUE
  assert(manifest_ok(OUTPUT_ROOT, file.path(
    OUTPUT_ROOT, "audit", "Script13A_output_manifest_with_MD5.csv")),
    "Post-commit manifest verification failed.")
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13A completed successfully.\n")
  cat("GSE58812 samples: ", ncol(expr), "\n", sep = "")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

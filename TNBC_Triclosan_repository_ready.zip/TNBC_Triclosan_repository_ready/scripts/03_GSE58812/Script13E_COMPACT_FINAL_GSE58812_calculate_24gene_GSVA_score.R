# ==============================================================================
# TNBC_Triclosan | GSE58812 | Script 13E COMPACT FINAL
# Calculate the fixed 24-gene continuous classical-GSVA score.
#
# Locked method:
# - supply the full 20,823-gene x 107-sample log2 MAS5 matrix to GSVA;
# - use the fixed 24-gene Triclosan signature;
# - preserve all 107 samples and their original order.
#
# No alternative score, EMT test, survival analysis, cutoff, high/low group,
# DEG, PCA, GSEA or manuscript figure is produced in this script.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13E_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step4_GSE58812_external_validation")
INPUT_ROOT <- file.path(STEP_ROOT, "03_gene_level_expression_log2_MAS5")
OUTPUT_ROOT <- file.path(STEP_ROOT, "04_Triclosan_GSVA_score")

INPUTS <- c(
  bundle = file.path(INPUT_ROOT, "objects",
    "GSE58812_gene_level_log2_MAS5_COMPLETE_bundle.rds"),
  matrix = file.path(INPUT_ROOT, "objects",
    "GSE58812_gene_level_log2_MAS5_matrix.rds"),
  signature_matrix = file.path(INPUT_ROOT, "objects",
    "GSE58812_locked_24gene_log2_MAS5_matrix.rds"),
  row_annotation = file.path(INPUT_ROOT, "audit",
    "GSE58812_gene_level_log2_MAS5_row_annotation.csv"),
  signature_audit = file.path(INPUT_ROOT, "audit",
    "GSE58812_locked_24gene_log2_MAS5_availability.csv"),
  transformation = file.path(INPUT_ROOT, "audit",
    "GSE58812_log2_transformation_audit.csv"),
  manifest = file.path(INPUT_ROOT, "audit",
    "Script13D_output_manifest_with_MD5.csv"),
  report = file.path(INPUT_ROOT, "logs",
    "Script13D_COMPLETE_report.txt")
)

EXPECTED_MD5 <- c(
  bundle = "d85f687aa51b9f738936f28abcca4e97",
  matrix = "cbda0e1ba636856c6ca9cd6353c9b775",
  signature_matrix = "7c41310f3aa69df721ce54b888a8005c",
  row_annotation = "bffcd53ef5cfff78eb85c959d2b51710",
  signature_audit = "7e2b25bf17106e91631a0160c499e46c",
  transformation = "26340f45b5bcecd16904d926ace150b2",
  manifest = "51aa48cd007f8bbb24b6af4a0297c044",
  report = "c233f0388594adbdb98a3e23573aaf65"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

num_summary <- function(x) {
  x <- as.numeric(x)
  data.frame(
    n = length(x),
    finite_n = sum(is.finite(x)),
    nonfinite_n = sum(!is.finite(x)),
    min = min(x),
    q1 = unname(quantile(x, 0.25)),
    median = median(x),
    mean = mean(x),
    q3 = unname(quantile(x, 0.75)),
    max = max(x),
    sd = sd(x),
    iqr = IQR(x),
    unique_n = length(unique(x)),
    check.names = FALSE
  )
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path","size_bytes","md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(root, "objects",
      "GSE58812_Triclosan_24gene_GSVA_COMPLETE_bundle.rds"),
    score = file.path(root, "objects",
      "GSE58812_Triclosan_24gene_GSVA_score.rds"),
    manifest = file.path(root, "audit",
      "Script13E_output_manifest_with_MD5.csv"),
    report = file.path(root, "logs",
      "Script13E_COMPLETE_report.txt")
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) return(FALSE)

  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT13E STATUS: COMPLETE", report, fixed = TRUE))) return(FALSE)

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  s <- tryCatch(readRDS(key["score"]), error = function(e) NULL)

  is.list(b) &&
    identical(as.character(b$script), "Script13E") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    identical(as.character(b$source_script13d_bundle_md5),
              unname(EXPECTED_MD5["bundle"])) &&
    is.numeric(s) && length(s) == 107L &&
    all(is.finite(s)) && sd(s) > 0 &&
    identical(s, b$Triclosan_activity) &&
    identical(dim(b$score_matrix), c(1L, 107L)) &&
    isFALSE(b$policy$EMT_test_performed) &&
    isFALSE(b$policy$survival_model_fitted) &&
    isFALSE(b$policy$cutoff_selected)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13E output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    STEP_ROOT,
    paste0("04_Triclosan_GSVA_score_INCOMPLETE_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Classical GSVA score only; EMT and survival analyses are disabled.\n")
  cat("============================================================\n")

  assert(dir.exists(STEP_ROOT), "Step 4 directory does not exist:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted Script 13D input(s):\n%s",
         paste(missing, collapse = "\n"))

  observed <- vapply(INPUTS, md5, character(1))
  assert(identical(observed, EXPECTED_MD5),
         "At least one accepted Script 13D input MD5 differs.\n%s",
         paste(sprintf("%s: expected %s; observed %s",
                       names(EXPECTED_MD5), EXPECTED_MD5, observed),
               collapse = "\n"))
  assert(any(grepl("SCRIPT13D STATUS: COMPLETE",
                   readLines(INPUTS["report"], warn = FALSE), fixed = TRUE)),
         "Script 13D completion marker is missing.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  assert(requireNamespace("GSVA", quietly = TRUE),
         "Package GSVA is missing. Install with BiocManager::install('GSVA').")
  assert(exists("gsvaParam", envir = asNamespace("GSVA"), mode = "function"),
         "Installed GSVA does not provide gsvaParam(); update GSVA.")

  source_bundle <- readRDS(INPUTS["bundle"])
  log_expr <- readRDS(INPUTS["matrix"])
  signature_expr <- readRDS(INPUTS["signature_matrix"])
  row_annotation <- read.csv(
    INPUTS["row_annotation"], stringsAsFactors = FALSE, check.names = FALSE
  )
  signature_audit <- read.csv(
    INPUTS["signature_audit"], stringsAsFactors = FALSE, check.names = FALSE
  )

  assert(is.list(source_bundle) &&
         identical(as.character(source_bundle$script), "Script13D") &&
         identical(as.character(source_bundle$script_build_id),
                   "Script13D_COMPACT_FINAL_20260711"),
         "Accepted Script 13D bundle identity is incorrect.")

  assert(is.matrix(log_expr) && is.numeric(log_expr) &&
         identical(dim(log_expr), c(20823L, 107L)) &&
         identical(log_expr, source_bundle$gene_level_expression_log2_MAS5) &&
         !anyDuplicated(rownames(log_expr)) &&
         !anyDuplicated(colnames(log_expr)) &&
         all(is.finite(log_expr)) &&
         all(apply(log_expr, 1L, sd) > 0),
         "Accepted full log2 matrix failed identity or quality checks.")

  assert(is.matrix(signature_expr) && is.numeric(signature_expr) &&
         identical(dim(signature_expr), c(24L, 107L)) &&
         identical(signature_expr,
                   source_bundle$locked_signature_expression_log2_MAS5) &&
         identical(rownames(signature_expr), LOCKED24) &&
         identical(colnames(signature_expr), colnames(log_expr)) &&
         identical(signature_expr, log_expr[LOCKED24, , drop = FALSE]) &&
         all(apply(signature_expr, 1L, sd) > 0),
         "Accepted locked 24-gene matrix is inconsistent.")

  assert(nrow(row_annotation) == 20823L &&
         identical(as.character(row_annotation$human_symbol),
                   rownames(log_expr)) &&
         nrow(signature_audit) == 24L &&
         identical(as.character(signature_audit$locked_human_symbol),
                   LOCKED24),
         "Accepted annotation CSVs are incomplete or reordered.")

  gene_set <- list(Triclosan_activity = LOCKED24)
  set.seed(20260711L)
  gsva_parameter <- GSVA::gsvaParam(log_expr, gene_set)
  score_object <- GSVA::gsva(gsva_parameter)

  score_matrix <- if (is.matrix(score_object)) {
    score_object
  } else if (inherits(score_object, "SummarizedExperiment") &&
             requireNamespace("SummarizedExperiment", quietly = TRUE)) {
    as.matrix(SummarizedExperiment::assay(score_object))
  } else {
    as.matrix(score_object)
  }

  assert(is.matrix(score_matrix) && is.numeric(score_matrix) &&
         identical(dim(score_matrix), c(1L, 107L)) &&
         identical(rownames(score_matrix), "Triclosan_activity") &&
         identical(colnames(score_matrix), colnames(log_expr)),
         "GSVA did not return the expected 1 x 107 score matrix.")

  score <- as.numeric(score_matrix[1L, ])
  names(score) <- colnames(score_matrix)

  assert(length(score) == 107L &&
         all(is.finite(score)) &&
         sd(score) > 0 &&
         length(unique(score)) > 1L &&
         identical(names(score), colnames(log_expr)),
         "Triclosan_activity score is incomplete, non-finite or invariant.")

  score_table <- data.frame(
    sample_order = seq_along(score),
    sample_id = names(score),
    Triclosan_activity = score,
    score_method = "Classical_GSVA",
    expression_input_gene_number = nrow(log_expr),
    signature_gene_number = length(LOCKED24),
    EMT_test_performed = FALSE,
    survival_model_fitted = FALSE,
    cutoff_selected = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  overall_summary <- cbind(
    data.frame(
      score_name = "Triclosan_activity",
      score_method = "Classical_GSVA",
      expression_input_gene_number = nrow(log_expr),
      signature_gene_number = length(LOCKED24),
      sample_number = length(score),
      check.names = FALSE
    ),
    num_summary(score)
  )

  signature_distribution <- do.call(rbind, lapply(LOCKED24, function(gene) {
    x <- signature_expr[gene, ]
    data.frame(
      signature_order = match(gene, LOCKED24),
      human_symbol = gene,
      min = min(x),
      q1 = unname(quantile(x, 0.25)),
      median = median(x),
      mean = mean(x),
      q3 = unname(quantile(x, 0.75)),
      max = max(x),
      sd = sd(x),
      unique_n = length(unique(x)),
      nonfinite_n = sum(!is.finite(x)),
      zero_variance = sd(x) == 0,
      included_in_score = TRUE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
  rownames(signature_distribution) <- NULL

  parameter_lock <- data.frame(
    field = c(
      "GSVA_package_version","Expression_input_dimensions",
      "Expression_input_scale","Expression_input_scope",
      "Gene_set_name","Gene_set_size","Gene_identifier_matching",
      "Parameter_constructor","Score_execution","Method",
      "Additional_normalization","Alternative_score",
      "EMT_test","Survival_analysis","Cutoff_or_high_low_group"
    ),
    value = c(
      as.character(packageVersion("GSVA")),
      paste(dim(log_expr), collapse = " x "),
      "LOG2_MAS5_INTENSITY",
      "Full 20823-gene matrix",
      "Triclosan_activity",
      length(LOCKED24),
      "Exact human-symbol matching",
      "GSVA::gsvaParam(log_expr, gene_set)",
      "GSVA::gsva(gsva_parameter)",
      "Classical_GSVA",
      "FALSE","FALSE","FALSE","FALSE","FALSE"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    scoring_method = "Classical_GSVA",
    full_expression_matrix_supplied = TRUE,
    expression_input_gene_number = 20823L,
    signature_gene_number = 24L,
    expression_input_scale = "LOG2_MAS5_INTENSITY",
    additional_normalization_performed = FALSE,
    expression_values_imputed = FALSE,
    samples_filtered = FALSE,
    alternative_score_calculated = FALSE,
    EMT_test_performed = FALSE,
    survival_endpoint_parsed = FALSE,
    survival_model_fitted = FALSE,
    cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID",
      "Source_Script13D_bundle_MD5","Source_log2_matrix_MD5",
      "Source_signature_matrix_MD5","GSVA_package_version",
      "Expression_dimensions","Signature_gene_number",
      "Signature_order_preserved","Signature_nonfinite_values",
      "Signature_zero_variance_genes","Score_dimensions",
      "Score_sample_number","Finite_score_number","Unique_score_number",
      "Score_standard_deviation","Sample_order_preserved",
      "Additional_normalization_performed","Expression_imputation_performed",
      "Samples_filtered","Alternative_score_calculated","EMT_test_performed",
      "Survival_endpoint_parsed","Survival_model_fitted","Cutoff_selected",
      "High_low_group_created","DEG_performed","PCA_performed",
      "GSEA_performed","Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "GSE58812","13E",BUILD_ID,EXPECTED_MD5["bundle"],
      EXPECTED_MD5["matrix"],EXPECTED_MD5["signature_matrix"],
      as.character(packageVersion("GSVA")),
      paste(dim(log_expr), collapse = " x "),length(LOCKED24),
      identical(rownames(signature_expr), LOCKED24),
      sum(!is.finite(signature_expr)),
      sum(apply(signature_expr, 1L, sd) == 0),
      paste(dim(score_matrix), collapse = " x "),length(score),
      sum(is.finite(score)),length(unique(score)),sd(score),
      identical(names(score), colnames(log_expr)),
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,FALSE,FALSE,"COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = "Script13D",
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step4_GSE58812_external_validation",
    script = "Script13E",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE58812",
    source_platform = "GPL570",
    source_script13d_bundle_md5 = unname(EXPECTED_MD5["bundle"]),
    source_log2_matrix_md5 = unname(EXPECTED_MD5["matrix"]),
    source_signature_matrix_md5 = unname(EXPECTED_MD5["signature_matrix"]),
    phenotype_raw = source_bundle$phenotype_raw,
    locked_signature_genes = LOCKED24,
    score_matrix = score_matrix,
    Triclosan_activity = score,
    score_table = score_table,
    overall_score_summary = overall_summary,
    signature_expression_distribution = signature_distribution,
    parameter_lock = parameter_lock,
    integrity_summary = integrity,
    policy = policy
  )
  class(bundle) <- c("GSE58812_Triclosan_24gene_GSVA_bundle", "list")

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script13E_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects","audit","logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(stage, "objects",
      "GSE58812_Triclosan_24gene_GSVA_COMPLETE_bundle.rds"),
    score = file.path(stage, "objects",
      "GSE58812_Triclosan_24gene_GSVA_score.rds"),
    score_table = file.path(stage, "audit",
      "GSE58812_Triclosan_24gene_GSVA_score_all107.csv"),
    summary = file.path(stage, "audit",
      "GSE58812_Triclosan_24gene_GSVA_score_summary.csv"),
    gene_distribution = file.path(stage, "audit",
      "GSE58812_locked_24gene_log2_expression_distribution.csv"),
    parameters = file.path(stage, "audit",
      "GSE58812_Triclosan_24gene_GSVA_parameter_lock.csv"),
    packages = file.path(stage, "audit",
      "Script13E_package_audit.csv"),
    integrity = file.path(stage, "audit",
      "GSE58812_Triclosan_24gene_GSVA_integrity_summary.csv"),
    inputs = file.path(stage, "audit",
      "Script13E_input_manifest_with_MD5.csv"),
    parameter_details = file.path(stage, "logs",
      "Script13E_GSVA_parameter_details.txt"),
    session = file.path(stage, "logs",
      "Script13E_sessionInfo.txt"),
    report = file.path(stage, "logs",
      "Script13E_COMPLETE_report.txt")
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(score, files["score"], version = 3)
  write_csv(score_table, files["score_table"])
  write_csv(overall_summary, files["summary"])
  write_csv(signature_distribution, files["gene_distribution"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(data.frame(
    package = "GSVA",
    version = as.character(packageVersion("GSVA")),
    available = TRUE,
    required_function = "gsvaParam",
    required_function_available = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  ), files["packages"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  writeLines(capture.output(show(gsva_parameter)),
             files["parameter_details"], useBytes = TRUE)
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 4 - Script 13E",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "GEO accession: GSE58812",
    "Platform: GPL570",
    paste0("Full expression matrix supplied: ",
           paste(dim(log_expr), collapse = " x ")),
    paste0("Locked signature genes used: ", length(LOCKED24), " / 24"),
    paste0("GSVA package version: ", packageVersion("GSVA")),
    paste0("Finite scores: ", sum(is.finite(score)), " / 107"),
    paste0("Unique scores: ", length(unique(score))),
    paste0("Score range: ", format(min(score), digits = 16), " to ",
           format(max(score), digits = 16)),
    paste0("Score standard deviation: ", format(sd(score), digits = 16)),
    "Additional normalization or imputation performed: FALSE",
    "Samples filtered: FALSE",
    "Alternative score calculated: FALSE",
    "EMT or survival analysis performed: FALSE",
    "Cutoff/high-low group/DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13E STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  s2 <- readRDS(files["score"])
  c2 <- read.csv(files["score_table"],
                 stringsAsFactors = FALSE, check.names = FALSE)

  assert(identical(s2, score) &&
         identical(b2$Triclosan_activity, score) &&
         identical(b2$score_matrix, score_matrix) &&
         nrow(c2) == 107L &&
         identical(as.character(c2$sample_id), names(score)) &&
         isTRUE(all.equal(
           c2$Triclosan_activity, as.numeric(score),
           tolerance = 1e-14, check.attributes = FALSE
         )),
         "RDS/CSV save-read validation failed.")

  output_manifest <- file.path(
    stage, "audit", "Script13E_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(stage, full.names = TRUE, all.files = TRUE, no.. = TRUE)
    copied <- file.copy(entries, OUTPUT_ROOT, recursive = TRUE,
                        copy.mode = TRUE, copy.date = TRUE)
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(manifest_ok(OUTPUT_ROOT, file.path(
      OUTPUT_ROOT, "audit", "Script13E_output_manifest_with_MD5.csv")),
      "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(manifest_ok(OUTPUT_ROOT, file.path(
    OUTPUT_ROOT, "audit", "Script13E_output_manifest_with_MD5.csv")),
    "Post-commit manifest verification failed.")
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13E completed successfully.\n")
  cat("Continuous GSVA scores: 107 / 107\n")
  cat("EMT and survival analyses performed: FALSE\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

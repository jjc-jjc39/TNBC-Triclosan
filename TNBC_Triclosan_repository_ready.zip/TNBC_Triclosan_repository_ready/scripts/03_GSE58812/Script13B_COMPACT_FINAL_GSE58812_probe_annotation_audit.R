# ==============================================================================
# TNBC_Triclosan | GSE58812 | Script 13B COMPACT FINAL
# Official GPL570 probe-annotation audit only.
#
# Consistent with the accepted GSE31519 workflow:
# - use official Bioconductor annotation;
# - audit all mappings before any representative-probe decision;
# - do not alter expression values or collapse probes in this script.
#
# This script does NOT:
# - transform or normalize expression values;
# - remove AFFX controls or unmapped/multi-symbol probes;
# - aggregate probes to genes;
# - calculate Triclosan_activity;
# - parse survival, fit models, select cutoffs, run DEG/PCA/GSEA or make figures.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13B_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step4_GSE58812_external_validation")
INPUT_ROOT <- file.path(STEP_ROOT, "00_preflight")
OUTPUT_ROOT <- file.path(STEP_ROOT, "01_probe_annotation_audit")

INPUTS <- c(
  bundle = file.path(INPUT_ROOT, "objects",
    "GSE58812_preflight_COMPLETE_bundle.rds"),
  eset = file.path(INPUT_ROOT, "objects",
    "GSE58812_processed_ExpressionSet_SOURCE.rds"),
  manifest = file.path(INPUT_ROOT, "audit",
    "Script13A_output_manifest_with_MD5.csv"),
  report = file.path(INPUT_ROOT, "logs",
    "Script13A_COMPLETE_report.txt")
)

EXPECTED_MD5 <- c(
  bundle = "10607fc74855b76b155713793442884f",
  eset = "4fb87ddc54b46dc32dd653e338e78b56",
  manifest = "84b0259a51a4a09bb26a16fb83417511",
  report = "91435f609eab42bfc7278e3010e407cd"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)
clean <- function(x) {
  y <- trimws(as.character(x))
  y[is.na(x) | !nzchar(y) | toupper(y) %in% c("NA","N/A","NULL","NONE")] <- NA_character_
  y
}
collapse_unique <- function(x) {
  x <- sort(unique(clean(x)))
  x <- x[!is.na(x)]
  if (length(x)) paste(x, collapse = ";") else NA_character_
}
count_unique <- function(x) {
  x <- unique(clean(x))
  sum(!is.na(x))
}
manifest_ok <- function(root, file) {
  m <- tryCatch(read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
                error = function(e) NULL)
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path","size_bytes","md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}
make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))
  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}
existing_valid <- function(root) {
  key <- c(
    bundle = file.path(root, "objects",
      "GSE58812_probe_annotation_audit_COMPLETE_bundle.rds"),
    manifest = file.path(root, "audit",
      "Script13B_output_manifest_with_MD5.csv"),
    report = file.path(root, "logs",
      "Script13B_COMPLETE_report.txt")
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) return(FALSE)
  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT13B STATUS: COMPLETE", report, fixed = TRUE))) return(FALSE)
  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  is.list(b) &&
    identical(as.character(b$script), "Script13B") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    identical(as.character(b$source_script13a_bundle_md5),
              unname(EXPECTED_MD5["bundle"])) &&
    nrow(b$probe_annotation_audit) == 54675L &&
    isFALSE(b$policy$expression_values_modified) &&
    isFALSE(b$policy$gene_aggregation_performed)
}
prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))
  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }
  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13B output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }
  archive <- file.path(
    STEP_ROOT,
    paste0("01_probe_annotation_audit_INCOMPLETE_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Official probe annotation audit only; expression is unchanged.\n")
  cat("============================================================\n")

  packages <- c("Biobase", "AnnotationDbi", "hgu133plus2.db")
  missing_packages <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  assert(!length(missing_packages),
         "Missing Bioconductor package(s): %s\nInstall with BiocManager::install(c(%s)).",
         paste(missing_packages, collapse = ", "),
         paste(sprintf("'%s'", missing_packages), collapse = ", "))

  assert(dir.exists(STEP_ROOT), "Step 4 directory does not exist:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted Script 13A inputs:\n%s",
         paste(missing, collapse = "\n"))
  observed <- vapply(INPUTS, md5, character(1))
  assert(identical(observed, EXPECTED_MD5),
         "At least one accepted Script 13A input MD5 differs.\n%s",
         paste(sprintf("%s: expected %s; observed %s",
                       names(EXPECTED_MD5), EXPECTED_MD5, observed),
               collapse = "\n"))
  assert(any(grepl("SCRIPT13A STATUS: COMPLETE",
                   readLines(INPUTS["report"], warn = FALSE), fixed = TRUE)),
         "Script 13A completion marker is missing.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  preflight <- readRDS(INPUTS["bundle"])
  eset <- readRDS(INPUTS["eset"])
  assert(is.list(preflight) &&
         identical(as.character(preflight$script), "Script13A") &&
         identical(as.character(preflight$script_build_id),
                   "Script13A_COMPACT_FINAL_20260711") &&
         inherits(eset, "ExpressionSet"),
         "Accepted Script 13A objects are malformed.")

  expr <- Biobase::exprs(eset)
  pheno <- Biobase::pData(eset)
  probe_ids <- rownames(expr)
  assert(is.matrix(expr) && is.numeric(expr) &&
         identical(dim(expr), c(54675L, 107L)) &&
         all(is.finite(expr)) &&
         !anyDuplicated(probe_ids) && !anyDuplicated(colnames(expr)) &&
         identical(rownames(pheno), colnames(expr)) &&
         identical(expr, preflight$expression_matrix),
         "ExpressionSet does not match the accepted Script 13A matrix.")

  annotation_keys <- AnnotationDbi::keys(
    hgu133plus2.db::hgu133plus2.db,
    keytype = "PROBEID"
  )
  assert(length(annotation_keys) > 0L && !anyDuplicated(annotation_keys),
         "hgu133plus2.db PROBEID keys are empty or duplicated.")

  mapping <- AnnotationDbi::select(
    hgu133plus2.db::hgu133plus2.db,
    keys = probe_ids,
    keytype = "PROBEID",
    columns = c("SYMBOL", "ENTREZID", "GENENAME")
  )
  mapping <- as.data.frame(mapping, stringsAsFactors = FALSE)
  required_columns <- c("PROBEID","SYMBOL","ENTREZID","GENENAME")
  assert(all(required_columns %in% names(mapping)),
         "Official annotation output lacks required columns.")
  mapping <- unique(mapping[, required_columns, drop = FALSE])
  mapping$PROBEID <- as.character(mapping$PROBEID)
  mapping$SYMBOL <- clean(mapping$SYMBOL)
  mapping$ENTREZID <- clean(mapping$ENTREZID)
  mapping$GENENAME <- clean(mapping$GENENAME)

  absent <- setdiff(probe_ids, unique(mapping$PROBEID))
  if (length(absent)) {
    mapping <- rbind(
      mapping,
      data.frame(PROBEID = absent, SYMBOL = NA_character_,
                 ENTREZID = NA_character_, GENENAME = NA_character_,
                 stringsAsFactors = FALSE, check.names = FALSE)
    )
  }
  assert(all(mapping$PROBEID %in% probe_ids),
         "Annotation returned probe IDs outside the accepted expression matrix.")

  split_map <- split(mapping, factor(mapping$PROBEID, levels = probe_ids))
  probe_audit <- do.call(rbind, lapply(seq_along(split_map), function(i) {
    x <- split_map[[i]]
    symbol_n <- count_unique(x$SYMBOL)
    entrez_n <- count_unique(x$ENTREZID)
    name_n <- count_unique(x$GENENAME)
    data.frame(
      probe_order = i,
      probe_id = probe_ids[i],
      is_AFFX_control = grepl("^AFFX", probe_ids[i], ignore.case = TRUE),
      annotation_row_number = nrow(x),
      symbol_number = symbol_n,
      symbols = collapse_unique(x$SYMBOL),
      entrez_id_number = entrez_n,
      entrez_ids = collapse_unique(x$ENTREZID),
      gene_name_number = name_n,
      gene_names = collapse_unique(x$GENENAME),
      mapping_status = if (symbol_n == 0L) "UNMAPPED_SYMBOL" else
        if (symbol_n == 1L) "UNIQUE_SYMBOL" else "MULTI_SYMBOL",
      eligible_for_later_gene_aggregation =
        symbol_n == 1L && !grepl("^AFFX", probe_ids[i], ignore.case = TRUE),
      expression_values_modified = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
  rownames(probe_audit) <- NULL
  assert(nrow(probe_audit) == 54675L &&
         identical(probe_audit$probe_id, probe_ids),
         "Probe audit does not preserve all 54,675 probes in original order.")

  unmapped <- probe_audit[
    probe_audit$mapping_status == "UNMAPPED_SYMBOL", , drop = FALSE
  ]
  multi_symbol <- probe_audit[
    probe_audit$mapping_status == "MULTI_SYMBOL", , drop = FALSE
  ]
  eligible <- probe_audit[
    probe_audit$eligible_for_later_gene_aggregation,
    c("probe_order","probe_id","symbols","entrez_ids","gene_names"),
    drop = FALSE
  ]
  names(eligible)[names(eligible) == "symbols"] <- "human_symbol"

  gene_split <- split(eligible$probe_id, eligible$human_symbol)
  gene_multiplicity <- data.frame(
    human_symbol = names(gene_split),
    eligible_probe_number = lengths(gene_split),
    eligible_probe_ids = vapply(gene_split, paste, collapse = ";", character(1)),
    later_aggregation_rule = ifelse(
      lengths(gene_split) == 1L,
      "KEEP_SINGLE_PROBE",
      "SAMPLE_WISE_MEDIAN_ACROSS_ELIGIBLE_PROBES"
    ),
    aggregation_performed_in_Script13B = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  gene_multiplicity <- gene_multiplicity[
    order(gene_multiplicity$human_symbol), , drop = FALSE
  ]
  rownames(gene_multiplicity) <- NULL

  signature_coverage <- do.call(rbind, lapply(seq_along(LOCKED24), function(i) {
    gene <- LOCKED24[i]
    probes <- eligible$probe_id[eligible$human_symbol == gene]
    data.frame(
      signature_order = i,
      locked_human_symbol = gene,
      eligible_probe_number = length(probes),
      eligible_probe_ids = if (length(probes))
        paste(probes, collapse = ";") else NA_character_,
      platform_coverage = length(probes) > 0L,
      score_calculated = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))

  summary_table <- data.frame(
    item = c(
      "Total_expression_probes",
      "Official_annotation_mapping_rows",
      "AFFX_control_probes",
      "Unmapped_symbol_probes",
      "Unique_symbol_probes",
      "Multi_symbol_probes",
      "Eligible_non_AFFX_unique_symbol_probes",
      "Eligible_unique_human_symbols",
      "Genes_with_one_eligible_probe",
      "Genes_with_multiple_eligible_probes",
      "Locked_signature_genes",
      "Locked_signature_genes_with_platform_coverage"
    ),
    value = c(
      nrow(expr), nrow(mapping), sum(probe_audit$is_AFFX_control),
      nrow(unmapped),
      sum(probe_audit$mapping_status == "UNIQUE_SYMBOL"),
      nrow(multi_symbol), nrow(eligible), nrow(gene_multiplicity),
      sum(gene_multiplicity$eligible_probe_number == 1L),
      sum(gene_multiplicity$eligible_probe_number > 1L),
      length(LOCKED24), sum(signature_coverage$platform_coverage)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    official_annotation_package = "hgu133plus2.db",
    expression_values_modified = FALSE,
    additional_normalization_performed = FALSE,
    AFFX_controls_removed = FALSE,
    unmapped_probes_removed = FALSE,
    multi_symbol_probes_removed = FALSE,
    representative_probe_selected = FALSE,
    gene_aggregation_performed = FALSE,
    Triclosan_score_calculated = FALSE,
    survival_endpoint_parsed = FALSE,
    survival_model_fitted = FALSE,
    cutoff_selected = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID","Platform",
      "Source_Script13A_bundle_MD5","Source_ExpressionSet_MD5",
      "Expression_dimensions","Input_probe_number",
      "Probe_audit_rows","Probe_order_preserved",
      "Official_annotation_package","Official_annotation_package_version",
      "Expression_values_modified","Additional_normalization_performed",
      "AFFX_controls_removed","Unmapped_probes_removed",
      "Multi_symbol_probes_removed","Representative_probe_selected",
      "Gene_aggregation_performed","Triclosan_score_calculated",
      "Survival_endpoint_parsed","Survival_model_fitted","Cutoff_selected",
      "DEG_performed","PCA_performed","GSEA_performed",
      "Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "GSE58812","13B",BUILD_ID,"GPL570",
      EXPECTED_MD5["bundle"],EXPECTED_MD5["eset"],
      paste(dim(expr), collapse = " x "),length(probe_ids),
      nrow(probe_audit),identical(probe_audit$probe_id, probe_ids),
      "hgu133plus2.db",as.character(packageVersion("hgu133plus2.db")),
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,FALSE,FALSE,FALSE,FALSE,"COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = "Script13A",
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step4_GSE58812_external_validation",
    script = "Script13B",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE58812",
    source_platform = "GPL570",
    source_script13a_bundle_md5 = unname(EXPECTED_MD5["bundle"]),
    source_expression_set_md5 = unname(EXPECTED_MD5["eset"]),
    official_mapping = mapping,
    probe_annotation_audit = probe_audit,
    unmapped_probe_audit = unmapped,
    multi_symbol_probe_audit = multi_symbol,
    eligible_unique_symbol_probes = eligible,
    gene_to_probe_multiplicity = gene_multiplicity,
    locked_signature_coverage = signature_coverage,
    annotation_summary = summary_table,
    policy = policy,
    integrity_summary = integrity
  )
  class(bundle) <- c("GSE58812_probe_annotation_audit_bundle", "list")

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script13B_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects","audit","logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(stage, "objects",
      "GSE58812_probe_annotation_audit_COMPLETE_bundle.rds"),
    mapping = file.path(stage, "audit",
      "GSE58812_official_probe_annotation_full_mapping.csv"),
    probe_audit = file.path(stage, "audit",
      "GSE58812_probe_annotation_audit.csv"),
    unmapped = file.path(stage, "audit",
      "GSE58812_unmapped_probe_audit.csv"),
    multi_symbol = file.path(stage, "audit",
      "GSE58812_multi_symbol_probe_audit.csv"),
    eligible = file.path(stage, "audit",
      "GSE58812_eligible_unique_symbol_probes.csv"),
    multiplicity = file.path(stage, "audit",
      "GSE58812_gene_to_probe_multiplicity.csv"),
    signature = file.path(stage, "audit",
      "GSE58812_locked_24gene_platform_coverage.csv"),
    summary = file.path(stage, "audit",
      "GSE58812_probe_annotation_summary.csv"),
    packages = file.path(stage, "audit",
      "Script13B_package_audit.csv"),
    integrity = file.path(stage, "audit",
      "GSE58812_probe_annotation_integrity_summary.csv"),
    inputs = file.path(stage, "audit",
      "Script13B_input_manifest_with_MD5.csv"),
    session = file.path(stage, "logs", "Script13B_sessionInfo.txt"),
    report = file.path(stage, "logs", "Script13B_COMPLETE_report.txt")
  )

  saveRDS(bundle, files["bundle"], version = 3)
  write_csv(mapping, files["mapping"])
  write_csv(probe_audit, files["probe_audit"])
  write_csv(unmapped, files["unmapped"])
  write_csv(multi_symbol, files["multi_symbol"])
  write_csv(eligible, files["eligible"])
  write_csv(gene_multiplicity, files["multiplicity"])
  write_csv(signature_coverage, files["signature"])
  write_csv(summary_table, files["summary"])
  write_csv(data.frame(
    package = c("Biobase","AnnotationDbi","hgu133plus2.db"),
    version = vapply(c("Biobase","AnnotationDbi","hgu133plus2.db"),
                     function(x) as.character(packageVersion(x)), character(1)),
    available = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  ), files["packages"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 4 - Script 13B",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "GEO accession: GSE58812",
    "Platform: GPL570",
    paste0("Expression probes audited: ", nrow(probe_audit)),
    paste0("AFFX controls: ", sum(probe_audit$is_AFFX_control)),
    paste0("Unmapped-symbol probes: ", nrow(unmapped)),
    paste0("Unique-symbol probes: ",
           sum(probe_audit$mapping_status == "UNIQUE_SYMBOL")),
    paste0("Multi-symbol probes: ", nrow(multi_symbol)),
    paste0("Eligible non-AFFX unique-symbol probes: ", nrow(eligible)),
    paste0("Eligible unique human symbols: ", nrow(gene_multiplicity)),
    paste0("Locked signature coverage: ",
           sum(signature_coverage$platform_coverage), " / 24"),
    "Expression values modified: FALSE",
    "Probes removed: FALSE",
    "Representative probe selected: FALSE",
    "Gene aggregation performed: FALSE",
    "Triclosan score or survival analysis performed: FALSE",
    "Cutoff/DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13B STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")
  b2 <- readRDS(files["bundle"])
  p2 <- read.csv(files["probe_audit"], stringsAsFactors = FALSE,
                 check.names = FALSE)
  s2 <- read.csv(files["signature"], stringsAsFactors = FALSE,
                 check.names = FALSE)
  assert(identical(b2$probe_annotation_audit, probe_audit) &&
         nrow(p2) == 54675L &&
         identical(as.character(p2$probe_id), probe_ids) &&
         nrow(s2) == 24L &&
         identical(as.character(s2$locked_human_symbol), LOCKED24),
         "RDS/CSV save-read validation failed.")

  output_manifest <- file.path(
    stage, "audit", "Script13B_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(stage, full.names = TRUE, all.files = TRUE, no.. = TRUE)
    copied <- file.copy(entries, OUTPUT_ROOT, recursive = TRUE,
                        copy.mode = TRUE, copy.date = TRUE)
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(manifest_ok(OUTPUT_ROOT, file.path(
      OUTPUT_ROOT, "audit", "Script13B_output_manifest_with_MD5.csv")),
      "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }
  committed <- TRUE
  assert(manifest_ok(OUTPUT_ROOT, file.path(
    OUTPUT_ROOT, "audit", "Script13B_output_manifest_with_MD5.csv")),
    "Post-commit manifest verification failed.")
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13B completed successfully.\n")
  cat("Probes audited: ", nrow(probe_audit), "\n", sep = "")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

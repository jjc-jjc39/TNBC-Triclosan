# ==============================================================================
# TNBC_Triclosan | GSE58812 | Script 13D COMPACT FINAL
# Convert the accepted gene-level MAS5 intensities to log2 scale.
#
# Locked transformation:
#   log2_expression = log2(raw_MAS5_expression)
#
# Every accepted raw value is strictly positive, so no pseudocount is added.
# No renormalization, imputation, sample filtering, scoring, survival analysis,
# cutoff, DEG, PCA, GSEA or figure generation is performed.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13D_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
STEP_ROOT <- file.path(PROJECT_ROOT, "Step4_GSE58812_external_validation")
INPUT_ROOT <- file.path(STEP_ROOT, "02_gene_level_expression_raw_MAS5")
OUTPUT_ROOT <- file.path(STEP_ROOT, "03_gene_level_expression_log2_MAS5")

INPUTS <- c(
  bundle = file.path(INPUT_ROOT, "objects",
    "GSE58812_gene_level_raw_MAS5_COMPLETE_bundle.rds"),
  matrix = file.path(INPUT_ROOT, "objects",
    "GSE58812_gene_level_raw_MAS5_matrix.rds"),
  signature_matrix = file.path(INPUT_ROOT, "objects",
    "GSE58812_locked_24gene_raw_MAS5_matrix.rds"),
  row_annotation = file.path(INPUT_ROOT, "audit",
    "GSE58812_gene_level_row_annotation.csv"),
  signature_audit = file.path(INPUT_ROOT, "audit",
    "GSE58812_locked_24gene_gene_level_availability.csv"),
  manifest = file.path(INPUT_ROOT, "audit",
    "Script13C_output_manifest_with_MD5.csv"),
  report = file.path(INPUT_ROOT, "logs",
    "Script13C_COMPLETE_report.txt")
)

EXPECTED_MD5 <- c(
  bundle = "82cec11df3c7e51510603d81d6cae4b2",
  matrix = "1e65ac475b34e95020565fa6ea0e3951",
  signature_matrix = "d558e7936c821d13a8ed1e477ed757c4",
  row_annotation = "62655a0e0061ea168375ef323df9e73e",
  signature_audit = "4d8e54bfb0a10cd35f26919edd41718d",
  manifest = "ff7ac0b6f08a99bb5a21bc04b76142db",
  report = "691b680b099650f6aac1a8079888e39a"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

num_summary <- function(x) {
  x <- as.numeric(x)
  data.frame(
    n = length(x),
    finite_n = sum(is.finite(x)),
    nonfinite_n = sum(!is.finite(x)),
    min = min(x),
    q1 = unname(quantile(x, 0.25)),
    median = median(x),
    mean = mean(x),
    q3 = unname(quantile(x, 0.75)),
    max = max(x),
    sd = sd(x),
    unique_n = length(unique(x)),
    check.names = FALSE
  )
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path","size_bytes","md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    check.names = FALSE
  )
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(root, "objects",
      "GSE58812_gene_level_log2_MAS5_COMPLETE_bundle.rds"),
    matrix = file.path(root, "objects",
      "GSE58812_gene_level_log2_MAS5_matrix.rds"),
    manifest = file.path(root, "audit",
      "Script13D_output_manifest_with_MD5.csv"),
    report = file.path(root, "logs",
      "Script13D_COMPLETE_report.txt")
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) return(FALSE)

  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT13D STATUS: COMPLETE", report, fixed = TRUE))) return(FALSE)

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  x <- tryCatch(readRDS(key["matrix"]), error = function(e) NULL)

  is.list(b) &&
    identical(as.character(b$script), "Script13D") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    identical(as.character(b$source_script13c_bundle_md5),
              unname(EXPECTED_MD5["bundle"])) &&
    is.matrix(x) && identical(dim(x), c(20823L, 107L)) &&
    identical(x, b$gene_level_expression_log2_MAS5) &&
    isTRUE(b$policy$log2_transformation_performed) &&
    isFALSE(b$policy$additional_normalization_performed) &&
    isFALSE(b$policy$Triclosan_score_calculated)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13D output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    STEP_ROOT,
    paste0("03_gene_level_expression_log2_MAS5_INCOMPLETE_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Transformation: log2(raw MAS5); pseudocount: 0.\n")
  cat("============================================================\n")

  assert(dir.exists(STEP_ROOT), "Step 4 directory does not exist:\n%s", STEP_ROOT)
  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted Script 13C input(s):\n%s",
         paste(missing, collapse = "\n"))

  observed <- vapply(INPUTS, md5, character(1))
  assert(identical(observed, EXPECTED_MD5),
         "At least one accepted Script 13C input MD5 differs.\n%s",
         paste(sprintf("%s: expected %s; observed %s",
                       names(EXPECTED_MD5), EXPECTED_MD5, observed),
               collapse = "\n"))
  assert(any(grepl("SCRIPT13C STATUS: COMPLETE",
                   readLines(INPUTS["report"], warn = FALSE), fixed = TRUE)),
         "Script 13C completion marker is missing.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  source_bundle <- readRDS(INPUTS["bundle"])
  raw_expr <- readRDS(INPUTS["matrix"])
  raw_signature <- readRDS(INPUTS["signature_matrix"])
  row_annotation <- read.csv(
    INPUTS["row_annotation"], stringsAsFactors = FALSE, check.names = FALSE
  )
  signature_audit <- read.csv(
    INPUTS["signature_audit"], stringsAsFactors = FALSE, check.names = FALSE
  )

  assert(is.list(source_bundle) &&
         identical(as.character(source_bundle$script), "Script13C") &&
         identical(as.character(source_bundle$script_build_id),
                   "Script13C_v2_COMPACT_FINAL_20260711"),
         "Accepted Script 13C bundle identity is incorrect.")

  assert(is.matrix(raw_expr) && is.numeric(raw_expr) &&
         identical(dim(raw_expr), c(20823L, 107L)) &&
         identical(raw_expr, source_bundle$gene_level_expression_raw_MAS5) &&
         !anyDuplicated(rownames(raw_expr)) &&
         !anyDuplicated(colnames(raw_expr)) &&
         all(is.finite(raw_expr)) &&
         min(raw_expr) > 0 &&
         all(apply(raw_expr, 1L, sd) > 0),
         "Accepted raw gene-level matrix failed identity or quality checks.")

  assert(is.matrix(raw_signature) && is.numeric(raw_signature) &&
         identical(dim(raw_signature), c(24L, 107L)) &&
         identical(raw_signature,
                   source_bundle$locked_signature_expression_raw_MAS5) &&
         identical(rownames(raw_signature), LOCKED24) &&
         identical(colnames(raw_signature), colnames(raw_expr)) &&
         identical(raw_signature, raw_expr[LOCKED24, , drop = FALSE]),
         "Accepted raw locked-signature matrix is inconsistent.")

  assert(nrow(row_annotation) == 20823L &&
         identical(as.character(row_annotation$human_symbol), rownames(raw_expr)) &&
         nrow(signature_audit) == 24L &&
         identical(as.character(signature_audit$locked_human_symbol), LOCKED24),
         "Accepted annotation CSVs are incomplete or reordered.")

  log_expr <- log2(raw_expr)
  log_signature <- log_expr[LOCKED24, , drop = FALSE]

  assert(is.matrix(log_expr) && identical(dim(log_expr), dim(raw_expr)) &&
         identical(rownames(log_expr), rownames(raw_expr)) &&
         identical(colnames(log_expr), colnames(raw_expr)) &&
         all(is.finite(log_expr)) &&
         all(apply(log_expr, 1L, sd) > 0),
         "Log2 matrix failed dimension, order, finite-value or variance checks.")
  assert(identical(log_signature, log2(raw_signature)) &&
         identical(dim(log_signature), c(24L, 107L)) &&
         all(apply(log_signature, 1L, sd) > 0),
         "Locked 24-gene log2 matrix is inconsistent.")
  assert(isTRUE(all.equal(
    2^log_expr, raw_expr, tolerance = 1e-12, check.attributes = TRUE
  )), "Inverse-transformation audit failed.")

  log_row_annotation <- row_annotation
  log_row_annotation$source_scale <- "SUBMITTED_UNLOGGED_MAS5_INTENSITY"
  log_row_annotation$output_scale <- "LOG2_MAS5_INTENSITY"
  log_row_annotation$transformation_formula <- "log2(x)"
  log_row_annotation$pseudocount <- 0
  log_row_annotation$log2_transformation_performed <- TRUE

  log_signature_audit <- signature_audit
  log_signature_audit$source_scale <- "SUBMITTED_UNLOGGED_MAS5_INTENSITY"
  log_signature_audit$output_scale <- "LOG2_MAS5_INTENSITY"
  log_signature_audit$transformation_formula <- "log2(x)"
  log_signature_audit$pseudocount <- 0
  log_signature_audit$log2_transformation_performed <- TRUE

  global_summary <- cbind(
    data.frame(
      GEO_accession = "GSE58812",
      platform = "GPL570",
      gene_number = nrow(log_expr),
      sample_number = ncol(log_expr),
      source_scale = "SUBMITTED_UNLOGGED_MAS5_INTENSITY",
      output_scale = "LOG2_MAS5_INTENSITY",
      transformation_formula = "log2(x)",
      pseudocount = 0,
      source_minimum = min(raw_expr),
      source_maximum = max(raw_expr),
      zero_variance_gene_number = sum(apply(log_expr, 1L, sd) == 0),
      check.names = FALSE
    ),
    num_summary(as.numeric(log_expr))
  )

  sample_summary <- do.call(rbind, lapply(seq_len(ncol(log_expr)), function(i) {
    cbind(
      data.frame(
        sample_order = i,
        sample_id = colnames(log_expr)[i],
        check.names = FALSE
      ),
      num_summary(log_expr[, i])
    )
  }))
  rownames(sample_summary) <- NULL

  signature_values <- data.frame(
    locked_human_symbol = LOCKED24,
    log_signature,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  transformation_audit <- data.frame(
    item = c(
      "Source_scale","Output_scale","Formula","Pseudocount",
      "Source_values_strictly_positive","Source_minimum","Source_maximum",
      "Inverse_transformation_tolerance","Inverse_transformation_passed",
      "Additional_normalization_performed","Expression_imputation_performed",
      "Samples_filtered"
    ),
    value = as.character(c(
      "SUBMITTED_UNLOGGED_MAS5_INTENSITY","LOG2_MAS5_INTENSITY",
      "log2(x)",0,min(raw_expr)>0,min(raw_expr),max(raw_expr),
      1e-12,TRUE,FALSE,FALSE,FALSE
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    transformation_formula = "log2(x)",
    pseudocount = 0,
    log2_transformation_performed = TRUE,
    additional_normalization_performed = FALSE,
    expression_values_imputed = FALSE,
    samples_filtered = FALSE,
    outliers_removed = FALSE,
    Triclosan_score_calculated = FALSE,
    survival_endpoint_parsed = FALSE,
    survival_model_fitted = FALSE,
    cutoff_selected = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "GEO_accession","Script","Script_build_ID",
      "Source_Script13C_bundle_MD5","Source_raw_matrix_MD5",
      "Source_signature_matrix_MD5","Raw_dimensions","Log2_dimensions",
      "Gene_order_preserved","Sample_order_preserved",
      "Raw_values_strictly_positive","Finite_log2_values",
      "Zero_variance_log2_genes","Locked_signature_dimensions",
      "Locked_signature_zero_variance_number",
      "Inverse_transformation_passed","Transformation_formula","Pseudocount",
      "Additional_normalization_performed","Expression_imputation_performed",
      "Samples_filtered","Outliers_removed","Triclosan_score_calculated",
      "Survival_endpoint_parsed","Survival_model_fitted","Cutoff_selected",
      "DEG_performed","PCA_performed","GSEA_performed",
      "Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "GSE58812","13D",BUILD_ID,EXPECTED_MD5["bundle"],
      EXPECTED_MD5["matrix"],EXPECTED_MD5["signature_matrix"],
      paste(dim(raw_expr), collapse = " x "),
      paste(dim(log_expr), collapse = " x "),
      identical(rownames(log_expr), rownames(raw_expr)),
      identical(colnames(log_expr), colnames(raw_expr)),
      min(raw_expr)>0,sum(is.finite(log_expr)),
      sum(apply(log_expr, 1L, sd)==0),
      paste(dim(log_signature), collapse = " x "),
      sum(apply(log_signature, 1L, sd)==0),TRUE,"log2(x)",0,
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,FALSE,"COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source_stage = "Script13C",
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step4_GSE58812_external_validation",
    script = "Script13D",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    source_accession = "GSE58812",
    source_platform = "GPL570",
    source_script13c_bundle_md5 = unname(EXPECTED_MD5["bundle"]),
    source_raw_matrix_md5 = unname(EXPECTED_MD5["matrix"]),
    phenotype_raw = source_bundle$phenotype_raw,
    gene_level_expression_log2_MAS5 = log_expr,
    gene_row_annotation = log_row_annotation,
    locked_signature_audit = log_signature_audit,
    locked_signature_expression_log2_MAS5 = log_signature,
    matrix_summary = global_summary,
    sample_expression_summary = sample_summary,
    transformation_audit = transformation_audit,
    policy = policy,
    integrity_summary = integrity
  )
  class(bundle) <- c("GSE58812_gene_level_log2_MAS5_bundle", "list")

  stage <- file.path(
    STEP_ROOT,
    paste0(".Script13D_staging_", format(Sys.time(), "%Y%m%d_%H%M%S"),
           "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects","audit","logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(stage, "objects",
      "GSE58812_gene_level_log2_MAS5_COMPLETE_bundle.rds"),
    matrix = file.path(stage, "objects",
      "GSE58812_gene_level_log2_MAS5_matrix.rds"),
    signature_matrix = file.path(stage, "objects",
      "GSE58812_locked_24gene_log2_MAS5_matrix.rds"),
    rows = file.path(stage, "audit",
      "GSE58812_gene_level_log2_MAS5_row_annotation.csv"),
    signature_audit = file.path(stage, "audit",
      "GSE58812_locked_24gene_log2_MAS5_availability.csv"),
    signature_values = file.path(stage, "audit",
      "GSE58812_locked_24gene_log2_MAS5_expression.csv"),
    matrix_summary = file.path(stage, "audit",
      "GSE58812_gene_level_log2_MAS5_summary.csv"),
    sample_summary = file.path(stage, "audit",
      "GSE58812_gene_level_log2_MAS5_sample_distribution.csv"),
    transformation = file.path(stage, "audit",
      "GSE58812_log2_transformation_audit.csv"),
    integrity = file.path(stage, "audit",
      "GSE58812_gene_level_log2_MAS5_integrity_summary.csv"),
    inputs = file.path(stage, "audit",
      "Script13D_input_manifest_with_MD5.csv"),
    session = file.path(stage, "logs", "Script13D_sessionInfo.txt"),
    report = file.path(stage, "logs", "Script13D_COMPLETE_report.txt")
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(log_expr, files["matrix"], version = 3)
  saveRDS(log_signature, files["signature_matrix"], version = 3)
  write_csv(log_row_annotation, files["rows"])
  write_csv(log_signature_audit, files["signature_audit"])
  write_csv(signature_values, files["signature_values"])
  write_csv(global_summary, files["matrix_summary"])
  write_csv(sample_summary, files["sample_summary"])
  write_csv(transformation_audit, files["transformation"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan Step 4 - Script 13D",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "GEO accession: GSE58812",
    "Platform: GPL570",
    paste0("Input matrix: ", paste(dim(raw_expr), collapse = " x ")),
    paste0("Output matrix: ", paste(dim(log_expr), collapse = " x ")),
    paste0("Raw value range: ", min(raw_expr), " to ", max(raw_expr)),
    paste0("Log2 value range: ", min(log_expr), " to ", max(log_expr)),
    "Transformation formula: log2(x)",
    "Pseudocount: 0",
    "Inverse-transformation audit: PASS",
    "Additional normalization or imputation performed: FALSE",
    "Samples filtered or outliers removed: FALSE",
    "Triclosan score or survival analysis performed: FALSE",
    "Cutoff/DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13D STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")
  b2 <- readRDS(files["bundle"])
  x2 <- readRDS(files["matrix"])
  s2 <- readRDS(files["signature_matrix"])
  assert(identical(x2, log_expr) &&
         identical(s2, log_signature) &&
         identical(b2$gene_level_expression_log2_MAS5, log_expr) &&
         identical(b2$locked_signature_expression_log2_MAS5, log_signature),
         "RDS save/read-back validation failed.")

  sig_csv <- read.csv(
    files["signature_values"], stringsAsFactors = FALSE, check.names = FALSE
  )
  assert(nrow(sig_csv) == 24L &&
         identical(as.character(sig_csv$locked_human_symbol), LOCKED24) &&
         isTRUE(all.equal(
           as.matrix(sig_csv[, -1L, drop = FALSE]),
           unname(log_signature),
           tolerance = 1e-12,
           check.attributes = FALSE
         )),
         "Signature CSV save/read-back validation failed.")

  output_manifest <- file.path(
    stage, "audit", "Script13D_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(stage, full.names = TRUE, all.files = TRUE, no.. = TRUE)
    copied <- file.copy(entries, OUTPUT_ROOT, recursive = TRUE,
                        copy.mode = TRUE, copy.date = TRUE)
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(manifest_ok(OUTPUT_ROOT, file.path(
      OUTPUT_ROOT, "audit", "Script13D_output_manifest_with_MD5.csv")),
      "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(manifest_ok(OUTPUT_ROOT, file.path(
    OUTPUT_ROOT, "audit", "Script13D_output_manifest_with_MD5.csv")),
    "Post-commit manifest verification failed.")
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13D completed successfully.\n")
  cat("Log2 matrix: 20823 x 107\n")
  cat("Transformation: log2(x); pseudocount: 0\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

# ==============================================================================
# TNBC_Triclosan | Script 15C v2 COMPACT FINAL
# Exchangeable matched-random 24-gene negative-control analysis.
#
# WHY v2:
# 1) The accepted TCGA fixed score was generated in the full BRCA cohort and
#    then subset to 197 TNBC samples. Recalculating GSVA only within the 197
#    TNBC samples changes the score scale and cannot be required to reproduce
#    the original numeric vector exactly.
# 2) The accepted "overlap-removed" sensitivity analysis removed locked
#    signature genes from the Hallmark EMT outcome gene set; it did NOT create
#    a 22-gene Triclosan score.
#
# CORRECT RANDOMIZATION TEST:
# - recompute the observed locked 24-gene signature and all 5,000 matched
#   random 24-gene signatures together, in the same cohort expression matrix;
# - correlate every recomputed signature with:
#     A. accepted full Hallmark EMT score;
#     B. accepted Hallmark EMT score after removing locked-signature overlap;
# - use identical cohort estimators and identical Fisher-z DL meta-analysis;
# - calculate +1-corrected positive and absolute empirical p values.
#
# The generated 22-gene random sets remain archived but are not used because
# they do not correspond to the accepted overlap-removed EMT sensitivity.
#
# No random set is removed according to its result.
# No survival, cutoff, grouping, sample filtering, DEG, PCA, GSEA or figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script15C_v2_COMPACT_FINAL_20260712"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"

SCRIPT14A_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "00_preflight_and_input_lock"
)
SCRIPT15B_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "03_matched_random_24gene_null",
  "01_random_signature_generation"
)
CORE_META_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "01_final_EMT_correlation_meta_analysis"
)
TCGA_VALIDATION_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "00_TCGA_TNBC_EMT_revalidation"
)
G315_VALIDATION_ROOT <- file.path(
  PROJECT_ROOT,
  "Step2_GSE31519_external_validation",
  "13_EMT_external_validation"
)
G588_VALIDATION_ROOT <- file.path(
  PROJECT_ROOT,
  "Step4_GSE58812_external_validation",
  "05_EMT_external_validation_and_continuous_survival"
)

OUTPUT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "03_matched_random_24gene_null",
  "02_random_GSVA_and_empirical_test"
)
CACHE_ROOT <- file.path(
  dirname(OUTPUT_ROOT),
  ".Script15C_v2_validated_cache"
)

INPUTS <- c(
  Script15B_bundle = file.path(
    SCRIPT15B_ROOT, "objects",
    "Matched_random24_generation_COMPLETE_bundle.rds"
  ),
  primary_sets = file.path(
    SCRIPT15B_ROOT, "objects",
    "Matched_random24_primary_5000_gene_sets.rds"
  ),
  mapping_csv = file.path(
    SCRIPT15B_ROOT, "audit",
    "Matched_random24_5000_target_gene_mappings.csv"
  ),
  set_summary = file.path(
    SCRIPT15B_ROOT, "audit",
    "Matched_random24_5000_set_summary.csv"
  ),
  Script15B_manifest = file.path(
    SCRIPT15B_ROOT, "audit",
    "Script15B_output_manifest_with_MD5.csv"
  ),
  Script15B_report = file.path(
    SCRIPT15B_ROOT, "logs",
    "Script15B_COMPLETE_report.txt"
  ),

  TCGA_prepared = file.path(
    SCRIPT14A_ROOT, "objects",
    "TCGA_TNBC_Hallmark_panorama_prepared_input.rds"
  ),
  GSE31519_prepared = file.path(
    SCRIPT14A_ROOT, "objects",
    "GSE31519_Hallmark_panorama_prepared_input.rds"
  ),
  GSE58812_prepared = file.path(
    SCRIPT14A_ROOT, "objects",
    "GSE58812_Hallmark_panorama_prepared_input.rds"
  ),
  Script14A_manifest = file.path(
    SCRIPT14A_ROOT, "audit",
    "Script14A_output_manifest_with_MD5.csv"
  ),
  Script14A_report = file.path(
    SCRIPT14A_ROOT, "logs",
    "Script14A_COMPLETE_report.txt"
  ),

  TCGA_validation_bundle = file.path(
    TCGA_VALIDATION_ROOT, "objects",
    "TCGA_TNBC_EMT_revalidation_COMPLETE_bundle.rds"
  ),
  TCGA_validation_manifest = file.path(
    TCGA_VALIDATION_ROOT, "audit",
    "Script13G_B_output_manifest_with_MD5.csv"
  ),
  TCGA_validation_report = file.path(
    TCGA_VALIDATION_ROOT, "logs",
    "Script13G_B_COMPLETE_report.txt"
  ),

  G315_validation_bundle = file.path(
    G315_VALIDATION_ROOT, "objects",
    "GSE31519_EMT_external_validation_COMPLETE_bundle.rds"
  ),
  G315_validation_manifest = file.path(
    G315_VALIDATION_ROOT, "audit",
    "Script13G_A_output_manifest_with_MD5.csv"
  ),
  G315_validation_report = file.path(
    G315_VALIDATION_ROOT, "logs",
    "Script13G_A_COMPLETE_report.txt"
  ),

  G588_validation_bundle = file.path(
    G588_VALIDATION_ROOT, "objects",
    "GSE58812_EMT_and_continuous_survival_COMPLETE_bundle.rds"
  ),
  G588_validation_manifest = file.path(
    G588_VALIDATION_ROOT, "audit",
    "Script13F_output_manifest_with_MD5.csv"
  ),
  G588_validation_report = file.path(
    G588_VALIDATION_ROOT, "logs",
    "Script13F_COMPLETE_report.txt"
  ),

  core_meta_bundle = file.path(
    CORE_META_ROOT, "objects",
    "Cross_cohort_EMT_meta_analysis_COMPLETE_bundle.rds"
  ),
  core_meta_manifest = file.path(
    CORE_META_ROOT, "audit",
    "Script13G_C_output_manifest_with_MD5.csv"
  ),
  core_meta_report = file.path(
    CORE_META_ROOT, "logs",
    "Script13G_C_COMPLETE_report.txt"
  )
)

EXPECTED_MD5 <- c(
  Script15B_bundle = "e1ab6bdaefed22f055f9c9af31a07d26",
  primary_sets = "51e0aea23e3418c21e490cf0cd9cffca",
  mapping_csv = "93a7eafe685c0f57927a7c439fee9520",
  set_summary = "85c5a7c5eb8a34475087d8ba5da150ed",
  Script15B_manifest = "a463d07c91e5add91b4cfbe66ac66019",
  Script15B_report = "e6313148d02eed2596a9f37094e9cf6c",

  TCGA_prepared = "55537d7f98fb915a811f1456072e6091",
  GSE31519_prepared = "2b6bba1d414c42625ab3cc00357a6a20",
  GSE58812_prepared = "cb667dcba01e5740eb6ecd607035b2bc",
  Script14A_manifest = "74f777ca434b0a6b4b420e0ead93f363",
  Script14A_report = "ebf11ae0ac8fc681200a7859e6a12b0c",

  TCGA_validation_bundle = "5c5d22abedd020fa9086b6fde82ee3d4",
  TCGA_validation_manifest = "d45031673a08dcffe8806839ab8e9b5c",
  TCGA_validation_report = "e8ea21abe7a908b6441f8d80689f4cf1",

  G315_validation_bundle = "c38714208098bd8871b4d7b16b36f0bf",
  G315_validation_manifest = "219cac414bb58e2d19d7947c65963ed7",
  G315_validation_report = "d763ae64264b716698eaedf1e241d4f1",

  G588_validation_bundle = "cd256862701cf62ac041b7d56f6fc45d",
  G588_validation_manifest = "f6021fe8d5114bac5d6a85c505a7ec91",
  G588_validation_report = "5238da233c70189c38cf6dc94b263ead",

  core_meta_bundle = "7625b1e291e1291762426382eb80a1f4",
  core_meta_manifest = "33d11d8780ce3964b4c5170510c21982",
  core_meta_report = "799b798e670d2b5b639d9294b7a259a2"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)

COHORT_ORDER <- c("TCGA_TNBC", "GSE31519", "GSE58812")
EXPECTED_N <- c(
  TCGA_TNBC = 197L,
  GSE31519 = 579L,
  GSE58812 = 107L
)
EXPECTED_DIMENSIONS <- list(
  TCGA_TNBC = c(56477L, 197L),
  GSE31519 = c(12650L, 579L),
  GSE58812 = c(20823L, 107L)
)

RANDOM_SET_NUMBER <- 5000L
RANDOM_SET_IDS <- sprintf(
  "RANDOM_SET_%04d",
  seq_len(RANDOM_SET_NUMBER)
)
OBSERVED_SET_NAME <- "OBSERVED_LOCKED24_RECOMPUTED"
RANDOM_PREFIX <- "MATCHED_RANDOM24_"
EFFECT_TOLERANCE <- 1e-12
QUANTILE_PROBABILITIES <- c(
  0, 0.01, 0.025, 0.05, 0.10, 0.25,
  0.50, 0.75, 0.90, 0.95, 0.975, 0.99, 1
)

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

scalar_text <- function(x, label = "value") {
  y <- as.character(x)
  assert(length(y) == 1L && !is.na(y) && nzchar(trimws(y)),
         "%s must be one nonblank scalar value.", label)
  unname(trimws(y))
}

same_text <- function(x, y) {
  identical(
    scalar_text(x, "observed text"),
    scalar_text(y, "expected text")
  )
}

same_numeric <- function(x, y, tolerance = EFFECT_TOLERANCE) {
  isTRUE(all.equal(
    as.numeric(x),
    as.numeric(y),
    tolerance = tolerance,
    check.attributes = FALSE
  ))
}

report_contains <- function(file, marker) {
  any(grepl(
    marker,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)

    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)

    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

set_key <- function(x) paste(sort(as.character(x)), collapse = ";")

validate_prepared <- function(object, cohort, expected_dim) {
  assert(is.list(object), "%s prepared input is not a list.", cohort)
  assert(same_text(object$cohort, cohort),
         "%s prepared cohort identity is incorrect.", cohort)

  x <- object$expression
  assert(
    is.matrix(x) && is.numeric(x) &&
      identical(dim(x), expected_dim) &&
      !is.null(rownames(x)) && !is.null(colnames(x)) &&
      !anyDuplicated(rownames(x)) &&
      !anyDuplicated(colnames(x)) &&
      all(is.finite(x)),
    "%s prepared expression matrix is malformed.", cohort
  )
  assert(
    is.numeric(object$Triclosan_activity) &&
      length(object$Triclosan_activity) == ncol(x) &&
      identical(names(object$Triclosan_activity), colnames(x)) &&
      all(is.finite(object$Triclosan_activity)) &&
      sd(object$Triclosan_activity) > 0,
    "%s accepted fixed score is malformed or misaligned.", cohort
  )
  invisible(TRUE)
}

extract_validation_vectors <- function(prepared, bundle, cohort) {
  table <- switch(
    cohort,
    TCGA_TNBC = bundle$sample_level_scores,
    GSE31519 = bundle$sample_level_scores,
    GSE58812 = bundle$sample_level_scores_and_clinical,
    stopf("Unsupported cohort: %s", cohort)
  )

  required <- c(
    "sample_id", "Triclosan_activity",
    "HALLMARK_EMT_FULL",
    "HALLMARK_EMT_NO_TRICLOSAN_OVERLAP"
  )
  assert(
    is.data.frame(table) &&
      all(required %in% names(table)) &&
      nrow(table) == ncol(prepared$expression) &&
      !anyDuplicated(as.character(table$sample_id)),
    "%s accepted validation sample table is malformed.", cohort
  )

  index <- match(colnames(prepared$expression), as.character(table$sample_id))
  assert(
    !anyNA(index),
    "%s accepted validation table cannot be aligned to prepared samples.",
    cohort
  )
  table <- table[index, , drop = FALSE]

  fixed_score <- as.numeric(table$Triclosan_activity)
  names(fixed_score) <- as.character(table$sample_id)
  full_EMT <- as.numeric(table$HALLMARK_EMT_FULL)
  names(full_EMT) <- names(fixed_score)
  no_overlap_EMT <- as.numeric(
    table$HALLMARK_EMT_NO_TRICLOSAN_OVERLAP
  )
  names(no_overlap_EMT) <- names(fixed_score)

  assert(
    identical(names(fixed_score), colnames(prepared$expression)) &&
      same_numeric(
        fixed_score,
        prepared$Triclosan_activity,
        tolerance = 1e-14
      ) &&
      all(is.finite(full_EMT)) && sd(full_EMT) > 0 &&
      all(is.finite(no_overlap_EMT)) && sd(no_overlap_EMT) > 0,
    "%s accepted score or EMT vectors failed alignment checks.", cohort
  )

  source <- as.character(prepared$source_dataset_id)
  assert(
    length(source) == length(fixed_score) &&
      all(!is.na(source) & nzchar(source)),
    "%s source_dataset_id is malformed.", cohort
  )

  list(
    fixed_score = fixed_score,
    full_EMT = full_EMT,
    no_overlap_EMT = no_overlap_EMT,
    source_dataset_id = source
  )
}

normalize_gsva_output <- function(
  object, expected_sets, expected_samples, cohort
) {
  raw_class <- paste(class(object), collapse = "/")
  if (is.matrix(object)) {
    x <- object
  } else if (
    inherits(object, "SummarizedExperiment") &&
      requireNamespace("SummarizedExperiment", quietly = TRUE)
  ) {
    x <- as.matrix(SummarizedExperiment::assay(object))
  } else {
    x <- tryCatch(as.matrix(object), error = function(e) NULL)
  }

  assert(
    is.matrix(x) && is.numeric(x),
    "%s GSVA output cannot be converted to a numeric matrix.", cohort
  )

  raw_dim <- dim(x)
  direct <- !is.null(rownames(x)) && !is.null(colnames(x)) &&
    setequal(rownames(x), expected_sets) &&
    setequal(colnames(x), expected_samples)
  reverse <- !is.null(rownames(x)) && !is.null(colnames(x)) &&
    setequal(rownames(x), expected_samples) &&
    setequal(colnames(x), expected_sets)

  transposed <- FALSE
  if (direct) {
    # keep
  } else if (reverse) {
    x <- t(x)
    transposed <- TRUE
  } else {
    stopf(
      "%s GSVA names do not identify the expected %d x %d matrix.",
      cohort, length(expected_sets), length(expected_samples)
    )
  }

  row_reordered <- !identical(rownames(x), expected_sets)
  col_reordered <- !identical(colnames(x), expected_samples)
  x <- x[expected_sets, expected_samples, drop = FALSE]
  row_sd <- apply(x, 1L, stats::sd)

  assert(
    identical(dim(x), c(length(expected_sets), length(expected_samples))) &&
      identical(rownames(x), expected_sets) &&
      identical(colnames(x), expected_samples) &&
      all(is.finite(x)) &&
      all(is.finite(row_sd) & row_sd > 0),
    "%s normalized GSVA score matrix failed integrity checks.", cohort
  )

  audit <- data.frame(
    cohort = cohort,
    input_gene_set_number = length(expected_sets),
    output_row_number = nrow(x),
    output_column_number = ncol(x),
    raw_output_class = raw_class,
    raw_row_number = raw_dim[1L],
    raw_column_number = raw_dim[2L],
    transposed = transposed,
    rows_reordered = row_reordered,
    columns_reordered = col_reordered,
    nonfinite_value_number = sum(!is.finite(x)),
    zero_variance_set_number = sum(!(is.finite(row_sd) & row_sd > 0)),
    minimum_score_SD = min(row_sd),
    maximum_score_SD = max(row_sd),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(scores = x, audit = audit)
}

rank_rows <- function(x) {
  ranked <- t(apply(
    x, 1L, rank,
    ties.method = "average",
    na.last = "keep"
  ))
  rownames(ranked) <- rownames(x)
  colnames(ranked) <- colnames(x)
  storage.mode(ranked) <- "double"

  assert(
    identical(dim(ranked), dim(x)) &&
      identical(rownames(ranked), rownames(x)) &&
      identical(colnames(ranked), colnames(x)) &&
      all(is.finite(ranked)),
    "Score-rank matrix construction failed."
  )
  ranked
}

correlate_rank_matrix <- function(
  ranked_scores, outcome, source_dataset_id, cohort
) {
  assert(
    identical(colnames(ranked_scores), names(outcome)) &&
      length(source_dataset_id) == length(outcome),
    "%s ranked scores, outcome and source vector are misaligned.", cohort
  )

  outcome_rank <- rank(outcome, ties.method = "average")
  work <- ranked_scores

  if (cohort == "GSE31519") {
    source <- factor(source_dataset_id)
    outcome_centered <- outcome_rank -
      ave(outcome_rank, source, FUN = mean)

    for (level in levels(source)) {
      index <- which(source == level)
      work[, index] <- sweep(
        work[, index, drop = FALSE],
        1L,
        rowMeans(work[, index, drop = FALSE]),
        FUN = "-"
      )
    }
    method <- "Partial_Spearman_source_centered_ranks"
  } else {
    outcome_centered <- outcome_rank - mean(outcome_rank)
    work <- sweep(work, 1L, rowMeans(work), FUN = "-")
    method <- "Spearman"
  }

  denominator <- sqrt(
    rowSums(work^2) * sum(outcome_centered^2)
  )
  rho <- as.numeric(work %*% outcome_centered) / denominator
  names(rho) <- rownames(ranked_scores)

  assert(
    length(rho) == nrow(ranked_scores) &&
      all(is.finite(rho)) &&
      all(rho > -1 & rho < 1),
    "%s contains invalid rank correlations.", cohort
  )

  list(
    rho = rho,
    method = method,
    source_dataset_number =
      length(unique(as.character(source_dataset_id)))
  )
}

meta_one <- function(rho, n) {
  rho <- as.numeric(rho)
  n <- as.numeric(n)
  assert(
    length(rho) == 3L &&
      length(n) == 3L &&
      all(is.finite(rho) & rho > -1 & rho < 1) &&
      all(n > 3),
    "Observed meta input is invalid."
  )

  z <- atanh(rho)
  variance <- 1 / (n - 3)
  weight <- 1 / variance
  z_fixed <- sum(weight * z) / sum(weight)
  Q <- sum(weight * (z - z_fixed)^2)
  df <- length(z) - 1L
  C <- sum(weight) - sum(weight^2) / sum(weight)
  tau2 <- if (C > 0) max(0, (Q - df) / C) else 0
  random_weight <- 1 / (variance + tau2)
  z_random <- sum(random_weight * z) / sum(random_weight)
  se_random <- sqrt(1 / sum(random_weight))
  critical <- qnorm(0.975)

  data.frame(
    random_pooled_rho = tanh(z_random),
    random_95CI_lower_rho =
      tanh(z_random - critical * se_random),
    random_95CI_upper_rho =
      tanh(z_random + critical * se_random),
    random_two_sided_p =
      2 * pnorm(abs(z_random / se_random), lower.tail = FALSE),
    Cochran_Q = Q,
    Q_p = pchisq(Q, df = df, lower.tail = FALSE),
    I2_percent =
      if (Q > 0) max(0, (Q - df) / Q) * 100 else 0,
    tau2 = tau2,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

meta_many <- function(effect_table, endpoint) {
  required <- c(
    "set_id", "TCGA_TNBC_rho",
    "GSE31519_rho", "GSE58812_rho"
  )
  assert(
    is.data.frame(effect_table) &&
      nrow(effect_table) == RANDOM_SET_NUMBER &&
      all(required %in% names(effect_table)),
    "%s cohort-effect table is malformed.", endpoint
  )

  rho <- as.matrix(effect_table[, required[-1L]])
  assert(
    all(is.finite(rho)) &&
      all(rho > -1 & rho < 1),
    "%s contains invalid correlations.", endpoint
  )

  z <- atanh(rho)
  variance <- 1 / (as.numeric(EXPECTED_N[COHORT_ORDER]) - 3)
  fixed_weight <- 1 / variance
  z_fixed <- as.numeric(z %*% fixed_weight) / sum(fixed_weight)

  centered <- sweep(z, 1L, z_fixed, FUN = "-")
  Q <- rowSums(sweep(centered^2, 2L, fixed_weight, FUN = "*"))
  df <- 2L
  C <- sum(fixed_weight) -
    sum(fixed_weight^2) / sum(fixed_weight)
  tau2 <- pmax(0, (Q - df) / C)

  variance_matrix <- matrix(
    variance, nrow = nrow(z), ncol = 3L, byrow = TRUE
  )
  random_weight <- 1 / (
    variance_matrix +
      matrix(tau2, nrow = nrow(z), ncol = 3L)
  )
  weight_sum <- rowSums(random_weight)
  z_random <- rowSums(random_weight * z) / weight_sum
  se_random <- sqrt(1 / weight_sum)
  critical <- qnorm(0.975)

  result <- data.frame(
    endpoint = endpoint,
    set_id = effect_table$set_id,
    TCGA_TNBC_rho = rho[, 1L],
    GSE31519_rho = rho[, 2L],
    GSE58812_rho = rho[, 3L],
    all_three_positive = rowSums(rho > 0) == 3L,
    all_three_negative = rowSums(rho < 0) == 3L,
    direction_consistent =
      rowSums(rho > 0) == 3L | rowSums(rho < 0) == 3L,
    random_pooled_fisher_z = z_random,
    random_standard_error = se_random,
    random_pooled_rho = tanh(z_random),
    random_95CI_lower_rho =
      tanh(z_random - critical * se_random),
    random_95CI_upper_rho =
      tanh(z_random + critical * se_random),
    random_two_sided_p =
      2 * pnorm(abs(z_random / se_random), lower.tail = FALSE),
    Cochran_Q = Q,
    Q_p = pchisq(Q, df = df, lower.tail = FALSE),
    I2_percent = ifelse(
      Q > 0,
      pmax(0, (Q - df) / Q) * 100,
      0
    ),
    tau2 = tau2,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert(
    nrow(result) == RANDOM_SET_NUMBER &&
      !anyDuplicated(result$set_id) &&
      all(is.finite(result$random_pooled_rho)) &&
      all(result$random_pooled_rho > -1 &
            result$random_pooled_rho < 1),
    "%s meta results failed integrity checks.", endpoint
  )
  result
}

empirical_row <- function(
  endpoint, level, observed, null_values
) {
  assert(
    length(observed) == 1L &&
      is.finite(observed) &&
      length(null_values) == RANDOM_SET_NUMBER &&
      all(is.finite(null_values)),
    "%s %s empirical-test input is invalid.", endpoint, level
  )

  positive_exceedance <- sum(null_values >= observed)
  absolute_exceedance <- sum(abs(null_values) >= abs(observed))
  tie_number <- sum(null_values == observed)
  percentile <- (
    sum(null_values < observed) + 0.5 * tie_number
  ) / length(null_values) * 100

  data.frame(
    endpoint = endpoint,
    level = level,
    observed_recomputed_effect = observed,
    null_set_number = length(null_values),
    null_mean = mean(null_values),
    null_SD = sd(null_values),
    null_median = median(null_values),
    null_2.5_percentile =
      unname(quantile(null_values, 0.025, type = 8)),
    null_97.5_percentile =
      unname(quantile(null_values, 0.975, type = 8)),
    positive_exceedance_number = positive_exceedance,
    positive_empirical_p =
      (1 + positive_exceedance) /
      (1 + length(null_values)),
    absolute_exceedance_number = absolute_exceedance,
    absolute_empirical_p =
      (1 + absolute_exceedance) /
      (1 + length(null_values)),
    observed_percentile = percentile,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

quantile_rows <- function(endpoint, metric, values) {
  q <- quantile(
    values,
    probs = QUANTILE_PROBABILITIES,
    names = FALSE,
    type = 8
  )
  data.frame(
    endpoint = endpoint,
    metric = metric,
    probability = QUANTILE_PROBABILITIES,
    quantile = q,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

cache_file <- function(cohort) {
  file.path(CACHE_ROOT, paste0(cohort, "_validated_effects.rds"))
}

valid_cache <- function(file, cohort, observed_md5) {
  if (!file.exists(file)) return(NULL)
  x <- tryCatch(readRDS(file), error = function(e) NULL)

  if (
    !is.list(x) ||
      !same_text(x$script_build_id, BUILD_ID) ||
      !same_text(x$cohort, cohort) ||
      !identical(unname(x$input_md5), unname(observed_md5)) ||
      length(x$full_random_rho) != RANDOM_SET_NUMBER ||
      length(x$no_overlap_random_rho) != RANDOM_SET_NUMBER ||
      !identical(names(x$full_random_rho), RANDOM_SET_IDS) ||
      !identical(names(x$no_overlap_random_rho), RANDOM_SET_IDS) ||
      any(!is.finite(x$full_random_rho)) ||
      any(!is.finite(x$no_overlap_random_rho)) ||
      !is.data.frame(x$observed_summary) ||
      nrow(x$observed_summary) != 2L
  ) return(NULL)
  x
}

score_cohort <- function(
  prepared, validation_vectors, cohort,
  primary_sets, accepted_primary_effect,
  accepted_overlap_effect, observed_md5
) {
  cached <- valid_cache(cache_file(cohort), cohort, observed_md5)
  if (!is.null(cached)) {
    cat("Using validated Script15C v2 cache for ", cohort, ".\n", sep = "")
    return(cached)
  }

  expression <- prepared$expression
  source <- validation_vectors$source_dataset_id

  set_names <- c(
    OBSERVED_SET_NAME,
    paste0(RANDOM_PREFIX, RANDOM_SET_IDS)
  )
  gene_sets <- c(
    setNames(list(LOCKED24), OBSERVED_SET_NAME),
    setNames(
      primary_sets,
      paste0(RANDOM_PREFIX, names(primary_sets))
    )
  )
  gene_sets <- gene_sets[set_names]

  assert(
    is.list(gene_sets) &&
      identical(names(gene_sets), set_names) &&
      all(lengths(gene_sets) == 24L) &&
      all(vapply(gene_sets, function(x)
        length(unique(x)) == 24L, logical(1))) &&
      all(unique(unlist(gene_sets, use.names = FALSE)) %in%
            rownames(expression)),
    "%s gene-set collection is malformed.", cohort
  )

  cat(
    "Running exchangeable GSVA for ", cohort,
    " (observed locked24 + 5,000 matched random24 sets).\n",
    sep = ""
  )
  parameter <- GSVA::gsvaParam(expression, gene_sets)
  raw <- GSVA::gsva(parameter, verbose = FALSE)
  normalized <- normalize_gsva_output(
    raw, set_names, colnames(expression), cohort
  )
  score_matrix <- normalized$scores

  observed_recomputed_score <- as.numeric(
    score_matrix[OBSERVED_SET_NAME, ]
  )
  names(observed_recomputed_score) <- colnames(score_matrix)

  score_concordance <- data.frame(
    cohort = cohort,
    fixed_score_context =
      if (cohort == "TCGA_TNBC") {
        "Original full-BRCA score subset to TNBC"
      } else {
        "Original cohort-level score"
      },
    random_test_score_context =
      "Observed and random signatures recomputed together in analysis cohort",
    maximum_absolute_score_difference = max(abs(
      observed_recomputed_score - validation_vectors$fixed_score
    )),
    Pearson_concordance = cor(
      observed_recomputed_score,
      validation_vectors$fixed_score,
      method = "pearson"
    ),
    Spearman_concordance = cor(
      observed_recomputed_score,
      validation_vectors$fixed_score,
      method = "spearman"
    ),
    numeric_identity_required = FALSE,
    exchangeability_required = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  ranked_scores <- rank_rows(score_matrix)
  full_effect <- correlate_rank_matrix(
    ranked_scores,
    validation_vectors$full_EMT,
    source,
    cohort
  )
  no_overlap_effect <- correlate_rank_matrix(
    ranked_scores,
    validation_vectors$no_overlap_EMT,
    source,
    cohort
  )

  observed_full_recomputed <- unname(
    full_effect$rho[OBSERVED_SET_NAME]
  )
  observed_overlap_recomputed <- unname(
    no_overlap_effect$rho[OBSERVED_SET_NAME]
  )

  random_names <- paste0(RANDOM_PREFIX, RANDOM_SET_IDS)
  full_random_rho <- full_effect$rho[random_names]
  no_overlap_random_rho <- no_overlap_effect$rho[random_names]
  names(full_random_rho) <- RANDOM_SET_IDS
  names(no_overlap_random_rho) <- RANDOM_SET_IDS

  observed_summary <- rbind(
    data.frame(
      cohort = cohort,
      endpoint = "FULL_HALLMARK_EMT",
      accepted_fixed_score_effect = accepted_primary_effect,
      recomputed_exchangeable_effect = observed_full_recomputed,
      effect_difference =
        observed_full_recomputed - accepted_primary_effect,
      effect_direction_agrees =
        sign(observed_full_recomputed) ==
          sign(accepted_primary_effect),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      cohort = cohort,
      endpoint = "NO_OVERLAP_HALLMARK_EMT",
      accepted_fixed_score_effect = accepted_overlap_effect,
      recomputed_exchangeable_effect =
        observed_overlap_recomputed,
      effect_difference =
        observed_overlap_recomputed - accepted_overlap_effect,
      effect_direction_agrees =
        sign(observed_overlap_recomputed) ==
          sign(accepted_overlap_effect),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  assert(
    all(is.finite(observed_summary$recomputed_exchangeable_effect)) &&
      all(observed_summary$effect_direction_agrees) &&
      length(full_random_rho) == RANDOM_SET_NUMBER &&
      length(no_overlap_random_rho) == RANDOM_SET_NUMBER &&
      identical(names(full_random_rho), RANDOM_SET_IDS) &&
      identical(names(no_overlap_random_rho), RANDOM_SET_IDS) &&
      all(is.finite(full_random_rho)) &&
      all(is.finite(no_overlap_random_rho)),
    "%s exchangeable observed or random effects failed checks.", cohort
  )

  result <- list(
    script_build_id = BUILD_ID,
    cohort = cohort,
    input_md5 = observed_md5,
    full_random_rho = full_random_rho,
    no_overlap_random_rho = no_overlap_random_rho,
    observed_summary = observed_summary,
    score_concordance = score_concordance,
    GSVA_audit = normalized$audit,
    GSVA_parameter_details = capture.output(show(parameter)),
    method = full_effect$method,
    source_dataset_number = full_effect$source_dataset_number
  )

  dir.create(CACHE_ROOT, recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(CACHE_ROOT), "Unable to create validated cache directory.")

  temp_cache <- paste0(cache_file(cohort), ".tmp_", Sys.getpid())
  saveRDS(result, temp_cache, version = 3)
  assert(
    identical(readRDS(temp_cache), result),
    "%s cache save-read verification failed.", cohort
  )

  if (file.exists(cache_file(cohort))) {
    unlink(cache_file(cohort), force = TRUE)
  }
  assert(
    file.rename(temp_cache, cache_file(cohort)),
    "%s validated cache commit failed.", cohort
  )
  result
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "Matched_random24_empirical_test_COMPLETE_bundle.rds"
    ),
    full = file.path(
      root, "audit",
      "Matched_random24_full_EMT_5000_null_results.csv"
    ),
    overlap = file.path(
      root, "audit",
      "Matched_random24_no_overlap_EMT_5000_null_results.csv"
    ),
    empirical = file.path(
      root, "audit",
      "Matched_random24_empirical_test_summary.csv"
    ),
    manifest = file.path(
      root, "audit",
      "Script15C_v2_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script15C_v2_COMPLETE_report.txt"
    )
  )

  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT15C_V2 STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  f <- tryCatch(
    read.csv(key["full"], stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  o <- tryCatch(
    read.csv(key["overlap"], stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  e <- tryCatch(
    read.csv(key["empirical"], stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )

  is.list(b) &&
    same_text(b$script, "Script15C_v2") &&
    same_text(b$script_build_id, BUILD_ID) &&
    same_text(
      b$strengthening_analysis_status,
      "MATCHED_RANDOM24_NULL_COMPLETE"
    ) &&
    is.data.frame(f) && nrow(f) == RANDOM_SET_NUMBER &&
    is.data.frame(o) && nrow(o) == RANDOM_SET_NUMBER &&
    is.data.frame(e) && nrow(e) == 8L &&
    isFALSE(b$policy$result_based_set_rejection)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT),
           "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script15C v2 output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "02_random_GSVA_and_empirical_test_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(
    file.rename(OUTPUT_ROOT, archive),
    "Existing output is incomplete, but safe archiving failed."
  )
  assert(
    !dir.exists(OUTPUT_ROOT) && dir.exists(archive),
    "Archive verification failed."
  )
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Exchangeable matched-random 24-gene empirical test.\n")
  cat("============================================================\n")

  missing_packages <- c("GSVA")[
    !vapply(c("GSVA"), requireNamespace, logical(1), quietly = TRUE)
  ]
  assert(
    !length(missing_packages),
    "Missing package(s): %s",
    paste(missing_packages, collapse = ", ")
  )

  missing_files <- INPUTS[!file.exists(INPUTS)]
  assert(
    !length(missing_files),
    "Missing accepted input(s):\n%s",
    paste(missing_files, collapse = "\n")
  )

  observed_md5 <- vapply(INPUTS, md5, character(1))
  assert(
    identical(unname(observed_md5), unname(EXPECTED_MD5)),
    "At least one accepted input MD5 differs:\n%s",
    paste(sprintf(
      "%s | expected=%s | observed=%s",
      names(EXPECTED_MD5), EXPECTED_MD5, observed_md5
    ), collapse = "\n")
  )

  assert(
    manifest_ok(SCRIPT15B_ROOT, INPUTS["Script15B_manifest"]),
    "Script15B output manifest verification failed."
  )
  assert(
    manifest_ok(SCRIPT14A_ROOT, INPUTS["Script14A_manifest"]),
    "Script14A output manifest verification failed."
  )
  assert(
    manifest_ok(
      TCGA_VALIDATION_ROOT,
      INPUTS["TCGA_validation_manifest"]
    ),
    "TCGA validation manifest verification failed."
  )
  assert(
    manifest_ok(
      G315_VALIDATION_ROOT,
      INPUTS["G315_validation_manifest"]
    ),
    "GSE31519 validation manifest verification failed."
  )
  assert(
    manifest_ok(
      G588_VALIDATION_ROOT,
      INPUTS["G588_validation_manifest"]
    ),
    "GSE58812 validation manifest verification failed."
  )
  assert(
    manifest_ok(CORE_META_ROOT, INPUTS["core_meta_manifest"]),
    "Core EMT meta manifest verification failed."
  )

  assert(
    report_contains(
      INPUTS["Script15B_report"], "SCRIPT15B STATUS: COMPLETE"
    ) &&
      report_contains(
        INPUTS["Script14A_report"], "SCRIPT14A STATUS: COMPLETE"
      ) &&
      report_contains(
        INPUTS["TCGA_validation_report"],
        "SCRIPT13G_B STATUS: COMPLETE"
      ) &&
      report_contains(
        INPUTS["G315_validation_report"],
        "SCRIPT13G_A STATUS: COMPLETE"
      ) &&
      report_contains(
        INPUTS["G588_validation_report"],
        "SCRIPT13F STATUS: COMPLETE"
      ) &&
      report_contains(
        INPUTS["core_meta_report"],
        "SCRIPT13G_C STATUS: COMPLETE"
      ),
    "At least one accepted completion marker is missing."
  )

  generation <- readRDS(INPUTS["Script15B_bundle"])
  primary_sets <- readRDS(INPUTS["primary_sets"])
  mapping <- read.csv(
    INPUTS["mapping_csv"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  set_summary <- read.csv(
    INPUTS["set_summary"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert(
    is.list(generation) &&
      same_text(generation$script, "Script15B") &&
      same_text(
        generation$script_build_id,
        "Script15B_COMPACT_FINAL_20260712"
      ) &&
      same_text(generation$readiness_status, "READY_FOR_SCRIPT15C") &&
      isFALSE(generation$policy$GSVA_performed) &&
      isFALSE(generation$policy$result_based_set_rejection),
    "Script15B bundle identity or boundary lock is incorrect."
  )
  assert(
    is.list(primary_sets) &&
      identical(names(primary_sets), RANDOM_SET_IDS) &&
      all(lengths(primary_sets) == 24L) &&
      all(vapply(primary_sets, function(x)
        length(unique(x)) == 24L, logical(1))) &&
      length(unique(vapply(
        primary_sets, set_key, character(1)
      ))) == RANDOM_SET_NUMBER,
    "Primary random-set RDS is malformed."
  )
  assert(
    is.data.frame(mapping) &&
      nrow(mapping) == RANDOM_SET_NUMBER * 24L &&
      !anyDuplicated(mapping[c("set_id", "target_gene")]) &&
      all(table(mapping$set_id) == 24L) &&
      all(mapping$target_in_Hallmark_EMT ==
            mapping$candidate_in_Hallmark_EMT),
    "Random-set mapping table is malformed."
  )
  assert(
    is.data.frame(set_summary) &&
      nrow(set_summary) == RANDOM_SET_NUMBER &&
      length(unique(set_summary$primary_signature_key)) ==
        RANDOM_SET_NUMBER,
    "Random-set summary is malformed."
  )

  for (set_id in RANDOM_SET_IDS) {
    d <- mapping[mapping$set_id == set_id, , drop = FALSE]
    d <- d[order(d$target_order), , drop = FALSE]
    assert(
      identical(
        as.character(primary_sets[[set_id]]),
        as.character(d$candidate_gene)
      ),
      "Primary random-set RDS and mapping differ for %s.", set_id
    )
  }

  TCGA <- readRDS(INPUTS["TCGA_prepared"])
  G315 <- readRDS(INPUTS["GSE31519_prepared"])
  G588 <- readRDS(INPUTS["GSE58812_prepared"])
  validate_prepared(
    TCGA, "TCGA_TNBC", EXPECTED_DIMENSIONS$TCGA_TNBC
  )
  validate_prepared(
    G315, "GSE31519", EXPECTED_DIMENSIONS$GSE31519
  )
  validate_prepared(
    G588, "GSE58812", EXPECTED_DIMENSIONS$GSE58812
  )

  TCGA_validation <- readRDS(INPUTS["TCGA_validation_bundle"])
  G315_validation <- readRDS(INPUTS["G315_validation_bundle"])
  G588_validation <- readRDS(INPUTS["G588_validation_bundle"])

  assert(
    is.list(TCGA_validation) &&
      same_text(TCGA_validation$script, "Script13G_B") &&
      same_text(
        TCGA_validation$script_build_id,
        "Script13G_B_v4_COMPACT_FINAL_20260711"
      ),
    "TCGA validation bundle identity is incorrect."
  )
  assert(
    is.list(G315_validation) &&
      same_text(G315_validation$script, "Script13G_A") &&
      same_text(
        G315_validation$script_build_id,
        "Script13G_A_COMPACT_FINAL_20260711"
      ),
    "GSE31519 validation bundle identity is incorrect."
  )
  assert(
    is.list(G588_validation) &&
      same_text(G588_validation$script, "Script13F") &&
      same_text(
        G588_validation$script_build_id,
        "Script13F_COMPACT_FINAL_20260711"
      ),
    "GSE58812 validation bundle identity is incorrect."
  )

  vectors <- list(
    TCGA_TNBC = extract_validation_vectors(
      TCGA, TCGA_validation, "TCGA_TNBC"
    ),
    GSE31519 = extract_validation_vectors(
      G315, G315_validation, "GSE31519"
    ),
    GSE58812 = extract_validation_vectors(
      G588, G588_validation, "GSE58812"
    )
  )

  core_meta <- readRDS(INPUTS["core_meta_bundle"])
  assert(
    is.list(core_meta) &&
      same_text(core_meta$script, "Script13G_C") &&
      same_text(
        core_meta$script_build_id,
        "Script13G_C_v2_COMPACT_FINAL_20260711"
      ) &&
      same_text(core_meta$analysis_freeze_decision, "FREEZE_ANALYSIS"),
    "Accepted core EMT meta bundle identity is incorrect."
  )

  accepted_primary <- core_meta$primary_effects
  accepted_overlap <- core_meta$overlap_removed_effects
  assert(
    is.data.frame(accepted_primary) &&
      is.data.frame(accepted_overlap) &&
      nrow(accepted_primary) == 3L &&
      nrow(accepted_overlap) == 3L &&
      all(c("cohort", "sample_number", "rho") %in%
            names(accepted_primary)) &&
      all(c("cohort", "sample_number", "rho") %in%
            names(accepted_overlap)),
    "Accepted core cohort-effect tables are malformed."
  )

  accepted_primary <- accepted_primary[
    match(COHORT_ORDER, accepted_primary$cohort),
    ,
    drop = FALSE
  ]
  accepted_overlap <- accepted_overlap[
    match(COHORT_ORDER, accepted_overlap$cohort),
    ,
    drop = FALSE
  ]
  assert(
    identical(as.character(accepted_primary$cohort), COHORT_ORDER) &&
      identical(as.character(accepted_overlap$cohort), COHORT_ORDER) &&
      identical(
        as.integer(accepted_primary$sample_number),
        as.integer(EXPECTED_N[COHORT_ORDER])
      ) &&
      identical(
        as.integer(accepted_overlap$sample_number),
        as.integer(EXPECTED_N[COHORT_ORDER])
      ),
    "Accepted cohort-effect order or sample numbers are incorrect."
  )

  # Independently verify that the extracted fixed score and EMT vectors
  # reproduce the accepted core effects exactly.
  for (i in seq_along(COHORT_ORDER)) {
    cohort <- COHORT_ORDER[i]
    v <- vectors[[cohort]]
    fixed_matrix <- matrix(
      v$fixed_score,
      nrow = 1L,
      dimnames = list("FIXED_SCORE", names(v$fixed_score))
    )
    fixed_rank <- rank_rows(fixed_matrix)

    full_check <- correlate_rank_matrix(
      fixed_rank, v$full_EMT, v$source_dataset_id, cohort
    )$rho[1L]
    overlap_check <- correlate_rank_matrix(
      fixed_rank, v$no_overlap_EMT, v$source_dataset_id, cohort
    )$rho[1L]

    assert(
      same_numeric(
        full_check,
        accepted_primary$rho[i],
        tolerance = EFFECT_TOLERANCE
      ) &&
        same_numeric(
          overlap_check,
          accepted_overlap$rho[i],
          tolerance = EFFECT_TOLERANCE
        ),
      "%s extracted accepted vectors do not reproduce core effects.",
      cohort
    )
  }

  all_random_genes <- unique(c(
    unlist(primary_sets, use.names = FALSE),
    LOCKED24
  ))
  assert(
    all(all_random_genes %in% rownames(TCGA$expression)) &&
      all(all_random_genes %in% rownames(G315$expression)) &&
      all(all_random_genes %in% rownames(G588$expression)),
    "At least one observed or random gene is absent from a cohort."
  )

  dir.create(dirname(OUTPUT_ROOT), recursive = TRUE, showWarnings = FALSE)
  assert(
    dir.exists(dirname(OUTPUT_ROOT)),
    "Unable to create random-null parent directory."
  )
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  # Never reuse the conceptually incorrect v1 cache.
  old_cache <- file.path(
    dirname(OUTPUT_ROOT),
    ".Script15C_validated_cache"
  )
  if (dir.exists(old_cache)) {
    unlink(old_cache, recursive = TRUE, force = TRUE)
  }

  if (dir.exists(CACHE_ROOT)) {
    cache_files <- file.path(
      CACHE_ROOT,
      paste0(COHORT_ORDER, "_validated_effects.rds")
    )
    cache_objects <- lapply(
      seq_along(COHORT_ORDER),
      function(i) valid_cache(
        cache_files[i], COHORT_ORDER[i], observed_md5
      )
    )
    if (!all(vapply(cache_objects, function(x)
      !is.null(x), logical(1)))) {
      unlink(CACHE_ROOT, recursive = TRUE, force = TRUE)
    }
  }
  dir.create(CACHE_ROOT, recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(CACHE_ROOT), "Unable to create v2 validated cache.")

  cohort_results <- list(
    TCGA_TNBC = score_cohort(
      TCGA,
      vectors$TCGA_TNBC,
      "TCGA_TNBC",
      primary_sets,
      accepted_primary$rho[1L],
      accepted_overlap$rho[1L],
      observed_md5
    ),
    GSE31519 = score_cohort(
      G315,
      vectors$GSE31519,
      "GSE31519",
      primary_sets,
      accepted_primary$rho[2L],
      accepted_overlap$rho[2L],
      observed_md5
    ),
    GSE58812 = score_cohort(
      G588,
      vectors$GSE58812,
      "GSE58812",
      primary_sets,
      accepted_primary$rho[3L],
      accepted_overlap$rho[3L],
      observed_md5
    )
  )

  observed_cohort <- do.call(
    rbind,
    lapply(cohort_results, function(x) x$observed_summary)
  )
  rownames(observed_cohort) <- NULL

  score_concordance <- do.call(
    rbind,
    lapply(cohort_results, function(x) x$score_concordance)
  )
  rownames(score_concordance) <- NULL

  GSVA_audit <- do.call(
    rbind,
    lapply(cohort_results, function(x) x$GSVA_audit)
  )
  rownames(GSVA_audit) <- NULL

  method_audit <- data.frame(
    cohort = COHORT_ORDER,
    sample_number = as.integer(EXPECTED_N[COHORT_ORDER]),
    method = vapply(
      cohort_results,
      function(x) scalar_text(x$method),
      character(1)
    ),
    source_dataset_number = vapply(
      cohort_results,
      function(x) as.integer(x$source_dataset_number),
      integer(1)
    ),
    observed_set_number = 1L,
    random_set_number = RANDOM_SET_NUMBER,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  full_effect_table <- data.frame(
    set_id = RANDOM_SET_IDS,
    TCGA_TNBC_rho =
      cohort_results$TCGA_TNBC$full_random_rho[RANDOM_SET_IDS],
    GSE31519_rho =
      cohort_results$GSE31519$full_random_rho[RANDOM_SET_IDS],
    GSE58812_rho =
      cohort_results$GSE58812$full_random_rho[RANDOM_SET_IDS],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  overlap_effect_table <- data.frame(
    set_id = RANDOM_SET_IDS,
    TCGA_TNBC_rho =
      cohort_results$TCGA_TNBC$
        no_overlap_random_rho[RANDOM_SET_IDS],
    GSE31519_rho =
      cohort_results$GSE31519$
        no_overlap_random_rho[RANDOM_SET_IDS],
    GSE58812_rho =
      cohort_results$GSE58812$
        no_overlap_random_rho[RANDOM_SET_IDS],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  full_null <- meta_many(
    full_effect_table,
    "FULL_HALLMARK_EMT"
  )
  overlap_null <- meta_many(
    overlap_effect_table,
    "NO_OVERLAP_HALLMARK_EMT"
  )

  recomputed_full_effects <- observed_cohort[
    observed_cohort$endpoint == "FULL_HALLMARK_EMT",
    ,
    drop = FALSE
  ]
  recomputed_overlap_effects <- observed_cohort[
    observed_cohort$endpoint == "NO_OVERLAP_HALLMARK_EMT",
    ,
    drop = FALSE
  ]
  recomputed_full_effects <- recomputed_full_effects[
    match(COHORT_ORDER, recomputed_full_effects$cohort),
    ,
    drop = FALSE
  ]
  recomputed_overlap_effects <- recomputed_overlap_effects[
    match(COHORT_ORDER, recomputed_overlap_effects$cohort),
    ,
    drop = FALSE
  ]

  observed_full_meta <- meta_one(
    recomputed_full_effects$recomputed_exchangeable_effect,
    EXPECTED_N[COHORT_ORDER]
  )
  observed_overlap_meta <- meta_one(
    recomputed_overlap_effects$recomputed_exchangeable_effect,
    EXPECTED_N[COHORT_ORDER]
  )
  accepted_full_meta <- meta_one(
    accepted_primary$rho,
    accepted_primary$sample_number
  )
  accepted_overlap_meta <- meta_one(
    accepted_overlap$rho,
    accepted_overlap$sample_number
  )

  observed_meta <- rbind(
    data.frame(
      endpoint = "FULL_HALLMARK_EMT",
      score_context = "ACCEPTED_FIXED_SCORE",
      accepted_full_meta,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      endpoint = "FULL_HALLMARK_EMT",
      score_context = "RECOMPUTED_EXCHANGEABLE_SCORE",
      observed_full_meta,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      endpoint = "NO_OVERLAP_HALLMARK_EMT",
      score_context = "ACCEPTED_FIXED_SCORE",
      accepted_overlap_meta,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      endpoint = "NO_OVERLAP_HALLMARK_EMT",
      score_context = "RECOMPUTED_EXCHANGEABLE_SCORE",
      observed_overlap_meta,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  empirical <- rbind(
    empirical_row(
      "FULL_HALLMARK_EMT",
      "TCGA_TNBC",
      recomputed_full_effects$recomputed_exchangeable_effect[1L],
      full_null$TCGA_TNBC_rho
    ),
    empirical_row(
      "FULL_HALLMARK_EMT",
      "GSE31519",
      recomputed_full_effects$recomputed_exchangeable_effect[2L],
      full_null$GSE31519_rho
    ),
    empirical_row(
      "FULL_HALLMARK_EMT",
      "GSE58812",
      recomputed_full_effects$recomputed_exchangeable_effect[3L],
      full_null$GSE58812_rho
    ),
    empirical_row(
      "FULL_HALLMARK_EMT",
      "RANDOM_EFFECTS_META",
      observed_full_meta$random_pooled_rho,
      full_null$random_pooled_rho
    ),
    empirical_row(
      "NO_OVERLAP_HALLMARK_EMT",
      "TCGA_TNBC",
      recomputed_overlap_effects$
        recomputed_exchangeable_effect[1L],
      overlap_null$TCGA_TNBC_rho
    ),
    empirical_row(
      "NO_OVERLAP_HALLMARK_EMT",
      "GSE31519",
      recomputed_overlap_effects$
        recomputed_exchangeable_effect[2L],
      overlap_null$GSE31519_rho
    ),
    empirical_row(
      "NO_OVERLAP_HALLMARK_EMT",
      "GSE58812",
      recomputed_overlap_effects$
        recomputed_exchangeable_effect[3L],
      overlap_null$GSE58812_rho
    ),
    empirical_row(
      "NO_OVERLAP_HALLMARK_EMT",
      "RANDOM_EFFECTS_META",
      observed_overlap_meta$random_pooled_rho,
      overlap_null$random_pooled_rho
    )
  )
  rownames(empirical) <- NULL

  meta_index <- empirical$level == "RANDOM_EFFECTS_META"
  empirical$positive_empirical_BH_across_two_endpoints <- NA_real_
  empirical$absolute_empirical_BH_across_two_endpoints <- NA_real_
  empirical$positive_empirical_BH_across_two_endpoints[meta_index] <-
    p.adjust(
      empirical$positive_empirical_p[meta_index],
      method = "BH"
    )
  empirical$absolute_empirical_BH_across_two_endpoints[meta_index] <-
    p.adjust(
      empirical$absolute_empirical_p[meta_index],
      method = "BH"
    )

  quantiles <- rbind(
    quantile_rows(
      "FULL_HALLMARK_EMT",
      "TCGA_TNBC_rho",
      full_null$TCGA_TNBC_rho
    ),
    quantile_rows(
      "FULL_HALLMARK_EMT",
      "GSE31519_rho",
      full_null$GSE31519_rho
    ),
    quantile_rows(
      "FULL_HALLMARK_EMT",
      "GSE58812_rho",
      full_null$GSE58812_rho
    ),
    quantile_rows(
      "FULL_HALLMARK_EMT",
      "random_pooled_rho",
      full_null$random_pooled_rho
    ),
    quantile_rows(
      "NO_OVERLAP_HALLMARK_EMT",
      "TCGA_TNBC_rho",
      overlap_null$TCGA_TNBC_rho
    ),
    quantile_rows(
      "NO_OVERLAP_HALLMARK_EMT",
      "GSE31519_rho",
      overlap_null$GSE31519_rho
    ),
    quantile_rows(
      "NO_OVERLAP_HALLMARK_EMT",
      "GSE58812_rho",
      overlap_null$GSE58812_rho
    ),
    quantile_rows(
      "NO_OVERLAP_HALLMARK_EMT",
      "random_pooled_rho",
      overlap_null$random_pooled_rho
    )
  )
  rownames(quantiles) <- NULL

  assert(
    nrow(full_null) == RANDOM_SET_NUMBER &&
      nrow(overlap_null) == RANDOM_SET_NUMBER &&
      !anyDuplicated(full_null$set_id) &&
      !anyDuplicated(overlap_null$set_id) &&
      nrow(observed_cohort) == 6L &&
      all(observed_cohort$effect_direction_agrees) &&
      nrow(empirical) == 8L &&
      all(empirical$positive_empirical_p > 0 &
            empirical$positive_empirical_p <= 1) &&
      all(empirical$absolute_empirical_p > 0 &
            empirical$absolute_empirical_p <= 1),
    "Final null distributions or empirical summaries failed checks."
  )

  parameter_lock <- data.frame(
    field = c(
      "Primary_random_sets",
      "Observed_signature",
      "Random_test_scoring_context",
      "Accepted_fixed_score_numeric_identity_required",
      "Endpoint_1",
      "Endpoint_2",
      "Endpoint_2_conservativeness",
      "Unused_generated_22gene_sets",
      "TCGA_association",
      "GSE31519_association",
      "GSE58812_association",
      "Meta_transformation",
      "Meta_variance",
      "Meta_model",
      "Positive_empirical_p",
      "Absolute_empirical_p",
      "Meta_empirical_BH",
      "Result_based_set_rejection",
      "Random_sets_removed_after_scoring",
      "Survival_analysis",
      "Cutoff_or_grouping",
      "Sample_filtering",
      "Figure_created",
      "Final_status"
    ),
    value = c(
      "5000 expression/variance-matched 24-gene sets; exactly 2 EMT genes",
      "Locked24 recomputed in the same GSVA call as all random sets",
      "Cohort-specific analysis matrix; observed and null fully exchangeable",
      "FALSE; concordance is reported instead",
      "Accepted full Hallmark EMT score",
      "Accepted Hallmark EMT score after removing locked24 overlap",
      paste0(
        "Conservative: random sets retain their two EMT genes in the fixed ",
        "no-overlap outcome, while observed IL6/JUN are removed"
      ),
      "Archived but not analyzed; they do not match the accepted sensitivity estimand",
      "Spearman",
      "Global ranks centered within source_dataset_id",
      "Spearman",
      "Fisher z = atanh(rho)",
      "1/(n-3)",
      "DerSimonian-Laird random effects",
      "(1 + count(null >= observed)) / 5001",
      "(1 + count(abs(null) >= abs(observed))) / 5001",
      "BH across the two prespecified endpoint-level meta empirical tests",
      "PROHIBITED",
      "0",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "MATCHED_RANDOM24_NULL_COMPLETE"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    input_name = names(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(
        PROJECT_ROOT, winslash = "/", mustWork = TRUE
      )) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed_md5,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  strengthening_status <- "MATCHED_RANDOM24_NULL_COMPLETE"
  integrity <- data.frame(
    item = c(
      "Script",
      "Script_build_ID",
      "Input_file_number",
      "Input_MD5_all_locked",
      "Random_24gene_set_number",
      "Full_EMT_null_result_number",
      "No_overlap_EMT_null_result_number",
      "Observed_cohort_comparison_row_number",
      "Observed_meta_summary_row_number",
      "Empirical_test_row_number",
      "All_recomputed_effect_directions_agree_with_accepted",
      "Score_numeric_identity_required",
      "Exchangeable_scoring_used",
      "Generated_22gene_sets_used",
      "Result_based_set_rejection",
      "Random_sets_removed_after_scoring",
      "Survival_analysis",
      "Cutoff_or_grouping",
      "Samples_filtered",
      "Figure_created",
      "Strengthening_analysis_status",
      "Completion_status"
    ),
    value = as.character(c(
      "15C_v2",
      BUILD_ID,
      length(INPUTS),
      TRUE,
      RANDOM_SET_NUMBER,
      nrow(full_null),
      nrow(overlap_null),
      nrow(observed_cohort),
      nrow(observed_meta),
      nrow(empirical),
      all(observed_cohort$effect_direction_agrees),
      FALSE,
      TRUE,
      FALSE,
      FALSE,
      0L,
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      strengthening_status,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = paste0(
      "Step5_cross_cohort_synthesis/",
      "03_matched_random_24gene_null/",
      "02_random_GSVA_and_empirical_test"
    ),
    script = "Script15C_v2",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    strengthening_analysis_status = strengthening_status,
    full_EMT_null_results = full_null,
    no_overlap_EMT_null_results = overlap_null,
    observed_cohort_effect_comparison = observed_cohort,
    observed_meta_summary = observed_meta,
    score_context_concordance = score_concordance,
    empirical_test_summary = empirical,
    null_distribution_quantiles = quantiles,
    GSVA_audit = GSVA_audit,
    correlation_method_audit = method_audit,
    parameter_lock = parameter_lock,
    input_manifest = input_manifest,
    integrity_summary = integrity,
    policy = list(
      core_analysis_remains_frozen = TRUE,
      Hallmark_panorama_remains_complete = TRUE,
      matched_random_null_completed = TRUE,
      observed_and_null_scores_exchangeable = TRUE,
      fixed_score_numeric_identity_required = FALSE,
      score_context_concordance_reported = TRUE,
      full_EMT_endpoint_analyzed = TRUE,
      no_overlap_EMT_endpoint_analyzed = TRUE,
      generated_22gene_sets_used = FALSE,
      all_5000_random24_sets_analyzed = TRUE,
      result_based_set_rejection = FALSE,
      random_sets_removed_after_scoring = 0L,
      survival_analysis_performed = FALSE,
      cutoff_selected = FALSE,
      high_low_group_created = FALSE,
      samples_filtered = FALSE,
      manuscript_figure_created = FALSE
    )
  )
  class(bundle) <- c(
    "Matched_random24_empirical_test_bundle", "list"
  )

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      ".Script15C_v2_staging_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(
    dirs, dir.create, logical(1),
    recursive = TRUE, showWarnings = FALSE
  ) | dir.exists(dirs)), "Unable to create staging directories.")

  committed <- FALSE
  on.exit(
    if (!committed && dir.exists(stage)) {
      unlink(stage, recursive = TRUE, force = TRUE)
    },
    add = TRUE
  )

  files <- c(
    bundle = file.path(
      stage, "objects",
      "Matched_random24_empirical_test_COMPLETE_bundle.rds"
    ),
    full_rds = file.path(
      stage, "objects",
      "Matched_random24_full_EMT_5000_null_results.rds"
    ),
    overlap_rds = file.path(
      stage, "objects",
      "Matched_random24_no_overlap_EMT_5000_null_results.rds"
    ),
    full_csv = file.path(
      stage, "audit",
      "Matched_random24_full_EMT_5000_null_results.csv"
    ),
    overlap_csv = file.path(
      stage, "audit",
      "Matched_random24_no_overlap_EMT_5000_null_results.csv"
    ),
    empirical = file.path(
      stage, "audit",
      "Matched_random24_empirical_test_summary.csv"
    ),
    quantiles = file.path(
      stage, "audit",
      "Matched_random24_null_distribution_quantiles.csv"
    ),
    observed_cohort = file.path(
      stage, "audit",
      "Matched_random24_observed_cohort_effect_comparison.csv"
    ),
    observed_meta = file.path(
      stage, "audit",
      "Matched_random24_observed_meta_summary.csv"
    ),
    concordance = file.path(
      stage, "audit",
      "Matched_random24_score_context_concordance.csv"
    ),
    GSVA_audit = file.path(
      stage, "audit",
      "Matched_random24_GSVA_audit.csv"
    ),
    methods = file.path(
      stage, "audit",
      "Matched_random24_correlation_method_audit.csv"
    ),
    parameters = file.path(
      stage, "audit",
      "Matched_random24_final_parameter_lock.csv"
    ),
    inputs = file.path(
      stage, "audit",
      "Script15C_v2_input_manifest_with_MD5.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "Matched_random24_final_integrity_summary.csv"
    ),
    TCGA_details = file.path(
      stage, "logs",
      "Script15C_v2_TCGA_GSVA_parameter_details.txt"
    ),
    G315_details = file.path(
      stage, "logs",
      "Script15C_v2_GSE31519_GSVA_parameter_details.txt"
    ),
    G588_details = file.path(
      stage, "logs",
      "Script15C_v2_GSE58812_GSVA_parameter_details.txt"
    ),
    session = file.path(
      stage, "logs",
      "Script15C_v2_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs",
      "Script15C_v2_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(full_null, files["full_rds"], version = 3)
  saveRDS(overlap_null, files["overlap_rds"], version = 3)

  write_csv(full_null, files["full_csv"])
  write_csv(overlap_null, files["overlap_csv"])
  write_csv(empirical, files["empirical"])
  write_csv(quantiles, files["quantiles"])
  write_csv(observed_cohort, files["observed_cohort"])
  write_csv(observed_meta, files["observed_meta"])
  write_csv(score_concordance, files["concordance"])
  write_csv(GSVA_audit, files["GSVA_audit"])
  write_csv(method_audit, files["methods"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(input_manifest, files["inputs"])
  write_csv(integrity, files["integrity"])

  writeLines(
    cohort_results$TCGA_TNBC$GSVA_parameter_details,
    files["TCGA_details"],
    useBytes = TRUE
  )
  writeLines(
    cohort_results$GSE31519$GSVA_parameter_details,
    files["G315_details"],
    useBytes = TRUE
  )
  writeLines(
    cohort_results$GSE58812$GSVA_parameter_details,
    files["G588_details"],
    useBytes = TRUE
  )
  capture.output(sessionInfo(), file = files["session"])

  full_meta_empirical <- empirical[
    empirical$endpoint == "FULL_HALLMARK_EMT" &
      empirical$level == "RANDOM_EFFECTS_META",
    ,
    drop = FALSE
  ]
  overlap_meta_empirical <- empirical[
    empirical$endpoint == "NO_OVERLAP_HALLMARK_EMT" &
      empirical$level == "RANDOM_EFFECTS_META",
    ,
    drop = FALSE
  ]

  report <- c(
    "============================================================",
    "TNBC_Triclosan - Script15C v2 Exchangeable Random24 Test",
    paste0("Script build ID: ", BUILD_ID),
    paste0(
      "Completion time: ",
      format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
    ),
    "Matched random 24-gene sets analyzed: 5000/5000",
    "Random sets removed after scoring: 0",
    "Generated random22 sets used: FALSE",
    "Observed and null signatures scored exchangeably: TRUE",
    "Fixed-score numeric identity required: FALSE",
    paste0(
      "TCGA recomputed/fixed score Spearman concordance: ",
      format(
        score_concordance$Spearman_concordance[
          score_concordance$cohort == "TCGA_TNBC"
        ],
        digits = 16
      )
    ),
    paste0(
      "Recomputed full-EMT pooled rho: ",
      format(observed_full_meta$random_pooled_rho, digits = 16)
    ),
    paste0(
      "Full-EMT positive empirical p: ",
      format(
        full_meta_empirical$positive_empirical_p,
        digits = 16
      )
    ),
    paste0(
      "Full-EMT absolute empirical p: ",
      format(
        full_meta_empirical$absolute_empirical_p,
        digits = 16
      )
    ),
    paste0(
      "Full-EMT observed percentile: ",
      format(
        full_meta_empirical$observed_percentile,
        digits = 12
      ), "%"
    ),
    paste0(
      "Recomputed no-overlap-EMT pooled rho: ",
      format(observed_overlap_meta$random_pooled_rho, digits = 16)
    ),
    paste0(
      "No-overlap-EMT positive empirical p: ",
      format(
        overlap_meta_empirical$positive_empirical_p,
        digits = 16
      )
    ),
    paste0(
      "No-overlap-EMT absolute empirical p: ",
      format(
        overlap_meta_empirical$absolute_empirical_p,
        digits = 16
      )
    ),
    paste0(
      "No-overlap-EMT observed percentile: ",
      format(
        overlap_meta_empirical$observed_percentile,
        digits = 12
      ), "%"
    ),
    "All recomputed effect directions agree with accepted effects: TRUE",
    "Result-based set rejection: FALSE",
    "Survival/cutoff/grouping/sample filtering/figure: FALSE",
    paste0(
      "Strengthening analysis status: ",
      strengthening_status
    ),
    "",
    "SCRIPT15C_V2 STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(
    all(file.exists(files)) &&
      all(file.info(files)$size > 0),
    "At least one staged output is missing or empty."
  )

  b2 <- readRDS(files["bundle"])
  f2 <- readRDS(files["full_rds"])
  o2 <- readRDS(files["overlap_rds"])
  e2 <- read.csv(
    files["empirical"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert(
    same_text(
      b2$strengthening_analysis_status,
      "MATCHED_RANDOM24_NULL_COMPLETE"
    ) &&
      identical(f2, full_null) &&
      identical(o2, overlap_null) &&
      nrow(e2) == 8L &&
      same_numeric(
        e2$positive_empirical_p,
        empirical$positive_empirical_p,
        tolerance = 1e-14
      ) &&
      same_numeric(
        e2$absolute_empirical_p,
        empirical$absolute_empirical_p,
        tolerance = 1e-14
      ),
    "Staged RDS/CSV save-read verification failed."
  )

  output_manifest <- file.path(
    stage, "audit",
    "Script15C_v2_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(
    manifest_ok(stage, output_manifest),
    "Staged output manifest verification failed."
  )

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script15C_v2_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script15C_v2_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(
    existing_valid(OUTPUT_ROOT),
    "Post-commit completed-output validation failed."
  )

  unlink(CACHE_ROOT, recursive = TRUE, force = TRUE)

  cat("============================================================\n")
  cat("Script15C v2 completed successfully.\n")
  cat("All 5,000 matched random24 sets were analyzed.\n")
  cat(
    "Full-EMT meta positive empirical p: ",
    format(
      full_meta_empirical$positive_empirical_p,
      digits = 16
    ), "\n",
    sep = ""
  )
  cat(
    "No-overlap-EMT meta positive empirical p: ",
    format(
      overlap_meta_empirical$positive_empirical_p,
      digits = 16
    ), "\n",
    sep = ""
  )
  cat(
    "Strengthening analysis status: ",
    strengthening_status, "\n",
    sep = ""
  )
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

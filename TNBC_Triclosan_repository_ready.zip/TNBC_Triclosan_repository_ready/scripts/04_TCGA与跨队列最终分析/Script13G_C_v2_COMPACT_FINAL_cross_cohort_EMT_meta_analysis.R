# ==============================================================================
# TNBC_Triclosan | Script 13G-C COMPACT FINAL
# Final TCGA/GSE31519/GSE58812 EMT-correlation meta-analysis.
#
# Primary effect:
#   continuous Spearman association between locked Triclosan_activity and
#   full Hallmark EMT score.
#
# Primary within-cohort variance:
#   empirical SD of Fisher-z-transformed bootstrap correlations.
# This is used because GSE31519 employs a source-adjusted partial Spearman
# estimator with within-source bootstrap resampling.
#
# Prespecified sensitivity:
# - overlap-removed EMT effects using the same empirical variance method;
# - conventional Fisher-z variance 1/(n-3);
# - leave-one-cohort-out synthesis.
#
# No new scoring, expression analysis, survival analysis, cutoff, high/low
# grouping, DEG, PCA, GSEA or manuscript figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13G_C_v2_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"

TCGA_ROOT <- file.path(
  PROJECT_ROOT, "Step5_cross_cohort_synthesis",
  "00_TCGA_TNBC_EMT_revalidation"
)
GSE31519_ROOT <- file.path(
  PROJECT_ROOT, "Step2_GSE31519_external_validation",
  "13_EMT_external_validation"
)
GSE58812_ROOT <- file.path(
  PROJECT_ROOT, "Step4_GSE58812_external_validation",
  "05_EMT_external_validation_and_continuous_survival"
)
OUTPUT_ROOT <- file.path(
  PROJECT_ROOT, "Step5_cross_cohort_synthesis",
  "01_final_EMT_correlation_meta_analysis"
)

INPUTS <- c(
  TCGA_bundle = file.path(
    TCGA_ROOT, "objects",
    "TCGA_TNBC_EMT_revalidation_COMPLETE_bundle.rds"
  ),
  TCGA_bootstrap = file.path(
    TCGA_ROOT, "objects",
    "TCGA_TNBC_EMT_correlation_bootstrap_distributions.rds"
  ),
  TCGA_manifest = file.path(
    TCGA_ROOT, "audit",
    "Script13G_B_output_manifest_with_MD5.csv"
  ),
  TCGA_report = file.path(
    TCGA_ROOT, "logs",
    "Script13G_B_COMPLETE_report.txt"
  ),
  GSE31519_bundle = file.path(
    GSE31519_ROOT, "objects",
    "GSE31519_EMT_external_validation_COMPLETE_bundle.rds"
  ),
  GSE31519_bootstrap = file.path(
    GSE31519_ROOT, "objects",
    "GSE31519_EMT_source_adjusted_resampling_distributions.rds"
  ),
  GSE31519_manifest = file.path(
    GSE31519_ROOT, "audit",
    "Script13G_A_output_manifest_with_MD5.csv"
  ),
  GSE31519_report = file.path(
    GSE31519_ROOT, "logs",
    "Script13G_A_COMPLETE_report.txt"
  ),
  GSE58812_bundle = file.path(
    GSE58812_ROOT, "objects",
    "GSE58812_EMT_and_continuous_survival_COMPLETE_bundle.rds"
  ),
  GSE58812_bootstrap = file.path(
    GSE58812_ROOT, "objects",
    "GSE58812_EMT_correlation_bootstrap_distributions.rds"
  ),
  GSE58812_manifest = file.path(
    GSE58812_ROOT, "audit",
    "Script13F_output_manifest_with_MD5.csv"
  ),
  GSE58812_report = file.path(
    GSE58812_ROOT, "logs",
    "Script13F_COMPLETE_report.txt"
  )
)

EXPECTED_MD5 <- c(
  TCGA_bundle = "5c5d22abedd020fa9086b6fde82ee3d4",
  TCGA_bootstrap = "3598390e0c854ae0d02825900e103a57",
  TCGA_manifest = "d45031673a08dcffe8806839ab8e9b5c",
  TCGA_report = "e8ea21abe7a908b6441f8d80689f4cf1",
  GSE31519_bundle = "c38714208098bd8871b4d7b16b36f0bf",
  GSE31519_bootstrap = "5cbaf6237f44adc573ca123145097a86",
  GSE31519_manifest = "219cac414bb58e2d19d7947c65963ed7",
  GSE31519_report = "d763ae64264b716698eaedf1e241d4f1",
  GSE58812_bundle = "cd256862701cf62ac041b7d56f6fc45d",
  GSE58812_bootstrap = "1abfe36a891ff4097ced48be66c3c839",
  GSE58812_manifest = "f6021fe8d5114bac5d6a85c505a7ec91",
  GSE58812_report = "5238da233c70189c38cf6dc94b263ead"
)

EXPECTED_PRIMARY_RHO <- c(
  TCGA_TNBC = 0.474691491732826,
  GSE31519 = 0.4222513341893304,
  GSE58812 = 0.3773193048453144
)
EXPECTED_NO_OVERLAP_RHO <- c(
  TCGA_TNBC = 0.4716762570279611,
  GSE31519 = 0.4174924759868561,
  GSE58812 = 0.3678265640000785
)
EXPECTED_N <- c(
  TCGA_TNBC = 197L,
  GSE31519 = 579L,
  GSE58812 = 107L
)
BOOTSTRAP_N <- 10000L

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)
clip_correlation <- function(x) pmax(pmin(as.numeric(x), 0.999999), -0.999999)

report_contains <- function(file, marker) {
  any(grepl(
    marker,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)

    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)

    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

select_one <- function(data, condition, label) {
  i <- which(condition)
  assert(length(i) == 1L,
         "%s must select exactly one row; selected %d.", label, length(i))
  data[i, , drop = FALSE]
}

bootstrap_audit <- function(values, reported_lower, reported_upper, label) {
  x <- as.numeric(values)
  assert(length(x) == BOOTSTRAP_N,
         "%s bootstrap length is %d, expected %d.",
         label, length(x), BOOTSTRAP_N)
  assert(all(is.finite(x)),
         "%s bootstrap contains non-finite values.", label)
  assert(all(x > -1 & x < 1),
         "%s bootstrap contains an invalid correlation.", label)

  q <- unname(quantile(x, c(0.025, 0.975)))
  assert(isTRUE(all.equal(
    q,
    c(as.numeric(reported_lower), as.numeric(reported_upper)),
    tolerance = 1e-12,
    check.attributes = FALSE
  )), "%s bootstrap interval does not reproduce the reported interval.", label)

  z_boot <- atanh(clip_correlation(x))
  se_z <- sd(z_boot)
  assert(is.finite(se_z) && se_z > 0,
         "%s empirical Fisher-z SE is invalid.", label)

  list(
    values = x,
    CI_lower = q[1L],
    CI_upper = q[2L],
    fisher_z_bootstrap_SE = se_z,
    fisher_z_bootstrap_variance = se_z^2
  )
}

extract_effect <- function(
  cohort, bundle, bootstrap_object,
  primary_table_name, primary_bootstrap_name,
  no_overlap_bootstrap_name
) {
  results <- bundle[[primary_table_name]]
  assert(is.data.frame(results) && nrow(results) >= 2L,
         "%s correlation-result table is malformed.", cohort)
  assert(all(c(
    "analysis", "method", "sample_number", "estimate",
    "confidence_interval_lower", "confidence_interval_upper",
    "two_sided_p", "primary_analysis"
  ) %in% names(results)),
  "%s correlation-result columns are incomplete.", cohort)

  primary_flag <- as.logical(results$primary_analysis)
  assert(
    !any(is.na(primary_flag)),
    "%s primary_analysis contains missing or non-logical values.", cohort
  )
  primary <- select_one(
    results,
    primary_flag,
    paste0(cohort, " primary effect")
  )

  analysis_normalized <- toupper(trimws(as.character(results$analysis)))
  method_normalized <- toupper(trimws(as.character(results$method)))
  primary_method_normalized <-
    toupper(trimws(as.character(primary$method[1L])))

  EMT_score_normalized <- if ("EMT_score" %in% names(results)) {
    toupper(trimws(as.character(results$EMT_score)))
  } else {
    rep("", nrow(results))
  }

  overlap_label <- grepl(
    "NO_OVERLAP|WITHOUT_LOCKED24_OVERLAP",
    analysis_normalized
  ) |
    EMT_score_normalized == "HALLMARK_EMT_NO_TRICLOSAN_OVERLAP"

  overlap_condition <-
    !primary_flag &
    overlap_label &
    method_normalized == primary_method_normalized

  overlap_index <- which(overlap_condition)
  if (length(overlap_index) != 1L) {
    diagnostic <- data.frame(
      row_number = seq_len(nrow(results)),
      analysis = as.character(results$analysis),
      method = as.character(results$method),
      EMT_score = if ("EMT_score" %in% names(results)) {
        as.character(results$EMT_score)
      } else {
        NA_character_
      },
      primary_analysis = primary_flag,
      overlap_label_detected = overlap_label,
      method_matches_primary =
        method_normalized == primary_method_normalized,
      selected_as_overlap = overlap_condition,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
    stopf(
      paste0(
        "%s overlap-removed effect selection returned %d row(s).\n",
        "Primary method: %s\n",
        "Available rows:\n%s"
      ),
      cohort,
      length(overlap_index),
      as.character(primary$method[1L]),
      paste(capture.output(print(diagnostic)), collapse = "\n")
    )
  }
  overlap <- results[overlap_index, , drop = FALSE]

  primary_boot <- bootstrap_audit(
    bootstrap_object[[primary_bootstrap_name]],
    primary$confidence_interval_lower,
    primary$confidence_interval_upper,
    paste0(cohort, " primary")
  )
  overlap_boot <- bootstrap_audit(
    bootstrap_object[[no_overlap_bootstrap_name]],
    overlap$confidence_interval_lower,
    overlap$confidence_interval_upper,
    paste0(cohort, " overlap-removed")
  )

  build_row <- function(row, boot, effect_set) {
    n <- as.integer(row$sample_number)
    rho <- as.numeric(row$estimate)
    assert(n == EXPECTED_N[cohort],
           "%s sample number differs from the accepted lock.", cohort)
    expected <- if (effect_set == "FULL_EMT") {
      EXPECTED_PRIMARY_RHO[cohort]
    } else {
      EXPECTED_NO_OVERLAP_RHO[cohort]
    }
    assert(isTRUE(all.equal(
      rho, unname(expected),
      tolerance = 1e-14, check.attributes = FALSE
    )), "%s %s rho differs from the accepted lock.", cohort, effect_set)

    data.frame(
      cohort = cohort,
      effect_set = effect_set,
      estimator = as.character(row$method),
      estimator_detail = if (cohort == "GSE31519") {
        "Source-adjusted partial Spearman"
      } else {
        "Cohort-level Spearman"
      },
      sample_number = n,
      rho = rho,
      fisher_z = atanh(clip_correlation(rho)),
      reported_two_sided_p = as.numeric(row$two_sided_p),
      reported_bootstrap_CI_lower =
        as.numeric(row$confidence_interval_lower),
      reported_bootstrap_CI_upper =
        as.numeric(row$confidence_interval_upper),
      bootstrap_number = BOOTSTRAP_N,
      empirical_fisher_z_SE = boot$fisher_z_bootstrap_SE,
      empirical_fisher_z_variance =
        boot$fisher_z_bootstrap_variance,
      conventional_fisher_z_SE = 1 / sqrt(n - 3),
      conventional_fisher_z_variance = 1 / (n - 3),
      direction_positive = rho > 0,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  list(
    primary = build_row(primary, primary_boot, "FULL_EMT"),
    overlap = build_row(overlap, overlap_boot, "NO_OVERLAP_EMT"),
    primary_bootstrap = primary_boot$values,
    overlap_bootstrap = overlap_boot$values
  )
}

meta_summary <- function(effect_table, variance_column, analysis, variance_method) {
  assert(nrow(effect_table) >= 2L,
         "Meta-analysis requires at least two cohorts.")
  assert(all(effect_table$rho > -1 & effect_table$rho < 1),
         "Meta-analysis contains an invalid correlation.")

  z <- as.numeric(effect_table$fisher_z)
  v <- as.numeric(effect_table[[variance_column]])
  assert(all(is.finite(v) & v > 0),
         "Meta-analysis variances are invalid.")

  k <- length(z)
  w <- 1 / v
  z_fixed <- sum(w * z) / sum(w)
  se_fixed <- sqrt(1 / sum(w))

  Q <- sum(w * (z - z_fixed)^2)
  Q_df <- k - 1L
  Q_p <- pchisq(Q, df = Q_df, lower.tail = FALSE)
  I2 <- if (Q > 0) max(0, (Q - Q_df) / Q) * 100 else 0
  C <- sum(w) - sum(w^2) / sum(w)
  tau2 <- if (C > 0) max(0, (Q - Q_df) / C) else 0

  wr <- 1 / (v + tau2)
  z_random <- sum(wr * z) / sum(wr)
  se_random <- sqrt(1 / sum(wr))

  residual_scale <- if (k > 1L) {
    max(1, sum(wr * (z - z_random)^2) / (k - 1L))
  } else {
    1
  }
  se_mKH <- sqrt(residual_scale / sum(wr))
  t_df <- k - 1L

  row_result <- function(
    pooling_method, estimate_z, standard_error,
    distribution, degrees_of_freedom = NA_real_
  ) {
    if (distribution == "NORMAL") {
      critical <- qnorm(0.975)
      p <- 2 * pnorm(
        abs(estimate_z / standard_error),
        lower.tail = FALSE
      )
    } else {
      critical <- qt(0.975, df = degrees_of_freedom)
      p <- 2 * pt(
        abs(estimate_z / standard_error),
        df = degrees_of_freedom,
        lower.tail = FALSE
      )
    }

    lower_z <- estimate_z - critical * standard_error
    upper_z <- estimate_z + critical * standard_error

    data.frame(
      analysis = analysis,
      variance_method = variance_method,
      pooling_method = pooling_method,
      cohort_number = k,
      total_sample_number = sum(effect_table$sample_number),
      pooled_fisher_z = estimate_z,
      standard_error = standard_error,
      inference_distribution = distribution,
      inference_df = degrees_of_freedom,
      critical_value = critical,
      confidence_level = 0.95,
      confidence_interval_lower_z = lower_z,
      confidence_interval_upper_z = upper_z,
      pooled_rho = tanh(estimate_z),
      confidence_interval_lower_rho = tanh(lower_z),
      confidence_interval_upper_rho = tanh(upper_z),
      two_sided_p = p,
      Cochran_Q = Q,
      Q_df = Q_df,
      Q_p = Q_p,
      I2_percent = I2,
      tau2 = tau2,
      modified_KH_residual_scale = if (
        pooling_method == "RANDOM_DL_MODIFIED_KH"
      ) residual_scale else NA_real_,
      all_cohort_directions_positive =
        all(effect_table$direction_positive),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  rbind(
    row_result(
      "FIXED_INVERSE_VARIANCE_NORMAL",
      z_fixed, se_fixed, "NORMAL"
    ),
    row_result(
      "RANDOM_DL_NORMAL",
      z_random, se_random, "NORMAL"
    ),
    row_result(
      "RANDOM_DL_MODIFIED_KH",
      z_random, se_mKH, "T", t_df
    )
  )
}

leave_one_out_meta <- function(effect_table, analysis) {
  cohorts <- as.character(effect_table$cohort)
  do.call(rbind, lapply(seq_along(cohorts), function(i) {
    reduced <- effect_table[-i, , drop = FALSE]
    meta <- meta_summary(
      reduced,
      "empirical_fisher_z_variance",
      analysis,
      "EMPIRICAL_BOOTSTRAP_FISHER_Z"
    )
    selected <- meta[
      meta$pooling_method %in%
        c("FIXED_INVERSE_VARIANCE_NORMAL", "RANDOM_DL_NORMAL"),
      ,
      drop = FALSE
    ]
    data.frame(
      analysis = analysis,
      omitted_cohort = cohorts[i],
      retained_cohort_number = nrow(reduced),
      retained_total_sample_number = sum(reduced$sample_number),
      pooling_method = selected$pooling_method,
      pooled_rho = selected$pooled_rho,
      confidence_interval_lower_rho =
        selected$confidence_interval_lower_rho,
      confidence_interval_upper_rho =
        selected$confidence_interval_upper_rho,
      two_sided_p = selected$two_sided_p,
      Cochran_Q = selected$Cochran_Q,
      Q_p = selected$Q_p,
      I2_percent = selected$I2_percent,
      tau2 = selected$tau2,
      all_retained_directions_positive =
        selected$all_cohort_directions_positive,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "Cross_cohort_EMT_meta_analysis_COMPLETE_bundle.rds"
    ),
    manifest = file.path(
      root, "audit",
      "Script13G_C_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script13G_C_COMPLETE_report.txt"
    )
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT13G_C STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  is.list(b) &&
    identical(as.character(b$script), "Script13G_C") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    nrow(b$primary_effects) == 3L &&
    nrow(b$overlap_removed_effects) == 3L &&
    nrow(b$primary_meta_empirical) == 3L &&
    nrow(b$overlap_meta_empirical) == 3L &&
    nrow(b$leave_one_cohort_out) == 12L &&
    identical(as.character(b$analysis_freeze_decision), "FREEZE_ANALYSIS") &&
    isFALSE(b$policy$new_biological_analysis_performed)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT),
           "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13G-C output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "01_final_EMT_correlation_meta_analysis_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Final three-cohort EMT correlation meta-analysis only.\n")
  cat("============================================================\n")

  missing <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing), "Missing accepted input(s):\n%s",
         paste(missing, collapse = "\n"))

  observed_md5 <- vapply(INPUTS, md5, character(1))
  assert(identical(observed_md5, EXPECTED_MD5),
         "At least one accepted input MD5 differs.\n%s",
         paste(sprintf(
           "%s: expected %s; observed %s",
           names(EXPECTED_MD5), EXPECTED_MD5, observed_md5
         ), collapse = "\n"))

  assert(manifest_ok(TCGA_ROOT, INPUTS["TCGA_manifest"]),
         "TCGA output manifest verification failed.")
  assert(manifest_ok(GSE31519_ROOT, INPUTS["GSE31519_manifest"]),
         "GSE31519 output manifest verification failed.")
  assert(manifest_ok(GSE58812_ROOT, INPUTS["GSE58812_manifest"]),
         "GSE58812 output manifest verification failed.")

  assert(report_contains(
    INPUTS["TCGA_report"], "SCRIPT13G_B STATUS: COMPLETE"
  ), "TCGA completion marker is missing.")
  assert(report_contains(
    INPUTS["GSE31519_report"], "SCRIPT13G_A STATUS: COMPLETE"
  ), "GSE31519 completion marker is missing.")
  assert(report_contains(
    INPUTS["GSE58812_report"], "SCRIPT13F STATUS: COMPLETE"
  ), "GSE58812 completion marker is missing.")

  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  TCGA_bundle <- readRDS(INPUTS["TCGA_bundle"])
  TCGA_bootstrap <- readRDS(INPUTS["TCGA_bootstrap"])
  GSE31519_bundle <- readRDS(INPUTS["GSE31519_bundle"])
  GSE31519_bootstrap <- readRDS(INPUTS["GSE31519_bootstrap"])
  GSE58812_bundle <- readRDS(INPUTS["GSE58812_bundle"])
  GSE58812_bootstrap <- readRDS(INPUTS["GSE58812_bootstrap"])

  assert(
    identical(as.character(TCGA_bundle$script), "Script13G_B") &&
      identical(
        as.character(TCGA_bundle$script_build_id),
        "Script13G_B_v4_COMPACT_FINAL_20260711"
      ) &&
      nrow(TCGA_bundle$sample_level_scores) == 197L &&
      !anyDuplicated(
        as.character(TCGA_bundle$sample_level_scores$sample_id)
      ) &&
      isFALSE(TCGA_bundle$policy$many_to_many_join_performed),
    "Accepted TCGA bundle identity or 197-sample lock is incorrect."
  )
  assert(
    identical(as.character(GSE31519_bundle$script), "Script13G_A") &&
      identical(
        as.character(GSE31519_bundle$script_build_id),
        "Script13G_A_COMPACT_FINAL_20260711"
      ) &&
      nrow(GSE31519_bundle$sample_level_scores) == 579L &&
      isFALSE(GSE31519_bundle$policy$samples_filtered),
    "Accepted GSE31519 bundle identity is incorrect."
  )
  assert(
    identical(as.character(GSE58812_bundle$script), "Script13F") &&
      identical(
        as.character(GSE58812_bundle$script_build_id),
        "Script13F_COMPACT_FINAL_20260711"
      ) &&
      nrow(GSE58812_bundle$sample_level_scores_and_clinical) == 107L &&
      isFALSE(GSE58812_bundle$policy$samples_filtered) &&
      isFALSE(GSE58812_bundle$policy$cutoff_selected),
    "Accepted GSE58812 bundle identity is incorrect."
  )

  TCGA <- extract_effect(
    "TCGA_TNBC",
    TCGA_bundle,
    TCGA_bootstrap,
    "correlation_results",
    "primary_full_EMT",
    "sensitivity_no_overlap_EMT"
  )
  GSE31519 <- extract_effect(
    "GSE31519",
    GSE31519_bundle,
    GSE31519_bootstrap,
    "primary_and_sensitivity_results",
    "primary_bootstrap",
    "no_overlap_bootstrap"
  )
  GSE58812 <- extract_effect(
    "GSE58812",
    GSE58812_bundle,
    GSE58812_bootstrap,
    "EMT_correlation_results",
    "primary_full_EMT",
    "sensitivity_no_overlap_EMT"
  )

  primary_effects <- rbind(
    TCGA$primary, GSE31519$primary, GSE58812$primary
  )
  overlap_effects <- rbind(
    TCGA$overlap, GSE31519$overlap, GSE58812$overlap
  )
  rownames(primary_effects) <- NULL
  rownames(overlap_effects) <- NULL

  assert(
    identical(as.character(primary_effects$cohort), names(EXPECTED_N)) &&
      identical(as.integer(primary_effects$sample_number),
                as.integer(EXPECTED_N)) &&
      all(primary_effects$direction_positive),
    "Primary effect table failed cohort, sample or direction checks."
  )
  assert(
    identical(as.character(overlap_effects$cohort), names(EXPECTED_N)) &&
      all(overlap_effects$direction_positive),
    "Overlap-removed effect table failed cohort or direction checks."
  )

  primary_meta_empirical <- meta_summary(
    primary_effects,
    "empirical_fisher_z_variance",
    "FULL_HALLMARK_EMT",
    "EMPIRICAL_BOOTSTRAP_FISHER_Z"
  )
  overlap_meta_empirical <- meta_summary(
    overlap_effects,
    "empirical_fisher_z_variance",
    "NO_OVERLAP_HALLMARK_EMT",
    "EMPIRICAL_BOOTSTRAP_FISHER_Z"
  )
  primary_meta_conventional <- meta_summary(
    primary_effects,
    "conventional_fisher_z_variance",
    "FULL_HALLMARK_EMT",
    "CONVENTIONAL_1_OVER_N_MINUS_3"
  )

  leave_primary <- leave_one_out_meta(
    primary_effects, "FULL_HALLMARK_EMT"
  )
  leave_overlap <- leave_one_out_meta(
    overlap_effects, "NO_OVERLAP_HALLMARK_EMT"
  )
  leave_one_out <- rbind(leave_primary, leave_overlap)
  rownames(leave_one_out) <- NULL

  primary_random <- select_one(
    primary_meta_empirical,
    primary_meta_empirical$pooling_method == "RANDOM_DL_NORMAL",
    "Primary random-effects meta row"
  )
  primary_mKH <- select_one(
    primary_meta_empirical,
    primary_meta_empirical$pooling_method == "RANDOM_DL_MODIFIED_KH",
    "Primary modified-KH meta row"
  )
  overlap_random <- select_one(
    overlap_meta_empirical,
    overlap_meta_empirical$pooling_method == "RANDOM_DL_NORMAL",
    "Overlap random-effects meta row"
  )
  conventional_random <- select_one(
    primary_meta_conventional,
    primary_meta_conventional$pooling_method == "RANDOM_DL_NORMAL",
    "Conventional-variance random-effects row"
  )

  freeze_summary <- data.frame(
    item = c(
      "Analysis_freeze_decision",
      "Cohorts_in_primary_meta",
      "Total_primary_sample_number",
      "All_primary_directions_positive",
      "Primary_random_effects_pooled_rho",
      "Primary_random_effects_95CI_lower",
      "Primary_random_effects_95CI_upper",
      "Primary_random_effects_p",
      "Primary_modified_KH_95CI_lower",
      "Primary_modified_KH_95CI_upper",
      "Primary_modified_KH_p",
      "Primary_I2_percent",
      "Primary_Q_p",
      "Primary_tau2",
      "Overlap_removed_random_effects_pooled_rho",
      "Overlap_removed_random_effects_95CI_lower",
      "Overlap_removed_random_effects_95CI_upper",
      "Conventional_variance_random_effects_pooled_rho",
      "Conventional_variance_random_effects_95CI_lower",
      "Conventional_variance_random_effects_95CI_upper",
      "Leave_one_out_random_minimum_pooled_rho",
      "Leave_one_out_random_minimum_95CI_lower",
      "Prognostic_claim_supported",
      "Causal_exposure_claim_supported",
      "Recommended_manuscript_claim",
      "Additional_machine_learning_or_cutoff_work"
    ),
    value = as.character(c(
      "FREEZE_ANALYSIS",
      paste(primary_effects$cohort, collapse = ";"),
      sum(primary_effects$sample_number),
      all(primary_effects$direction_positive),
      primary_random$pooled_rho,
      primary_random$confidence_interval_lower_rho,
      primary_random$confidence_interval_upper_rho,
      primary_random$two_sided_p,
      primary_mKH$confidence_interval_lower_rho,
      primary_mKH$confidence_interval_upper_rho,
      primary_mKH$two_sided_p,
      primary_random$I2_percent,
      primary_random$Q_p,
      primary_random$tau2,
      overlap_random$pooled_rho,
      overlap_random$confidence_interval_lower_rho,
      overlap_random$confidence_interval_upper_rho,
      conventional_random$pooled_rho,
      conventional_random$confidence_interval_lower_rho,
      conventional_random$confidence_interval_upper_rho,
      min(
        leave_primary$pooled_rho[
          leave_primary$pooling_method == "RANDOM_DL_NORMAL"
        ]
      ),
      min(
        leave_primary$confidence_interval_lower_rho[
          leave_primary$pooling_method == "RANDOM_DL_NORMAL"
        ]
      ),
      FALSE,
      FALSE,
      paste0(
        "Triclosan-associated transcriptional activity is reproducibly ",
        "associated with EMT-related tumor state in human TNBC, while ",
        "prognostic value and direct exposure validation are limited."
      ),
      "NOT_RECOMMENDED"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  parameter_lock <- data.frame(
    field = c(
      "Primary_effect",
      "Primary_cohorts",
      "Primary_variance",
      "Primary_transformation",
      "Primary_pooling",
      "Random_effects_tau2",
      "Small_k_sensitivity",
      "Overlap_sensitivity",
      "Conventional_variance_sensitivity",
      "Leave_one_cohort_out",
      "Effect_direction",
      "Survival_reanalysis",
      "New_expression_or_scoring_analysis",
      "Cutoff_high_low_KM",
      "DEG_PCA_GSEA_figure",
      "Post_meta_analysis_status"
    ),
    value = c(
      "Continuous Spearman Triclosan_activity versus full Hallmark EMT",
      "TCGA_TNBC;GSE31519;GSE58812",
      "Empirical SD of Fisher-z-transformed cohort bootstrap correlations",
      "Fisher z = atanh(rho)",
      "Fixed inverse variance and DerSimonian-Laird random effects",
      "DerSimonian-Laird",
      "Modified Knapp-Hartung t inference with scale not below 1",
      "Repeat meta with overlap-removed EMT scores",
      "Repeat primary meta with variance 1/(n-3)",
      "Fixed and DL-random synthesis after omitting each cohort",
      "Positive prespecified direction",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "FREEZE_ANALYSIS"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    final_cross_cohort_meta_performed = TRUE,
    empirical_bootstrap_variance_primary = TRUE,
    conventional_variance_sensitivity_performed = TRUE,
    overlap_removed_sensitivity_performed = TRUE,
    leave_one_cohort_out_performed = TRUE,
    new_biological_analysis_performed = FALSE,
    new_Triclosan_score_calculated = FALSE,
    expression_values_reprocessed = FALSE,
    survival_model_fitted = FALSE,
    samples_filtered = FALSE,
    outliers_removed = FALSE,
    cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    Kaplan_Meier_performed = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE,
    analysis_frozen_after_completion = TRUE
  )

  integrity <- data.frame(
    item = c(
      "Script","Script_build_ID",
      "TCGA_bundle_MD5","TCGA_bootstrap_MD5",
      "GSE31519_bundle_MD5","GSE31519_bootstrap_MD5",
      "GSE58812_bundle_MD5","GSE58812_bootstrap_MD5",
      "Primary_cohort_number","Primary_total_sample_number",
      "Primary_positive_direction_number",
      "Primary_bootstrap_vectors_valid",
      "Overlap_bootstrap_vectors_valid",
      "Primary_meta_rows","Overlap_meta_rows",
      "Conventional_sensitivity_rows","Leave_one_out_rows",
      "New_biological_analysis_performed",
      "New_score_calculated","Expression_reprocessed",
      "Survival_model_fitted","Samples_filtered","Outliers_removed",
      "Cutoff_selected","High_low_group_created",
      "Kaplan_Meier_performed","DEG_performed","PCA_performed",
      "GSEA_performed","Manuscript_figure_created",
      "Analysis_frozen","Completion_status"
    ),
    value = as.character(c(
      "13G_C",BUILD_ID,
      EXPECTED_MD5["TCGA_bundle"],EXPECTED_MD5["TCGA_bootstrap"],
      EXPECTED_MD5["GSE31519_bundle"],EXPECTED_MD5["GSE31519_bootstrap"],
      EXPECTED_MD5["GSE58812_bundle"],EXPECTED_MD5["GSE58812_bootstrap"],
      nrow(primary_effects),sum(primary_effects$sample_number),
      sum(primary_effects$direction_positive),
      all(primary_effects$bootstrap_number == BOOTSTRAP_N),
      all(overlap_effects$bootstrap_number == BOOTSTRAP_N),
      nrow(primary_meta_empirical),nrow(overlap_meta_empirical),
      nrow(primary_meta_conventional),nrow(leave_one_out),
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,FALSE,FALSE,FALSE,TRUE,"COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    source = c(
      rep("TCGA_TNBC_Script13G_B", 4L),
      rep("GSE31519_Script13G_A", 4L),
      rep("GSE58812_Script13F", 4L)
    ),
    file_name = basename(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed_md5,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step5_cross_cohort_synthesis",
    script = "Script13G_C",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    primary_effects = primary_effects,
    overlap_removed_effects = overlap_effects,
    primary_meta_empirical = primary_meta_empirical,
    overlap_meta_empirical = overlap_meta_empirical,
    primary_meta_conventional_sensitivity =
      primary_meta_conventional,
    leave_one_cohort_out = leave_one_out,
    analysis_freeze_summary = freeze_summary,
    analysis_freeze_decision = "FREEZE_ANALYSIS",
    parameter_lock = parameter_lock,
    integrity_summary = integrity,
    policy = policy
  )
  class(bundle) <- c(
    "TNBC_Triclosan_cross_cohort_EMT_meta_bundle", "list"
  )

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(".Script13G_C_staging_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) |
               dir.exists(dirs)),
         "Unable to create staging directories.")

  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "Cross_cohort_EMT_meta_analysis_COMPLETE_bundle.rds"
    ),
    primary_effects = file.path(
      stage, "audit",
      "Cross_cohort_EMT_primary_effects.csv"
    ),
    overlap_effects = file.path(
      stage, "audit",
      "Cross_cohort_EMT_overlap_removed_effects.csv"
    ),
    primary_meta = file.path(
      stage, "audit",
      "Cross_cohort_EMT_primary_meta_empirical_bootstrap_variance.csv"
    ),
    overlap_meta = file.path(
      stage, "audit",
      "Cross_cohort_EMT_overlap_removed_meta_empirical_bootstrap_variance.csv"
    ),
    conventional_meta = file.path(
      stage, "audit",
      "Cross_cohort_EMT_primary_meta_conventional_variance_sensitivity.csv"
    ),
    leave_one_out = file.path(
      stage, "audit",
      "Cross_cohort_EMT_leave_one_cohort_out.csv"
    ),
    freeze = file.path(
      stage, "audit",
      "Cross_cohort_EMT_analysis_freeze_summary.csv"
    ),
    parameters = file.path(
      stage, "audit",
      "Cross_cohort_EMT_meta_parameter_lock.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "Cross_cohort_EMT_meta_integrity_summary.csv"
    ),
    inputs = file.path(
      stage, "audit",
      "Script13G_C_input_manifest_with_MD5.csv"
    ),
    session = file.path(
      stage, "logs",
      "Script13G_C_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs",
      "Script13G_C_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  write_csv(primary_effects, files["primary_effects"])
  write_csv(overlap_effects, files["overlap_effects"])
  write_csv(primary_meta_empirical, files["primary_meta"])
  write_csv(overlap_meta_empirical, files["overlap_meta"])
  write_csv(primary_meta_conventional, files["conventional_meta"])
  write_csv(leave_one_out, files["leave_one_out"])
  write_csv(freeze_summary, files["freeze"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(integrity, files["integrity"])
  write_csv(input_manifest, files["inputs"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan - Script 13G-C Final EMT Meta-analysis",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("Cohorts: ", paste(primary_effects$cohort, collapse = "; ")),
    paste0("Total samples: ", sum(primary_effects$sample_number)),
    paste0("Cohort rho values: ",
           paste(
             sprintf("%s=%.10f",
                     primary_effects$cohort, primary_effects$rho),
             collapse = "; "
           )),
    paste0("Primary random-effects pooled rho: ",
           format(primary_random$pooled_rho, digits = 16)),
    paste0("Primary random-effects 95% CI: ",
           format(primary_random$confidence_interval_lower_rho,
                  digits = 16), " to ",
           format(primary_random$confidence_interval_upper_rho,
                  digits = 16)),
    paste0("Primary random-effects p: ",
           format(primary_random$two_sided_p, digits = 16)),
    paste0("Primary modified-KH 95% CI: ",
           format(primary_mKH$confidence_interval_lower_rho,
                  digits = 16), " to ",
           format(primary_mKH$confidence_interval_upper_rho,
                  digits = 16)),
    paste0("Primary modified-KH p: ",
           format(primary_mKH$two_sided_p, digits = 16)),
    paste0("Primary I2: ",
           format(primary_random$I2_percent, digits = 10), "%"),
    paste0("Primary Q p: ",
           format(primary_random$Q_p, digits = 16)),
    paste0("Overlap-removed pooled rho: ",
           format(overlap_random$pooled_rho, digits = 16)),
    paste0("Conventional-variance pooled rho: ",
           format(conventional_random$pooled_rho, digits = 16)),
    paste0("Leave-one-out minimum random pooled rho: ",
           format(min(
             leave_primary$pooled_rho[
               leave_primary$pooling_method == "RANDOM_DL_NORMAL"
             ]
           ), digits = 16)),
    "All cohort directions positive: TRUE",
    "New biological analysis performed: FALSE",
    "Survival/cutoff/high-low/KM/DEG/PCA/GSEA/figure performed: FALSE",
    "Analysis freeze decision: FREEZE_ANALYSIS",
    "",
    "SCRIPT13G_C STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  p2 <- read.csv(files["primary_effects"],
                 stringsAsFactors = FALSE, check.names = FALSE)
  m2 <- read.csv(files["primary_meta"],
                 stringsAsFactors = FALSE, check.names = FALSE)
  l2 <- read.csv(files["leave_one_out"],
                 stringsAsFactors = FALSE, check.names = FALSE)

  assert(
    nrow(p2) == 3L &&
      isTRUE(all.equal(
        p2$rho, primary_effects$rho,
        tolerance = 1e-14, check.attributes = FALSE
      )) &&
      nrow(m2) == 3L &&
      isTRUE(all.equal(
        m2$pooled_rho, primary_meta_empirical$pooled_rho,
        tolerance = 1e-14, check.attributes = FALSE
      )) &&
      nrow(l2) == 12L &&
      identical(as.character(b2$analysis_freeze_decision),
                "FREEZE_ANALYSIS"),
    "RDS/CSV save-read validation failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script13G_C_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging preserved at:\n%s", stage)
    }
    assert(manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script13G_C_output_manifest_with_MD5.csv"
      )
    ), "Copied final output failed manifest verification.")
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(manifest_ok(
    OUTPUT_ROOT,
    file.path(
      OUTPUT_ROOT, "audit",
      "Script13G_C_output_manifest_with_MD5.csv"
    )
  ), "Post-commit manifest verification failed.")
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13G-C completed successfully.\n")
  cat("Three cohorts and 883 samples synthesized.\n")
  cat("Analysis freeze decision: FREEZE_ANALYSIS\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

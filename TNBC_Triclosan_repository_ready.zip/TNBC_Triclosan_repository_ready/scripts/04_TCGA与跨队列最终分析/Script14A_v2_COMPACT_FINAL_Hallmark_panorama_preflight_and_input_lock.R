# ==============================================================================
# TNBC_Triclosan | Script 14A COMPACT FINAL
# Three-cohort Hallmark panorama: preflight, provenance lock and prepared inputs.
#
# This step performs NO pathway correlation and NO meta-analysis.
#
# It:
# - verifies every accepted upstream expression, score and validation object;
# - reconstructs one aligned expression/score input for each human TNBC cohort;
# - preserves the accepted GSE31519 source_dataset_id structure;
# - retrieves the complete human Hallmark collection;
# - audits pathway coverage in TCGA TNBC, GSE31519 and GSE58812;
# - freezes eligibility rules before any pathway result is inspected;
# - saves prepared objects for Script 14B.
#
# No new score, survival model, cutoff, grouping, sample deletion, DEG, PCA,
# GSEA, correlation, meta-analysis or manuscript figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script14A_v2_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"

OUTPUT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "00_preflight_and_input_lock"
)

TCGA_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "00_TCGA_TNBC_EMT_revalidation"
)
GSE31519_ROOT <- file.path(
  PROJECT_ROOT,
  "Step2_GSE31519_external_validation"
)
GSE58812_ROOT <- file.path(
  PROJECT_ROOT,
  "Step4_GSE58812_external_validation"
)

INPUTS <- c(
  TCGA_expression = file.path(
    PROJECT_ROOT, "data", "TNBC_expression_matrix.rds"
  ),
  TCGA_original_score = file.path(
    PROJECT_ROOT, "results", "Triclosan_activity_score.rds"
  ),
  TCGA_accepted_bundle = file.path(
    TCGA_ROOT, "objects",
    "TCGA_TNBC_EMT_revalidation_COMPLETE_bundle.rds"
  ),
  TCGA_accepted_manifest = file.path(
    TCGA_ROOT, "audit",
    "Script13G_B_output_manifest_with_MD5.csv"
  ),
  TCGA_accepted_report = file.path(
    TCGA_ROOT, "logs",
    "Script13G_B_COMPLETE_report.txt"
  ),

  GSE31519_clinical_bundle = file.path(
    GSE31519_ROOT, "06_curated_clinical_endpoint", "objects",
    "GSE31519_curated_clinical_endpoint_COMPLETE_bundle.rds"
  ),
  GSE31519_clinical_manifest = file.path(
    GSE31519_ROOT, "06_curated_clinical_endpoint", "audit",
    "Script09B_output_manifest_with_MD5.csv"
  ),
  GSE31519_clinical_report = file.path(
    GSE31519_ROOT, "06_curated_clinical_endpoint", "logs",
    "Script09B_COMPLETE_report.txt"
  ),
  GSE31519_score_bundle = file.path(
    GSE31519_ROOT, "08_Triclosan_GSVA_score", "objects",
    "GSE31519_Triclosan_GSVA_score_COMPLETE_bundle.rds"
  ),
  GSE31519_score_manifest = file.path(
    GSE31519_ROOT, "08_Triclosan_GSVA_score", "audit",
    "Script10B_output_manifest_with_MD5.csv"
  ),
  GSE31519_score_report = file.path(
    GSE31519_ROOT, "08_Triclosan_GSVA_score", "logs",
    "Script10B_COMPLETE_report.txt"
  ),
  GSE31519_accepted_bundle = file.path(
    GSE31519_ROOT, "13_EMT_external_validation", "objects",
    "GSE31519_EMT_external_validation_COMPLETE_bundle.rds"
  ),
  GSE31519_accepted_manifest = file.path(
    GSE31519_ROOT, "13_EMT_external_validation", "audit",
    "Script13G_A_output_manifest_with_MD5.csv"
  ),
  GSE31519_accepted_report = file.path(
    GSE31519_ROOT, "13_EMT_external_validation", "logs",
    "Script13G_A_COMPLETE_report.txt"
  ),

  GSE58812_matrix_bundle = file.path(
    GSE58812_ROOT, "03_gene_level_expression_log2_MAS5", "objects",
    "GSE58812_gene_level_log2_MAS5_COMPLETE_bundle.rds"
  ),
  GSE58812_matrix = file.path(
    GSE58812_ROOT, "03_gene_level_expression_log2_MAS5", "objects",
    "GSE58812_gene_level_log2_MAS5_matrix.rds"
  ),
  GSE58812_matrix_manifest = file.path(
    GSE58812_ROOT, "03_gene_level_expression_log2_MAS5", "audit",
    "Script13D_output_manifest_with_MD5.csv"
  ),
  GSE58812_matrix_report = file.path(
    GSE58812_ROOT, "03_gene_level_expression_log2_MAS5", "logs",
    "Script13D_COMPLETE_report.txt"
  ),
  GSE58812_score_bundle = file.path(
    GSE58812_ROOT, "04_Triclosan_GSVA_score", "objects",
    "GSE58812_Triclosan_24gene_GSVA_COMPLETE_bundle.rds"
  ),
  GSE58812_score = file.path(
    GSE58812_ROOT, "04_Triclosan_GSVA_score", "objects",
    "GSE58812_Triclosan_24gene_GSVA_score.rds"
  ),
  GSE58812_score_csv = file.path(
    GSE58812_ROOT, "04_Triclosan_GSVA_score", "audit",
    "GSE58812_Triclosan_24gene_GSVA_score_all107.csv"
  ),
  GSE58812_score_manifest = file.path(
    GSE58812_ROOT, "04_Triclosan_GSVA_score", "audit",
    "Script13E_output_manifest_with_MD5.csv"
  ),
  GSE58812_score_report = file.path(
    GSE58812_ROOT, "04_Triclosan_GSVA_score", "logs",
    "Script13E_COMPLETE_report.txt"
  ),
  GSE58812_accepted_bundle = file.path(
    GSE58812_ROOT,
    "05_EMT_external_validation_and_continuous_survival", "objects",
    "GSE58812_EMT_and_continuous_survival_COMPLETE_bundle.rds"
  ),
  GSE58812_accepted_manifest = file.path(
    GSE58812_ROOT,
    "05_EMT_external_validation_and_continuous_survival", "audit",
    "Script13F_output_manifest_with_MD5.csv"
  ),
  GSE58812_accepted_report = file.path(
    GSE58812_ROOT,
    "05_EMT_external_validation_and_continuous_survival", "logs",
    "Script13F_COMPLETE_report.txt"
  )
)

EXPECTED_MD5 <- c(
  TCGA_expression = "d5918fa39ad8bbd7cd21c3643acf3de7",
  TCGA_original_score = "06b267c24d5e59acab9e1fcb1c8e3167",
  TCGA_accepted_bundle = "5c5d22abedd020fa9086b6fde82ee3d4",
  TCGA_accepted_manifest = "d45031673a08dcffe8806839ab8e9b5c",
  TCGA_accepted_report = "e8ea21abe7a908b6441f8d80689f4cf1",

  GSE31519_clinical_bundle = "02606ffd117178bcd20571ab34740104",
  GSE31519_clinical_manifest = "cea3d8faaad2c65e8c4c9c05969964e0",
  GSE31519_clinical_report = "69a016f36eb05d57e88c323c5a21cb21",
  GSE31519_score_bundle = "2a9a2e6f0ad35d0478f76347897244b4",
  GSE31519_score_manifest = "84258652348dfa986426b5f78f6b9980",
  GSE31519_score_report = "7b379b8bd8bbb75691a0c2c30a511fff",
  GSE31519_accepted_bundle = "c38714208098bd8871b4d7b16b36f0bf",
  GSE31519_accepted_manifest = "219cac414bb58e2d19d7947c65963ed7",
  GSE31519_accepted_report = "d763ae64264b716698eaedf1e241d4f1",

  GSE58812_matrix_bundle = "d85f687aa51b9f738936f28abcca4e97",
  GSE58812_matrix = "cbda0e1ba636856c6ca9cd6353c9b775",
  GSE58812_matrix_manifest = "51aa48cd007f8bbb24b6af4a0297c044",
  GSE58812_matrix_report = "c233f0388594adbdb98a3e23573aaf65",
  GSE58812_score_bundle = "86e33e3ae27d718ce932c1cecaa8bfd8",
  GSE58812_score = "1627558d0c93cd71faf09f61eebd7a6d",
  GSE58812_score_csv = "bb997f63968dd82dc06fa453f199ddce",
  GSE58812_score_manifest = "e798c0be870a783e8da3977a2c99ef2a",
  GSE58812_score_report = "faca63097281eaaa8f32638053bbc979",
  GSE58812_accepted_bundle = "cd256862701cf62ac041b7d56f6fc45d",
  GSE58812_accepted_manifest = "f6021fe8d5114bac5d6a85c505a7ec91",
  GSE58812_accepted_report = "5238da233c70189c38cf6dc94b263ead"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)

EMT_NAME <- "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"
EXPECTED_HALLMARK_NUMBER <- 50L
MIN_DETECTED_GENES <- 10L
MIN_COVERAGE_FRACTION <- 0.50

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

scalar_text <- function(x, label = "value") {
  y <- as.character(x)
  assert(length(y) == 1L && !is.na(y) && nzchar(trimws(y)),
         "%s must be one nonblank scalar value.", label)
  unname(trimws(y))
}

same_text <- function(x, y) {
  identical(
    scalar_text(x, "observed text"),
    scalar_text(y, "expected text")
  )
}

same_md5 <- function(x, y) {
  identical(
    tolower(scalar_text(x, "observed MD5")),
    tolower(scalar_text(y, "expected MD5"))
  )
}

same_numeric <- function(x, y, tolerance = 1e-14) {
  isTRUE(all.equal(
    as.numeric(x),
    as.numeric(y),
    tolerance = tolerance,
    check.attributes = FALSE
  ))
}

same_matrix <- function(x, y, tolerance = 0) {
  is.matrix(x) && is.matrix(y) &&
    identical(dim(x), dim(y)) &&
    identical(rownames(x), rownames(y)) &&
    identical(colnames(x), colnames(y)) &&
    isTRUE(all.equal(
      as.numeric(x),
      as.numeric(y),
      tolerance = tolerance,
      check.attributes = FALSE
    ))
}

report_contains <- function(file, marker) {
  any(grepl(
    marker,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)

    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)

    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

extract_numeric_score <- function(x, label) {
  if (is.numeric(x)) {
    y <- as.numeric(x)
    names(y) <- names(x)
  } else if (is.matrix(x) && nrow(x) == 1L) {
    y <- as.numeric(x[1L, ])
    names(y) <- colnames(x)
  } else {
    stopf("%s is not a supported named continuous score.", label)
  }

  assert(
    length(y) > 1L && all(is.finite(y)) && sd(y) > 0 &&
      !is.null(names(y)) && all(nzchar(names(y))) &&
      !anyDuplicated(names(y)),
    "%s is incomplete, invariant or has invalid sample names.", label
  )
  y
}

build_unique_gene_matrix <- function(expr, label) {
  assert(is.matrix(expr) && is.numeric(expr),
         "%s expression object is not a numeric matrix.", label)
  assert(!is.null(rownames(expr)) && !is.null(colnames(expr)),
         "%s expression matrix lacks row or column names.", label)
  assert(all(nzchar(trimws(colnames(expr)))),
         "%s expression matrix contains blank sample IDs.", label)
  assert(all(is.finite(expr)),
         "%s expression matrix contains non-finite values.", label)

  raw_ids <- trimws(as.character(rownames(expr)))
  blank <- is.na(raw_ids) | !nzchar(raw_ids)
  valid_expr <- expr[!blank, , drop = FALSE]
  valid_ids <- raw_ids[!blank]

  assert(length(valid_ids) > 0L,
         "%s has no nonblank gene identifiers.", label)

  gene_order <- unique(valid_ids)

  if (!anyDuplicated(valid_ids)) {
    source_count <- rep.int(1L, length(valid_ids))
    names(source_count) <- valid_ids
    gene_expr <- valid_expr
    rownames(gene_expr) <- valid_ids
  } else {
    split_index <- split(
      seq_along(valid_ids),
      factor(valid_ids, levels = gene_order)
    )
    source_count <- lengths(split_index)

    gene_expr <- t(vapply(split_index, function(i) {
      if (length(i) == 1L) {
        as.numeric(valid_expr[i, , drop = TRUE])
      } else {
        apply(valid_expr[i, , drop = FALSE], 2L, stats::median)
      }
    }, numeric(ncol(valid_expr))))

    rownames(gene_expr) <- gene_order
  }

  colnames(gene_expr) <- colnames(valid_expr)
  storage.mode(gene_expr) <- "double"

  assert(
    is.matrix(gene_expr) &&
      identical(colnames(gene_expr), colnames(expr)) &&
      !anyDuplicated(rownames(gene_expr)) &&
      all(nzchar(rownames(gene_expr))) &&
      all(is.finite(gene_expr)),
    "%s unique gene matrix failed identity checks.", label
  )

  list(
    expression = gene_expr,
    summary = data.frame(
      cohort = label,
      raw_gene_row_number = nrow(expr),
      blank_gene_ID_row_number = sum(blank),
      duplicate_symbol_excess_row_number = sum(duplicated(valid_ids)),
      unique_gene_number = nrow(gene_expr),
      multi_row_gene_number = sum(source_count > 1L),
      maximum_rows_per_gene = max(source_count),
      sample_number = ncol(gene_expr),
      nonfinite_value_number = sum(!is.finite(expr)),
      minimum_expression = min(expr),
      maximum_expression = max(expr),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )
}

remove_zero_variance <- function(expr, label) {
  row_sd <- apply(expr, 1L, stats::sd)
  keep <- is.finite(row_sd) & row_sd > 0
  result <- expr[keep, , drop = FALSE]

  assert(
    nrow(result) >= 1000L &&
      ncol(result) == ncol(expr) &&
      all(is.finite(result)) &&
      all(apply(result, 1L, stats::sd) > 0),
    "%s zero-variance filtering failed.", label
  )

  list(
    expression = result,
    removed = sum(!keep)
  )
}

coverage_table <- function(cohort, genes, hallmark_list) {
  do.call(rbind, lapply(names(hallmark_list), function(pathway) {
    full <- hallmark_list[[pathway]]
    detected <- intersect(full, genes)
    overlap <- intersect(detected, LOCKED24)

    data.frame(
      cohort = cohort,
      pathway = pathway,
      Hallmark_total_gene_number = length(full),
      detected_gene_number = length(detected),
      detected_fraction = length(detected) / length(full),
      locked24_overlap_gene_number = length(overlap),
      locked24_overlap_genes =
        if (length(overlap)) paste(overlap, collapse = ";") else "",
      meets_min_detected_genes =
        length(detected) >= MIN_DETECTED_GENES,
      meets_min_coverage_fraction =
        length(detected) / length(full) >= MIN_COVERAGE_FRACTION,
      cohort_pathway_eligible =
        length(detected) >= MIN_DETECTED_GENES &&
          length(detected) / length(full) >= MIN_COVERAGE_FRACTION,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "Hallmark_panorama_preflight_COMPLETE_bundle.rds"
    ),
    TCGA = file.path(
      root, "objects",
      "TCGA_TNBC_Hallmark_panorama_prepared_input.rds"
    ),
    GSE31519 = file.path(
      root, "objects",
      "GSE31519_Hallmark_panorama_prepared_input.rds"
    ),
    GSE58812 = file.path(
      root, "objects",
      "GSE58812_Hallmark_panorama_prepared_input.rds"
    ),
    manifest = file.path(
      root, "audit",
      "Script14A_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script14A_COMPLETE_report.txt"
    )
  )

  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT14A STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  t <- tryCatch(readRDS(key["TCGA"]), error = function(e) NULL)
  g1 <- tryCatch(readRDS(key["GSE31519"]), error = function(e) NULL)
  g2 <- tryCatch(readRDS(key["GSE58812"]), error = function(e) NULL)

  is.list(b) &&
    identical(as.character(b$script), "Script14A") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    identical(as.character(b$readiness_status), "READY_FOR_SCRIPT14B") &&
    is.list(t) && identical(dim(t$expression), c(56477L, 197L)) &&
    is.list(g1) && identical(dim(g1$expression), c(12650L, 579L)) &&
    is.list(g2) && identical(dim(g2$expression), c(20823L, 107L))
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT),
           "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 14A output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "00_preflight_and_input_lock_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Hallmark panorama preflight and prepared-input lock only.\n")
  cat("============================================================\n")

  packages <- c("msigdbr", "GSVA")
  missing_packages <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  assert(!length(missing_packages),
         "Missing package(s): %s", paste(missing_packages, collapse = ", "))

  missing_files <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing_files), "Missing accepted input(s):\n%s",
         paste(missing_files, collapse = "\n"))

  observed_md5 <- vapply(INPUTS, md5, character(1))
  assert(
    identical(observed_md5, EXPECTED_MD5),
    "At least one accepted input MD5 differs:\n%s",
    paste(sprintf(
      "%s | expected=%s | observed=%s",
      names(EXPECTED_MD5), EXPECTED_MD5, observed_md5
    ), collapse = "\n")
  )

  assert(
    manifest_ok(TCGA_ROOT, INPUTS["TCGA_accepted_manifest"]),
    "TCGA accepted output manifest verification failed."
  )
  assert(
    manifest_ok(
      file.path(GSE31519_ROOT, "13_EMT_external_validation"),
      INPUTS["GSE31519_accepted_manifest"]
    ),
    "GSE31519 Script13G-A manifest verification failed."
  )
  assert(
    manifest_ok(
      file.path(
        GSE58812_ROOT,
        "05_EMT_external_validation_and_continuous_survival"
      ),
      INPUTS["GSE58812_accepted_manifest"]
    ),
    "GSE58812 Script13F manifest verification failed."
  )

  assert(
    report_contains(
      INPUTS["TCGA_accepted_report"], "SCRIPT13G_B STATUS: COMPLETE"
    ),
    "TCGA accepted completion marker is missing."
  )
  assert(
    report_contains(
      INPUTS["GSE31519_clinical_report"], "SCRIPT09B STATUS: COMPLETE"
    ),
    "GSE31519 Script09B completion marker is missing."
  )
  assert(
    report_contains(
      INPUTS["GSE31519_score_report"], "SCRIPT10B STATUS: COMPLETE"
    ),
    "GSE31519 Script10B completion marker is missing."
  )
  assert(
    report_contains(
      INPUTS["GSE31519_accepted_report"], "SCRIPT13G_A STATUS: COMPLETE"
    ),
    "GSE31519 accepted completion marker is missing."
  )
  assert(
    report_contains(
      INPUTS["GSE58812_matrix_report"], "SCRIPT13D STATUS: COMPLETE"
    ),
    "GSE58812 Script13D completion marker is missing."
  )
  assert(
    report_contains(
      INPUTS["GSE58812_score_report"], "SCRIPT13E STATUS: COMPLETE"
    ),
    "GSE58812 Script13E completion marker is missing."
  )
  assert(
    report_contains(
      INPUTS["GSE58812_accepted_report"], "SCRIPT13F STATUS: COMPLETE"
    ),
    "GSE58812 accepted completion marker is missing."
  )

  dir.create(dirname(OUTPUT_ROOT), recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(dirname(OUTPUT_ROOT)),
         "Unable to create Hallmark panorama parent directory.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  # ---------------------------------------------------------------------------
  # TCGA TNBC prepared input
  # ---------------------------------------------------------------------------
  TCGA_raw <- readRDS(INPUTS["TCGA_expression"])
  TCGA_accepted <- readRDS(INPUTS["TCGA_accepted_bundle"])

  assert(is.list(TCGA_accepted),
         "TCGA accepted bundle is not a list.")
  assert(same_text(TCGA_accepted$script, "Script13G_B"),
         "TCGA accepted bundle script identity is incorrect.")
  assert(
    same_text(
      TCGA_accepted$script_build_id,
      "Script13G_B_v4_COMPACT_FINAL_20260711"
    ),
    "TCGA accepted bundle build identity is incorrect."
  )
  assert(
    same_md5(
      TCGA_accepted$source_expression_md5,
      unname(EXPECTED_MD5["TCGA_expression"])
    ),
    "TCGA accepted bundle expression provenance MD5 is incorrect."
  )
  assert(
    same_md5(
      TCGA_accepted$source_score_md5,
      unname(EXPECTED_MD5["TCGA_original_score"])
    ),
    "TCGA accepted bundle score provenance MD5 is incorrect."
  )
  assert(
    is.list(TCGA_accepted$policy) &&
      isFALSE(as.logical(
        TCGA_accepted$policy$many_to_many_join_performed
      )[1L]),
    "TCGA accepted bundle many-to-many policy lock is incorrect."
  )
  assert(
    is.matrix(TCGA_raw) && is.numeric(TCGA_raw) &&
      identical(dim(TCGA_raw), c(59427L, 197L)) &&
      all(is.finite(TCGA_raw)) && min(TCGA_raw) >= 0,
    "TCGA raw expression matrix is malformed."
  )

  TCGA_samples <- TCGA_accepted$sample_level_scores
  assert(
    is.data.frame(TCGA_samples) && nrow(TCGA_samples) == 197L &&
      all(c(
        "expression_sample_id_original", "sample_id",
        "Triclosan_activity", "HALLMARK_EMT_FULL"
      ) %in% names(TCGA_samples)) &&
      identical(
        as.character(TCGA_samples$expression_sample_id_original),
        colnames(TCGA_raw)
      ) &&
      !anyDuplicated(as.character(TCGA_samples$sample_id)),
    "TCGA accepted sample mapping is malformed or misaligned."
  )

  TCGA_gene_build <- build_unique_gene_matrix(TCGA_raw, "TCGA_TNBC")
  TCGA_log2 <- log2(TCGA_gene_build$expression + 1)
  colnames(TCGA_log2) <- as.character(TCGA_samples$sample_id)
  TCGA_filtered <- remove_zero_variance(TCGA_log2, "TCGA_TNBC")

  TCGA_score <- as.numeric(TCGA_samples$Triclosan_activity)
  names(TCGA_score) <- as.character(TCGA_samples$sample_id)
  TCGA_EMT_accepted <- as.numeric(TCGA_samples$HALLMARK_EMT_FULL)
  names(TCGA_EMT_accepted) <- names(TCGA_score)

  assert(
    identical(colnames(TCGA_filtered$expression), names(TCGA_score)) &&
      length(TCGA_score) == 197L &&
      all(is.finite(TCGA_score)) && sd(TCGA_score) > 0 &&
      all(is.finite(TCGA_EMT_accepted)) && sd(TCGA_EMT_accepted) > 0,
    "TCGA prepared expression, score or accepted EMT benchmark is invalid."
  )

  TCGA_prepared <- list(
    cohort = "TCGA_TNBC",
    expression = TCGA_filtered$expression,
    Triclosan_activity = TCGA_score,
    source_dataset_id = rep("TCGA_TNBC", 197L),
    accepted_EMT_score = TCGA_EMT_accepted,
    primary_method = "Spearman",
    expression_scale = "log2(x+1)",
    raw_expression_md5 = unname(EXPECTED_MD5["TCGA_expression"]),
    score_source_md5 = unname(EXPECTED_MD5["TCGA_original_score"]),
    accepted_validation_bundle_md5 =
      unname(EXPECTED_MD5["TCGA_accepted_bundle"]),
    zero_variance_gene_number = TCGA_filtered$removed,
    samples_filtered = FALSE
  )

  # ---------------------------------------------------------------------------
  # GSE31519 prepared input
  # ---------------------------------------------------------------------------
  G315_clinical <- readRDS(INPUTS["GSE31519_clinical_bundle"])
  G315_score_bundle <- readRDS(INPUTS["GSE31519_score_bundle"])
  G315_accepted <- readRDS(INPUTS["GSE31519_accepted_bundle"])

  assert(
    is.list(G315_clinical) &&
      same_text(G315_clinical$script, "Script09B") &&
      same_text(G315_clinical$source_accession, "GSE31519") &&
      all(c("expression_matrix", "curated_clinical") %in%
            names(G315_clinical)),
    "GSE31519 Script09B bundle identity is incorrect."
  )
  assert(is.list(G315_score_bundle),
         "GSE31519 Script10B bundle is not a list.")
  assert(same_text(G315_score_bundle$script, "Script10B"),
         "GSE31519 Script10B script identity is incorrect.")
  assert(
    same_md5(
      G315_score_bundle$source_script09b_bundle_md5,
      unname(EXPECTED_MD5["GSE31519_clinical_bundle"])
    ),
    "GSE31519 Script10B source Script09B MD5 is incorrect."
  )
  assert(is.list(G315_accepted),
         "GSE31519 accepted validation bundle is not a list.")
  assert(same_text(G315_accepted$script, "Script13G_A"),
         "GSE31519 accepted validation script identity is incorrect.")
  assert(
    same_text(
      G315_accepted$script_build_id,
      "Script13G_A_COMPACT_FINAL_20260711"
    ),
    "GSE31519 accepted validation build identity is incorrect."
  )
  assert(
    same_md5(
      G315_accepted$source_clinical_bundle_md5,
      unname(EXPECTED_MD5["GSE31519_clinical_bundle"])
    ),
    "GSE31519 accepted clinical-bundle provenance MD5 is incorrect."
  )
  assert(
    same_md5(
      G315_accepted$source_score_bundle_md5,
      unname(EXPECTED_MD5["GSE31519_score_bundle"])
    ),
    "GSE31519 accepted score-bundle provenance MD5 is incorrect."
  )

  G315_expr <- G315_clinical$expression_matrix
  G315_pheno <- G315_clinical$curated_clinical
  G315_score <- extract_numeric_score(
    G315_score_bundle$Triclosan_activity,
    "GSE31519 Triclosan_activity"
  )
  G315_samples <- G315_accepted$sample_level_scores

  assert(
    is.matrix(G315_expr) && is.numeric(G315_expr) &&
      identical(dim(G315_expr), c(12650L, 579L)) &&
      all(is.finite(G315_expr)) &&
      !anyDuplicated(rownames(G315_expr)) &&
      !anyDuplicated(colnames(G315_expr)),
    "GSE31519 expression matrix is malformed."
  )
  assert(
    is.data.frame(G315_pheno) && nrow(G315_pheno) == 579L &&
      all(c("sample_id", "source_dataset_id") %in% names(G315_pheno)) &&
      identical(as.character(G315_pheno$sample_id), colnames(G315_expr)),
    "GSE31519 phenotype is malformed or misaligned."
  )
  assert(
    identical(names(G315_score), colnames(G315_expr)) &&
      same_numeric(
        G315_accepted$Triclosan_activity,
        G315_score
      ) &&
      is.data.frame(G315_samples) && nrow(G315_samples) == 579L &&
      identical(as.character(G315_samples$sample_id), colnames(G315_expr)),
    "GSE31519 accepted score or validation sample table is misaligned."
  )

  G315_source <- trimws(as.character(G315_pheno$source_dataset_id))
  assert(
    length(G315_source) == 579L &&
      all(!is.na(G315_source) & nzchar(G315_source)) &&
      identical(
        G315_source,
        as.character(G315_samples$source_dataset_id)
      ) &&
      length(unique(G315_source)) == 28L,
    "GSE31519 source_dataset_id lock is incorrect."
  )

  G315_row_sd <- apply(G315_expr, 1L, stats::sd)
  assert(all(is.finite(G315_row_sd)),
         "GSE31519 contains non-finite gene standard deviations.")
  G315_zero_variance_number <- sum(G315_row_sd == 0)

  G315_EMT_accepted <- as.numeric(G315_samples$HALLMARK_EMT_FULL)
  names(G315_EMT_accepted) <- colnames(G315_expr)

  G315_prepared <- list(
    cohort = "GSE31519",
    expression = G315_expr,
    Triclosan_activity = G315_score,
    source_dataset_id = G315_source,
    accepted_EMT_score = G315_EMT_accepted,
    primary_method = "Partial_Spearman_source_centered_ranks",
    expression_scale = "accepted Script09B normalized gene-level expression",
    clinical_bundle_md5 =
      unname(EXPECTED_MD5["GSE31519_clinical_bundle"]),
    score_bundle_md5 = unname(EXPECTED_MD5["GSE31519_score_bundle"]),
    accepted_validation_bundle_md5 =
      unname(EXPECTED_MD5["GSE31519_accepted_bundle"]),
    zero_variance_gene_number = G315_zero_variance_number,
    samples_filtered = FALSE
  )

  # ---------------------------------------------------------------------------
  # GSE58812 prepared input
  # ---------------------------------------------------------------------------
  G588_matrix_bundle <- readRDS(INPUTS["GSE58812_matrix_bundle"])
  G588_expr <- readRDS(INPUTS["GSE58812_matrix"])
  G588_score_bundle <- readRDS(INPUTS["GSE58812_score_bundle"])
  G588_score <- extract_numeric_score(
    readRDS(INPUTS["GSE58812_score"]),
    "GSE58812 Triclosan_activity"
  )
  G588_score_csv <- read.csv(
    INPUTS["GSE58812_score_csv"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  G588_accepted <- readRDS(INPUTS["GSE58812_accepted_bundle"])

  assert(is.list(G588_matrix_bundle),
         "GSE58812 Script13D bundle is not a list.")
  assert(same_text(G588_matrix_bundle$script, "Script13D"),
         "GSE58812 Script13D script identity is incorrect.")
  assert(
    same_text(
      G588_matrix_bundle$script_build_id,
      "Script13D_COMPACT_FINAL_20260711"
    ),
    "GSE58812 Script13D build identity is incorrect."
  )
  assert(
    same_matrix(
      G588_expr,
      G588_matrix_bundle$gene_level_expression_log2_MAS5
    ),
    "GSE58812 Script13D standalone and bundle matrices differ."
  )

  assert(is.list(G588_score_bundle),
         "GSE58812 Script13E bundle is not a list.")
  assert(same_text(G588_score_bundle$script, "Script13E"),
         "GSE58812 Script13E script identity is incorrect.")
  assert(
    same_text(
      G588_score_bundle$script_build_id,
      "Script13E_COMPACT_FINAL_20260711"
    ),
    "GSE58812 Script13E build identity is incorrect."
  )
  assert(
    same_numeric(
      G588_score_bundle$Triclosan_activity,
      G588_score
    ),
    "GSE58812 Script13E standalone and bundle scores differ."
  )

  assert(is.list(G588_accepted),
         "GSE58812 accepted validation bundle is not a list.")
  assert(same_text(G588_accepted$script, "Script13F"),
         "GSE58812 accepted validation script identity is incorrect.")
  assert(
    same_text(
      G588_accepted$script_build_id,
      "Script13F_COMPACT_FINAL_20260711"
    ),
    "GSE58812 accepted validation build identity is incorrect."
  )
  assert(
    same_md5(
      G588_accepted$source_log2_matrix_md5,
      unname(EXPECTED_MD5["GSE58812_matrix"])
    ),
    "GSE58812 accepted expression provenance MD5 is incorrect."
  )
  assert(
    same_md5(
      G588_accepted$source_Triclosan_score_md5,
      unname(EXPECTED_MD5["GSE58812_score"])
    ),
    "GSE58812 accepted score provenance MD5 is incorrect."
  )
  assert(
    is.matrix(G588_expr) && is.numeric(G588_expr) &&
      identical(dim(G588_expr), c(20823L, 107L)) &&
      all(is.finite(G588_expr)) &&
      !anyDuplicated(rownames(G588_expr)) &&
      !anyDuplicated(colnames(G588_expr)) &&
      all(apply(G588_expr, 1L, stats::sd) > 0),
    "GSE58812 log2 expression matrix is malformed."
  )
  assert(
    identical(names(G588_score), colnames(G588_expr)) &&
      length(G588_score) == 107L &&
      all(is.finite(G588_score)) && sd(G588_score) > 0,
    "GSE58812 expression and score are misaligned."
  )
  assert(
    is.data.frame(G588_score_csv) && nrow(G588_score_csv) == 107L &&
      all(c("sample_id", "Triclosan_activity") %in%
            names(G588_score_csv)) &&
      identical(
        as.character(G588_score_csv$sample_id),
        names(G588_score)
      ) &&
      isTRUE(all.equal(
        as.numeric(G588_score_csv$Triclosan_activity),
        as.numeric(G588_score),
        tolerance = 1e-14,
        check.attributes = FALSE
      )),
    "GSE58812 score CSV differs from the accepted score RDS."
  )

  G588_samples <- G588_accepted$sample_level_scores_and_clinical
  assert(
    is.data.frame(G588_samples) && nrow(G588_samples) == 107L &&
      identical(as.character(G588_samples$sample_id), colnames(G588_expr)) &&
      same_numeric(
        G588_samples$Triclosan_activity,
        G588_score
      ),
    "GSE58812 accepted sample table is malformed or misaligned."
  )

  G588_EMT_accepted <- as.numeric(G588_samples$HALLMARK_EMT_FULL)
  names(G588_EMT_accepted) <- colnames(G588_expr)

  G588_prepared <- list(
    cohort = "GSE58812",
    expression = G588_expr,
    Triclosan_activity = G588_score,
    source_dataset_id = rep("GSE58812", 107L),
    accepted_EMT_score = G588_EMT_accepted,
    primary_method = "Spearman",
    expression_scale = "accepted Script13D log2 MAS5",
    expression_bundle_md5 =
      unname(EXPECTED_MD5["GSE58812_matrix_bundle"]),
    expression_matrix_md5 = unname(EXPECTED_MD5["GSE58812_matrix"]),
    score_bundle_md5 = unname(EXPECTED_MD5["GSE58812_score_bundle"]),
    score_md5 = unname(EXPECTED_MD5["GSE58812_score"]),
    accepted_validation_bundle_md5 =
      unname(EXPECTED_MD5["GSE58812_accepted_bundle"]),
    zero_variance_gene_number = 0L,
    samples_filtered = FALSE
  )

  # ---------------------------------------------------------------------------
  # Hallmark collection and coverage lock
  # ---------------------------------------------------------------------------
  msig_formals <- names(formals(msigdbr::msigdbr))
  msig_args <- list(species = "Homo sapiens")
  if ("db_species" %in% msig_formals) msig_args$db_species <- "HS"
  if ("collection" %in% msig_formals) {
    msig_args$collection <- "H"
  } else {
    msig_args$category <- "H"
  }

  hallmark_table <- do.call(msigdbr::msigdbr, msig_args)
  assert(
    is.data.frame(hallmark_table) &&
      all(c("gs_name", "gene_symbol") %in% names(hallmark_table)),
    "msigdbr Hallmark output is malformed."
  )

  hallmark_table <- unique(data.frame(
    pathway = trimws(as.character(hallmark_table$gs_name)),
    gene_symbol = trimws(as.character(hallmark_table$gene_symbol)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  ))
  hallmark_table <- hallmark_table[
    !is.na(hallmark_table$pathway) &
      nzchar(hallmark_table$pathway) &
      !is.na(hallmark_table$gene_symbol) &
      nzchar(hallmark_table$gene_symbol),
    ,
    drop = FALSE
  ]

  hallmark_list <- split(
    hallmark_table$gene_symbol,
    factor(
      hallmark_table$pathway,
      levels = sort(unique(hallmark_table$pathway))
    )
  )
  hallmark_list <- lapply(hallmark_list, function(x) sort(unique(x)))

  assert(
    length(hallmark_list) == EXPECTED_HALLMARK_NUMBER &&
      EMT_NAME %in% names(hallmark_list) &&
      all(lengths(hallmark_list) >= 10L) &&
      all(lengths(hallmark_list) <= 500L),
    "Hallmark collection count, EMT membership or set size is incorrect."
  )

  coverage <- rbind(
    coverage_table(
      "TCGA_TNBC",
      rownames(TCGA_prepared$expression),
      hallmark_list
    ),
    coverage_table(
      "GSE31519",
      rownames(G315_prepared$expression),
      hallmark_list
    ),
    coverage_table(
      "GSE58812",
      rownames(G588_prepared$expression),
      hallmark_list
    )
  )
  rownames(coverage) <- NULL

  eligibility <- do.call(rbind, lapply(names(hallmark_list), function(pathway) {
    d <- coverage[coverage$pathway == pathway, , drop = FALSE]
    assert(nrow(d) == 3L,
           "Coverage table does not contain three rows for %s.", pathway)

    data.frame(
      pathway = pathway,
      cohort_number = nrow(d),
      eligible_cohort_number = sum(d$cohort_pathway_eligible),
      minimum_detected_gene_number = min(d$detected_gene_number),
      minimum_detected_fraction = min(d$detected_fraction),
      maximum_locked24_overlap_gene_number =
        max(d$locked24_overlap_gene_number),
      eligible_in_all_three_cohorts =
        all(d$cohort_pathway_eligible),
      prespecified_for_Script14B =
        all(d$cohort_pathway_eligible),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
  rownames(eligibility) <- NULL

  EMT_coverage <- coverage[
    coverage$pathway == EMT_NAME,
    c("cohort", "detected_gene_number"),
    drop = FALSE
  ]
  expected_EMT_detected <- c(
    TCGA_TNBC = 200L,
    GSE31519 = 197L,
    GSE58812 = 200L
  )
  observed_EMT_detected <- setNames(
    EMT_coverage$detected_gene_number,
    EMT_coverage$cohort
  )
  assert(
    identical(
      as.integer(observed_EMT_detected[names(expected_EMT_detected)]),
      as.integer(expected_EMT_detected)
    ),
    "EMT coverage does not reproduce the three accepted validation analyses."
  )

  eligible_n <- sum(eligibility$eligible_in_all_three_cohorts)
  readiness_status <- if (
    length(hallmark_list) == 50L &&
      eligible_n == 50L &&
      all(eligibility$prespecified_for_Script14B)
  ) {
    "READY_FOR_SCRIPT14B"
  } else {
    "REVIEW_REQUIRED_BEFORE_SCRIPT14B"
  }

  assert(
    identical(readiness_status, "READY_FOR_SCRIPT14B"),
    paste0(
      "Not all 50 Hallmark pathways passed prespecified coverage. ",
      "Review the saved eligibility audit before proceeding."
    )
  )

  sample_audit <- rbind(
    data.frame(
      cohort = "TCGA_TNBC",
      sample_number = ncol(TCGA_prepared$expression),
      unique_sample_ID_number =
        length(unique(colnames(TCGA_prepared$expression))),
      expression_score_order_identical =
        identical(
          colnames(TCGA_prepared$expression),
          names(TCGA_prepared$Triclosan_activity)
        ),
      source_dataset_number = 1L,
      accepted_EMT_benchmark_available = TRUE,
      samples_filtered = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      cohort = "GSE31519",
      sample_number = ncol(G315_prepared$expression),
      unique_sample_ID_number =
        length(unique(colnames(G315_prepared$expression))),
      expression_score_order_identical =
        identical(
          colnames(G315_prepared$expression),
          names(G315_prepared$Triclosan_activity)
        ),
      source_dataset_number =
        length(unique(G315_prepared$source_dataset_id)),
      accepted_EMT_benchmark_available = TRUE,
      samples_filtered = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      cohort = "GSE58812",
      sample_number = ncol(G588_prepared$expression),
      unique_sample_ID_number =
        length(unique(colnames(G588_prepared$expression))),
      expression_score_order_identical =
        identical(
          colnames(G588_prepared$expression),
          names(G588_prepared$Triclosan_activity)
        ),
      source_dataset_number = 1L,
      accepted_EMT_benchmark_available = TRUE,
      samples_filtered = FALSE,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  cohort_summary <- rbind(
    data.frame(
      TCGA_gene_build$summary,
      expression_scale = TCGA_prepared$expression_scale,
      zero_variance_gene_number = TCGA_prepared$zero_variance_gene_number,
      prepared_gene_number = nrow(TCGA_prepared$expression),
      score_SD = sd(TCGA_prepared$Triclosan_activity),
      source_dataset_number = 1L,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      cohort = "GSE31519",
      raw_gene_row_number = 12650L,
      blank_gene_ID_row_number = 0L,
      duplicate_symbol_excess_row_number = 0L,
      unique_gene_number = 12650L,
      multi_row_gene_number = 0L,
      maximum_rows_per_gene = 1L,
      sample_number = 579L,
      nonfinite_value_number = 0L,
      minimum_expression = min(G315_expr),
      maximum_expression = max(G315_expr),
      expression_scale = G315_prepared$expression_scale,
      zero_variance_gene_number = G315_prepared$zero_variance_gene_number,
      prepared_gene_number = nrow(G315_prepared$expression),
      score_SD = sd(G315_prepared$Triclosan_activity),
      source_dataset_number =
        length(unique(G315_prepared$source_dataset_id)),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      cohort = "GSE58812",
      raw_gene_row_number = 20823L,
      blank_gene_ID_row_number = 0L,
      duplicate_symbol_excess_row_number = 0L,
      unique_gene_number = 20823L,
      multi_row_gene_number = 0L,
      maximum_rows_per_gene = 1L,
      sample_number = 107L,
      nonfinite_value_number = 0L,
      minimum_expression = min(G588_expr),
      maximum_expression = max(G588_expr),
      expression_scale = G588_prepared$expression_scale,
      zero_variance_gene_number = 0L,
      prepared_gene_number = nrow(G588_prepared$expression),
      score_SD = sd(G588_prepared$Triclosan_activity),
      source_dataset_number = 1L,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )
  rownames(cohort_summary) <- NULL

  analysis_lock <- data.frame(
    field = c(
      "Analysis_stage",
      "Hallmark_collection",
      "Expected_pathway_number",
      "Eligibility_minimum_detected_genes",
      "Eligibility_minimum_coverage_fraction",
      "Eligible_pathways_required",
      "TCGA_method_for_Script14B",
      "GSE31519_method_for_Script14B",
      "GSE58812_method_for_Script14B",
      "Within_cohort_multiple_testing",
      "Cross_cohort_meta_transformation",
      "Cross_cohort_primary_variance",
      "Cross_cohort_pooling",
      "Cross_pathway_multiple_testing",
      "EMT_ranking_rule",
      "Pathway_selection_after_results",
      "Survival_analysis",
      "New_Triclosan_score",
      "Sample_filtering",
      "Cutoff_or_high_low_group",
      "DEG_PCA_GSEA_figure",
      "Next_script"
    ),
    value = c(
      "Prespecified strengthening analysis after core EMT freeze",
      paste0("Human Hallmark; msigdbr ", packageVersion("msigdbr")),
      EXPECTED_HALLMARK_NUMBER,
      MIN_DETECTED_GENES,
      MIN_COVERAGE_FRACTION,
      "All pathways passing coverage in all three cohorts",
      "Two-sided cohort-level Spearman",
      "Global ranks centered within source_dataset_id; Pearson correlation",
      "Two-sided cohort-level Spearman",
      "BH across all eligible pathways within each cohort",
      "Fisher z = atanh(rho)",
      "Conventional 1/(n-3) for uniform 50-pathway screening",
      "Fixed inverse variance and DerSimonian-Laird random effects",
      "BH across all eligible pathway random-effects meta p values",
      paste0(
        "Rank EMT by absolute pooled rho, signed pooled rho and meta FDR; ",
        "all ranks reported"
      ),
      "PROHIBITED",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "Script14B: score all locked eligible Hallmark pathways and calculate cohort effects"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  package_audit <- data.frame(
    package = c("msigdbr", "GSVA"),
    version = vapply(
      c("msigdbr", "GSVA"),
      function(x) as.character(packageVersion(x)),
      character(1)
    ),
    available = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    input_name = names(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(PROJECT_ROOT, winslash = "/", mustWork = TRUE)) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed_md5,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  integrity <- data.frame(
    item = c(
      "Script",
      "Script_build_ID",
      "Input_file_number",
      "Input_MD5_all_locked",
      "TCGA_prepared_dimensions",
      "GSE31519_prepared_dimensions",
      "GSE58812_prepared_dimensions",
      "Total_sample_number",
      "GSE31519_source_dataset_number",
      "Hallmark_pathway_number",
      "Eligible_pathway_number",
      "EMT_detected_TCGA",
      "EMT_detected_GSE31519",
      "EMT_detected_GSE58812",
      "Expression_score_orders_aligned",
      "Accepted_EMT_benchmarks_saved",
      "Pathway_correlations_performed",
      "Meta_analysis_performed",
      "New_score_calculated",
      "Survival_analysis_performed",
      "Samples_filtered",
      "Readiness_status",
      "Completion_status"
    ),
    value = as.character(c(
      "14A",
      BUILD_ID,
      length(INPUTS),
      TRUE,
      paste(dim(TCGA_prepared$expression), collapse = " x "),
      paste(dim(G315_prepared$expression), collapse = " x "),
      paste(dim(G588_prepared$expression), collapse = " x "),
      197L + 579L + 107L,
      length(unique(G315_prepared$source_dataset_id)),
      length(hallmark_list),
      eligible_n,
      observed_EMT_detected["TCGA_TNBC"],
      observed_EMT_detected["GSE31519"],
      observed_EMT_detected["GSE58812"],
      all(sample_audit$expression_score_order_identical),
      TRUE,
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      readiness_status,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step5_cross_cohort_synthesis/02_Hallmark_panorama",
    script = "Script14A",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    readiness_status = readiness_status,
    hallmark_collection = hallmark_list,
    hallmark_table = hallmark_table,
    cohort_summary = cohort_summary,
    sample_alignment_audit = sample_audit,
    coverage_by_cohort = coverage,
    pathway_eligibility = eligibility,
    analysis_lock = analysis_lock,
    input_manifest = input_manifest,
    integrity_summary = integrity,
    policy = list(
      core_EMT_analysis_remains_frozen = TRUE,
      prespecified_strengthening_analysis_authorized = TRUE,
      pathway_results_inspected_before_eligibility_lock = FALSE,
      pathway_correlations_performed = FALSE,
      meta_analysis_performed = FALSE,
      new_Triclosan_score_calculated = FALSE,
      survival_analysis_performed = FALSE,
      samples_filtered = FALSE,
      outliers_removed = FALSE,
      cutoff_selected = FALSE,
      high_low_group_created = FALSE,
      DEG_performed = FALSE,
      PCA_performed = FALSE,
      GSEA_performed = FALSE,
      manuscript_figure_created = FALSE
    )
  )
  class(bundle) <- c("Hallmark_panorama_preflight_bundle", "list")

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      ".Script14A_staging_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(
    dirs, dir.create, logical(1),
    recursive = TRUE, showWarnings = FALSE
  ) | dir.exists(dirs)), "Unable to create staging directories.")

  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "Hallmark_panorama_preflight_COMPLETE_bundle.rds"
    ),
    TCGA = file.path(
      stage, "objects",
      "TCGA_TNBC_Hallmark_panorama_prepared_input.rds"
    ),
    GSE31519 = file.path(
      stage, "objects",
      "GSE31519_Hallmark_panorama_prepared_input.rds"
    ),
    GSE58812 = file.path(
      stage, "objects",
      "GSE58812_Hallmark_panorama_prepared_input.rds"
    ),
    hallmark = file.path(
      stage, "objects",
      "Human_Hallmark_collection_locked.rds"
    ),
    cohort_summary = file.path(
      stage, "audit",
      "Hallmark_panorama_cohort_preflight_summary.csv"
    ),
    sample_audit = file.path(
      stage, "audit",
      "Hallmark_panorama_sample_alignment_audit.csv"
    ),
    coverage = file.path(
      stage, "audit",
      "Hallmark_panorama_gene_set_coverage_by_cohort.csv"
    ),
    eligibility = file.path(
      stage, "audit",
      "Hallmark_panorama_pathway_eligibility.csv"
    ),
    lock = file.path(
      stage, "audit",
      "Hallmark_panorama_analysis_lock.csv"
    ),
    packages = file.path(
      stage, "audit",
      "Script14A_package_audit.csv"
    ),
    inputs = file.path(
      stage, "audit",
      "Script14A_input_manifest_with_MD5.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "Hallmark_panorama_preflight_integrity_summary.csv"
    ),
    session = file.path(
      stage, "logs",
      "Script14A_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs",
      "Script14A_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(TCGA_prepared, files["TCGA"], version = 3)
  saveRDS(G315_prepared, files["GSE31519"], version = 3)
  saveRDS(G588_prepared, files["GSE58812"], version = 3)
  saveRDS(hallmark_list, files["hallmark"], version = 3)

  write_csv(cohort_summary, files["cohort_summary"])
  write_csv(sample_audit, files["sample_audit"])
  write_csv(coverage, files["coverage"])
  write_csv(eligibility, files["eligibility"])
  write_csv(analysis_lock, files["lock"])
  write_csv(package_audit, files["packages"])
  write_csv(input_manifest, files["inputs"])
  write_csv(integrity, files["integrity"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan - Script 14A Hallmark Panorama Preflight",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("TCGA prepared dimensions: ",
           paste(dim(TCGA_prepared$expression), collapse = " x ")),
    paste0("GSE31519 prepared dimensions: ",
           paste(dim(G315_prepared$expression), collapse = " x ")),
    paste0("GSE58812 prepared dimensions: ",
           paste(dim(G588_prepared$expression), collapse = " x ")),
    paste0("Total samples: ", 197L + 579L + 107L),
    paste0("GSE31519 source datasets: ",
           length(unique(G315_prepared$source_dataset_id))),
    paste0("Human Hallmark pathways: ", length(hallmark_list)),
    paste0("Eligible in all three cohorts: ", eligible_n),
    paste0(
      "EMT detected genes: TCGA=",
      observed_EMT_detected["TCGA_TNBC"],
      "; GSE31519=", observed_EMT_detected["GSE31519"],
      "; GSE58812=", observed_EMT_detected["GSE58812"]
    ),
    "Pathway correlations performed: FALSE",
    "Meta-analysis performed: FALSE",
    "New score/survival/cutoff/grouping/sample filtering performed: FALSE",
    paste0("Readiness status: ", readiness_status),
    "",
    "SCRIPT14A STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  t2 <- readRDS(files["TCGA"])
  g12 <- readRDS(files["GSE31519"])
  g22 <- readRDS(files["GSE58812"])
  h2 <- readRDS(files["hallmark"])

  assert(
    identical(as.character(b2$readiness_status), "READY_FOR_SCRIPT14B") &&
      identical(t2$expression, TCGA_prepared$expression) &&
      identical(g12$expression, G315_prepared$expression) &&
      identical(g22$expression, G588_prepared$expression) &&
      identical(h2, hallmark_list) &&
      identical(colnames(t2$expression), names(t2$Triclosan_activity)) &&
      identical(colnames(g12$expression), names(g12$Triclosan_activity)) &&
      identical(colnames(g22$expression), names(g22$Triclosan_activity)),
    "Prepared RDS save-read verification failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script14A_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script14A_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script14A_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 14A completed successfully.\n")
  cat("50 Hallmark pathways passed three-cohort coverage preflight.\n")
  cat("Readiness status: READY_FOR_SCRIPT14B\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

# ==============================================================================
# TNBC_Triclosan | Script 14C COMPACT FINAL
# Uniform cross-cohort meta-analysis of all 50 locked Hallmark pathways and
# objective EMT ranking.
#
# Primary screening design locked before Script14B results:
# - Fisher z transformation of each cohort association;
# - conventional within-cohort variance 1/(n-3);
# - fixed inverse-variance and DerSimonian-Laird random effects;
# - primary multiple testing: BH across 50 random-effects normal p values;
# - modified Knapp-Hartung t inference as a conservative small-k sensitivity;
# - EMT ranks by absolute pooled rho, signed pooled rho and meta FDR.
#
# This script performs NO new GSVA, NO pathway selection and NO figure.
# No new Triclosan score, survival model, cutoff, grouping, sample deletion,
# DEG, PCA or GSEA.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script14C_COMPACT_FINAL_20260712"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"

SCRIPT14B_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "01_cohort_Hallmark_scores_and_associations"
)
CORE_META_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "01_final_EMT_correlation_meta_analysis"
)
OUTPUT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "02_cross_cohort_Hallmark_meta_and_EMT_ranking"
)

INPUTS <- c(
  Script14B_bundle = file.path(
    SCRIPT14B_ROOT, "objects",
    "Hallmark_panorama_cohort_associations_COMPLETE_bundle.rds"
  ),
  Script14B_results = file.path(
    SCRIPT14B_ROOT, "audit",
    "Hallmark_panorama_cohort_association_results.csv"
  ),
  Script14B_manifest = file.path(
    SCRIPT14B_ROOT, "audit",
    "Script14B_output_manifest_with_MD5.csv"
  ),
  Script14B_report = file.path(
    SCRIPT14B_ROOT, "logs",
    "Script14B_COMPLETE_report.txt"
  ),
  accepted_core_EMT_meta_bundle = file.path(
    CORE_META_ROOT, "objects",
    "Cross_cohort_EMT_meta_analysis_COMPLETE_bundle.rds"
  ),
  accepted_core_EMT_meta_manifest = file.path(
    CORE_META_ROOT, "audit",
    "Script13G_C_output_manifest_with_MD5.csv"
  ),
  accepted_core_EMT_meta_report = file.path(
    CORE_META_ROOT, "logs",
    "Script13G_C_COMPLETE_report.txt"
  )
)

EXPECTED_MD5 <- c(
  Script14B_bundle = "a79eae31667fa1d8b4b8f736debd4652",
  Script14B_results = "1d3d6d6c1d7c84d2e1c5cb80151a8fb1",
  Script14B_manifest = "3a9e4b9d9fa2d5a29e51fd0606b20a49",
  Script14B_report = "b9361c2292b95deda63189d3a7d2d320",
  accepted_core_EMT_meta_bundle =
    "7625b1e291e1291762426382eb80a1f4",
  accepted_core_EMT_meta_manifest =
    "33d11d8780ce3964b4c5170510c21982",
  accepted_core_EMT_meta_report =
    "799b798e670d2b5b639d9294b7a259a2"
)

COHORT_ORDER <- c("TCGA_TNBC", "GSE31519", "GSE58812")
EXPECTED_N <- c(
  TCGA_TNBC = 197L,
  GSE31519 = 579L,
  GSE58812 = 107L
)
EXPECTED_METHOD <- c(
  TCGA_TNBC = "Spearman",
  GSE31519 = "Partial_Spearman_source_centered_ranks",
  GSE58812 = "Spearman"
)
EXPECTED_HALLMARK_NUMBER <- 50L
EMT_NAME <- "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"
NUMERIC_TOLERANCE <- 1e-12

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

scalar_text <- function(x, label = "value") {
  y <- as.character(x)
  assert(length(y) == 1L && !is.na(y) && nzchar(trimws(y)),
         "%s must be one nonblank scalar value.", label)
  unname(trimws(y))
}

same_text <- function(x, y) {
  identical(
    scalar_text(x, "observed text"),
    scalar_text(y, "expected text")
  )
}

same_numeric <- function(x, y, tolerance = NUMERIC_TOLERANCE) {
  isTRUE(all.equal(
    as.numeric(x),
    as.numeric(y),
    tolerance = tolerance,
    check.attributes = FALSE
  ))
}

report_contains <- function(file, marker) {
  any(grepl(
    marker,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)

    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)

    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

select_one <- function(data, condition, label) {
  index <- which(condition)
  assert(length(index) == 1L,
         "%s must select exactly one row; selected %d.",
         label, length(index))
  data[index, , drop = FALSE]
}

meta_one_pathway <- function(data) {
  data <- data[match(COHORT_ORDER, data$cohort), , drop = FALSE]
  assert(
    nrow(data) == 3L &&
      identical(as.character(data$cohort), COHORT_ORDER) &&
      identical(as.integer(data$sample_number),
                as.integer(EXPECTED_N[COHORT_ORDER])) &&
      identical(as.character(data$method),
                unname(EXPECTED_METHOD[COHORT_ORDER])),
    "A pathway failed cohort, sample-number or method locks."
  )

  rho <- as.numeric(data$estimate)
  assert(all(is.finite(rho) & rho > -1 & rho < 1),
         "A pathway contains an invalid correlation.")

  z <- atanh(pmax(pmin(rho, 0.999999), -0.999999))
  variance <- 1 / (as.numeric(data$sample_number) - 3)
  weight <- 1 / variance

  z_fixed <- sum(weight * z) / sum(weight)
  se_fixed <- sqrt(1 / sum(weight))

  Q <- sum(weight * (z - z_fixed)^2)
  Q_df <- length(z) - 1L
  Q_p <- pchisq(Q, df = Q_df, lower.tail = FALSE)
  I2 <- if (Q > 0) max(0, (Q - Q_df) / Q) * 100 else 0
  C <- sum(weight) - sum(weight^2) / sum(weight)
  tau2 <- if (C > 0) max(0, (Q - Q_df) / C) else 0

  random_weight <- 1 / (variance + tau2)
  z_random <- sum(random_weight * z) / sum(random_weight)
  se_random <- sqrt(1 / sum(random_weight))
  random_p <- 2 * pnorm(
    abs(z_random / se_random), lower.tail = FALSE
  )
  normal_critical <- qnorm(0.975)

  residual_scale <- max(
    1,
    sum(random_weight * (z - z_random)^2) / Q_df
  )
  se_modified_KH <- sqrt(residual_scale / sum(random_weight))
  t_critical <- qt(0.975, df = Q_df)
  modified_KH_p <- 2 * pt(
    abs(z_random / se_modified_KH),
    df = Q_df,
    lower.tail = FALSE
  )

  sign_vector <- ifelse(rho > 0, "+", ifelse(rho < 0, "-", "0"))

  data.frame(
    pathway = as.character(data$pathway[1L]),
    cohort_number = 3L,
    total_sample_number = sum(data$sample_number),
    TCGA_TNBC_rho = rho[1L],
    GSE31519_rho = rho[2L],
    GSE58812_rho = rho[3L],
    positive_cohort_number = sum(rho > 0),
    negative_cohort_number = sum(rho < 0),
    direction_pattern = paste(sign_vector, collapse = ";"),
    all_three_positive = all(rho > 0),
    all_three_negative = all(rho < 0),
    direction_consistent = all(rho > 0) || all(rho < 0),
    fixed_pooled_fisher_z = z_fixed,
    fixed_standard_error = se_fixed,
    fixed_pooled_rho = tanh(z_fixed),
    fixed_95CI_lower_rho =
      tanh(z_fixed - normal_critical * se_fixed),
    fixed_95CI_upper_rho =
      tanh(z_fixed + normal_critical * se_fixed),
    fixed_two_sided_p =
      2 * pnorm(abs(z_fixed / se_fixed), lower.tail = FALSE),
    random_pooled_fisher_z = z_random,
    random_standard_error = se_random,
    random_pooled_rho = tanh(z_random),
    random_95CI_lower_rho =
      tanh(z_random - normal_critical * se_random),
    random_95CI_upper_rho =
      tanh(z_random + normal_critical * se_random),
    random_two_sided_p = random_p,
    Cochran_Q = Q,
    Q_df = Q_df,
    Q_p = Q_p,
    I2_percent = I2,
    tau2 = tau2,
    modified_KH_residual_scale = residual_scale,
    modified_KH_standard_error = se_modified_KH,
    modified_KH_df = Q_df,
    modified_KH_95CI_lower_rho =
      tanh(z_random - t_critical * se_modified_KH),
    modified_KH_95CI_upper_rho =
      tanh(z_random + t_critical * se_modified_KH),
    modified_KH_two_sided_p = modified_KH_p,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

validate_results_table <- function(results) {
  required <- c(
    "cohort", "pathway", "sample_number", "source_dataset_number",
    "method", "estimate", "two_sided_p", "BH_adjusted_p",
    "direction", "rank_by_absolute_rho", "rank_by_signed_rho_desc",
    "is_EMT", "Hallmark_total_gene_number", "detected_gene_number",
    "detected_fraction", "locked24_overlap_gene_number",
    "locked24_overlap_genes"
  )
  assert(
    is.data.frame(results) &&
      nrow(results) == 150L &&
      all(required %in% names(results)) &&
      !anyDuplicated(results[c("cohort", "pathway")]),
    "Script14B result table structure is invalid."
  )

  pathways <- sort(unique(as.character(results$pathway)))
  assert(
    length(pathways) == EXPECTED_HALLMARK_NUMBER &&
      EMT_NAME %in% pathways &&
      identical(sort(unique(as.character(results$cohort))),
                sort(COHORT_ORDER)) &&
      all(table(results$cohort) == EXPECTED_HALLMARK_NUMBER) &&
      all(table(results$pathway) == 3L) &&
      sum(as.logical(results$is_EMT)) == 3L &&
      all(is.finite(results$estimate)) &&
      all(results$estimate > -1 & results$estimate < 1) &&
      all(is.finite(results$two_sided_p)) &&
      all(results$two_sided_p >= 0 & results$two_sided_p <= 1) &&
      all(is.finite(results$BH_adjusted_p)) &&
      all(results$BH_adjusted_p >= 0 & results$BH_adjusted_p <= 1),
    "Script14B result values or 50-by-3 completeness are invalid."
  )

  for (cohort in COHORT_ORDER) {
    d <- results[results$cohort == cohort, , drop = FALSE]
    assert(
      all(d$sample_number == EXPECTED_N[cohort]) &&
        all(d$method == EXPECTED_METHOD[cohort]),
      "%s sample-number or method lock differs.", cohort
    )

    recalculated_BH <- p.adjust(d$two_sided_p, method = "BH")
    assert(
      same_numeric(
        recalculated_BH,
        d$BH_adjusted_p,
        tolerance = 1e-12
      ),
      "%s within-cohort BH values do not reproduce.", cohort
    )
  }

  invisible(pathways)
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "Hallmark_panorama_cross_cohort_meta_COMPLETE_bundle.rds"
    ),
    meta = file.path(
      root, "audit",
      "Hallmark_panorama_50_pathway_meta_results.csv"
    ),
    manifest = file.path(
      root, "audit",
      "Script14C_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script14C_COMPLETE_report.txt"
    )
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT14C STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  m <- tryCatch(
    read.csv(key["meta"], stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )

  is.list(b) &&
    same_text(b$script, "Script14C") &&
    same_text(b$script_build_id, BUILD_ID) &&
    same_text(
      b$strengthening_analysis_status,
      "HALLMARK_PANORAMA_COMPLETE"
    ) &&
    is.data.frame(m) && nrow(m) == 50L &&
    sum(m$is_EMT) == 1L &&
    isFALSE(b$policy$pathway_selection_after_results)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT),
           "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script14C output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "02_cross_cohort_Hallmark_meta_and_EMT_ranking_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Uniform 50-Hallmark cross-cohort meta and EMT ranking only.\n")
  cat("============================================================\n")

  missing_files <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing_files), "Missing accepted input(s):\n%s",
         paste(missing_files, collapse = "\n"))

  observed_md5 <- vapply(INPUTS, md5, character(1))
  assert(
    identical(unname(observed_md5), unname(EXPECTED_MD5)),
    "At least one accepted input MD5 differs:\n%s",
    paste(sprintf(
      "%s | expected=%s | observed=%s",
      names(EXPECTED_MD5), EXPECTED_MD5, observed_md5
    ), collapse = "\n")
  )

  assert(
    manifest_ok(SCRIPT14B_ROOT, INPUTS["Script14B_manifest"]),
    "Script14B manifest verification failed."
  )
  assert(
    manifest_ok(
      CORE_META_ROOT,
      INPUTS["accepted_core_EMT_meta_manifest"]
    ),
    "Accepted Script13G-C manifest verification failed."
  )
  assert(
    report_contains(
      INPUTS["Script14B_report"], "SCRIPT14B STATUS: COMPLETE"
    ),
    "Script14B COMPLETE marker is missing."
  )
  assert(
    report_contains(
      INPUTS["accepted_core_EMT_meta_report"],
      "SCRIPT13G_C STATUS: COMPLETE"
    ),
    "Accepted Script13G-C COMPLETE marker is missing."
  )

  Script14B <- readRDS(INPUTS["Script14B_bundle"])
  results_csv <- read.csv(
    INPUTS["Script14B_results"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  accepted_core <- readRDS(
    INPUTS["accepted_core_EMT_meta_bundle"]
  )

  assert(
    is.list(Script14B) &&
      same_text(Script14B$script, "Script14B") &&
      same_text(
        Script14B$script_build_id,
        "Script14B_COMPACT_FINAL_20260712"
      ) &&
      same_text(
        Script14B$readiness_status,
        "READY_FOR_SCRIPT14C"
      ) &&
      isTRUE(Script14B$policy$all_50_pathways_scored) &&
      isTRUE(
        Script14B$policy$within_cohort_associations_performed
      ) &&
      isFALSE(Script14B$policy$pathway_selection_after_results) &&
      isFALSE(Script14B$policy$meta_analysis_performed),
    "Script14B bundle identity or analysis-boundary lock is incorrect."
  )

  results <- Script14B$cohort_association_results
  validate_results_table(results)
  validate_results_table(results_csv)

  key <- c(
    "cohort", "pathway", "sample_number", "source_dataset_number",
    "method", "estimate", "two_sided_p", "BH_adjusted_p",
    "rank_by_absolute_rho", "rank_by_signed_rho_desc",
    "Hallmark_total_gene_number", "detected_gene_number",
    "detected_fraction", "locked24_overlap_gene_number"
  )
  assert(
    identical(
      as.character(results$cohort),
      as.character(results_csv$cohort)
    ) &&
      identical(
        as.character(results$pathway),
        as.character(results_csv$pathway)
      ) &&
      same_numeric(
        unlist(results[key[vapply(
          results[key], is.numeric, logical(1)
        )]]),
        unlist(results_csv[key[vapply(
          results_csv[key], is.numeric, logical(1)
        )]]),
        tolerance = 1e-12
      ),
    "Script14B RDS and CSV result tables differ."
  )

  assert(
    is.list(accepted_core) &&
      same_text(accepted_core$script, "Script13G_C") &&
      same_text(
        accepted_core$script_build_id,
        "Script13G_C_v2_COMPACT_FINAL_20260711"
      ) &&
      same_text(
        accepted_core$analysis_freeze_decision,
        "FREEZE_ANALYSIS"
      ),
    "Accepted core EMT meta bundle identity is incorrect."
  )

  dir.create(dirname(OUTPUT_ROOT), recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(dirname(OUTPUT_ROOT)),
         "Unable to create Hallmark panorama parent directory.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  pathways <- sort(unique(as.character(results$pathway)))
  meta_results <- do.call(rbind, lapply(pathways, function(pathway) {
    meta_one_pathway(
      results[results$pathway == pathway, , drop = FALSE]
    )
  }))
  rownames(meta_results) <- NULL

  meta_results$random_meta_BH <- p.adjust(
    meta_results$random_two_sided_p, method = "BH"
  )
  meta_results$modified_KH_meta_BH <- p.adjust(
    meta_results$modified_KH_two_sided_p, method = "BH"
  )
  meta_results$rank_by_absolute_random_rho <- rank(
    -abs(meta_results$random_pooled_rho), ties.method = "min"
  )
  meta_results$rank_by_signed_random_rho_desc <- rank(
    -meta_results$random_pooled_rho, ties.method = "min"
  )
  meta_results$rank_by_random_meta_BH <- rank(
    meta_results$random_meta_BH, ties.method = "min"
  )
  meta_results$rank_by_modified_KH_meta_BH <- rank(
    meta_results$modified_KH_meta_BH, ties.method = "min"
  )
  meta_results$is_EMT <- meta_results$pathway == EMT_NAME

  meta_results <- meta_results[
    order(meta_results$rank_by_absolute_random_rho,
          meta_results$pathway),
    ,
    drop = FALSE
  ]
  rownames(meta_results) <- NULL

  assert(
    nrow(meta_results) == 50L &&
      !anyDuplicated(meta_results$pathway) &&
      sum(meta_results$is_EMT) == 1L &&
      all(is.finite(meta_results$random_pooled_rho)) &&
      all(is.finite(meta_results$random_two_sided_p)) &&
      all(is.finite(meta_results$random_meta_BH)) &&
      all(is.finite(meta_results$modified_KH_two_sided_p)) &&
      all(is.finite(meta_results$modified_KH_meta_BH)),
    "Final 50-pathway meta table failed integrity checks."
  )

  EMT <- select_one(
    meta_results,
    meta_results$is_EMT,
    "Hallmark EMT meta result"
  )
  accepted_conventional <- select_one(
    accepted_core$primary_meta_conventional_sensitivity,
    accepted_core$primary_meta_conventional_sensitivity$
      pooling_method == "RANDOM_DL_NORMAL",
    "Accepted conventional-variance core EMT result"
  )

  benchmark_fields <- c(
    "pooled_rho",
    "confidence_interval_lower_rho",
    "confidence_interval_upper_rho",
    "two_sided_p",
    "I2_percent",
    "Q_p",
    "tau2"
  )
  observed_benchmark <- c(
    EMT$random_pooled_rho,
    EMT$random_95CI_lower_rho,
    EMT$random_95CI_upper_rho,
    EMT$random_two_sided_p,
    EMT$I2_percent,
    EMT$Q_p,
    EMT$tau2
  )
  accepted_benchmark <- as.numeric(
    accepted_conventional[1L, benchmark_fields]
  )

  assert(
    same_numeric(
      observed_benchmark,
      accepted_benchmark,
      tolerance = 1e-12
    ),
    "Script14C EMT meta does not reproduce the accepted conventional result."
  )

  EMT_rank <- data.frame(
    pathway = EMT$pathway,
    cohort_number = EMT$cohort_number,
    total_sample_number = EMT$total_sample_number,
    TCGA_TNBC_rho = EMT$TCGA_TNBC_rho,
    GSE31519_rho = EMT$GSE31519_rho,
    GSE58812_rho = EMT$GSE58812_rho,
    random_pooled_rho = EMT$random_pooled_rho,
    random_95CI_lower_rho = EMT$random_95CI_lower_rho,
    random_95CI_upper_rho = EMT$random_95CI_upper_rho,
    random_two_sided_p = EMT$random_two_sided_p,
    random_meta_BH = EMT$random_meta_BH,
    modified_KH_95CI_lower_rho =
      EMT$modified_KH_95CI_lower_rho,
    modified_KH_95CI_upper_rho =
      EMT$modified_KH_95CI_upper_rho,
    modified_KH_two_sided_p =
      EMT$modified_KH_two_sided_p,
    modified_KH_meta_BH = EMT$modified_KH_meta_BH,
    I2_percent = EMT$I2_percent,
    Q_p = EMT$Q_p,
    tau2 = EMT$tau2,
    all_three_positive = EMT$all_three_positive,
    rank_by_absolute_random_rho =
      EMT$rank_by_absolute_random_rho,
    rank_by_signed_random_rho_desc =
      EMT$rank_by_signed_random_rho_desc,
    rank_by_random_meta_BH =
      EMT$rank_by_random_meta_BH,
    rank_by_modified_KH_meta_BH =
      EMT$rank_by_modified_KH_meta_BH,
    accepted_core_conventional_benchmark_reproduced = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  cohort_effects_wide <- meta_results[, c(
    "pathway", "TCGA_TNBC_rho", "GSE31519_rho",
    "GSE58812_rho", "direction_pattern",
    "positive_cohort_number", "negative_cohort_number",
    "all_three_positive", "all_three_negative",
    "direction_consistent"
  )]

  direction_summary <- data.frame(
    category = c(
      "All_three_positive",
      "All_three_negative",
      "Direction_consistent_total",
      "Mixed_direction",
      "Random_meta_BH_below_0.05",
      "Modified_KH_meta_BH_below_0.05",
      "Both_meta_BH_below_0.05",
      "All_three_positive_and_both_meta_BH_below_0.05"
    ),
    pathway_number = c(
      sum(meta_results$all_three_positive),
      sum(meta_results$all_three_negative),
      sum(meta_results$direction_consistent),
      sum(!meta_results$direction_consistent),
      sum(meta_results$random_meta_BH < 0.05),
      sum(meta_results$modified_KH_meta_BH < 0.05),
      sum(
        meta_results$random_meta_BH < 0.05 &
          meta_results$modified_KH_meta_BH < 0.05
      ),
      sum(
        meta_results$all_three_positive &
          meta_results$random_meta_BH < 0.05 &
          meta_results$modified_KH_meta_BH < 0.05
      )
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  top_summary <- meta_results[
    meta_results$rank_by_absolute_random_rho <= 10L,
    c(
      "pathway", "random_pooled_rho",
      "random_95CI_lower_rho", "random_95CI_upper_rho",
      "random_two_sided_p", "random_meta_BH",
      "modified_KH_two_sided_p", "modified_KH_meta_BH",
      "I2_percent", "Q_p", "direction_pattern",
      "all_three_positive", "all_three_negative",
      "rank_by_absolute_random_rho",
      "rank_by_signed_random_rho_desc",
      "rank_by_random_meta_BH"
    ),
    drop = FALSE
  ]

  parameter_lock <- data.frame(
    field = c(
      "Analysis_stage",
      "Pathway_number",
      "Cohort_order",
      "Effect_measure",
      "Transformation",
      "Within_cohort_variance",
      "Primary_random_effects_model",
      "Primary_multiple_testing",
      "Small_k_sensitivity",
      "Sensitivity_multiple_testing",
      "Heterogeneity",
      "EMT_rank_metrics",
      "Pathway_selection_after_results",
      "New_GSVA_or_score",
      "Survival_analysis",
      "Sample_filtering",
      "Cutoff_or_high_low_group",
      "DEG_PCA_GSEA_figure",
      "Next_stage"
    ),
    value = c(
      "Uniform 50-Hallmark cross-cohort synthesis",
      50L,
      paste(COHORT_ORDER, collapse = ";"),
      "Cohort association rho",
      "Fisher z = atanh(rho)",
      "1/(n-3), locked before pathway results",
      "DerSimonian-Laird; normal inference",
      "BH across 50 random-effects p values",
      "Modified Knapp-Hartung; t df=2; scale not below 1",
      "BH across 50 modified-KH p values",
      "Cochran Q, Q p, I2 and DL tau2",
      paste0(
        "Absolute random pooled rho; signed random pooled rho; ",
        "random meta BH; modified-KH meta BH"
      ),
      "PROHIBITED",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "Proceed to strengthening analysis 2 only after uploaded-result audit"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    input_name = names(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(
        PROJECT_ROOT, winslash = "/", mustWork = TRUE
      )) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed_md5,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  strengthening_status <- "HALLMARK_PANORAMA_COMPLETE"
  integrity <- data.frame(
    item = c(
      "Script",
      "Script_build_ID",
      "Input_file_number",
      "Input_MD5_all_locked",
      "Input_cohort_effect_row_number",
      "Pathway_number",
      "Meta_result_row_number",
      "Unique_pathways",
      "EMT_row_number",
      "Accepted_core_EMT_benchmark_reproduced",
      "Random_meta_BH_performed",
      "Modified_KH_meta_BH_performed",
      "Heterogeneity_calculated",
      "Pathways_selected_after_results",
      "New_GSVA_or_score_calculated",
      "Survival_analysis_performed",
      "Samples_filtered",
      "Figure_created",
      "Strengthening_analysis_status",
      "Completion_status"
    ),
    value = as.character(c(
      "14C",
      BUILD_ID,
      length(INPUTS),
      TRUE,
      nrow(results),
      length(pathways),
      nrow(meta_results),
      length(unique(meta_results$pathway)),
      sum(meta_results$is_EMT),
      TRUE,
      TRUE,
      TRUE,
      TRUE,
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      strengthening_status,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = paste0(
      "Step5_cross_cohort_synthesis/02_Hallmark_panorama/",
      "02_cross_cohort_Hallmark_meta_and_EMT_ranking"
    ),
    script = "Script14C",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    strengthening_analysis_status = strengthening_status,
    all_50_pathway_meta_results = meta_results,
    cohort_effects_wide = cohort_effects_wide,
    EMT_rank_summary = EMT_rank,
    top_10_absolute_effect_pathways = top_summary,
    direction_consistency_summary = direction_summary,
    parameter_lock = parameter_lock,
    input_manifest = input_manifest,
    integrity_summary = integrity,
    policy = list(
      core_EMT_analysis_remains_frozen = TRUE,
      Hallmark_panorama_completed = TRUE,
      all_50_pathways_meta_analyzed = TRUE,
      random_meta_BH_performed = TRUE,
      modified_KH_sensitivity_performed = TRUE,
      modified_KH_meta_BH_performed = TRUE,
      heterogeneity_calculated = TRUE,
      pathway_selection_after_results = FALSE,
      new_GSVA_performed = FALSE,
      new_Triclosan_score_calculated = FALSE,
      survival_analysis_performed = FALSE,
      samples_filtered = FALSE,
      outliers_removed = FALSE,
      cutoff_selected = FALSE,
      high_low_group_created = FALSE,
      DEG_performed = FALSE,
      PCA_performed = FALSE,
      GSEA_performed = FALSE,
      manuscript_figure_created = FALSE
    )
  )
  class(bundle) <- c(
    "Hallmark_panorama_cross_cohort_meta_bundle", "list"
  )

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      ".Script14C_staging_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(
    dirs, dir.create, logical(1),
    recursive = TRUE, showWarnings = FALSE
  ) | dir.exists(dirs)), "Unable to create staging directories.")

  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "Hallmark_panorama_cross_cohort_meta_COMPLETE_bundle.rds"
    ),
    meta_rds = file.path(
      stage, "objects",
      "Hallmark_panorama_50_pathway_meta_results.rds"
    ),
    meta_csv = file.path(
      stage, "audit",
      "Hallmark_panorama_50_pathway_meta_results.csv"
    ),
    effects = file.path(
      stage, "audit",
      "Hallmark_panorama_cohort_effects_wide.csv"
    ),
    EMT = file.path(
      stage, "audit",
      "Hallmark_panorama_EMT_rank_summary.csv"
    ),
    top = file.path(
      stage, "audit",
      "Hallmark_panorama_top10_absolute_effect_pathways.csv"
    ),
    direction = file.path(
      stage, "audit",
      "Hallmark_panorama_direction_consistency_summary.csv"
    ),
    parameters = file.path(
      stage, "audit",
      "Hallmark_panorama_meta_parameter_lock.csv"
    ),
    inputs = file.path(
      stage, "audit",
      "Script14C_input_manifest_with_MD5.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "Hallmark_panorama_meta_integrity_summary.csv"
    ),
    session = file.path(
      stage, "logs", "Script14C_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs", "Script14C_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(meta_results, files["meta_rds"], version = 3)
  write_csv(meta_results, files["meta_csv"])
  write_csv(cohort_effects_wide, files["effects"])
  write_csv(EMT_rank, files["EMT"])
  write_csv(top_summary, files["top"])
  write_csv(direction_summary, files["direction"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(input_manifest, files["inputs"])
  write_csv(integrity, files["integrity"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan - Script14C 50-Hallmark Meta and EMT Rank",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "Pathways meta-analyzed uniformly: 50",
    "Cohorts: TCGA_TNBC; GSE31519; GSE58812",
    "Total samples per pathway: 883",
    paste0(
      "EMT pooled rho: ",
      format(EMT$random_pooled_rho, digits = 16)
    ),
    paste0(
      "EMT normal 95% CI: ",
      format(EMT$random_95CI_lower_rho, digits = 16),
      " to ",
      format(EMT$random_95CI_upper_rho, digits = 16)
    ),
    paste0(
      "EMT random meta p: ",
      format(EMT$random_two_sided_p, digits = 16)
    ),
    paste0(
      "EMT random meta BH: ",
      format(EMT$random_meta_BH, digits = 16)
    ),
    paste0(
      "EMT modified-KH p: ",
      format(EMT$modified_KH_two_sided_p, digits = 16)
    ),
    paste0(
      "EMT modified-KH BH: ",
      format(EMT$modified_KH_meta_BH, digits = 16)
    ),
    paste0(
      "EMT I2: ",
      format(EMT$I2_percent, digits = 10), "%"
    ),
    paste0(
      "EMT rank by absolute pooled rho: ",
      EMT$rank_by_absolute_random_rho, "/50"
    ),
    paste0(
      "EMT rank by signed pooled rho: ",
      EMT$rank_by_signed_random_rho_desc, "/50"
    ),
    paste0(
      "EMT rank by random meta BH: ",
      EMT$rank_by_random_meta_BH, "/50"
    ),
    "Accepted core conventional EMT result reproduced: TRUE",
    paste0(
      "Pathways with all-three-positive direction: ",
      sum(meta_results$all_three_positive)
    ),
    paste0(
      "Pathways with random meta BH < 0.05: ",
      sum(meta_results$random_meta_BH < 0.05)
    ),
    paste0(
      "Pathways with modified-KH meta BH < 0.05: ",
      sum(meta_results$modified_KH_meta_BH < 0.05)
    ),
    "Pathway selection after results: FALSE",
    "New GSVA/score/survival/cutoff/grouping/sample filtering: FALSE",
    paste0(
      "Strengthening analysis status: ",
      strengthening_status
    ),
    "",
    "SCRIPT14C STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  m2 <- readRDS(files["meta_rds"])
  c2 <- read.csv(
    files["meta_csv"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  e2 <- read.csv(
    files["EMT"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert(
    same_text(
      b2$strengthening_analysis_status,
      "HALLMARK_PANORAMA_COMPLETE"
    ) &&
      identical(m2, meta_results) &&
      nrow(c2) == 50L &&
      same_numeric(
        c2$random_pooled_rho,
        meta_results$random_pooled_rho,
        tolerance = 1e-14
      ) &&
      nrow(e2) == 1L &&
      same_numeric(
        e2$random_pooled_rho,
        EMT$random_pooled_rho,
        tolerance = 1e-14
      ),
    "Staged RDS/CSV save-read verification failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script14C_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script14C_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script14C_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script14C completed successfully.\n")
  cat("All 50 Hallmark pathways were meta-analyzed uniformly.\n")
  cat(
    "EMT absolute pooled-effect rank: ",
    EMT$rank_by_absolute_random_rho, "/50\n",
    sep = ""
  )
  cat("Strengthening analysis status: HALLMARK_PANORAMA_COMPLETE\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

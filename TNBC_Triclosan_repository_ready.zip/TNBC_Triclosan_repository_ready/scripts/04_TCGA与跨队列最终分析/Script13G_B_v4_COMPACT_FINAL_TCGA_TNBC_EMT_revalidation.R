# ==============================================================================
# TNBC_Triclosan | TCGA TNBC | Script 13G-B COMPACT FINAL
# Rebuild the TCGA Triclosan_activity–EMT validation with one row per sample.
#
# This step replaces the historical Figure 3C join, which expanded 197 intended
# TNBC samples to 209 rows through a many-to-many merge.
#
# Locked inputs:
# - TNBC_expression_matrix.rds: expected 59,427 genes x 197 samples;
# - Triclosan_activity_score.rds: original continuous TCGA score object.
#
# Locked analysis:
# - audit raw gene symbols without assuming they are already unique;
# - remove blank gene-symbol rows and aggregate duplicate symbols by
#   sample-wise median, without using phenotype or outcome information;
# - restore each shortened expression-column ID to its original complete
#   TCGA score barcode by short-ID multiplicity and preserved source order;
# - retain all 197 expression columns without deleting repeated short IDs;
# - log2(x + 1) expression transformation;
# - classical GSVA Hallmark EMT scoring;
# - continuous Spearman association;
# - overlap-removed EMT sensitivity and Pearson sensitivity;
# - 10,000-sample percentile bootstrap confidence intervals.
#
# No survival analysis, cutoff, high/low grouping, sample deletion, DEG, PCA,
# GSEA, final meta-analysis or manuscript figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script13G_B_v4_COMPACT_FINAL_20260711"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"
OUTPUT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "00_TCGA_TNBC_EMT_revalidation"
)

PREFERRED_INPUTS <- c(
  expression = file.path(PROJECT_ROOT, "data", "TNBC_expression_matrix.rds"),
  score = file.path(PROJECT_ROOT, "results", "Triclosan_activity_score.rds")
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)
EMT_NAME <- "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"
BOOTSTRAP_N <- 10000L
BOOTSTRAP_SEED <- 20260711L

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

resolve_input <- function(preferred, target_basename) {
  if (file.exists(preferred)) {
    return(list(
      selected = normalizePath(preferred, winslash = "/", mustWork = TRUE),
      candidates = normalizePath(preferred, winslash = "/", mustWork = TRUE),
      resolution = "PREFERRED_PATH"
    ))
  }

  search_roots <- unique(c(
    file.path(PROJECT_ROOT, "data"),
    file.path(PROJECT_ROOT, "results"),
    PROJECT_ROOT
  ))
  search_roots <- search_roots[dir.exists(search_roots)]
  candidates <- unique(unlist(lapply(search_roots, function(root) {
    list.files(
      root,
      pattern = paste0("^", gsub("\\.", "\\\\.", target_basename), "$"),
      recursive = TRUE,
      full.names = TRUE,
      ignore.case = FALSE
    )
  })))
  candidates <- candidates[file.exists(candidates)]
  candidates <- normalizePath(candidates, winslash = "/", mustWork = TRUE)

  assert(length(candidates) >= 1L,
         "Could not locate required file: %s", target_basename)

  candidate_md5 <- vapply(candidates, md5, character(1))
  distinct_md5 <- unique(candidate_md5)
  assert(
    length(distinct_md5) == 1L,
    paste0(
      "Multiple different files named ", target_basename,
      " were found. No file was selected automatically:\n",
      paste(sprintf("%s | %s", candidates, candidate_md5), collapse = "\n")
    )
  )

  selected <- candidates[
    order(nchar(candidates), candidates)
  ][1L]
  list(
    selected = selected,
    candidates = candidates,
    resolution = if (length(candidates) == 1L) {
      "UNIQUE_RECURSIVE_MATCH"
    } else {
      "MULTIPLE_IDENTICAL_MD5_MATCHES_SHORTEST_PATH_SELECTED"
    }
  )
}

extract_expression <- function(object) {
  if (is.matrix(object)) {
    x <- object
  } else if (is.data.frame(object)) {
    assert(all(vapply(object, is.numeric, logical(1))),
           "Expression data.frame contains non-numeric columns.")
    x <- as.matrix(object)
  } else if (
    inherits(object, "SummarizedExperiment") &&
      requireNamespace("SummarizedExperiment", quietly = TRUE)
  ) {
    x <- as.matrix(SummarizedExperiment::assay(object))
  } else {
    stopf("Unsupported expression object class: %s",
          paste(class(object), collapse = ", "))
  }
  storage.mode(x) <- "double"
  x
}

extract_score <- function(object) {
  if (is.numeric(object) && !is.null(names(object))) {
    x <- as.numeric(object)
    names(x) <- names(object)
    return(x)
  }

  if (is.matrix(object) || is.data.frame(object)) {
    d <- as.data.frame(object, stringsAsFactors = FALSE, check.names = FALSE)
    if ("Triclosan_activity" %in% names(d)) {
      x <- as.numeric(d$Triclosan_activity)
      names(x) <- rownames(d)
      if (
        ("sample_id" %in% names(d)) &&
          all(!is.na(d$sample_id) & nzchar(as.character(d$sample_id)))
      ) {
        names(x) <- as.character(d$sample_id)
      }
      return(x)
    }
    if (ncol(d) == 1L) {
      x <- as.numeric(d[[1L]])
      names(x) <- rownames(d)
      return(x)
    }
    if (nrow(d) == 1L) {
      x <- as.numeric(d[1L, ])
      names(x) <- names(d)
      return(x)
    }
  }

  stopf("Could not extract one named continuous Triclosan score vector.")
}

build_unique_gene_matrix <- function(expr) {
  raw_ids <- rownames(expr)
  assert(!is.null(raw_ids),
         "Expression matrix has no gene-row identifiers.")

  clean_ids <- trimws(as.character(raw_ids))
  blank <- is.na(clean_ids) | !nzchar(clean_ids)
  valid_expr <- expr[!blank, , drop = FALSE]
  valid_ids <- clean_ids[!blank]

  assert(length(valid_ids) > 0L,
         "No nonblank gene identifiers remain.")
  assert(all(is.finite(valid_expr)),
         "Expression matrix contains non-finite values; no imputation is allowed.")
  assert(min(valid_expr) >= 0,
         paste0(
           "Expression matrix contains negative values (minimum = ",
           format(min(valid_expr), digits = 16),
           "). The locked log2(x+1) transformation was not applied."
         ))
  gene_order <- unique(valid_ids)
  split_index <- split(
    seq_along(valid_ids),
    factor(valid_ids, levels = gene_order)
  )
  source_count <- lengths(split_index)

  gene_expr <- t(vapply(split_index, function(i) {
    if (length(i) == 1L) {
      as.numeric(valid_expr[i, , drop = TRUE])
    } else {
      apply(valid_expr[i, , drop = FALSE], 2L, stats::median)
    }
  }, numeric(ncol(valid_expr))))

  rownames(gene_expr) <- gene_order
  colnames(gene_expr) <- colnames(valid_expr)

  assert(
    is.matrix(gene_expr) && is.numeric(gene_expr) &&
      ncol(gene_expr) == ncol(expr) &&
      identical(rownames(gene_expr), gene_order) &&
      identical(colnames(gene_expr), colnames(expr)) &&
      !anyDuplicated(rownames(gene_expr)) &&
      all(is.finite(gene_expr)) &&
      min(gene_expr) >= 0,
    "Unique gene-level matrix failed dimension, order or finite-value checks."
  )

  single <- which(source_count == 1L)
  assert(
    all(vapply(single, function(i) {
      identical(
        as.numeric(gene_expr[i, ]),
        as.numeric(valid_expr[split_index[[i]], , drop = TRUE])
      )
    }, logical(1))),
    "At least one single-row gene was not copied unchanged."
  )

  multi <- which(source_count > 1L)
  if (length(multi)) {
    audit_multi <- unique(round(seq(
      1L, length(multi), length.out = min(25L, length(multi))
    )))
    assert(
      all(vapply(multi[audit_multi], function(i) {
        expected <- apply(
          valid_expr[split_index[[i]], , drop = FALSE],
          2L, stats::median
        )
        identical(as.numeric(gene_expr[i, ]), as.numeric(expected))
      }, logical(1))),
      "Deterministic duplicate-symbol median audit failed."
    )
  }

  row_audit <- data.frame(
    gene_order = seq_along(gene_order),
    gene_symbol = gene_order,
    source_row_number = as.integer(source_count),
    aggregation_rule = ifelse(
      source_count == 1L,
      "COPIED_SINGLE_ROW_UNCHANGED",
      "SAMPLE_WISE_MEDIAN_ACROSS_DUPLICATE_SYMBOL_ROWS"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  summary <- data.frame(
    raw_row_number = nrow(expr),
    blank_gene_ID_row_number = sum(blank),
    nonblank_row_number = length(valid_ids),
    duplicated_symbol_excess_row_number = sum(duplicated(valid_ids)),
    unique_gene_number = length(gene_order),
    single_row_gene_number = sum(source_count == 1L),
    multi_row_gene_number = sum(source_count > 1L),
    maximum_rows_per_gene = max(source_count),
    nonfinite_value_number = sum(!is.finite(expr)),
    negative_value_number = sum(expr < 0, na.rm = TRUE),
    minimum_expression = min(expr, na.rm = TRUE),
    maximum_expression = max(expr, na.rm = TRUE),
    expression_values_modified_before_aggregation = FALSE,
    blank_rows_excluded = sum(blank) > 0L,
    duplicate_symbols_aggregated = any(source_count > 1L),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(
    expression = gene_expr,
    row_audit = row_audit,
    summary = summary
  )
}

tcga16 <- function(x) {
  y <- substr(trimws(as.character(x)), 1L, 16L)
  y[!grepl("^TCGA-[A-Za-z0-9]{2}-[A-Za-z0-9]{4}-[0-9]{2}[A-Za-z]$", y)] <-
    NA_character_
  y
}

occurrence_index <- function(ids) {
  ids <- as.character(ids)
  ave(seq_along(ids), ids, FUN = seq_along)
}

occurrence_key <- function(ids) {
  paste0(ids, "__OCC", sprintf("%03d", occurrence_index(ids)))
}

restore_complete_sample_barcodes <- function(expression_short_ids, score_names) {
  score_short_ids <- tcga16(score_names)

  assert(
    all(!is.na(expression_short_ids)),
    "At least one expression column lacks a valid 16-character TCGA sample ID."
  )
  assert(
    sum(!is.na(score_short_ids)) >= length(expression_short_ids),
    "The score object contains too few valid complete TCGA barcodes."
  )

  expression_counts <- table(expression_short_ids)
  score_counts <- table(score_short_ids[score_short_ids %in%
                                          names(expression_counts)])

  missing_groups <- setdiff(names(expression_counts), names(score_counts))
  assert(
    !length(missing_groups),
    "Score object lacks short sample ID group(s): %s",
    paste(missing_groups, collapse = ", ")
  )

  count_audit <- data.frame(
    sample_id16 = names(expression_counts),
    expression_column_number = as.integer(expression_counts),
    score_barcode_number = as.integer(
      score_counts[match(names(expression_counts), names(score_counts))]
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  count_audit$counts_equal <-
    count_audit$expression_column_number == count_audit$score_barcode_number

  assert(
    all(count_audit$counts_equal),
    paste0(
      "Expression/score multiplicity differs for at least one short TCGA ID:\n",
      paste(
        capture.output(print(
          count_audit[!count_audit$counts_equal, , drop = FALSE]
        )),
        collapse = "\n"
      )
    )
  )

  # Both objects were created from the same original 1,231-column TCGA matrix
  # and preserve its column order. Filtering the score object to exactly the
  # short-ID groups present in the 197-column expression matrix must therefore
  # reproduce the expression short-ID sequence.
  candidate <- which(
    !is.na(score_short_ids) &
      score_short_ids %in% names(expression_counts)
  )

  assert(
    length(candidate) == length(expression_short_ids),
    paste0(
      "Filtering the score object by the 197 expression short-ID groups ",
      "returned ", length(candidate), " score rows instead of ",
      length(expression_short_ids), "."
    )
  )
  assert(
    identical(score_short_ids[candidate], expression_short_ids),
    paste0(
      "Expression and score short-ID sequences differ after order-preserving ",
      "filtering. No positional restoration was performed."
    )
  )

  restored_names <- trimws(as.character(score_names[candidate]))
  assert(
    length(restored_names) == length(expression_short_ids) &&
      all(nzchar(restored_names)) &&
      !anyDuplicated(restored_names),
    "Restored complete TCGA score barcodes are blank or duplicated."
  )

  expression_occurrence <- occurrence_index(expression_short_ids)
  score_occurrence <- occurrence_index(score_short_ids[candidate])
  assert(
    identical(expression_occurrence, score_occurrence),
    "Within-short-ID occurrence order differs between expression and score."
  )

  mapping <- data.frame(
    sample_order = seq_along(expression_short_ids),
    expression_sample_id_short = expression_short_ids,
    occurrence_within_short_ID = expression_occurrence,
    occurrence_key = occurrence_key(expression_short_ids),
    restored_complete_score_barcode = restored_names,
    score_object_row_index = candidate,
    score_sample_id_short = score_short_ids[candidate],
    short_ID_sequence_matches = TRUE,
    multiplicity_matches = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(
    score_index = candidate,
    restored_names = restored_names,
    short_ids = expression_short_ids,
    count_audit = count_audit,
    mapping = mapping,
    resolution =
      "ORDER_PRESERVING_SHORT_ID_MULTIPLICITY_RESTORATION"
  )
}

bootstrap_correlation <- function(x, y, method, n_boot, seed) {
  set.seed(seed)
  n <- length(x)
  values <- replicate(n_boot, {
    i <- sample.int(n, n, replace = TRUE)
    suppressWarnings(stats::cor(x[i], y[i], method = method))
  })
  values <- values[is.finite(values)]
  assert(length(values) >= 0.99 * n_boot,
         "Too many non-finite bootstrap correlation estimates.")
  list(
    values = values,
    lower = unname(quantile(values, 0.025)),
    upper = unname(quantile(values, 0.975))
  )
}

normalize_gsva_result <- function(
  object, expected_gene_sets, expected_samples
) {
  m <- if (is.matrix(object)) {
    object
  } else if (
    inherits(object, "SummarizedExperiment") &&
      requireNamespace("SummarizedExperiment", quietly = TRUE)
  ) {
    as.matrix(SummarizedExperiment::assay(object))
  } else {
    as.matrix(object)
  }

  assert(is.matrix(m),
         "GSVA output could not be converted to a matrix.")
  storage.mode(m) <- "double"

  raw_dim <- dim(m)
  raw_rownames <- rownames(m)
  raw_colnames <- colnames(m)
  orientation_action <- "AS_RETURNED"

  # Some versions/classes may expose samples x gene sets. Transpose only when
  # dimensions and names both establish the reversed orientation.
  reversed_by_names <-
    identical(dim(m), c(length(expected_samples), length(expected_gene_sets))) &&
    !is.null(rownames(m)) && !is.null(colnames(m)) &&
    setequal(as.character(rownames(m)), expected_samples) &&
    setequal(as.character(colnames(m)), expected_gene_sets)

  if (reversed_by_names) {
    m <- t(m)
    orientation_action <- "TRANSPOSED_FROM_SAMPLE_BY_GENE_SET"
  }

  assert(
    identical(
      dim(m),
      c(as.integer(length(expected_gene_sets)),
        as.integer(length(expected_samples)))
    ),
    paste0(
      "Unexpected GSVA dimensions after orientation check: ",
      paste(dim(m), collapse = " x "),
      "; expected ", length(expected_gene_sets), " x ",
      length(expected_samples), "."
    )
  )

  rowname_action <- "PRESERVED"
  if (is.null(rownames(m))) {
    rownames(m) <- expected_gene_sets
    rowname_action <- "ASSIGNED_FROM_INPUT_GENE_SET_ORDER"
  } else {
    observed <- as.character(rownames(m))
    assert(!anyDuplicated(observed),
           "GSVA output contains duplicated gene-set row names.")
    assert(
      setequal(observed, expected_gene_sets),
      paste0(
        "GSVA gene-set names differ. Expected: ",
        paste(expected_gene_sets, collapse = ";"),
        " | Observed: ", paste(observed, collapse = ";")
      )
    )
    m <- m[match(expected_gene_sets, rownames(m)), , drop = FALSE]
    if (!identical(observed, expected_gene_sets)) {
      rowname_action <- "REORDERED_TO_INPUT_GENE_SET_ORDER"
    }
  }

  colname_action <- "PRESERVED"
  if (is.null(colnames(m))) {
    colnames(m) <- expected_samples
    colname_action <- "ASSIGNED_FROM_INPUT_SAMPLE_ORDER"
  } else {
    observed <- as.character(colnames(m))
    assert(!anyDuplicated(observed),
           "GSVA output contains duplicated sample column names.")
    assert(
      setequal(observed, expected_samples),
      paste0(
        "GSVA sample names differ from the 197 restored complete barcodes. ",
        "Missing expected IDs: ",
        paste(setdiff(expected_samples, observed), collapse = ";"),
        " | Unexpected IDs: ",
        paste(setdiff(observed, expected_samples), collapse = ";")
      )
    )
    m <- m[, match(expected_samples, colnames(m)), drop = FALSE]
    if (!identical(observed, expected_samples)) {
      colname_action <- "REORDERED_TO_RESTORED_COMPLETE_BARCODE_ORDER"
    }
  }

  assert(identical(rownames(m), expected_gene_sets),
         "Final GSVA gene-set order is incorrect.")
  assert(identical(colnames(m), expected_samples),
         "Final GSVA sample order is incorrect.")
  assert(all(is.finite(m)),
         "GSVA output contains %d non-finite values.",
         sum(!is.finite(m)))

  score_sd <- apply(m, 1L, stats::sd)
  assert(
    all(is.finite(score_sd) & score_sd > 0),
    paste0(
      "At least one EMT GSVA score is invariant or non-finite: ",
      paste(
        sprintf("%s=%s", names(score_sd),
                format(score_sd, digits = 16)),
        collapse = "; "
      )
    )
  )

  raw_rows <- if (is.null(raw_rownames)) "" else
    paste(as.character(raw_rownames), collapse = ";")
  raw_cols_preview <- if (is.null(raw_colnames)) "" else
    paste(head(as.character(raw_colnames), 10L), collapse = ";")

  audit <- data.frame(
    item = c(
      "Raw_GSVA_class",
      "Raw_GSVA_dimensions",
      "Raw_GSVA_row_names",
      "Raw_GSVA_first10_column_names",
      "Orientation_action",
      "Gene_set_name_action",
      "Sample_name_action",
      "Final_GSVA_dimensions",
      "Final_gene_set_order",
      "Final_sample_number",
      "Final_sample_order_matches_restored_complete_barcodes",
      "Nonfinite_value_number",
      "HALLMARK_EMT_FULL_SD",
      "HALLMARK_EMT_NO_TRICLOSAN_OVERLAP_SD"
    ),
    value = as.character(c(
      paste(class(object), collapse = ";"),
      paste(raw_dim, collapse = " x "),
      raw_rows,
      raw_cols_preview,
      orientation_action,
      rowname_action,
      colname_action,
      paste(dim(m), collapse = " x "),
      paste(rownames(m), collapse = ";"),
      ncol(m),
      identical(colnames(m), expected_samples),
      sum(!is.finite(m)),
      score_sd["HALLMARK_EMT_FULL"],
      score_sd["HALLMARK_EMT_NO_TRICLOSAN_OVERLAP"]
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(matrix = m, audit = audit)
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path","size_bytes","md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)
    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "TCGA_TNBC_EMT_revalidation_COMPLETE_bundle.rds"
    ),
    manifest = file.path(
      root, "audit",
      "Script13G_B_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script13G_B_COMPLETE_report.txt"
    )
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }

  report <- tryCatch(readLines(key["report"], warn = FALSE), error = function(e) "")
  if (!any(grepl("SCRIPT13G_B STATUS: COMPLETE", report, fixed = TRUE))) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  is.list(b) &&
    identical(as.character(b$script), "Script13G_B") &&
    identical(as.character(b$script_build_id), BUILD_ID) &&
    nrow(b$sample_level_scores) == 197L &&
    nrow(b$correlation_results) == 3L &&
    is.data.frame(b$GSVA_output_normalization_audit) &&
    nrow(b$GSVA_output_normalization_audit) >= 10L &&
    is.data.frame(b$gene_build_summary) &&
    nrow(b$gene_build_summary) == 1L &&
    is.data.frame(b$gene_row_aggregation_audit) &&
    nrow(b$gene_row_aggregation_audit) >= 10000L &&
    is.data.frame(b$sample_barcode_restoration_audit) &&
    nrow(b$sample_barcode_restoration_audit) == 197L &&
    !anyDuplicated(
      as.character(
        b$sample_barcode_restoration_audit$restored_complete_score_barcode
      )
    ) &&
    isTRUE(b$policy$complete_sample_barcodes_restored) &&
    isFALSE(b$policy$many_to_many_join_performed) &&
    isFALSE(b$policy$meta_analysis_performed) &&
    isFALSE(b$policy$cutoff_selected)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT), "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 13G-B output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "00_TCGA_TNBC_EMT_revalidation_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("TCGA one-to-one EMT revalidation; final meta-analysis disabled.\n")
  cat("============================================================\n")

  packages <- c("GSVA", "msigdbr")
  missing_packages <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  assert(!length(missing_packages),
         "Missing package(s): %s", paste(missing_packages, collapse = ", "))

  dir.create(dirname(OUTPUT_ROOT), recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(dirname(OUTPUT_ROOT)),
         "Unable to create cross-cohort synthesis directory.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  expression_resolution <- resolve_input(
    PREFERRED_INPUTS["expression"],
    "TNBC_expression_matrix.rds"
  )
  score_resolution <- resolve_input(
    PREFERRED_INPUTS["score"],
    "Triclosan_activity_score.rds"
  )
  input_files <- c(
    expression = expression_resolution$selected,
    score = score_resolution$selected
  )

  expr <- extract_expression(readRDS(input_files["expression"]))
  score_all <- extract_score(readRDS(input_files["score"]))

  assert(
    identical(dim(expr), c(59427L, 197L)),
    "Expected a 59,427 x 197 TNBC expression matrix; detected %s.",
    paste(dim(expr), collapse = " x ")
  )
  assert(!is.null(colnames(expr)),
         "Expression matrix has no sample-column identifiers.")
  assert(all(!is.na(colnames(expr)) & nzchar(trimws(colnames(expr)))),
         "Expression matrix contains blank sample IDs.")
  assert(!is.null(rownames(expr)),
         "Expression matrix has no gene-row identifiers.")
  assert(sum(!is.finite(expr)) == 0L,
         "Expression matrix contains %d non-finite values; no imputation is allowed.",
         sum(!is.finite(expr)))
  assert(min(expr) >= 0,
         "Expression matrix contains negative values; minimum = %s.",
         format(min(expr), digits = 16))

  gene_build <- build_unique_gene_matrix(expr)
  gene_expr <- gene_build$expression
  gene_row_audit <- gene_build$row_audit
  gene_build_summary <- gene_build$summary

  assert(
    is.numeric(score_all) && length(score_all) >= 197L &&
      all(is.finite(score_all)) && !is.null(names(score_all)) &&
      all(nzchar(names(score_all))),
    "Original Triclosan score object is malformed."
  )

  expression_id_original <- trimws(as.character(colnames(expr)))
  expression_id16 <- tcga16(expression_id_original)
  assert(
    all(!is.na(expression_id16)),
    "At least one expression column name is not a valid TCGA short sample ID."
  )
  assert(
    identical(expression_id_original, expression_id16),
    paste0(
      "TNBC expression columns are expected to be 16-character short TCGA ",
      "sample IDs created during the original 197-sample subset."
    )
  )

  restoration <- restore_complete_sample_barcodes(
    expression_id16,
    names(score_all)
  )
  score_index <- restoration$score_index
  restored_complete_ids <- restoration$restored_names
  sample_restoration_audit <- restoration$mapping
  short_ID_multiplicity_audit <- restoration$count_audit

  score <- as.numeric(score_all[score_index])
  names(score) <- restored_complete_ids
  colnames(expr) <- restored_complete_ids
  colnames(gene_expr) <- restored_complete_ids

  assert(
    length(score) == 197L &&
      all(is.finite(score)) &&
      sd(score) > 0 &&
      length(unique(score)) > 1L &&
      !anyDuplicated(names(score)) &&
      identical(names(score), colnames(expr)) &&
      identical(colnames(expr), colnames(gene_expr)),
    "Restored 197-sample score/expression alignment is incomplete or invalid."
  )

  log_expr <- log2(gene_expr + 1)
  row_sd <- apply(log_expr, 1L, sd)
  informative <- is.finite(row_sd) & row_sd > 0
  gsva_expr <- log_expr[informative, , drop = FALSE]

  assert(
    ncol(gsva_expr) == 197L &&
      nrow(gsva_expr) >= 10000L &&
      identical(colnames(gsva_expr), restored_complete_ids) &&
      all(is.finite(gsva_expr)) &&
      !anyDuplicated(rownames(gsva_expr)) &&
      all(nzchar(rownames(gsva_expr))),
    "Informative log2 expression matrix failed quality checks."
  )

  msig_formals <- names(formals(msigdbr::msigdbr))
  msig_args <- list(species = "Homo sapiens")
  if ("db_species" %in% msig_formals) msig_args$db_species <- "HS"
  if ("collection" %in% msig_formals) {
    msig_args$collection <- "H"
  } else {
    msig_args$category <- "H"
  }

  hallmark <- do.call(msigdbr::msigdbr, msig_args)
  assert(
    is.data.frame(hallmark) &&
      all(c("gs_name", "gene_symbol") %in% names(hallmark)),
    "msigdbr Hallmark output is malformed."
  )

  emt_all <- sort(unique(as.character(
    hallmark$gene_symbol[hallmark$gs_name == EMT_NAME]
  )))
  emt_all <- emt_all[!is.na(emt_all) & nzchar(emt_all)]
  assert(length(emt_all) >= 150L && length(emt_all) <= 250L,
         "Retrieved Hallmark EMT gene count is implausible: %d.", length(emt_all))

  emt_detected <- emt_all[emt_all %in% rownames(gsva_expr)]
  overlap <- intersect(emt_detected, LOCKED24)
  emt_no_overlap <- setdiff(emt_detected, LOCKED24)

  assert(
    length(emt_detected) >= ceiling(0.80 * length(emt_all)),
    "TCGA Hallmark EMT coverage is below 80%%."
  )
  assert(
    length(emt_no_overlap) >= ceiling(0.90 * length(emt_detected)),
    "Overlap-removed EMT set is unexpectedly small."
  )

  gene_sets <- list(
    HALLMARK_EMT_FULL = emt_detected,
    HALLMARK_EMT_NO_TRICLOSAN_OVERLAP = emt_no_overlap
  )
  set.seed(20260711L)
  param <- GSVA::gsvaParam(gsva_expr, gene_sets)
  emt_object <- GSVA::gsva(param)
  normalized_gsva <- normalize_gsva_result(
    emt_object,
    expected_gene_sets = names(gene_sets),
    expected_samples = restored_complete_ids
  )
  emt_matrix <- normalized_gsva$matrix
  gsva_output_audit <- normalized_gsva$audit

  emt_full <- as.numeric(emt_matrix["HALLMARK_EMT_FULL", ])
  emt_no_overlap_score <- as.numeric(
    emt_matrix["HALLMARK_EMT_NO_TRICLOSAN_OVERLAP", ]
  )
  names(emt_full) <- restored_complete_ids
  names(emt_no_overlap_score) <- restored_complete_ids

  primary <- suppressWarnings(cor.test(
    score, emt_full, method = "spearman", exact = FALSE
  ))
  no_overlap <- suppressWarnings(cor.test(
    score, emt_no_overlap_score, method = "spearman", exact = FALSE
  ))
  pearson <- cor.test(score, emt_full, method = "pearson")

  primary_boot <- bootstrap_correlation(
    score, emt_full, "spearman", BOOTSTRAP_N, BOOTSTRAP_SEED
  )
  no_overlap_boot <- bootstrap_correlation(
    score, emt_no_overlap_score, "spearman",
    BOOTSTRAP_N, BOOTSTRAP_SEED + 1L
  )

  results <- data.frame(
    analysis = c(
      "PRIMARY_TCGA_SPEARMAN_FULL_EMT",
      "SENSITIVITY_TCGA_SPEARMAN_NO_OVERLAP_EMT",
      "SENSITIVITY_TCGA_PEARSON_FULL_EMT"
    ),
    method = c("Spearman", "Spearman", "Pearson"),
    EMT_score = c(
      "HALLMARK_EMT_FULL",
      "HALLMARK_EMT_NO_TRICLOSAN_OVERLAP",
      "HALLMARK_EMT_FULL"
    ),
    sample_number = 197L,
    estimate = c(
      unname(primary$estimate),
      unname(no_overlap$estimate),
      unname(pearson$estimate)
    ),
    confidence_level = 0.95,
    confidence_interval_method = c(
      paste0("Percentile bootstrap; B=", BOOTSTRAP_N),
      paste0("Percentile bootstrap; B=", BOOTSTRAP_N),
      "Pearson cor.test"
    ),
    confidence_interval_lower = c(
      primary_boot$lower,
      no_overlap_boot$lower,
      unname(pearson$conf.int[1L])
    ),
    confidence_interval_upper = c(
      primary_boot$upper,
      no_overlap_boot$upper,
      unname(pearson$conf.int[2L])
    ),
    two_sided_p = c(
      primary$p.value,
      no_overlap$p.value,
      pearson$p.value
    ),
    expected_direction = "positive",
    direction_matches_external_cohorts = c(
      unname(primary$estimate) > 0,
      unname(no_overlap$estimate) > 0,
      unname(pearson$estimate) > 0
    ),
    primary_analysis = c(TRUE, FALSE, FALSE),
    many_to_many_join_used = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  results$secondary_BH_adjusted_p <- c(
    NA_real_,
    p.adjust(results$two_sided_p[2:3], method = "BH")
  )

  sample_table <- data.frame(
    sample_order = seq_len(197L),
    expression_sample_id_original = expression_id_original,
    expression_sample_id_short = expression_id16,
    occurrence_within_short_ID =
      sample_restoration_audit$occurrence_within_short_ID,
    occurrence_key = sample_restoration_audit$occurrence_key,
    sample_id = restored_complete_ids,
    source_score_id = names(score_all)[score_index],
    score_object_row_index = score_index,
    score_match_number = 1L,
    Triclosan_activity = score,
    HALLMARK_EMT_FULL = emt_full,
    HALLMARK_EMT_NO_TRICLOSAN_OVERLAP = emt_no_overlap_score,
    short_IDs_may_repeat = duplicated(expression_id16) |
      duplicated(expression_id16, fromLast = TRUE),
    complete_sample_IDs_unique = TRUE,
    samples_filtered = FALSE,
    duplicated_sample_rows_created = FALSE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  EMT_summary <- data.frame(
    pathway = EMT_NAME,
    msigdbr_version = as.character(packageVersion("msigdbr")),
    total_gene_number = length(emt_all),
    detected_gene_number = length(emt_detected),
    detected_fraction = length(emt_detected) / length(emt_all),
    locked24_overlap_gene_number = length(overlap),
    locked24_overlap_genes =
      if (length(overlap)) paste(overlap, collapse = ";") else "",
    overlap_removed_gene_number = length(emt_no_overlap),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  EMT_audit <- data.frame(
    pathway = EMT_NAME,
    human_symbol = emt_all,
    present_in_TCGA_TNBC = emt_all %in% emt_detected,
    overlaps_locked_24gene_signature = emt_all %in% overlap,
    used_in_primary_EMT_score = emt_all %in% emt_detected,
    used_in_overlap_removed_EMT_score = emt_all %in% emt_no_overlap,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_resolution <- rbind(
    data.frame(
      input = "expression",
      preferred_path = PREFERRED_INPUTS["expression"],
      selected_path = expression_resolution$selected,
      candidate_number = length(expression_resolution$candidates),
      resolution = expression_resolution$resolution,
      selected_size_bytes =
        as.numeric(file.info(expression_resolution$selected)$size),
      selected_md5 = md5(expression_resolution$selected),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      input = "score",
      preferred_path = PREFERRED_INPUTS["score"],
      selected_path = score_resolution$selected,
      candidate_number = length(score_resolution$candidates),
      resolution = score_resolution$resolution,
      selected_size_bytes =
        as.numeric(file.info(score_resolution$selected)$size),
      selected_md5 = md5(score_resolution$selected),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  transformation_audit <- data.frame(
    item = c(
      "Raw_expression_dimensions",
      "Raw_gene_ID_blank_rows",
      "Raw_gene_ID_duplicate_excess_rows",
      "Unique_gene_level_dimensions",
      "Single_row_genes",
      "Multi_row_genes",
      "Maximum_rows_per_gene",
      "Duplicate_symbol_aggregation_rule",
      "Raw_expression_nonfinite_values",
      "Raw_expression_negative_values",
      "Transformation",
      "Pseudocount",
      "Zero_variance_gene_number",
      "Informative_GSVA_expression_dimensions",
      "Raw_short_expression_ID_unique_number",
      "Raw_short_expression_ID_duplicate_excess_number",
      "Raw_short_expression_ID_groups_with_multiplicity_gt1",
      "Score_complete_IDs_valid",
      "Short_ID_group_multiplicities_equal",
      "Short_ID_sequences_equal_after_score_filter",
      "Restored_complete_sample_IDs_unique",
      "Final_sample_number",
      "Duplicated_final_sample_IDs",
      "Many_to_many_join_performed"
    ),
    value = as.character(c(
      paste(dim(expr), collapse = " x "),
      gene_build_summary$blank_gene_ID_row_number,
      gene_build_summary$duplicated_symbol_excess_row_number,
      paste(dim(gene_expr), collapse = " x "),
      gene_build_summary$single_row_gene_number,
      gene_build_summary$multi_row_gene_number,
      gene_build_summary$maximum_rows_per_gene,
      "SAMPLE_WISE_MEDIAN",
      sum(!is.finite(expr)),
      sum(expr < 0),
      "log2(x+1)",
      1,
      sum(!informative),
      paste(dim(gsva_expr), collapse = " x "),
      length(unique(expression_id16)),
      sum(duplicated(expression_id16)),
      sum(table(expression_id16) > 1L),
      sum(!is.na(tcga16(names(score_all)))),
      all(short_ID_multiplicity_audit$counts_equal),
      all(sample_restoration_audit$short_ID_sequence_matches),
      !anyDuplicated(restored_complete_ids),
      length(score),
      anyDuplicated(names(score)),
      FALSE
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  parameter_lock <- data.frame(
    field = c(
      "Primary_endpoint",
      "Primary_method",
      "Primary_sample_definition",
      "Raw_expression_column_ID_state",
      "Sample_matching",
      "Restored_final_sample_ID",
      "Raw_gene_ID_policy",
      "Duplicate_gene_symbol_policy",
      "Expression_transformation",
      "EMT_source",
      "EMT_scoring",
      "Overlap_sensitivity",
      "Primary_confidence_interval",
      "Historical_many_to_many_result_used",
      "Survival_analysis",
      "Final_cross_cohort_meta",
      "Cutoff_or_high_low_group",
      "Sample_filtering",
      "DEG_PCA_GSEA_figure"
    ),
    value = c(
      "Triclosan_activity versus HALLMARK_EMT_FULL",
      "Two-sided Spearman correlation",
      "Exactly 197 retained TCGA TNBC expression columns",
      "16-character short IDs may repeat by original construction",
      "Order-preserving short-ID multiplicity restoration",
      "Complete unique TCGA barcode from original score object",
      "Exclude blank gene IDs only",
      "Sample-wise median before EMT GSVA",
      "log2(x+1)",
      paste0("msigdbr ", packageVersion("msigdbr")),
      "Classical GSVA",
      "Remove all locked-24 overlap genes and rescore",
      paste0("Percentile bootstrap; B=", BOOTSTRAP_N,
             "; seed=", BOOTSTRAP_SEED),
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  policy <- list(
    expression_short_IDs_allowed_to_repeat = TRUE,
    all_197_expression_columns_retained = TRUE,
    complete_sample_barcodes_restored = TRUE,
    sample_restoration_method =
      "ORDER_PRESERVING_SHORT_ID_MULTIPLICITY_RESTORATION",
    one_row_per_complete_TCGA_barcode = TRUE,
    many_to_many_join_performed = FALSE,
    historical_209_row_result_used = FALSE,
    blank_gene_rows_excluded = TRUE,
    duplicate_gene_symbols_aggregated = TRUE,
    duplicate_gene_symbol_rule = "SAMPLE_WISE_MEDIAN",
    expression_transformation = "log2(x+1)",
    alternative_Triclosan_score_calculated = FALSE,
    survival_model_fitted = FALSE,
    meta_analysis_performed = FALSE,
    samples_filtered = FALSE,
    outliers_removed = FALSE,
    cutoff_selected = FALSE,
    high_low_group_created = FALSE,
    Kaplan_Meier_performed = FALSE,
    DEG_performed = FALSE,
    PCA_performed = FALSE,
    GSEA_performed = FALSE,
    manuscript_figure_created = FALSE
  )

  integrity <- data.frame(
    item = c(
      "Dataset","Script","Script_build_ID",
      "Expression_input_MD5","Score_input_MD5",
      "Raw_expression_dimensions","Unique_gene_level_dimensions",
      "Blank_gene_ID_rows","Duplicate_symbol_excess_rows",
      "Single_row_genes","Multi_row_genes","Maximum_rows_per_gene",
      "Informative_expression_dimensions",
      "Expression_sample_number","Final_score_sample_number",
      "Raw_short_ID_unique_number","Raw_short_ID_duplicate_excess_number",
      "Raw_short_ID_groups_with_multiplicity_gt1",
      "Short_ID_group_multiplicities_equal",
      "Short_ID_order_sequence_equal",
      "Final_complete_sample_IDs_unique","Finite_final_scores",
      "Hallmark_EMT_total_genes","Hallmark_EMT_detected_genes",
      "Hallmark_EMT_overlap_locked24","Hallmark_EMT_no_overlap_genes",
      "Primary_test_number","Many_to_many_join_performed",
      "Historical_209_row_result_used","Survival_model_fitted",
      "Meta_analysis_performed","Samples_filtered","Outliers_removed",
      "Alternative_score_calculated","Cutoff_selected",
      "High_low_group_created","Kaplan_Meier_performed",
      "DEG_performed","PCA_performed","GSEA_performed",
      "Manuscript_figure_created","Completion_status"
    ),
    value = as.character(c(
      "TCGA_TNBC","13G_B",BUILD_ID,
      md5(input_files["expression"]),md5(input_files["score"]),
      paste(dim(expr), collapse = " x "),
      paste(dim(gene_expr), collapse = " x "),
      gene_build_summary$blank_gene_ID_row_number,
      gene_build_summary$duplicated_symbol_excess_row_number,
      gene_build_summary$single_row_gene_number,
      gene_build_summary$multi_row_gene_number,
      gene_build_summary$maximum_rows_per_gene,
      paste(dim(gsva_expr), collapse = " x "),
      ncol(expr),length(score),length(unique(expression_id16)),
      sum(duplicated(expression_id16)),sum(table(expression_id16) > 1L),
      all(short_ID_multiplicity_audit$counts_equal),
      all(sample_restoration_audit$short_ID_sequence_matches),
      !anyDuplicated(names(score)),sum(is.finite(score)),length(emt_all),length(emt_detected),
      length(overlap),length(emt_no_overlap),
      sum(results$primary_analysis),FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,
      FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,"COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = "Step5_cross_cohort_synthesis",
    script = "Script13G_B",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    dataset = "TCGA_TNBC",
    source_expression_md5 = md5(input_files["expression"]),
    source_score_md5 = md5(input_files["score"]),
    input_resolution = input_resolution,
    gene_build_summary = gene_build_summary,
    gene_row_aggregation_audit = gene_row_audit,
    sample_barcode_restoration_audit = sample_restoration_audit,
    short_ID_multiplicity_audit = short_ID_multiplicity_audit,
    Triclosan_activity = score,
    EMT_score_matrix = emt_matrix,
    sample_level_scores = sample_table,
    EMT_gene_set_summary = EMT_summary,
    EMT_gene_set_audit = EMT_audit,
    GSVA_output_normalization_audit = gsva_output_audit,
    correlation_results = results,
    transformation_audit = transformation_audit,
    parameter_lock = parameter_lock,
    integrity_summary = integrity,
    policy = policy
  )
  class(bundle) <- c("TCGA_TNBC_EMT_revalidation_bundle", "list")

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(".Script13G_B_staging_",
           format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid())
  )
  dirs <- file.path(stage, c("objects","audit","logs"))
  assert(all(vapply(dirs, dir.create, logical(1),
                    recursive = TRUE, showWarnings = FALSE) | dir.exists(dirs)),
         "Unable to create staging directories.")
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "TCGA_TNBC_EMT_revalidation_COMPLETE_bundle.rds"
    ),
    EMT_scores = file.path(
      stage, "objects",
      "TCGA_TNBC_Hallmark_EMT_GSVA_scores.rds"
    ),
    bootstrap = file.path(
      stage, "objects",
      "TCGA_TNBC_EMT_correlation_bootstrap_distributions.rds"
    ),
    samples = file.path(
      stage, "audit",
      "TCGA_TNBC_Triclosan_EMT_scores_unique197.csv"
    ),
    results = file.path(
      stage, "audit",
      "TCGA_TNBC_Triclosan_EMT_revalidation_results.csv"
    ),
    EMT_summary = file.path(
      stage, "audit",
      "TCGA_TNBC_Hallmark_EMT_gene_set_summary.csv"
    ),
    EMT_audit = file.path(
      stage, "audit",
      "TCGA_TNBC_Hallmark_EMT_gene_set_audit.csv"
    ),
    GSVA_output_audit = file.path(
      stage, "audit",
      "TCGA_TNBC_EMT_GSVA_output_normalization_audit.csv"
    ),
    input_resolution = file.path(
      stage, "audit",
      "Script13G_B_input_resolution_and_MD5.csv"
    ),
    transformation = file.path(
      stage, "audit",
      "TCGA_TNBC_expression_and_sample_matching_audit.csv"
    ),
    gene_summary = file.path(
      stage, "audit",
      "TCGA_TNBC_raw_gene_ID_and_aggregation_summary.csv"
    ),
    gene_rows = file.path(
      stage, "audit",
      "TCGA_TNBC_unique_gene_row_aggregation_audit.csv"
    ),
    sample_restoration = file.path(
      stage, "audit",
      "TCGA_TNBC_short_to_complete_barcode_restoration.csv"
    ),
    short_ID_counts = file.path(
      stage, "audit",
      "TCGA_TNBC_short_ID_multiplicity_audit.csv"
    ),
    parameters = file.path(
      stage, "audit",
      "TCGA_TNBC_EMT_revalidation_parameter_lock.csv"
    ),
    packages = file.path(
      stage, "audit",
      "Script13G_B_package_audit.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "TCGA_TNBC_EMT_revalidation_integrity_summary.csv"
    ),
    GSVA_details = file.path(
      stage, "logs",
      "Script13G_B_EMT_GSVA_parameter_details.txt"
    ),
    session = file.path(
      stage, "logs",
      "Script13G_B_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs",
      "Script13G_B_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(emt_matrix, files["EMT_scores"], version = 3)
  saveRDS(list(
    primary_full_EMT = primary_boot$values,
    sensitivity_no_overlap_EMT = no_overlap_boot$values,
    bootstrap_n = BOOTSTRAP_N,
    seeds = c(BOOTSTRAP_SEED, BOOTSTRAP_SEED + 1L)
  ), files["bootstrap"], version = 3)

  write_csv(sample_table, files["samples"])
  write_csv(results, files["results"])
  write_csv(EMT_summary, files["EMT_summary"])
  write_csv(EMT_audit, files["EMT_audit"])
  write_csv(gsva_output_audit, files["GSVA_output_audit"])
  write_csv(input_resolution, files["input_resolution"])
  write_csv(transformation_audit, files["transformation"])
  write_csv(gene_build_summary, files["gene_summary"])
  write_csv(gene_row_audit, files["gene_rows"])
  write_csv(sample_restoration_audit, files["sample_restoration"])
  write_csv(short_ID_multiplicity_audit, files["short_ID_counts"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(data.frame(
    package = packages,
    version = vapply(
      packages, function(x) as.character(packageVersion(x)), character(1)
    ),
    available = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  ), files["packages"])
  write_csv(integrity, files["integrity"])
  writeLines(capture.output(show(param)),
             files["GSVA_details"], useBytes = TRUE)
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan - TCGA TNBC Script 13G-B",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("Raw expression dimensions: ", paste(dim(expr), collapse = " x ")),
    paste0("Blank gene-ID rows excluded: ",
           gene_build_summary$blank_gene_ID_row_number),
    paste0("Duplicate-symbol excess rows: ",
           gene_build_summary$duplicated_symbol_excess_row_number),
    paste0("Unique gene-level matrix: ",
           paste(dim(gene_expr), collapse = " x ")),
    paste0("Multi-row genes aggregated by sample-wise median: ",
           gene_build_summary$multi_row_gene_number),
    paste0("Informative GSVA matrix: ",
           paste(dim(gsva_expr), collapse = " x ")),
    "Expression transformation: log2(x+1)",
    paste0("Raw short-ID unique number: ",
           length(unique(expression_id16)), " / 197"),
    paste0("Raw duplicate short-ID excess columns: ",
           sum(duplicated(expression_id16))),
    paste0("Repeated short-ID groups: ",
           sum(table(expression_id16) > 1L)),
    paste0("Restored unique complete barcodes: ",
           length(unique(restored_complete_ids)), " / 197"),
    paste0("Restoration method: ", restoration$resolution),
    "Many-to-many join performed: FALSE",
    paste0("GSVA final dimensions: ",
           paste(dim(emt_matrix), collapse = " x ")),
    paste0("GSVA final sample order matches restored complete barcodes: ",
           identical(colnames(emt_matrix), restored_complete_ids)),
    paste0("Hallmark EMT detected: ", length(emt_detected), " / ",
           length(emt_all)),
    paste0("Locked-24 overlap genes: ", length(overlap),
           if (length(overlap))
             paste0(" [", paste(overlap, collapse = ";"), "]") else ""),
    paste0("Primary Spearman rho: ",
           format(unname(primary$estimate), digits = 16)),
    paste0("Primary two-sided p: ",
           format(primary$p.value, digits = 16)),
    paste0("Primary bootstrap 95% CI: ",
           format(primary_boot$lower, digits = 16), " to ",
           format(primary_boot$upper, digits = 16)),
    paste0("Overlap-removed Spearman rho: ",
           format(unname(no_overlap$estimate), digits = 16)),
    paste0("Overlap-removed p: ",
           format(no_overlap$p.value, digits = 16)),
    "Survival analysis performed: FALSE",
    "Final cross-cohort meta performed: FALSE",
    "Cutoff/high-low/KM/DEG/PCA/GSEA/figure performed: FALSE",
    "",
    "SCRIPT13G_B STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  e2 <- readRDS(files["EMT_scores"])
  r2 <- read.csv(files["results"],
                 stringsAsFactors = FALSE, check.names = FALSE)
  s2 <- read.csv(files["samples"],
                 stringsAsFactors = FALSE, check.names = FALSE)

  assert(
    identical(e2, emt_matrix) &&
      identical(b2$EMT_score_matrix, emt_matrix) &&
      nrow(r2) == 3L &&
      isTRUE(all.equal(
        r2$estimate, results$estimate,
        tolerance = 1e-14, check.attributes = FALSE
      )) &&
      isTRUE(all.equal(
        r2$two_sided_p, results$two_sided_p,
        tolerance = 1e-14, check.attributes = FALSE
      )) &&
      nrow(s2) == 197L &&
      !anyDuplicated(as.character(s2$sample_id)) &&
      identical(
        as.character(s2$sample_id),
        restored_complete_ids
      ) &&
      identical(
        as.character(s2$expression_sample_id_short),
        expression_id16
      ) &&
      all(as.integer(s2$score_match_number) == 1L),
    "RDS/CSV save-read validation failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script13G_B_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging directory was preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script13G_B_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script13G_B_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 13G-B completed successfully.\n")
  cat("Unique TCGA TNBC samples: 197 / 197\n")
  cat("Many-to-many join performed: FALSE\n")
  cat("Final cross-cohort meta performed: FALSE\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

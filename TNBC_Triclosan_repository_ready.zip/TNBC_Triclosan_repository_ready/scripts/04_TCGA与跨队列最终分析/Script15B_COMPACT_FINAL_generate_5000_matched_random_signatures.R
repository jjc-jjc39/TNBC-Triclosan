# ==============================================================================
# TNBC_Triclosan | Script 15B COMPACT FINAL
# Generate and audit 5,000 unique matched random signatures.
#
# This step performs NO GSVA, NO cohort association and NO empirical p value.
#
# Primary null:
# - 5,000 unique 24-gene sets;
# - one candidate matched to each locked target;
# - exactly 2 Hallmark EMT genes and 22 non-EMT genes.
#
# Sensitivity null:
# - remove the candidates matched to IL6 and JUN;
# - 5,000 unique 22-gene sets containing no Hallmark EMT genes.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script15B_COMPACT_FINAL_20260712"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"

SCRIPT15A_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "03_matched_random_24gene_null",
  "00_preflight_and_matching_pool"
)
OUTPUT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "03_matched_random_24gene_null",
  "01_random_signature_generation"
)

INPUTS <- c(
  preflight_bundle = file.path(
    SCRIPT15A_ROOT, "objects",
    "Matched_random24_preflight_COMPLETE_bundle.rds"
  ),
  matching_features = file.path(
    SCRIPT15A_ROOT, "objects",
    "Cross_cohort_common_gene_matching_features.rds"
  ),
  candidate_neighbors = file.path(
    SCRIPT15A_ROOT, "objects",
    "Locked24_target_candidate_neighbors.rds"
  ),
  candidate_list = file.path(
    SCRIPT15A_ROOT, "objects",
    "Locked24_target_candidate_list.rds"
  ),
  preflight_manifest = file.path(
    SCRIPT15A_ROOT, "audit",
    "Script15A_output_manifest_with_MD5.csv"
  ),
  preflight_report = file.path(
    SCRIPT15A_ROOT, "logs",
    "Script15A_COMPLETE_report.txt"
  ),
  design_lock = file.path(
    SCRIPT15A_ROOT, "audit",
    "Matched_random24_design_lock.csv"
  ),
  observed_benchmarks = file.path(
    SCRIPT15A_ROOT, "audit",
    "Matched_random24_observed_EMT_benchmarks.csv"
  )
)

EXPECTED_MD5 <- c(
  preflight_bundle = "df1ec4d03dae41184c0ef66cf4403e0a",
  matching_features = "623b549d603219bbb1e9233fde3fd4e7",
  candidate_neighbors = "6204fb1459edcc92e9b56f9ad16595e9",
  candidate_list = "5c1a3349ffd87e54d56926bd5a13f57f",
  preflight_manifest = "d7d56210a4a3d04b3d2478518e08c774",
  preflight_report = "75e74edeed0ee27a89ab43b1aa4ae4b0",
  design_lock = "63cc008cd55eb65e799042412040ead8",
  observed_benchmarks = "7b90ca826e337e69bab036c3a2a4b09b"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)
EMT_TARGETS <- c("IL6", "JUN")
NON_EMT_TARGETS <- setdiff(LOCKED24, EMT_TARGETS)

RANDOM_SET_NUMBER <- 5000L
RANDOM_SEED <- 20260712L
NEIGHBOR_NUMBER <- 50L
MAX_ATTEMPTS_PER_SET <- 100L
EXPECTED_COMMON_GENE_NUMBER <- 12394L
EXPECTED_EMT_CANDIDATE_NUMBER <- 195L
EXPECTED_NON_EMT_CANDIDATE_NUMBER <- 12175L

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

scalar_text <- function(x, label = "value") {
  y <- as.character(x)
  assert(length(y) == 1L && !is.na(y) && nzchar(trimws(y)),
         "%s must be one nonblank scalar value.", label)
  unname(trimws(y))
}

same_text <- function(x, y) {
  identical(
    scalar_text(x, "observed text"),
    scalar_text(y, "expected text")
  )
}

report_contains <- function(file, marker) {
  any(grepl(
    marker,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)

    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)

    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

set_key <- function(x) paste(sort(as.character(x)), collapse = ";")

generate_mapping <- function(candidate_list) {
  target_order <- sample(LOCKED24, length(LOCKED24), replace = FALSE)
  used <- character(0)
  selected <- setNames(rep(NA_character_, length(LOCKED24)), LOCKED24)

  for (target in target_order) {
    available <- setdiff(candidate_list[[target]], used)
    if (!length(available)) return(NULL)
    chosen <- sample(available, 1L)
    selected[target] <- chosen
    used <- c(used, chosen)
  }

  assert(
    !anyNA(selected) &&
      length(unique(selected)) == length(LOCKED24),
    "Generated mapping is incomplete or contains duplicate genes."
  )
  selected[LOCKED24]
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "Matched_random24_generation_COMPLETE_bundle.rds"
    ),
    primary = file.path(
      root, "objects",
      "Matched_random24_primary_5000_gene_sets.rds"
    ),
    sensitivity = file.path(
      root, "objects",
      "Matched_random22_no_EMT_5000_gene_sets.rds"
    ),
    mapping = file.path(
      root, "objects",
      "Matched_random24_5000_target_gene_mappings.rds"
    ),
    manifest = file.path(
      root, "audit",
      "Script15B_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script15B_COMPLETE_report.txt"
    )
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT15B STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  p <- tryCatch(readRDS(key["primary"]), error = function(e) NULL)
  s <- tryCatch(readRDS(key["sensitivity"]), error = function(e) NULL)
  m <- tryCatch(readRDS(key["mapping"]), error = function(e) NULL)

  is.list(b) &&
    same_text(b$script, "Script15B") &&
    same_text(b$script_build_id, BUILD_ID) &&
    same_text(b$readiness_status, "READY_FOR_SCRIPT15C") &&
    is.list(p) && length(p) == RANDOM_SET_NUMBER &&
    is.list(s) && length(s) == RANDOM_SET_NUMBER &&
    is.data.frame(m) &&
    nrow(m) == RANDOM_SET_NUMBER * length(LOCKED24) &&
    isFALSE(b$policy$GSVA_performed)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT),
           "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script15B output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "01_random_signature_generation_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Generate 5,000 matched random mappings only.\n")
  cat("============================================================\n")

  missing_files <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing_files), "Missing accepted input(s):\n%s",
         paste(missing_files, collapse = "\n"))

  observed_md5 <- vapply(INPUTS, md5, character(1))
  assert(
    identical(unname(observed_md5), unname(EXPECTED_MD5)),
    "At least one accepted input MD5 differs:\n%s",
    paste(sprintf(
      "%s | expected=%s | observed=%s",
      names(EXPECTED_MD5), EXPECTED_MD5, observed_md5
    ), collapse = "\n")
  )
  assert(
    manifest_ok(SCRIPT15A_ROOT, INPUTS["preflight_manifest"]),
    "Script15A output manifest verification failed."
  )
  assert(
    report_contains(
      INPUTS["preflight_report"], "SCRIPT15A STATUS: COMPLETE"
    ),
    "Script15A COMPLETE marker is missing."
  )

  preflight <- readRDS(INPUTS["preflight_bundle"])
  features <- readRDS(INPUTS["matching_features"])
  candidates <- readRDS(INPUTS["candidate_neighbors"])
  candidate_list <- readRDS(INPUTS["candidate_list"])
  design_lock <- read.csv(
    INPUTS["design_lock"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  observed_benchmarks <- read.csv(
    INPUTS["observed_benchmarks"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert(
    is.list(preflight) &&
      same_text(preflight$script, "Script15A") &&
      same_text(
        preflight$script_build_id,
        "Script15A_COMPACT_FINAL_20260712"
      ) &&
      same_text(preflight$readiness_status, "READY_FOR_SCRIPT15B") &&
      identical(as.character(preflight$locked24), LOCKED24) &&
      isFALSE(preflight$policy$random_signatures_generated) &&
      isFALSE(preflight$policy$GSVA_performed),
    "Script15A bundle identity or boundary lock is incorrect."
  )
  assert(
    is.data.frame(features) &&
      nrow(features) == EXPECTED_COMMON_GENE_NUMBER &&
      !anyDuplicated(features$gene_symbol) &&
      all(c(
        "gene_symbol", "in_locked24", "in_Hallmark_EMT",
        "eligible_random_candidate"
      ) %in% names(features)),
    "Matching-feature table is malformed."
  )
  assert(
    sum(features$eligible_random_candidate &
          features$in_Hallmark_EMT) ==
      EXPECTED_EMT_CANDIDATE_NUMBER &&
      sum(features$eligible_random_candidate &
            !features$in_Hallmark_EMT) ==
      EXPECTED_NON_EMT_CANDIDATE_NUMBER,
    "Eligible EMT or non-EMT candidate counts differ."
  )
  assert(
    is.data.frame(candidates) &&
      nrow(candidates) == length(LOCKED24) * NEIGHBOR_NUMBER &&
      !anyDuplicated(candidates[c("target_gene", "neighbor_rank")]) &&
      all(table(candidates$target_gene) == NEIGHBOR_NUMBER),
    "Candidate-neighbor table is malformed."
  )
  assert(
    is.list(candidate_list) &&
      identical(names(candidate_list), LOCKED24) &&
      all(lengths(candidate_list) == NEIGHBOR_NUMBER) &&
      all(vapply(candidate_list, function(x) {
        length(unique(x)) == NEIGHBOR_NUMBER &&
          all(!x %in% LOCKED24)
      }, logical(1))),
    "Candidate list is malformed."
  )

  for (target in LOCKED24) {
    d <- candidates[
      candidates$target_gene == target,
      ,
      drop = FALSE
    ]
    d <- d[order(d$neighbor_rank), , drop = FALSE]
    assert(
      identical(as.character(candidate_list[[target]]),
                as.character(d$candidate_gene)),
      "Candidate list and neighbor table differ for %s.", target
    )
  }

  assert(
    is.data.frame(design_lock) &&
      any(design_lock$field == "Random_set_number" &
            as.integer(design_lock$value) == RANDOM_SET_NUMBER) &&
      any(design_lock$field == "Random_seed" &
            as.integer(design_lock$value) == RANDOM_SEED) &&
      any(design_lock$field == "Neighbors_per_target" &
            as.integer(design_lock$value) == NEIGHBOR_NUMBER),
    "Script15A design lock differs from Script15B constants."
  )
  assert(
    is.data.frame(observed_benchmarks) &&
      nrow(observed_benchmarks) == 2L &&
      setequal(
        observed_benchmarks$analysis,
        c("FULL_LOCKED24", "NO_OVERLAP_LOCKED22")
      ),
    "Observed benchmark table is malformed."
  )

  dir.create(dirname(OUTPUT_ROOT), recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(dirname(OUTPUT_ROOT)),
         "Unable to create random-null parent directory.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  set.seed(
    RANDOM_SEED,
    kind = "Mersenne-Twister",
    normal.kind = "Inversion",
    sample.kind = "Rejection"
  )

  accepted_mappings <- vector("list", RANDOM_SET_NUMBER)
  attempts_to_accept <- integer(RANDOM_SET_NUMBER)
  primary_keys <- character(RANDOM_SET_NUMBER)
  sensitivity_keys <- character(RANDOM_SET_NUMBER)
  seen_primary <- new.env(hash = TRUE, parent = emptyenv())
  seen_sensitivity <- new.env(hash = TRUE, parent = emptyenv())

  assignment_failures <- 0L
  duplicate_primary_rejections <- 0L
  duplicate_sensitivity_rejections <- 0L

  for (set_index in seq_len(RANDOM_SET_NUMBER)) {
    accepted <- FALSE

    for (attempt in seq_len(MAX_ATTEMPTS_PER_SET)) {
      mapping <- generate_mapping(candidate_list)
      if (is.null(mapping)) {
        assignment_failures <- assignment_failures + 1L
        next
      }

      primary_key <- set_key(mapping)
      sensitivity_mapping <- mapping[NON_EMT_TARGETS]
      sensitivity_key <- set_key(sensitivity_mapping)

      if (exists(primary_key, envir = seen_primary, inherits = FALSE)) {
        duplicate_primary_rejections <-
          duplicate_primary_rejections + 1L
        next
      }
      if (exists(
        sensitivity_key,
        envir = seen_sensitivity,
        inherits = FALSE
      )) {
        duplicate_sensitivity_rejections <-
          duplicate_sensitivity_rejections + 1L
        next
      }

      assign(primary_key, TRUE, envir = seen_primary)
      assign(sensitivity_key, TRUE, envir = seen_sensitivity)
      accepted_mappings[[set_index]] <- mapping
      attempts_to_accept[set_index] <- attempt
      primary_keys[set_index] <- primary_key
      sensitivity_keys[set_index] <- sensitivity_key
      accepted <- TRUE
      break
    }

    assert(
      accepted,
      paste0(
        "Unable to generate unique matched set %d within %d attempts. ",
        "No completed output was committed."
      ),
      set_index, MAX_ATTEMPTS_PER_SET
    )
  }

  set_ids <- sprintf("RANDOM_SET_%04d", seq_len(RANDOM_SET_NUMBER))
  names(accepted_mappings) <- set_ids

  primary_sets <- lapply(accepted_mappings, function(x) {
    unname(as.character(x[LOCKED24]))
  })
  sensitivity_sets <- lapply(accepted_mappings, function(x) {
    unname(as.character(x[NON_EMT_TARGETS]))
  })
  names(primary_sets) <- set_ids
  names(sensitivity_sets) <- set_ids

  assert(
    length(unique(primary_keys)) == RANDOM_SET_NUMBER &&
      length(unique(sensitivity_keys)) == RANDOM_SET_NUMBER &&
      all(lengths(primary_sets) == 24L) &&
      all(lengths(sensitivity_sets) == 22L) &&
      all(vapply(primary_sets, function(x)
        length(unique(x)) == 24L, logical(1))) &&
      all(vapply(sensitivity_sets, function(x)
        length(unique(x)) == 22L, logical(1))),
    "Generated primary or sensitivity set uniqueness failed."
  )

  feature_EMT <- setNames(
    as.logical(features$in_Hallmark_EMT),
    as.character(features$gene_symbol)
  )
  assert(
    all(vapply(primary_sets, function(x)
      sum(feature_EMT[x]) == 2L, logical(1))) &&
      all(vapply(sensitivity_sets, function(x)
        sum(feature_EMT[x]) == 0L, logical(1))) &&
      all(vapply(primary_sets, function(x)
        !any(x %in% LOCKED24), logical(1))),
    "Generated EMT membership or locked-gene exclusion failed."
  )

  mapping_rows <- lapply(seq_len(RANDOM_SET_NUMBER), function(i) {
    mapping <- accepted_mappings[[i]]
    data.frame(
      set_id = set_ids[i],
      set_number = i,
      target_gene = LOCKED24,
      target_order = seq_along(LOCKED24),
      candidate_gene = unname(mapping[LOCKED24]),
      retained_in_no_overlap22 = LOCKED24 %in% NON_EMT_TARGETS,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  })
  mapping_long <- do.call(rbind, mapping_rows)
  rownames(mapping_long) <- NULL

  candidate_details <- candidates[, c(
    "target_gene", "target_in_Hallmark_EMT",
    "candidate_gene", "candidate_in_Hallmark_EMT",
    "neighbor_rank", "six_feature_RMS_distance",
    "six_feature_mean_absolute_difference",
    "six_feature_maximum_absolute_difference"
  )]
  mapping_long <- merge(
    mapping_long,
    candidate_details,
    by = c("target_gene", "candidate_gene"),
    all.x = TRUE,
    sort = FALSE
  )
  mapping_long <- mapping_long[
    order(mapping_long$set_number, mapping_long$target_order),
    ,
    drop = FALSE
  ]
  rownames(mapping_long) <- NULL

  assert(
    nrow(mapping_long) == RANDOM_SET_NUMBER * length(LOCKED24) &&
      !anyDuplicated(mapping_long[c("set_id", "target_gene")]) &&
      all(is.finite(mapping_long$neighbor_rank)) &&
      all(is.finite(mapping_long$six_feature_RMS_distance)) &&
      all(
        mapping_long$target_in_Hallmark_EMT ==
          mapping_long$candidate_in_Hallmark_EMT
      ),
    "Generated long mapping table failed integrity checks."
  )

  set_summary <- do.call(rbind, lapply(seq_len(RANDOM_SET_NUMBER), function(i) {
    d <- mapping_long[
      mapping_long$set_number == i,
      ,
      drop = FALSE
    ]
    data.frame(
      set_id = set_ids[i],
      set_number = i,
      attempts_to_accept = attempts_to_accept[i],
      primary_gene_number = nrow(d),
      primary_unique_gene_number = length(unique(d$candidate_gene)),
      primary_EMT_gene_number = sum(d$candidate_in_Hallmark_EMT),
      sensitivity_gene_number =
        sum(d$retained_in_no_overlap22),
      sensitivity_unique_gene_number = length(unique(
        d$candidate_gene[d$retained_in_no_overlap22]
      )),
      sensitivity_EMT_gene_number = sum(
        d$candidate_in_Hallmark_EMT[
          d$retained_in_no_overlap22
        ]
      ),
      mean_neighbor_rank = mean(d$neighbor_rank),
      maximum_neighbor_rank = max(d$neighbor_rank),
      mean_RMS_distance =
        mean(d$six_feature_RMS_distance),
      maximum_RMS_distance =
        max(d$six_feature_RMS_distance),
      primary_signature_key = primary_keys[i],
      sensitivity_signature_key = sensitivity_keys[i],
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))

  target_usage <- aggregate(
    rep(1L, nrow(mapping_long)),
    by = list(
      target_gene = mapping_long$target_gene,
      candidate_gene = mapping_long$candidate_gene
    ),
    FUN = sum
  )
  names(target_usage)[3L] <- "selection_count"
  target_usage$selection_frequency <-
    target_usage$selection_count / RANDOM_SET_NUMBER
  target_usage <- merge(
    candidate_details,
    target_usage,
    by = c("target_gene", "candidate_gene"),
    all.x = TRUE,
    sort = FALSE
  )
  target_usage$selection_count[
    is.na(target_usage$selection_count)
  ] <- 0L
  target_usage$selection_frequency[
    is.na(target_usage$selection_frequency)
  ] <- 0
  target_usage <- target_usage[
    order(target_usage$target_gene, target_usage$neighbor_rank),
    ,
    drop = FALSE
  ]
  rownames(target_usage) <- NULL

  overall_usage <- aggregate(
    rep(1L, nrow(mapping_long)),
    by = list(candidate_gene = mapping_long$candidate_gene),
    FUN = sum
  )
  names(overall_usage)[2L] <- "selection_count"
  overall_usage$selection_frequency_per_mapping <-
    overall_usage$selection_count /
    (RANDOM_SET_NUMBER * length(LOCKED24))
  overall_usage$set_frequency <- vapply(
    overall_usage$candidate_gene,
    function(gene) {
      sum(vapply(primary_sets, function(x)
        gene %in% x, logical(1))) / RANDOM_SET_NUMBER
    },
    numeric(1)
  )
  overall_usage$in_Hallmark_EMT <-
    feature_EMT[overall_usage$candidate_gene]
  overall_usage <- overall_usage[
    order(-overall_usage$selection_count,
          overall_usage$candidate_gene),
    ,
    drop = FALSE
  ]
  rownames(overall_usage) <- NULL

  target_quality <- do.call(rbind, lapply(LOCKED24, function(target) {
    d <- mapping_long[
      mapping_long$target_gene == target,
      ,
      drop = FALSE
    ]
    data.frame(
      target_gene = target,
      target_in_Hallmark_EMT =
        unique(d$target_in_Hallmark_EMT),
      set_number = nrow(d),
      unique_candidate_number =
        length(unique(d$candidate_gene)),
      minimum_neighbor_rank = min(d$neighbor_rank),
      median_neighbor_rank = median(d$neighbor_rank),
      mean_neighbor_rank = mean(d$neighbor_rank),
      maximum_neighbor_rank = max(d$neighbor_rank),
      mean_RMS_distance =
        mean(d$six_feature_RMS_distance),
      maximum_RMS_distance =
        max(d$six_feature_RMS_distance),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))

  generation_summary <- data.frame(
    item = c(
      "Random_seed",
      "Requested_unique_set_number",
      "Accepted_unique_primary_set_number",
      "Accepted_unique_sensitivity_set_number",
      "Mapping_row_number",
      "Assignment_failure_number",
      "Duplicate_primary_rejection_number",
      "Duplicate_sensitivity_rejection_number",
      "Maximum_attempts_used_for_one_set",
      "Mean_attempts_per_accepted_set",
      "Primary_gene_number_per_set",
      "Primary_EMT_gene_number_per_set",
      "Sensitivity_gene_number_per_set",
      "Sensitivity_EMT_gene_number_per_set",
      "Locked_gene_used_as_candidate_number",
      "Result_based_rejection_number"
    ),
    value = c(
      RANDOM_SEED,
      RANDOM_SET_NUMBER,
      length(unique(primary_keys)),
      length(unique(sensitivity_keys)),
      nrow(mapping_long),
      assignment_failures,
      duplicate_primary_rejections,
      duplicate_sensitivity_rejections,
      max(attempts_to_accept),
      mean(attempts_to_accept),
      24L,
      2L,
      22L,
      0L,
      sum(mapping_long$candidate_gene %in% LOCKED24),
      0L
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  readiness_status <- "READY_FOR_SCRIPT15C"
  integrity <- data.frame(
    item = c(
      "Script",
      "Script_build_ID",
      "Input_file_number",
      "Input_MD5_all_locked",
      "Primary_set_number",
      "Sensitivity_set_number",
      "Primary_sets_all_unique",
      "Sensitivity_sets_all_unique",
      "Genes_per_primary_set",
      "Genes_per_sensitivity_set",
      "EMT_genes_per_primary_set",
      "EMT_genes_per_sensitivity_set",
      "Within_set_duplicate_genes",
      "Locked_genes_used_as_candidates",
      "Mapping_row_number",
      "Outcome_used_for_generation",
      "Result_based_set_rejection",
      "GSVA_performed",
      "Empirical_p_calculated",
      "Readiness_status",
      "Completion_status"
    ),
    value = as.character(c(
      "15B",
      BUILD_ID,
      length(INPUTS),
      TRUE,
      length(primary_sets),
      length(sensitivity_sets),
      length(unique(primary_keys)) == RANDOM_SET_NUMBER,
      length(unique(sensitivity_keys)) == RANDOM_SET_NUMBER,
      24L,
      22L,
      2L,
      0L,
      0L,
      sum(mapping_long$candidate_gene %in% LOCKED24),
      nrow(mapping_long),
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      readiness_status,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    input_name = names(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(
        PROJECT_ROOT, winslash = "/", mustWork = TRUE
      )) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed_md5,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = paste0(
      "Step5_cross_cohort_synthesis/",
      "03_matched_random_24gene_null/",
      "01_random_signature_generation"
    ),
    script = "Script15B",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    readiness_status = readiness_status,
    random_seed = RANDOM_SEED,
    random_set_number = RANDOM_SET_NUMBER,
    primary_signature_keys = primary_keys,
    sensitivity_signature_keys = sensitivity_keys,
    generation_summary = generation_summary,
    target_matching_quality = target_quality,
    target_candidate_usage = target_usage,
    overall_candidate_usage = overall_usage,
    observed_benchmarks = observed_benchmarks,
    input_manifest = input_manifest,
    integrity_summary = integrity,
    policy = list(
      matching_design_unchanged = TRUE,
      unique_primary_sets_required = TRUE,
      unique_sensitivity_sets_required = TRUE,
      exact_EMT_membership_preserved = TRUE,
      locked_genes_used_as_candidates = FALSE,
      outcome_used_for_generation = FALSE,
      result_based_set_rejection = FALSE,
      GSVA_performed = FALSE,
      cohort_association_performed = FALSE,
      meta_analysis_performed = FALSE,
      empirical_p_calculated = FALSE,
      survival_analysis_performed = FALSE,
      manuscript_figure_created = FALSE
    )
  )
  class(bundle) <- c(
    "Matched_random24_generation_bundle", "list"
  )

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      ".Script15B_staging_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(
    dirs, dir.create, logical(1),
    recursive = TRUE, showWarnings = FALSE
  ) | dir.exists(dirs)), "Unable to create staging directories.")

  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "Matched_random24_generation_COMPLETE_bundle.rds"
    ),
    primary_sets = file.path(
      stage, "objects",
      "Matched_random24_primary_5000_gene_sets.rds"
    ),
    sensitivity_sets = file.path(
      stage, "objects",
      "Matched_random22_no_EMT_5000_gene_sets.rds"
    ),
    mappings_rds = file.path(
      stage, "objects",
      "Matched_random24_5000_target_gene_mappings.rds"
    ),
    mappings_csv = file.path(
      stage, "audit",
      "Matched_random24_5000_target_gene_mappings.csv"
    ),
    set_summary = file.path(
      stage, "audit",
      "Matched_random24_5000_set_summary.csv"
    ),
    generation_summary = file.path(
      stage, "audit",
      "Matched_random24_generation_summary.csv"
    ),
    target_quality = file.path(
      stage, "audit",
      "Matched_random24_target_matching_quality.csv"
    ),
    target_usage = file.path(
      stage, "audit",
      "Matched_random24_target_candidate_usage.csv"
    ),
    overall_usage = file.path(
      stage, "audit",
      "Matched_random24_overall_candidate_usage.csv"
    ),
    inputs = file.path(
      stage, "audit",
      "Script15B_input_manifest_with_MD5.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "Matched_random24_generation_integrity_summary.csv"
    ),
    session = file.path(
      stage, "logs",
      "Script15B_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs",
      "Script15B_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(primary_sets, files["primary_sets"], version = 3)
  saveRDS(sensitivity_sets, files["sensitivity_sets"], version = 3)
  saveRDS(mapping_long, files["mappings_rds"], version = 3)

  write_csv(mapping_long, files["mappings_csv"])
  write_csv(set_summary, files["set_summary"])
  write_csv(generation_summary, files["generation_summary"])
  write_csv(target_quality, files["target_quality"])
  write_csv(target_usage, files["target_usage"])
  write_csv(overall_usage, files["overall_usage"])
  write_csv(input_manifest, files["inputs"])
  write_csv(integrity, files["integrity"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan - Script15B Matched Random Signature Generation",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("Random seed: ", RANDOM_SEED),
    paste0("Unique primary 24-gene sets: ", length(primary_sets)),
    paste0("Unique sensitivity 22-gene sets: ", length(sensitivity_sets)),
    paste0("Target-gene mapping rows: ", nrow(mapping_long)),
    paste0("Assignment failures: ", assignment_failures),
    paste0(
      "Duplicate primary rejections: ",
      duplicate_primary_rejections
    ),
    paste0(
      "Duplicate sensitivity rejections: ",
      duplicate_sensitivity_rejections
    ),
    paste0(
      "Maximum attempts used for one accepted set: ",
      max(attempts_to_accept)
    ),
    "Primary set composition: 24 unique genes; exactly 2 EMT genes",
    "Sensitivity set composition: 22 unique genes; 0 EMT genes",
    "Locked genes used as candidates: 0",
    "Outcome used for generation: FALSE",
    "Result-based set rejection: FALSE",
    "GSVA performed: FALSE",
    "Empirical p calculated: FALSE",
    paste0("Readiness status: ", readiness_status),
    "",
    "SCRIPT15B STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  p2 <- readRDS(files["primary_sets"])
  s2 <- readRDS(files["sensitivity_sets"])
  m2 <- readRDS(files["mappings_rds"])
  a2 <- read.csv(
    files["set_summary"],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert(
    same_text(b2$readiness_status, "READY_FOR_SCRIPT15C") &&
      identical(p2, primary_sets) &&
      identical(s2, sensitivity_sets) &&
      identical(m2, mapping_long) &&
      nrow(a2) == RANDOM_SET_NUMBER &&
      length(unique(a2$primary_signature_key)) ==
        RANDOM_SET_NUMBER &&
      length(unique(a2$sensitivity_signature_key)) ==
        RANDOM_SET_NUMBER,
    "Staged RDS/CSV save-read verification failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script15B_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script15B_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script15B_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script15B completed successfully.\n")
  cat("5,000 unique matched primary and sensitivity sets generated.\n")
  cat("GSVA performed: FALSE\n")
  cat("Readiness status: READY_FOR_SCRIPT15C\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

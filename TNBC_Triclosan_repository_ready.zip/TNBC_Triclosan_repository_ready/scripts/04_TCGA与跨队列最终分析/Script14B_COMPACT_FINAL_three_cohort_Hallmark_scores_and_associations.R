# ==============================================================================
# TNBC_Triclosan | Script 14B COMPACT FINAL
# Three-cohort Hallmark GSVA scores and within-cohort associations.
#
# Locked by accepted Script 14A:
# - 50 human Hallmark pathways;
# - TCGA TNBC: cohort-level two-sided Spearman;
# - GSE31519: global ranks centered within source_dataset_id, followed by
#   Pearson correlation and partial-correlation t inference;
# - GSE58812: cohort-level two-sided Spearman;
# - BH correction across all 50 pathways within each cohort.
#
# This script performs NO cross-cohort meta-analysis and NO pathway selection.
# It must reproduce the accepted EMT score and effect in every cohort.
#
# No new Triclosan score, survival model, cutoff, grouping, sample deletion,
# DEG, PCA, GSEA or manuscript figure.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script14B_COMPACT_FINAL_20260712"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"

PREFLIGHT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "00_preflight_and_input_lock"
)
OUTPUT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "01_cohort_Hallmark_scores_and_associations"
)

INPUTS <- c(
  preflight_bundle = file.path(
    PREFLIGHT_ROOT, "objects",
    "Hallmark_panorama_preflight_COMPLETE_bundle.rds"
  ),
  TCGA_prepared = file.path(
    PREFLIGHT_ROOT, "objects",
    "TCGA_TNBC_Hallmark_panorama_prepared_input.rds"
  ),
  GSE31519_prepared = file.path(
    PREFLIGHT_ROOT, "objects",
    "GSE31519_Hallmark_panorama_prepared_input.rds"
  ),
  GSE58812_prepared = file.path(
    PREFLIGHT_ROOT, "objects",
    "GSE58812_Hallmark_panorama_prepared_input.rds"
  ),
  Hallmark_collection = file.path(
    PREFLIGHT_ROOT, "objects",
    "Human_Hallmark_collection_locked.rds"
  ),
  preflight_manifest = file.path(
    PREFLIGHT_ROOT, "audit",
    "Script14A_output_manifest_with_MD5.csv"
  ),
  preflight_report = file.path(
    PREFLIGHT_ROOT, "logs",
    "Script14A_COMPLETE_report.txt"
  )
)

EXPECTED_MD5 <- c(
  preflight_bundle = "fd38a6e71ca6b58eecd337ae7600d5b5",
  TCGA_prepared = "55537d7f98fb915a811f1456072e6091",
  GSE31519_prepared = "2b6bba1d414c42625ab3cc00357a6a20",
  GSE58812_prepared = "cb667dcba01e5740eb6ecd607035b2bc",
  Hallmark_collection = "c6e2898a41dafdc39ea56747be0fbcc0",
  preflight_manifest = "74f777ca434b0a6b4b420e0ead93f363",
  preflight_report = "ebf11ae0ac8fc681200a7859e6a12b0c"
)

EXPECTED_DIMENSIONS <- list(
  TCGA_TNBC = c(56477L, 197L),
  GSE31519 = c(12650L, 579L),
  GSE58812 = c(20823L, 107L)
)
EXPECTED_EMT_RHO <- c(
  TCGA_TNBC = 0.474691491732826,
  GSE31519 = 0.4222513341893304,
  GSE58812 = 0.3773193048453144
)
EXPECTED_HALLMARK_NUMBER <- 50L
EMT_NAME <- "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"
EMT_SCORE_TOLERANCE <- 1e-8
EMT_RHO_TOLERANCE <- 1e-12

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

scalar_text <- function(x, label = "value") {
  y <- as.character(x)
  assert(length(y) == 1L && !is.na(y) && nzchar(trimws(y)),
         "%s must be one nonblank scalar value.", label)
  unname(trimws(y))
}

same_text <- function(x, y) {
  identical(
    scalar_text(x, "observed text"),
    scalar_text(y, "expected text")
  )
}

same_md5 <- function(x, y) {
  identical(
    tolower(scalar_text(x, "observed MD5")),
    tolower(scalar_text(y, "expected MD5"))
  )
}

report_contains <- function(file, marker) {
  any(grepl(
    marker,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)

    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)

    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

normalize_gsva_output <- function(
  object, expected_pathways, expected_samples, cohort
) {
  raw_class <- paste(class(object), collapse = "/")
  if (is.matrix(object)) {
    x <- object
  } else if (
    inherits(object, "SummarizedExperiment") &&
      requireNamespace("SummarizedExperiment", quietly = TRUE)
  ) {
    x <- as.matrix(SummarizedExperiment::assay(object))
  } else {
    x <- tryCatch(as.matrix(object), error = function(e) NULL)
  }

  assert(is.matrix(x) && is.numeric(x),
         "%s GSVA output cannot be converted to a numeric matrix.", cohort)

  raw_dim <- dim(x)
  raw_rows <- rownames(x)
  raw_cols <- colnames(x)
  transposed <- FALSE

  direct_named <-
    !is.null(raw_rows) && !is.null(raw_cols) &&
    setequal(raw_rows, expected_pathways) &&
    setequal(raw_cols, expected_samples)

  reverse_named <-
    !is.null(raw_rows) && !is.null(raw_cols) &&
    setequal(raw_rows, expected_samples) &&
    setequal(raw_cols, expected_pathways)

  if (direct_named) {
    # keep as returned
  } else if (reverse_named) {
    x <- t(x)
    transposed <- TRUE
  } else {
    stopf(
      paste0(
        "%s GSVA output names do not identify a valid pathway-by-sample ",
        "matrix. Raw dimensions: %s; expected: %d x %d."
      ),
      cohort,
      paste(raw_dim, collapse = " x "),
      length(expected_pathways),
      length(expected_samples)
    )
  }

  assert(
    setequal(rownames(x), expected_pathways) &&
      setequal(colnames(x), expected_samples),
    "%s GSVA output names remain incomplete after orientation.", cohort
  )

  row_reordered <- !identical(rownames(x), expected_pathways)
  col_reordered <- !identical(colnames(x), expected_samples)
  x <- x[expected_pathways, expected_samples, drop = FALSE]

  row_sd <- apply(x, 1L, stats::sd)
  assert(
    identical(dim(x), c(length(expected_pathways), length(expected_samples))) &&
      identical(rownames(x), expected_pathways) &&
      identical(colnames(x), expected_samples) &&
      all(is.finite(x)) &&
      all(is.finite(row_sd) & row_sd > 0),
    "%s normalized GSVA matrix failed dimension, order, finite or variance checks.",
    cohort
  )

  audit <- data.frame(
    cohort = cohort,
    raw_class = raw_class,
    raw_row_number = raw_dim[1L],
    raw_column_number = raw_dim[2L],
    raw_first_row_name =
      if (length(raw_rows)) as.character(raw_rows[1L]) else "",
    raw_first_column_name =
      if (length(raw_cols)) as.character(raw_cols[1L]) else "",
    transposed = transposed,
    pathway_rows_reordered = row_reordered,
    sample_columns_reordered = col_reordered,
    final_row_number = nrow(x),
    final_column_number = ncol(x),
    nonfinite_value_number = sum(!is.finite(x)),
    zero_variance_pathway_number = sum(!(is.finite(row_sd) & row_sd > 0)),
    minimum_pathway_SD = min(row_sd),
    maximum_pathway_SD = max(row_sd),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(scores = x, audit = audit)
}

source_adjusted_partial_spearman <- function(x, y, source) {
  assert(
    length(x) == length(y) && length(x) == length(source) &&
      all(is.finite(x)) && all(is.finite(y)) &&
      all(!is.na(source) & nzchar(source)),
    "Source-adjusted input vectors are incomplete."
  )

  source <- factor(source)
  rx <- rank(x, ties.method = "average")
  ry <- rank(y, ties.method = "average")

  rx_centered <- rx - ave(rx, source, FUN = mean)
  ry_centered <- ry - ave(ry, source, FUN = mean)

  rho <- suppressWarnings(cor(
    rx_centered, ry_centered, method = "pearson"
  ))
  design_rank <- qr(model.matrix(~ source))$rank
  df <- length(x) - design_rank - 1L

  assert(
    is.finite(rho) && rho > -1 && rho < 1 && df > 0,
    "Source-adjusted partial Spearman estimate or residual df is invalid."
  )

  t_statistic <- rho * sqrt(df / (1 - rho^2))
  p_value <- 2 * pt(abs(t_statistic), df = df, lower.tail = FALSE)

  list(
    estimate = unname(rho),
    p_value = unname(p_value),
    statistic = unname(t_statistic),
    df = as.integer(df),
    source_dataset_number = nlevels(source),
    rank_method = "Global ranks; centered within source_dataset_id"
  )
}

cohort_associations <- function(
  cohort, score, pathway_scores, source_dataset_id
) {
  pathways <- rownames(pathway_scores)
  assert(
    identical(colnames(pathway_scores), names(score)) &&
      length(source_dataset_id) == length(score),
    "%s score, pathway matrix and source vector are misaligned.", cohort
  )

  rows <- lapply(pathways, function(pathway) {
    y <- as.numeric(pathway_scores[pathway, ])

    if (cohort == "GSE31519") {
      fit <- source_adjusted_partial_spearman(
        score, y, source_dataset_id
      )
      data.frame(
        cohort = cohort,
        pathway = pathway,
        sample_number = length(score),
        source_dataset_number = fit$source_dataset_number,
        method = "Partial_Spearman_source_centered_ranks",
        estimate = fit$estimate,
        test_statistic = fit$statistic,
        test_df = fit$df,
        two_sided_p = fit$p_value,
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    } else {
      fit <- suppressWarnings(cor.test(
        score, y, method = "spearman", exact = FALSE
      ))
      data.frame(
        cohort = cohort,
        pathway = pathway,
        sample_number = length(score),
        source_dataset_number = 1L,
        method = "Spearman",
        estimate = unname(fit$estimate),
        test_statistic = unname(fit$statistic),
        test_df = NA_integer_,
        two_sided_p = fit$p.value,
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
  })

  result <- do.call(rbind, rows)
  result$BH_adjusted_p <- p.adjust(result$two_sided_p, method = "BH")
  result$direction <- ifelse(
    result$estimate > 0, "POSITIVE",
    ifelse(result$estimate < 0, "NEGATIVE", "ZERO")
  )
  result$rank_by_absolute_rho <- rank(
    -abs(result$estimate), ties.method = "min"
  )
  result$rank_by_signed_rho_desc <- rank(
    -result$estimate, ties.method = "min"
  )
  result$is_EMT <- result$pathway == EMT_NAME
  result
}

score_one_cohort <- function(
  prepared, hallmark_collection, coverage, expected_dim
) {
  cohort <- scalar_text(prepared$cohort, "cohort")
  expression <- prepared$expression
  score <- prepared$Triclosan_activity
  source <- as.character(prepared$source_dataset_id)
  accepted_EMT <- prepared$accepted_EMT_score

  assert(
    is.matrix(expression) && is.numeric(expression) &&
      identical(dim(expression), expected_dim) &&
      !anyDuplicated(rownames(expression)) &&
      !anyDuplicated(colnames(expression)) &&
      all(is.finite(expression)),
    "%s prepared expression is malformed.", cohort
  )
  assert(
    is.numeric(score) && length(score) == ncol(expression) &&
      identical(names(score), colnames(expression)) &&
      all(is.finite(score)) && sd(score) > 0,
    "%s prepared Triclosan score is malformed or misaligned.", cohort
  )
  assert(
    is.numeric(accepted_EMT) &&
      length(accepted_EMT) == ncol(expression) &&
      identical(names(accepted_EMT), colnames(expression)) &&
      all(is.finite(accepted_EMT)) && sd(accepted_EMT) > 0,
    "%s accepted EMT benchmark is malformed or misaligned.", cohort
  )
  assert(
    length(source) == ncol(expression) &&
      all(!is.na(source) & nzchar(source)),
    "%s source_dataset_id vector is malformed.", cohort
  )

  cohort_coverage <- coverage[
    coverage$cohort == cohort &
      coverage$cohort_pathway_eligible,
    ,
    drop = FALSE
  ]
  assert(
    nrow(cohort_coverage) == EXPECTED_HALLMARK_NUMBER &&
      setequal(cohort_coverage$pathway, names(hallmark_collection)),
    "%s does not have all 50 eligible Hallmark pathways.", cohort
  )

  detected_sets <- lapply(names(hallmark_collection), function(pathway) {
    intersect(hallmark_collection[[pathway]], rownames(expression))
  })
  names(detected_sets) <- names(hallmark_collection)

  detected_n <- lengths(detected_sets)
  coverage_expected <- setNames(
    cohort_coverage$detected_gene_number,
    cohort_coverage$pathway
  )
  assert(
    identical(
      as.integer(detected_n[names(hallmark_collection)]),
      as.integer(coverage_expected[names(hallmark_collection)])
    ),
    "%s detected Hallmark membership differs from Script14A.", cohort
  )

  set.seed(20260712L)
  parameter <- GSVA::gsvaParam(expression, detected_sets)
  raw_scores <- GSVA::gsva(parameter)
  normalized <- normalize_gsva_output(
    raw_scores,
    names(hallmark_collection),
    colnames(expression),
    cohort
  )
  pathway_scores <- normalized$scores

  EMT_new <- as.numeric(pathway_scores[EMT_NAME, ])
  names(EMT_new) <- colnames(pathway_scores)
  max_abs_difference <- max(abs(EMT_new - accepted_EMT))
  pearson_identity <- suppressWarnings(cor(
    EMT_new, accepted_EMT, method = "pearson"
  ))
  spearman_identity <- suppressWarnings(cor(
    EMT_new, accepted_EMT, method = "spearman"
  ))

  assert(
    is.finite(max_abs_difference) &&
      max_abs_difference <= EMT_SCORE_TOLERANCE &&
      is.finite(pearson_identity) &&
      pearson_identity >= 1 - EMT_SCORE_TOLERANCE &&
      is.finite(spearman_identity) &&
      spearman_identity >= 1 - EMT_SCORE_TOLERANCE,
    paste0(
      "%s all-Hallmark GSVA failed to reproduce the accepted EMT score. ",
      "Maximum absolute difference = %.16g."
    ),
    cohort, max_abs_difference
  )

  association <- cohort_associations(
    cohort, as.numeric(score) |> setNames(names(score)),
    pathway_scores, source
  )

  EMT_result <- association[
    association$pathway == EMT_NAME,
    ,
    drop = FALSE
  ]
  assert(nrow(EMT_result) == 1L,
         "%s EMT association row is missing or duplicated.", cohort)

  expected_rho <- unname(EXPECTED_EMT_RHO[cohort])
  assert(
    isTRUE(all.equal(
      as.numeric(EMT_result$estimate),
      expected_rho,
      tolerance = EMT_RHO_TOLERANCE,
      check.attributes = FALSE
    )),
    "%s EMT association does not reproduce the accepted estimate.", cohort
  )

  benchmark <- data.frame(
    cohort = cohort,
    sample_number = ncol(expression),
    accepted_EMT_score_SD = sd(accepted_EMT),
    recalculated_EMT_score_SD = sd(EMT_new),
    maximum_absolute_score_difference = max_abs_difference,
    score_Pearson_identity = pearson_identity,
    score_Spearman_identity = spearman_identity,
    accepted_EMT_rho = expected_rho,
    recalculated_EMT_rho = as.numeric(EMT_result$estimate),
    absolute_rho_difference =
      abs(as.numeric(EMT_result$estimate) - expected_rho),
    score_reproduction_pass = TRUE,
    effect_reproduction_pass = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  method_audit <- data.frame(
    cohort = cohort,
    sample_number = ncol(expression),
    source_dataset_number = length(unique(source)),
    correlation_method = unique(association$method),
    source_adjustment =
      if (cohort == "GSE31519") {
        "Global ranks centered within source_dataset_id"
      } else {
        "None"
      },
    test_inference =
      if (cohort == "GSE31519") {
        paste0(
          "Partial-correlation t test; residual df=",
          unique(association$test_df)
        )
      } else {
        "Two-sided asymptotic Spearman cor.test"
      },
    pathway_number = nrow(association),
    within_cohort_adjustment = "BH across 50 pathways",
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  list(
    scores = pathway_scores,
    associations = association,
    benchmark = benchmark,
    normalization_audit = normalized$audit,
    method_audit = method_audit,
    gsva_parameter = parameter
  )
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "Hallmark_panorama_cohort_associations_COMPLETE_bundle.rds"
    ),
    results = file.path(
      root, "audit",
      "Hallmark_panorama_cohort_association_results.csv"
    ),
    manifest = file.path(
      root, "audit",
      "Script14B_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script14B_COMPLETE_report.txt"
    )
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT14B STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  r <- tryCatch(
    read.csv(key["results"], stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )

  is.list(b) &&
    same_text(b$script, "Script14B") &&
    same_text(b$script_build_id, BUILD_ID) &&
    identical(as.character(b$readiness_status), "READY_FOR_SCRIPT14C") &&
    is.data.frame(r) && nrow(r) == 150L &&
    sum(r$is_EMT) == 3L &&
    isFALSE(b$policy$meta_analysis_performed)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT),
           "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script 14B output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "01_cohort_Hallmark_scores_and_associations_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Three-cohort 50-Hallmark GSVA and cohort associations only.\n")
  cat("============================================================\n")

  missing_packages <- c("GSVA")[
    !vapply(c("GSVA"), requireNamespace, logical(1), quietly = TRUE)
  ]
  assert(!length(missing_packages),
         "Missing package(s): %s", paste(missing_packages, collapse = ", "))

  missing_files <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing_files), "Missing Script14A input(s):\n%s",
         paste(missing_files, collapse = "\n"))

  observed_md5 <- vapply(INPUTS, md5, character(1))
  assert(
    identical(unname(observed_md5), unname(EXPECTED_MD5)),
    "At least one accepted Script14A input MD5 differs:\n%s",
    paste(sprintf(
      "%s | expected=%s | observed=%s",
      names(EXPECTED_MD5), EXPECTED_MD5, observed_md5
    ), collapse = "\n")
  )
  assert(
    manifest_ok(PREFLIGHT_ROOT, INPUTS["preflight_manifest"]),
    "Script14A output manifest verification failed."
  )
  assert(
    report_contains(
      INPUTS["preflight_report"], "SCRIPT14A STATUS: COMPLETE"
    ),
    "Script14A COMPLETE marker is missing."
  )

  preflight <- readRDS(INPUTS["preflight_bundle"])
  assert(
    is.list(preflight) &&
      same_text(preflight$script, "Script14A") &&
      same_text(
        preflight$script_build_id,
        "Script14A_v2_COMPACT_FINAL_20260711"
      ) &&
      same_text(preflight$readiness_status, "READY_FOR_SCRIPT14B") &&
      isFALSE(preflight$policy$pathway_correlations_performed) &&
      isFALSE(preflight$policy$meta_analysis_performed),
    "Script14A preflight identity or readiness lock is incorrect."
  )

  Hallmark <- readRDS(INPUTS["Hallmark_collection"])
  TCGA <- readRDS(INPUTS["TCGA_prepared"])
  G315 <- readRDS(INPUTS["GSE31519_prepared"])
  G588 <- readRDS(INPUTS["GSE58812_prepared"])

  assert(
    is.list(Hallmark) &&
      length(Hallmark) == EXPECTED_HALLMARK_NUMBER &&
      identical(names(Hallmark), sort(names(Hallmark))) &&
      EMT_NAME %in% names(Hallmark),
    "Locked Hallmark collection is malformed."
  )

  coverage <- preflight$coverage_by_cohort
  eligibility <- preflight$pathway_eligibility
  assert(
    is.data.frame(coverage) && nrow(coverage) == 150L &&
      is.data.frame(eligibility) && nrow(eligibility) == 50L &&
      all(eligibility$prespecified_for_Script14B) &&
      all(eligibility$eligible_in_all_three_cohorts),
    "Script14A coverage or eligibility lock is malformed."
  )

  dir.create(dirname(OUTPUT_ROOT), recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(dirname(OUTPUT_ROOT)),
         "Unable to create Hallmark panorama parent directory.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  TCGA_result <- score_one_cohort(
    TCGA, Hallmark, coverage, EXPECTED_DIMENSIONS$TCGA_TNBC
  )
  G315_result <- score_one_cohort(
    G315, Hallmark, coverage, EXPECTED_DIMENSIONS$GSE31519
  )
  G588_result <- score_one_cohort(
    G588, Hallmark, coverage, EXPECTED_DIMENSIONS$GSE58812
  )

  all_results <- rbind(
    TCGA_result$associations,
    G315_result$associations,
    G588_result$associations
  )
  rownames(all_results) <- NULL

  coverage_join <- coverage[, c(
    "cohort", "pathway", "Hallmark_total_gene_number",
    "detected_gene_number", "detected_fraction",
    "locked24_overlap_gene_number", "locked24_overlap_genes"
  )]
  all_results <- merge(
    all_results,
    coverage_join,
    by = c("cohort", "pathway"),
    all.x = TRUE,
    sort = FALSE
  )

  cohort_order <- c("TCGA_TNBC", "GSE31519", "GSE58812")
  all_results$cohort <- factor(all_results$cohort, levels = cohort_order)
  all_results$pathway <- factor(
    all_results$pathway, levels = names(Hallmark)
  )
  all_results <- all_results[
    order(all_results$cohort, all_results$pathway),
    ,
    drop = FALSE
  ]
  all_results$cohort <- as.character(all_results$cohort)
  all_results$pathway <- as.character(all_results$pathway)
  rownames(all_results) <- NULL

  assert(
    nrow(all_results) == 150L &&
      all(table(all_results$cohort) == 50L) &&
      sum(all_results$is_EMT) == 3L &&
      all(is.finite(all_results$estimate)) &&
      all(is.finite(all_results$two_sided_p)) &&
      all(is.finite(all_results$BH_adjusted_p)) &&
      !anyDuplicated(all_results[c("cohort", "pathway")]),
    "Combined 150-row cohort association table failed integrity checks."
  )

  EMT_rows <- all_results[all_results$is_EMT, , drop = FALSE]
  EMT_rows <- EMT_rows[
    match(cohort_order, EMT_rows$cohort),
    ,
    drop = FALSE
  ]
  assert(
    identical(EMT_rows$cohort, cohort_order) &&
      isTRUE(all.equal(
        EMT_rows$estimate,
        unname(EXPECTED_EMT_RHO[cohort_order]),
        tolerance = EMT_RHO_TOLERANCE,
        check.attributes = FALSE
      )),
    "Combined EMT rows do not reproduce all three accepted effects."
  )

  benchmark <- rbind(
    TCGA_result$benchmark,
    G315_result$benchmark,
    G588_result$benchmark
  )
  normalization_audit <- rbind(
    TCGA_result$normalization_audit,
    G315_result$normalization_audit,
    G588_result$normalization_audit
  )
  method_audit <- rbind(
    TCGA_result$method_audit,
    G315_result$method_audit,
    G588_result$method_audit
  )
  rownames(benchmark) <- NULL
  rownames(normalization_audit) <- NULL
  rownames(method_audit) <- NULL

  parameter_lock <- data.frame(
    field = c(
      "Analysis_stage",
      "Hallmark_pathway_number",
      "Hallmark_membership",
      "GSVA_method",
      "TCGA_association",
      "GSE31519_association",
      "GSE31519_test_df",
      "GSE58812_association",
      "Within_cohort_multiple_testing",
      "EMT_score_benchmark_tolerance",
      "EMT_effect_benchmark_tolerance",
      "Pathway_selection_after_results",
      "Cross_cohort_meta_analysis",
      "New_Triclosan_score",
      "Survival_analysis",
      "Sample_filtering",
      "Cutoff_or_high_low_group",
      "DEG_PCA_GSEA_figure",
      "Next_script"
    ),
    value = c(
      "Three-cohort Hallmark scores and within-cohort effects",
      EXPECTED_HALLMARK_NUMBER,
      "Detected genes locked by accepted Script14A coverage",
      paste0("Classical GSVA; GSVA ", packageVersion("GSVA")),
      "Two-sided Spearman",
      paste0(
        "Global ranks centered within source_dataset_id; ",
        "Pearson correlation"
      ),
      unique(G315_result$associations$test_df),
      "Two-sided Spearman",
      "BH across 50 pathways separately within each cohort",
      EMT_SCORE_TOLERANCE,
      EMT_RHO_TOLERANCE,
      "PROHIBITED",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "FALSE",
      "Script14C after uploaded-result acceptance"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    input_name = names(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(
        PROJECT_ROOT, winslash = "/", mustWork = TRUE
      )) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed_md5,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  package_audit <- data.frame(
    package = "GSVA",
    version = as.character(packageVersion("GSVA")),
    available = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  readiness_status <- "READY_FOR_SCRIPT14C"
  integrity <- data.frame(
    item = c(
      "Script",
      "Script_build_ID",
      "Input_file_number",
      "Input_MD5_all_locked",
      "Hallmark_pathway_number",
      "TCGA_score_dimensions",
      "GSE31519_score_dimensions",
      "GSE58812_score_dimensions",
      "Cohort_association_row_number",
      "Unique_cohort_pathway_pairs",
      "EMT_benchmark_number",
      "EMT_score_benchmarks_passed",
      "EMT_effect_benchmarks_passed",
      "GSE31519_source_dataset_number",
      "Within_cohort_BH_performed",
      "Cross_cohort_meta_performed",
      "Pathways_selected_after_results",
      "New_score_calculated",
      "Survival_analysis_performed",
      "Samples_filtered",
      "Readiness_status",
      "Completion_status"
    ),
    value = as.character(c(
      "14B",
      BUILD_ID,
      length(INPUTS),
      TRUE,
      paste(length(Hallmark)),
      paste(dim(TCGA_result$scores), collapse = " x "),
      paste(dim(G315_result$scores), collapse = " x "),
      paste(dim(G588_result$scores), collapse = " x "),
      nrow(all_results),
      nrow(unique(all_results[c("cohort", "pathway")])),
      nrow(benchmark),
      all(benchmark$score_reproduction_pass),
      all(benchmark$effect_reproduction_pass),
      length(unique(G315$source_dataset_id)),
      TRUE,
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      FALSE,
      readiness_status,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = paste0(
      "Step5_cross_cohort_synthesis/02_Hallmark_panorama/",
      "01_cohort_Hallmark_scores_and_associations"
    ),
    script = "Script14B",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    readiness_status = readiness_status,
    cohort_association_results = all_results,
    EMT_benchmark_reproduction = benchmark,
    GSVA_normalization_audit = normalization_audit,
    correlation_method_audit = method_audit,
    parameter_lock = parameter_lock,
    input_manifest = input_manifest,
    integrity_summary = integrity,
    policy = list(
      core_EMT_analysis_remains_frozen = TRUE,
      prespecified_Hallmark_panorama = TRUE,
      all_50_pathways_scored = TRUE,
      within_cohort_associations_performed = TRUE,
      within_cohort_BH_performed = TRUE,
      pathway_selection_after_results = FALSE,
      meta_analysis_performed = FALSE,
      new_Triclosan_score_calculated = FALSE,
      survival_analysis_performed = FALSE,
      samples_filtered = FALSE,
      outliers_removed = FALSE,
      cutoff_selected = FALSE,
      high_low_group_created = FALSE,
      DEG_performed = FALSE,
      PCA_performed = FALSE,
      GSEA_performed = FALSE,
      manuscript_figure_created = FALSE
    )
  )
  class(bundle) <- c(
    "Hallmark_panorama_cohort_associations_bundle", "list"
  )

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      ".Script14B_staging_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(
    dirs, dir.create, logical(1),
    recursive = TRUE, showWarnings = FALSE
  ) | dir.exists(dirs)), "Unable to create staging directories.")

  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "Hallmark_panorama_cohort_associations_COMPLETE_bundle.rds"
    ),
    TCGA_scores = file.path(
      stage, "objects", "TCGA_TNBC_50_Hallmark_GSVA_scores.rds"
    ),
    G315_scores = file.path(
      stage, "objects", "GSE31519_50_Hallmark_GSVA_scores.rds"
    ),
    G588_scores = file.path(
      stage, "objects", "GSE58812_50_Hallmark_GSVA_scores.rds"
    ),
    TCGA_scores_csv = file.path(
      stage, "audit", "TCGA_TNBC_50_Hallmark_GSVA_scores.csv"
    ),
    G315_scores_csv = file.path(
      stage, "audit", "GSE31519_50_Hallmark_GSVA_scores.csv"
    ),
    G588_scores_csv = file.path(
      stage, "audit", "GSE58812_50_Hallmark_GSVA_scores.csv"
    ),
    results = file.path(
      stage, "audit",
      "Hallmark_panorama_cohort_association_results.csv"
    ),
    benchmark = file.path(
      stage, "audit",
      "Hallmark_panorama_EMT_benchmark_reproduction.csv"
    ),
    normalization = file.path(
      stage, "audit",
      "Hallmark_panorama_GSVA_output_normalization_audit.csv"
    ),
    methods = file.path(
      stage, "audit",
      "Hallmark_panorama_cohort_correlation_method_audit.csv"
    ),
    parameters = file.path(
      stage, "audit",
      "Hallmark_panorama_cohort_association_parameter_lock.csv"
    ),
    packages = file.path(
      stage, "audit", "Script14B_package_audit.csv"
    ),
    inputs = file.path(
      stage, "audit", "Script14B_input_manifest_with_MD5.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "Hallmark_panorama_cohort_association_integrity_summary.csv"
    ),
    TCGA_GSVA_details = file.path(
      stage, "logs", "Script14B_TCGA_GSVA_parameter_details.txt"
    ),
    G315_GSVA_details = file.path(
      stage, "logs", "Script14B_GSE31519_GSVA_parameter_details.txt"
    ),
    G588_GSVA_details = file.path(
      stage, "logs", "Script14B_GSE58812_GSVA_parameter_details.txt"
    ),
    session = file.path(
      stage, "logs", "Script14B_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs", "Script14B_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(TCGA_result$scores, files["TCGA_scores"], version = 3)
  saveRDS(G315_result$scores, files["G315_scores"], version = 3)
  saveRDS(G588_result$scores, files["G588_scores"], version = 3)

  matrix_to_csv <- function(x, file) {
    d <- data.frame(
      sample_id = colnames(x),
      t(x),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
    write_csv(d, file)
  }
  matrix_to_csv(TCGA_result$scores, files["TCGA_scores_csv"])
  matrix_to_csv(G315_result$scores, files["G315_scores_csv"])
  matrix_to_csv(G588_result$scores, files["G588_scores_csv"])

  write_csv(all_results, files["results"])
  write_csv(benchmark, files["benchmark"])
  write_csv(normalization_audit, files["normalization"])
  write_csv(method_audit, files["methods"])
  write_csv(parameter_lock, files["parameters"])
  write_csv(package_audit, files["packages"])
  write_csv(input_manifest, files["inputs"])
  write_csv(integrity, files["integrity"])

  writeLines(
    capture.output(show(TCGA_result$gsva_parameter)),
    files["TCGA_GSVA_details"], useBytes = TRUE
  )
  writeLines(
    capture.output(show(G315_result$gsva_parameter)),
    files["G315_GSVA_details"], useBytes = TRUE
  )
  writeLines(
    capture.output(show(G588_result$gsva_parameter)),
    files["G588_GSVA_details"], useBytes = TRUE
  )
  capture.output(sessionInfo(), file = files["session"])

  EMT_text <- apply(
    EMT_rows[, c(
      "cohort", "estimate", "two_sided_p", "BH_adjusted_p",
      "rank_by_absolute_rho"
    )],
    1L,
    function(x) paste(
      x["cohort"],
      paste0("rho=", format(as.numeric(x["estimate"]), digits = 16)),
      paste0("p=", format(as.numeric(x["two_sided_p"]), digits = 16)),
      paste0("BH=", format(as.numeric(x["BH_adjusted_p"]), digits = 16)),
      paste0("abs-rank=", x["rank_by_absolute_rho"]),
      sep = "; "
    )
  )

  report <- c(
    "============================================================",
    "TNBC_Triclosan - Script 14B Hallmark Cohort Associations",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "Hallmark pathways scored per cohort: 50",
    "Cohort association rows: 150",
    paste0(
      "Score dimensions: TCGA=",
      paste(dim(TCGA_result$scores), collapse = " x "),
      "; GSE31519=",
      paste(dim(G315_result$scores), collapse = " x "),
      "; GSE58812=",
      paste(dim(G588_result$scores), collapse = " x ")
    ),
    "Accepted EMT score benchmarks reproduced: TRUE",
    "Accepted EMT effect benchmarks reproduced: TRUE",
    "EMT cohort results:",
    paste0("  ", EMT_text),
    "Within-cohort BH across 50 pathways: TRUE",
    "Cross-cohort meta-analysis performed: FALSE",
    "Pathway selection after results: FALSE",
    "New score/survival/cutoff/grouping/sample filtering performed: FALSE",
    paste0("Readiness status: ", readiness_status),
    "",
    "SCRIPT14B STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  t2 <- readRDS(files["TCGA_scores"])
  g12 <- readRDS(files["G315_scores"])
  g22 <- readRDS(files["G588_scores"])
  r2 <- read.csv(
    files["results"], stringsAsFactors = FALSE, check.names = FALSE
  )
  e2 <- read.csv(
    files["benchmark"], stringsAsFactors = FALSE, check.names = FALSE
  )

  assert(
    same_text(b2$readiness_status, "READY_FOR_SCRIPT14C") &&
      identical(t2, TCGA_result$scores) &&
      identical(g12, G315_result$scores) &&
      identical(g22, G588_result$scores) &&
      nrow(r2) == 150L &&
      isTRUE(all.equal(
        r2$estimate,
        all_results$estimate,
        tolerance = 1e-14,
        check.attributes = FALSE
      )) &&
      nrow(e2) == 3L &&
      all(as.logical(e2$score_reproduction_pass)) &&
      all(as.logical(e2$effect_reproduction_pass)),
    "Staged RDS/CSV save-read verification failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script14B_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script14B_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script14B_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script 14B completed successfully.\n")
  cat("50 Hallmark pathways scored in all three cohorts.\n")
  cat("Accepted EMT score and effect benchmarks reproduced.\n")
  cat("Cross-cohort meta-analysis performed: FALSE\n")
  cat("Readiness status: READY_FOR_SCRIPT14C\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()

# ==============================================================================
# TNBC_Triclosan | Script 15A COMPACT FINAL
# Matched random 24-gene null: preflight, feature construction and pool lock.
#
# This step performs NO random-signature generation, NO GSVA and NO empirical
# significance test.
#
# Matching dimensions:
# - mean-expression percentile in each of three cohorts;
# - expression-SD percentile in each of three cohorts;
# - exact Hallmark EMT membership, so every future 24-gene null contains
#   exactly two EMT genes, matching IL6 and JUN in the locked signature.
#
# For every locked gene, the 50 nearest eligible genes are retained according
# to RMS distance across the six percentile features.
#
# No result-dependent rejection or biological outcome is used for matching.
# ==============================================================================

rm(list = ls(all.names = TRUE))
gc()
options(stringsAsFactors = FALSE, warn = 1)
Sys.setenv(TZ = "Asia/Singapore")

BUILD_ID <- "Script15A_COMPACT_FINAL_20260712"
PROJECT_ROOT <- "C:/Users/14351/Documents/TNBC_Triclosan"

SCRIPT14A_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "00_preflight_and_input_lock"
)
SCRIPT14C_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "02_Hallmark_panorama",
  "02_cross_cohort_Hallmark_meta_and_EMT_ranking"
)
CORE_META_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "01_final_EMT_correlation_meta_analysis"
)
OUTPUT_ROOT <- file.path(
  PROJECT_ROOT,
  "Step5_cross_cohort_synthesis",
  "03_matched_random_24gene_null",
  "00_preflight_and_matching_pool"
)

INPUTS <- c(
  Script14A_bundle = file.path(
    SCRIPT14A_ROOT, "objects",
    "Hallmark_panorama_preflight_COMPLETE_bundle.rds"
  ),
  TCGA_prepared = file.path(
    SCRIPT14A_ROOT, "objects",
    "TCGA_TNBC_Hallmark_panorama_prepared_input.rds"
  ),
  GSE31519_prepared = file.path(
    SCRIPT14A_ROOT, "objects",
    "GSE31519_Hallmark_panorama_prepared_input.rds"
  ),
  GSE58812_prepared = file.path(
    SCRIPT14A_ROOT, "objects",
    "GSE58812_Hallmark_panorama_prepared_input.rds"
  ),
  Hallmark_collection = file.path(
    SCRIPT14A_ROOT, "objects",
    "Human_Hallmark_collection_locked.rds"
  ),
  Script14A_manifest = file.path(
    SCRIPT14A_ROOT, "audit",
    "Script14A_output_manifest_with_MD5.csv"
  ),
  Script14A_report = file.path(
    SCRIPT14A_ROOT, "logs",
    "Script14A_COMPLETE_report.txt"
  ),
  Script14C_bundle = file.path(
    SCRIPT14C_ROOT, "objects",
    "Hallmark_panorama_cross_cohort_meta_COMPLETE_bundle.rds"
  ),
  Script14C_manifest = file.path(
    SCRIPT14C_ROOT, "audit",
    "Script14C_output_manifest_with_MD5.csv"
  ),
  Script14C_report = file.path(
    SCRIPT14C_ROOT, "logs",
    "Script14C_COMPLETE_report.txt"
  ),
  core_meta_bundle = file.path(
    CORE_META_ROOT, "objects",
    "Cross_cohort_EMT_meta_analysis_COMPLETE_bundle.rds"
  ),
  core_meta_manifest = file.path(
    CORE_META_ROOT, "audit",
    "Script13G_C_output_manifest_with_MD5.csv"
  ),
  core_meta_report = file.path(
    CORE_META_ROOT, "logs",
    "Script13G_C_COMPLETE_report.txt"
  )
)

EXPECTED_MD5 <- c(
  Script14A_bundle = "fd38a6e71ca6b58eecd337ae7600d5b5",
  TCGA_prepared = "55537d7f98fb915a811f1456072e6091",
  GSE31519_prepared = "2b6bba1d414c42625ab3cc00357a6a20",
  GSE58812_prepared = "cb667dcba01e5740eb6ecd607035b2bc",
  Hallmark_collection = "c6e2898a41dafdc39ea56747be0fbcc0",
  Script14A_manifest = "74f777ca434b0a6b4b420e0ead93f363",
  Script14A_report = "ebf11ae0ac8fc681200a7859e6a12b0c",
  Script14C_bundle = "344177cdf25b6ce60966a5d9ca75cc75",
  Script14C_manifest = "872175cac5a73dc270fb020c4a9b4d80",
  Script14C_report = "974a86afd1369def9d9240ab72b9cdac",
  core_meta_bundle = "7625b1e291e1291762426382eb80a1f4",
  core_meta_manifest = "33d11d8780ce3964b4c5170510c21982",
  core_meta_report = "799b798e670d2b5b639d9294b7a259a2"
)

LOCKED24 <- c(
  "ESR1","AR","PGR","THRA","THRB","CAT","BCL2","BAX","PARP1","IL6",
  "ABCB1","ABCG2","FASN","SCD","TWIST1","PPARG","EGFR","MMP9","JUN",
  "FOS","ADRB2","ERG","H2AX","MITF"
)

EMT_NAME <- "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION"
COHORT_ORDER <- c("TCGA_TNBC", "GSE31519", "GSE58812")
EXPECTED_DIMENSIONS <- list(
  TCGA_TNBC = c(56477L, 197L),
  GSE31519 = c(12650L, 579L),
  GSE58812 = c(20823L, 107L)
)
EXPECTED_COMMON_GENE_NUMBER <- 12394L
EXPECTED_COMMON_EMT_GENE_NUMBER <- 197L
EXPECTED_EMT_OVERLAP <- c("IL6", "JUN")
NEIGHBOR_NUMBER <- 50L
RANDOM_SET_NUMBER <- 5000L
RANDOM_SEED <- 20260712L
MAX_ATTEMPTS_PER_SET <- 100L
NUMERIC_TOLERANCE <- 1e-12

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert <- function(ok, ...) if (!isTRUE(ok)) stopf(...)
md5 <- function(x) tolower(unname(tools::md5sum(x)))
write_csv <- function(x, path) write.csv(
  x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8"
)

scalar_text <- function(x, label = "value") {
  y <- as.character(x)
  assert(length(y) == 1L && !is.na(y) && nzchar(trimws(y)),
         "%s must be one nonblank scalar value.", label)
  unname(trimws(y))
}

same_text <- function(x, y) {
  identical(
    scalar_text(x, "observed text"),
    scalar_text(y, "expected text")
  )
}

same_numeric <- function(x, y, tolerance = NUMERIC_TOLERANCE) {
  isTRUE(all.equal(
    as.numeric(x),
    as.numeric(y),
    tolerance = tolerance,
    check.attributes = FALSE
  ))
}

report_contains <- function(file, marker) {
  any(grepl(
    marker,
    readLines(file, warn = FALSE, encoding = "UTF-8"),
    fixed = TRUE
  ))
}

manifest_ok <- function(root, file) {
  m <- tryCatch(
    read.csv(file, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(m) || !nrow(m) ||
      !all(c("relative_path", "size_bytes", "md5") %in% names(m)) ||
      anyDuplicated(m$relative_path)) return(FALSE)

  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  all(vapply(seq_len(nrow(m)), function(i) {
    rel <- gsub("\\\\", "/", as.character(m$relative_path[i]))
    parts <- strsplit(rel, "/", fixed = TRUE)[[1L]]
    if (!nzchar(rel) || grepl("^([A-Za-z]:|/)", rel) ||
        any(parts %in% c(".", ".."))) return(FALSE)

    f <- file.path(root, rel)
    if (!file.exists(f)) return(FALSE)
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)

    startsWith(f2, paste0(root2, "/")) &&
      identical(as.numeric(file.info(f)$size), as.numeric(m$size_bytes[i])) &&
      identical(md5(f), tolower(trimws(as.character(m$md5[i]))))
  }, logical(1)))
}

make_manifest <- function(files, root) {
  root2 <- normalizePath(root, winslash = "/", mustWork = TRUE)
  rel <- vapply(files, function(f) {
    f2 <- normalizePath(f, winslash = "/", mustWork = TRUE)
    assert(startsWith(f2, paste0(root2, "/")),
           "Output is outside staging root: %s", f2)
    substring(f2, nchar(root2) + 2L)
  }, character(1))

  data.frame(
    file_name = basename(files),
    relative_path = rel,
    size_bytes = as.numeric(file.info(files)$size),
    md5 = vapply(files, md5, character(1)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

validate_prepared <- function(object, cohort, expected_dim) {
  assert(is.list(object), "%s prepared input is not a list.", cohort)
  assert(same_text(object$cohort, cohort),
         "%s prepared cohort identity is incorrect.", cohort)

  x <- object$expression
  assert(
    is.matrix(x) && is.numeric(x) &&
      identical(dim(x), expected_dim) &&
      !is.null(rownames(x)) && !is.null(colnames(x)) &&
      !anyDuplicated(rownames(x)) &&
      !anyDuplicated(colnames(x)) &&
      all(nzchar(rownames(x))) &&
      all(nzchar(colnames(x))) &&
      all(is.finite(x)),
    "%s prepared expression matrix is malformed.", cohort
  )
  assert(
    is.numeric(object$Triclosan_activity) &&
      length(object$Triclosan_activity) == ncol(x) &&
      identical(names(object$Triclosan_activity), colnames(x)) &&
      all(is.finite(object$Triclosan_activity)),
    "%s prepared score is malformed or misaligned.", cohort
  )
  x
}

percentile_rank <- function(x) {
  assert(length(x) > 1L && all(is.finite(x)),
         "Percentile-rank input is invalid.")
  as.numeric(rank(x, ties.method = "average")) / length(x)
}

feature_block <- function(x, cohort) {
  gene_mean <- rowMeans(x)
  gene_SD <- apply(x, 1L, stats::sd)

  assert(
    all(is.finite(gene_mean)) &&
      all(is.finite(gene_SD) & gene_SD > 0),
    "%s common-gene means or SD values are invalid.", cohort
  )

  data.frame(
    gene_symbol = rownames(x),
    mean_expression = gene_mean,
    expression_SD = gene_SD,
    mean_percentile = percentile_rank(gene_mean),
    SD_percentile = percentile_rank(gene_SD),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

dl_meta <- function(rho, n) {
  rho <- as.numeric(rho)
  n <- as.numeric(n)
  assert(
    length(rho) == 3L && length(n) == 3L &&
      all(is.finite(rho) & rho > -1 & rho < 1) &&
      all(n > 3),
    "Observed meta input is invalid."
  )

  z <- atanh(rho)
  variance <- 1 / (n - 3)
  w <- 1 / variance
  z_fixed <- sum(w * z) / sum(w)
  Q <- sum(w * (z - z_fixed)^2)
  df <- length(z) - 1L
  C <- sum(w) - sum(w^2) / sum(w)
  tau2 <- if (C > 0) max(0, (Q - df) / C) else 0
  wr <- 1 / (variance + tau2)
  zr <- sum(wr * z) / sum(wr)
  ser <- sqrt(1 / sum(wr))
  critical <- qnorm(0.975)

  data.frame(
    random_pooled_rho = tanh(zr),
    random_95CI_lower_rho = tanh(zr - critical * ser),
    random_95CI_upper_rho = tanh(zr + critical * ser),
    random_two_sided_p =
      2 * pnorm(abs(zr / ser), lower.tail = FALSE),
    Cochran_Q = Q,
    Q_p = pchisq(Q, df = df, lower.tail = FALSE),
    I2_percent =
      if (Q > 0) max(0, (Q - df) / Q) * 100 else 0,
    tau2 = tau2,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

greedy_assignment_possible <- function(target_order, candidate_list) {
  used <- character(0)
  for (target in target_order) {
    available <- setdiff(candidate_list[[target]], used)
    if (!length(available)) return(FALSE)
    used <- c(used, available[1L])
  }
  length(unique(used)) == length(target_order)
}

existing_valid <- function(root) {
  key <- c(
    bundle = file.path(
      root, "objects",
      "Matched_random24_preflight_COMPLETE_bundle.rds"
    ),
    features = file.path(
      root, "objects",
      "Cross_cohort_common_gene_matching_features.rds"
    ),
    candidates = file.path(
      root, "objects",
      "Locked24_target_candidate_neighbors.rds"
    ),
    manifest = file.path(
      root, "audit",
      "Script15A_output_manifest_with_MD5.csv"
    ),
    report = file.path(
      root, "logs",
      "Script15A_COMPLETE_report.txt"
    )
  )
  if (!all(file.exists(key)) || !manifest_ok(root, key["manifest"])) {
    return(FALSE)
  }
  if (!report_contains(key["report"], "SCRIPT15A STATUS: COMPLETE")) {
    return(FALSE)
  }

  b <- tryCatch(readRDS(key["bundle"]), error = function(e) NULL)
  f <- tryCatch(readRDS(key["features"]), error = function(e) NULL)
  c <- tryCatch(readRDS(key["candidates"]), error = function(e) NULL)

  is.list(b) &&
    same_text(b$script, "Script15A") &&
    same_text(b$script_build_id, BUILD_ID) &&
    same_text(b$readiness_status, "READY_FOR_SCRIPT15B") &&
    is.data.frame(f) && nrow(f) == EXPECTED_COMMON_GENE_NUMBER &&
    is.data.frame(c) &&
    nrow(c) == length(LOCKED24) * NEIGHBOR_NUMBER &&
    isFALSE(b$policy$random_signatures_generated)
}

prepare_output <- function() {
  if (!dir.exists(OUTPUT_ROOT)) return(FALSE)
  entries <- setdiff(list.files(OUTPUT_ROOT, all.files = TRUE), c(".", ".."))

  if (!length(entries)) {
    unlink(OUTPUT_ROOT, recursive = TRUE, force = TRUE)
    assert(!dir.exists(OUTPUT_ROOT),
           "Empty output directory could not be removed.")
    return(FALSE)
  }

  if (existing_valid(OUTPUT_ROOT)) {
    cat("Existing Script15A output is complete and valid.\n")
    cat("Nothing was overwritten or recalculated.\n")
    cat("Please compress and upload:\n", OUTPUT_ROOT, "\n", sep = "")
    cat("✅ 已完成\n")
    return(TRUE)
  }

  archive <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      "00_preflight_and_matching_pool_INCOMPLETE_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  assert(file.rename(OUTPUT_ROOT, archive),
         "Existing output is incomplete, but safe archiving failed.")
  assert(!dir.exists(OUTPUT_ROOT) && dir.exists(archive),
         "Archive verification failed.")
  cat("Incomplete/stale directory preserved at:\n", archive, "\n", sep = "")
  FALSE
}

main <- function() {
  cat("============================================================\n")
  cat("RUNNING: ", BUILD_ID, "\n", sep = "")
  cat("Matched random-24 preflight and candidate-pool lock only.\n")
  cat("============================================================\n")

  missing_files <- INPUTS[!file.exists(INPUTS)]
  assert(!length(missing_files), "Missing accepted input(s):\n%s",
         paste(missing_files, collapse = "\n"))

  observed_md5 <- vapply(INPUTS, md5, character(1))
  assert(
    identical(unname(observed_md5), unname(EXPECTED_MD5)),
    "At least one accepted input MD5 differs:\n%s",
    paste(sprintf(
      "%s | expected=%s | observed=%s",
      names(EXPECTED_MD5), EXPECTED_MD5, observed_md5
    ), collapse = "\n")
  )

  assert(
    manifest_ok(SCRIPT14A_ROOT, INPUTS["Script14A_manifest"]),
    "Script14A manifest verification failed."
  )
  assert(
    manifest_ok(SCRIPT14C_ROOT, INPUTS["Script14C_manifest"]),
    "Script14C manifest verification failed."
  )
  assert(
    manifest_ok(CORE_META_ROOT, INPUTS["core_meta_manifest"]),
    "Core EMT meta manifest verification failed."
  )
  assert(
    report_contains(INPUTS["Script14A_report"],
                    "SCRIPT14A STATUS: COMPLETE") &&
      report_contains(INPUTS["Script14C_report"],
                      "SCRIPT14C STATUS: COMPLETE") &&
      report_contains(INPUTS["core_meta_report"],
                      "SCRIPT13G_C STATUS: COMPLETE"),
    "At least one accepted completion marker is missing."
  )

  preflight <- readRDS(INPUTS["Script14A_bundle"])
  panorama <- readRDS(INPUTS["Script14C_bundle"])
  core_meta <- readRDS(INPUTS["core_meta_bundle"])

  assert(
    is.list(preflight) &&
      same_text(preflight$script, "Script14A") &&
      same_text(
        preflight$script_build_id,
        "Script14A_v2_COMPACT_FINAL_20260711"
      ) &&
      same_text(preflight$readiness_status, "READY_FOR_SCRIPT14B"),
    "Script14A accepted bundle identity is incorrect."
  )
  assert(
    is.list(panorama) &&
      same_text(panorama$script, "Script14C") &&
      same_text(
        panorama$script_build_id,
        "Script14C_COMPACT_FINAL_20260712"
      ) &&
      same_text(
        panorama$strengthening_analysis_status,
        "HALLMARK_PANORAMA_COMPLETE"
      ) &&
      isFALSE(panorama$policy$pathway_selection_after_results),
    "Script14C accepted bundle identity is incorrect."
  )
  assert(
    is.list(core_meta) &&
      same_text(core_meta$script, "Script13G_C") &&
      same_text(
        core_meta$script_build_id,
        "Script13G_C_v2_COMPACT_FINAL_20260711"
      ) &&
      same_text(core_meta$analysis_freeze_decision, "FREEZE_ANALYSIS"),
    "Accepted core EMT bundle identity is incorrect."
  )

  Hallmark <- readRDS(INPUTS["Hallmark_collection"])
  assert(
    is.list(Hallmark) && length(Hallmark) == 50L &&
      EMT_NAME %in% names(Hallmark),
    "Locked Hallmark collection is malformed."
  )
  EMT_genes <- sort(unique(as.character(Hallmark[[EMT_NAME]])))

  TCGA <- readRDS(INPUTS["TCGA_prepared"])
  G315 <- readRDS(INPUTS["GSE31519_prepared"])
  G588 <- readRDS(INPUTS["GSE58812_prepared"])

  TCGA_expr <- validate_prepared(
    TCGA, "TCGA_TNBC", EXPECTED_DIMENSIONS$TCGA_TNBC
  )
  G315_expr <- validate_prepared(
    G315, "GSE31519", EXPECTED_DIMENSIONS$GSE31519
  )
  G588_expr <- validate_prepared(
    G588, "GSE58812", EXPECTED_DIMENSIONS$GSE58812
  )

  common_genes <- sort(Reduce(
    intersect,
    list(
      rownames(TCGA_expr),
      rownames(G315_expr),
      rownames(G588_expr)
    )
  ))

  assert(
    length(common_genes) == EXPECTED_COMMON_GENE_NUMBER &&
      !anyDuplicated(common_genes) &&
      all(LOCKED24 %in% common_genes),
    "Cross-cohort common-gene universe differs from the accepted lock."
  )

  common_EMT <- intersect(common_genes, EMT_genes)
  observed_EMT_overlap <- intersect(LOCKED24, EMT_genes)

  assert(
    length(common_EMT) == EXPECTED_COMMON_EMT_GENE_NUMBER &&
      identical(sort(observed_EMT_overlap),
                sort(EXPECTED_EMT_OVERLAP)),
    "Common EMT membership or locked-signature overlap is incorrect."
  )

  TCGA_common <- TCGA_expr[common_genes, , drop = FALSE]
  G315_common <- G315_expr[common_genes, , drop = FALSE]
  G588_common <- G588_expr[common_genes, , drop = FALSE]

  TCGA_features <- feature_block(TCGA_common, "TCGA_TNBC")
  G315_features <- feature_block(G315_common, "GSE31519")
  G588_features <- feature_block(G588_common, "GSE58812")

  features <- data.frame(
    gene_symbol = common_genes,
    in_locked24 = common_genes %in% LOCKED24,
    in_Hallmark_EMT = common_genes %in% EMT_genes,
    TCGA_mean_expression = TCGA_features$mean_expression,
    TCGA_expression_SD = TCGA_features$expression_SD,
    TCGA_mean_percentile = TCGA_features$mean_percentile,
    TCGA_SD_percentile = TCGA_features$SD_percentile,
    GSE31519_mean_expression = G315_features$mean_expression,
    GSE31519_expression_SD = G315_features$expression_SD,
    GSE31519_mean_percentile = G315_features$mean_percentile,
    GSE31519_SD_percentile = G315_features$SD_percentile,
    GSE58812_mean_expression = G588_features$mean_expression,
    GSE58812_expression_SD = G588_features$expression_SD,
    GSE58812_mean_percentile = G588_features$mean_percentile,
    GSE58812_SD_percentile = G588_features$SD_percentile,
    eligible_random_candidate = !(common_genes %in% LOCKED24),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  feature_columns <- c(
    "TCGA_mean_percentile", "TCGA_SD_percentile",
    "GSE31519_mean_percentile", "GSE31519_SD_percentile",
    "GSE58812_mean_percentile", "GSE58812_SD_percentile"
  )

  assert(
    nrow(features) == EXPECTED_COMMON_GENE_NUMBER &&
      !anyDuplicated(features$gene_symbol) &&
      all(is.finite(as.matrix(features[, feature_columns]))) &&
      all(as.matrix(features[, feature_columns]) > 0) &&
      all(as.matrix(features[, feature_columns]) <= 1),
    "Cross-cohort matching feature table failed integrity checks."
  )

  candidate_rows <- lapply(LOCKED24, function(target) {
    target_row <- features[
      features$gene_symbol == target,
      ,
      drop = FALSE
    ]
    assert(nrow(target_row) == 1L,
           "Locked target %s is missing or duplicated.", target)

    eligible <- features[
      features$eligible_random_candidate &
        features$in_Hallmark_EMT == target_row$in_Hallmark_EMT,
      ,
      drop = FALSE
    ]

    target_vector <- as.numeric(target_row[, feature_columns])
    candidate_matrix <- as.matrix(eligible[, feature_columns])
    delta <- sweep(candidate_matrix, 2L, target_vector, FUN = "-")
    distance <- sqrt(rowMeans(delta^2))
    mean_absolute_difference <- rowMeans(abs(delta))
    maximum_absolute_difference <- apply(abs(delta), 1L, max)

    order_index <- order(distance, eligible$gene_symbol)
    keep <- order_index[seq_len(NEIGHBOR_NUMBER)]

    data.frame(
      target_gene = target,
      target_order = match(target, LOCKED24),
      target_in_Hallmark_EMT = target_row$in_Hallmark_EMT,
      eligible_candidate_number = nrow(eligible),
      candidate_gene = eligible$gene_symbol[keep],
      candidate_in_Hallmark_EMT =
        eligible$in_Hallmark_EMT[keep],
      neighbor_rank = seq_len(NEIGHBOR_NUMBER),
      six_feature_RMS_distance = distance[keep],
      six_feature_mean_absolute_difference =
        mean_absolute_difference[keep],
      six_feature_maximum_absolute_difference =
        maximum_absolute_difference[keep],
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  })

  candidates <- do.call(rbind, candidate_rows)
  rownames(candidates) <- NULL

  assert(
    nrow(candidates) == length(LOCKED24) * NEIGHBOR_NUMBER &&
      !anyDuplicated(candidates[c("target_gene", "neighbor_rank")]) &&
      all(table(candidates$target_gene) == NEIGHBOR_NUMBER) &&
      all(!candidates$candidate_gene %in% LOCKED24) &&
      all(
        candidates$target_in_Hallmark_EMT ==
          candidates$candidate_in_Hallmark_EMT
      ) &&
      all(is.finite(candidates$six_feature_RMS_distance)) &&
      all(candidates$six_feature_RMS_distance >= 0),
    "Target-specific candidate-neighbor table failed integrity checks."
  )

  candidate_list <- split(
    candidates$candidate_gene,
    factor(candidates$target_gene, levels = LOCKED24)
  )
  candidate_list <- lapply(candidate_list, as.character)

  rotations <- lapply(seq_along(LOCKED24), function(i) {
    c(
      LOCKED24[i:length(LOCKED24)],
      if (i > 1L) LOCKED24[seq_len(i - 1L)] else character(0)
    )
  })
  feasibility_orders <- c(
    rotations,
    lapply(rotations, rev)
  )
  feasibility_pass <- vapply(
    feasibility_orders,
    greedy_assignment_possible,
    logical(1),
    candidate_list = candidate_list
  )

  assert(
    all(feasibility_pass),
    "At least one deterministic target order lacks a unique assignment."
  )

  EMT_targets <- LOCKED24[LOCKED24 %in% EMT_genes]
  non_EMT_targets <- setdiff(LOCKED24, EMT_targets)
  EMT_neighbor_union <- unique(unlist(
    candidate_list[EMT_targets],
    use.names = FALSE
  ))
  non_EMT_neighbor_union <- unique(unlist(
    candidate_list[non_EMT_targets],
    use.names = FALSE
  ))

  pool_summary <- data.frame(
    item = c(
      "Common_gene_universe",
      "Locked_signature_gene_number",
      "Common_Hallmark_EMT_gene_number",
      "Locked_signature_EMT_overlap_number",
      "Locked_signature_non_EMT_gene_number",
      "Eligible_candidate_total",
      "Eligible_candidate_EMT",
      "Eligible_candidate_non_EMT",
      "Neighbors_per_locked_gene",
      "Candidate_neighbor_row_number",
      "EMT_target_neighbor_union",
      "Non_EMT_target_neighbor_union",
      "Deterministic_feasibility_order_number",
      "Deterministic_feasibility_pass_number"
    ),
    value = c(
      length(common_genes),
      length(LOCKED24),
      length(common_EMT),
      length(EMT_targets),
      length(non_EMT_targets),
      sum(features$eligible_random_candidate),
      sum(
        features$eligible_random_candidate &
          features$in_Hallmark_EMT
      ),
      sum(
        features$eligible_random_candidate &
          !features$in_Hallmark_EMT
      ),
      NEIGHBOR_NUMBER,
      nrow(candidates),
      length(EMT_neighbor_union),
      length(non_EMT_neighbor_union),
      length(feasibility_pass),
      sum(feasibility_pass)
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assert(
    pool_summary$value[
      pool_summary$item == "Eligible_candidate_EMT"
    ] == 195L &&
      pool_summary$value[
        pool_summary$item == "Eligible_candidate_non_EMT"
      ] == 12175L &&
      length(EMT_neighbor_union) >= length(EMT_targets) &&
      length(non_EMT_neighbor_union) >= length(non_EMT_targets),
    "Matching candidate pool counts are incorrect."
  )

  target_summary <- do.call(rbind, lapply(LOCKED24, function(target) {
    d <- candidates[
      candidates$target_gene == target,
      ,
      drop = FALSE
    ]
    data.frame(
      target_gene = target,
      target_order = match(target, LOCKED24),
      target_in_Hallmark_EMT =
        unique(d$target_in_Hallmark_EMT),
      eligible_candidate_number =
        unique(d$eligible_candidate_number),
      nearest_distance =
        min(d$six_feature_RMS_distance),
      median_top50_distance =
        median(d$six_feature_RMS_distance),
      maximum_top50_distance =
        max(d$six_feature_RMS_distance),
      unique_top50_candidate_number =
        length(unique(d$candidate_gene)),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))

  locked_features <- features[
    match(LOCKED24, features$gene_symbol),
    ,
    drop = FALSE
  ]
  locked_features$locked_gene_order <- seq_along(LOCKED24)
  locked_features <- locked_features[, c(
    "locked_gene_order",
    setdiff(names(locked_features), "locked_gene_order")
  )]

  full_EMT <- panorama$EMT_rank_summary
  assert(
    is.data.frame(full_EMT) && nrow(full_EMT) == 1L &&
      same_text(full_EMT$pathway, EMT_NAME) &&
      full_EMT$rank_by_absolute_random_rho == 5L,
    "Accepted Hallmark EMT panorama benchmark is incorrect."
  )

  overlap_effects <- core_meta$overlap_removed_effects
  assert(
    is.data.frame(overlap_effects) &&
      nrow(overlap_effects) == 3L &&
      all(c("cohort", "sample_number", "rho") %in%
            names(overlap_effects)),
    "Accepted overlap-removed cohort effects are malformed."
  )
  overlap_effects <- overlap_effects[
    match(COHORT_ORDER, overlap_effects$cohort),
    ,
    drop = FALSE
  ]
  assert(
    identical(as.character(overlap_effects$cohort), COHORT_ORDER),
    "Overlap-removed cohort order is incomplete."
  )
  no_overlap_meta <- dl_meta(
    overlap_effects$rho,
    overlap_effects$sample_number
  )

  observed_benchmarks <- rbind(
    data.frame(
      analysis = "FULL_LOCKED24",
      gene_number = 24L,
      direct_EMT_overlap_gene_number = 2L,
      TCGA_TNBC_rho = full_EMT$TCGA_TNBC_rho,
      GSE31519_rho = full_EMT$GSE31519_rho,
      GSE58812_rho = full_EMT$GSE58812_rho,
      random_pooled_rho = full_EMT$random_pooled_rho,
      random_95CI_lower_rho =
        full_EMT$random_95CI_lower_rho,
      random_95CI_upper_rho =
        full_EMT$random_95CI_upper_rho,
      random_two_sided_p = full_EMT$random_two_sided_p,
      I2_percent = full_EMT$I2_percent,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    data.frame(
      analysis = "NO_OVERLAP_LOCKED22",
      gene_number = 22L,
      direct_EMT_overlap_gene_number = 0L,
      TCGA_TNBC_rho = overlap_effects$rho[1L],
      GSE31519_rho = overlap_effects$rho[2L],
      GSE58812_rho = overlap_effects$rho[3L],
      random_pooled_rho = no_overlap_meta$random_pooled_rho,
      random_95CI_lower_rho =
        no_overlap_meta$random_95CI_lower_rho,
      random_95CI_upper_rho =
        no_overlap_meta$random_95CI_upper_rho,
      random_two_sided_p = no_overlap_meta$random_two_sided_p,
      I2_percent = no_overlap_meta$I2_percent,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  )

  design_lock <- data.frame(
    field = c(
      "Primary_null",
      "Sensitivity_null",
      "Random_set_number",
      "Random_seed",
      "Locked_target_gene_number",
      "Neighbors_per_target",
      "Matching_feature_number",
      "Matching_features",
      "Feature_scaling",
      "Distance",
      "EMT_membership_matching",
      "Locked_genes_allowed_as_candidates",
      "Duplicates_within_random_set",
      "Candidate_sampling",
      "Target_order_per_attempt",
      "Maximum_attempts_per_set",
      "Duplicate_random_sets",
      "Result_based_set_rejection",
      "Primary_empirical_p",
      "Absolute_empirical_p",
      "Future_cohort_methods",
      "Future_meta_method",
      "Random_signatures_generated_in_Script15A",
      "GSVA_performed_in_Script15A",
      "Next_script"
    ),
    value = c(
      paste0(
        "5000 matched 24-gene sets; exactly 2 Hallmark EMT genes; ",
        "compare with full locked24"
      ),
      paste0(
        "Drop the two candidates matched to IL6 and JUN; ",
        "5000 matched 22-gene sets with 0 EMT genes; compare with locked22"
      ),
      RANDOM_SET_NUMBER,
      RANDOM_SEED,
      length(LOCKED24),
      NEIGHBOR_NUMBER,
      length(feature_columns),
      paste(feature_columns, collapse = ";"),
      "Within-cohort percentile ranks across 12,394 common genes",
      "RMS Euclidean distance across six percentile features",
      "Exact target-specific membership; 2 EMT + 22 non-EMT",
      "FALSE",
      "PROHIBITED",
      "Uniform among currently unused target-specific top-50 candidates",
      "Random permutation of the 24 locked targets for each attempt",
      MAX_ATTEMPTS_PER_SET,
      "PROHIBITED; retry until 5000 unique sets are obtained",
      "PROHIBITED",
      "(1 + number null pooled rho >= observed) / 5001",
      "(1 + number abs(null pooled rho) >= abs(observed)) / 5001",
      paste0(
        "TCGA/GSE58812 Spearman; GSE31519 source-adjusted ",
        "centered-rank partial Spearman"
      ),
      "Fisher z; variance 1/(n-3); DerSimonian-Laird random effects",
      "FALSE",
      "FALSE",
      "Script15B: generate and audit 5000 unique matched mappings only"
    ),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  input_manifest <- data.frame(
    input_name = names(INPUTS),
    project_relative_path = substring(
      normalizePath(INPUTS, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(
        PROJECT_ROOT, winslash = "/", mustWork = TRUE
      )) + 2L
    ),
    size_bytes = as.numeric(file.info(INPUTS)$size),
    md5 = observed_md5,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  readiness_status <- "READY_FOR_SCRIPT15B"
  integrity <- data.frame(
    item = c(
      "Script",
      "Script_build_ID",
      "Input_file_number",
      "Input_MD5_all_locked",
      "Common_gene_number",
      "Common_EMT_gene_number",
      "Locked24_all_common",
      "Locked24_EMT_overlap",
      "Matching_feature_number",
      "Candidate_neighbor_row_number",
      "Neighbors_per_target",
      "Unique_assignment_feasibility_pass",
      "Observed_full24_benchmark_saved",
      "Observed_no_overlap22_benchmark_saved",
      "Random_signatures_generated",
      "GSVA_performed",
      "Outcome_used_for_matching",
      "Readiness_status",
      "Completion_status"
    ),
    value = as.character(c(
      "15A",
      BUILD_ID,
      length(INPUTS),
      TRUE,
      length(common_genes),
      length(common_EMT),
      all(LOCKED24 %in% common_genes),
      paste(sort(observed_EMT_overlap), collapse = ";"),
      length(feature_columns),
      nrow(candidates),
      NEIGHBOR_NUMBER,
      all(feasibility_pass),
      TRUE,
      TRUE,
      FALSE,
      FALSE,
      FALSE,
      readiness_status,
      "COMPLETE"
    )),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  bundle <- list(
    project = "TNBC_Triclosan",
    step = paste0(
      "Step5_cross_cohort_synthesis/",
      "03_matched_random_24gene_null/",
      "00_preflight_and_matching_pool"
    ),
    script = "Script15A",
    script_build_id = BUILD_ID,
    created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
    readiness_status = readiness_status,
    locked24 = LOCKED24,
    Hallmark_EMT_genes = EMT_genes,
    feature_columns = feature_columns,
    matching_pool_summary = pool_summary,
    target_matching_summary = target_summary,
    observed_benchmarks = observed_benchmarks,
    random_null_design_lock = design_lock,
    input_manifest = input_manifest,
    integrity_summary = integrity,
    policy = list(
      core_analysis_remains_frozen = TRUE,
      Hallmark_panorama_remains_complete = TRUE,
      matching_uses_expression_and_variance_only = TRUE,
      exact_EMT_membership_matching = TRUE,
      outcome_used_for_matching = FALSE,
      random_signatures_generated = FALSE,
      GSVA_performed = FALSE,
      empirical_p_calculated = FALSE,
      result_based_set_rejection = FALSE,
      survival_analysis_performed = FALSE,
      samples_filtered = FALSE,
      cutoff_selected = FALSE,
      manuscript_figure_created = FALSE
    )
  )
  class(bundle) <- c(
    "Matched_random24_preflight_bundle", "list"
  )

  dir.create(dirname(OUTPUT_ROOT), recursive = TRUE, showWarnings = FALSE)
  assert(dir.exists(dirname(OUTPUT_ROOT)),
         "Unable to create random-null parent directory.")
  if (prepare_output()) return(invisible(OUTPUT_ROOT))

  stage <- file.path(
    dirname(OUTPUT_ROOT),
    paste0(
      ".Script15A_staging_",
      format(Sys.time(), "%Y%m%d_%H%M%S"), "_", Sys.getpid()
    )
  )
  dirs <- file.path(stage, c("objects", "audit", "logs"))
  assert(all(vapply(
    dirs, dir.create, logical(1),
    recursive = TRUE, showWarnings = FALSE
  ) | dir.exists(dirs)), "Unable to create staging directories.")

  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage))
            unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)

  files <- c(
    bundle = file.path(
      stage, "objects",
      "Matched_random24_preflight_COMPLETE_bundle.rds"
    ),
    features_rds = file.path(
      stage, "objects",
      "Cross_cohort_common_gene_matching_features.rds"
    ),
    candidates_rds = file.path(
      stage, "objects",
      "Locked24_target_candidate_neighbors.rds"
    ),
    candidate_list = file.path(
      stage, "objects",
      "Locked24_target_candidate_list.rds"
    ),
    features_csv = file.path(
      stage, "audit",
      "Cross_cohort_common_gene_matching_features.csv"
    ),
    locked_features = file.path(
      stage, "audit",
      "Locked24_cross_cohort_matching_features.csv"
    ),
    candidates_csv = file.path(
      stage, "audit",
      "Locked24_target_candidate_neighbors.csv"
    ),
    pool_summary = file.path(
      stage, "audit",
      "Matched_random24_pool_summary.csv"
    ),
    target_summary = file.path(
      stage, "audit",
      "Matched_random24_target_matching_summary.csv"
    ),
    benchmarks = file.path(
      stage, "audit",
      "Matched_random24_observed_EMT_benchmarks.csv"
    ),
    design = file.path(
      stage, "audit",
      "Matched_random24_design_lock.csv"
    ),
    inputs = file.path(
      stage, "audit",
      "Script15A_input_manifest_with_MD5.csv"
    ),
    integrity = file.path(
      stage, "audit",
      "Matched_random24_preflight_integrity_summary.csv"
    ),
    session = file.path(
      stage, "logs",
      "Script15A_sessionInfo.txt"
    ),
    report = file.path(
      stage, "logs",
      "Script15A_COMPLETE_report.txt"
    )
  )

  saveRDS(bundle, files["bundle"], version = 3)
  saveRDS(features, files["features_rds"], version = 3)
  saveRDS(candidates, files["candidates_rds"], version = 3)
  saveRDS(candidate_list, files["candidate_list"], version = 3)

  write_csv(features, files["features_csv"])
  write_csv(locked_features, files["locked_features"])
  write_csv(candidates, files["candidates_csv"])
  write_csv(pool_summary, files["pool_summary"])
  write_csv(target_summary, files["target_summary"])
  write_csv(observed_benchmarks, files["benchmarks"])
  write_csv(design_lock, files["design"])
  write_csv(input_manifest, files["inputs"])
  write_csv(integrity, files["integrity"])
  capture.output(sessionInfo(), file = files["session"])

  report <- c(
    "============================================================",
    "TNBC_Triclosan - Script15A Matched Random-24 Preflight",
    paste0("Script build ID: ", BUILD_ID),
    paste0("Completion time: ",
           format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("Cross-cohort common genes: ", length(common_genes)),
    paste0("Common Hallmark EMT genes: ", length(common_EMT)),
    paste0("Locked signature genes: ", length(LOCKED24)),
    paste0(
      "Locked signature EMT overlap: ",
      paste(sort(observed_EMT_overlap), collapse = ";")
    ),
    paste0("Matching features: ", length(feature_columns)),
    paste0("Nearest candidates per target: ", NEIGHBOR_NUMBER),
    paste0("Candidate-neighbor rows: ", nrow(candidates)),
    paste0("EMT-target neighbor union: ", length(EMT_neighbor_union)),
    paste0(
      "Non-EMT-target neighbor union: ",
      length(non_EMT_neighbor_union)
    ),
    paste0(
      "Deterministic feasibility orders passed: ",
      sum(feasibility_pass), "/", length(feasibility_pass)
    ),
    paste0(
      "Observed full24 pooled rho: ",
      format(
        observed_benchmarks$random_pooled_rho[
          observed_benchmarks$analysis == "FULL_LOCKED24"
        ],
        digits = 16
      )
    ),
    paste0(
      "Observed no-overlap22 pooled rho: ",
      format(
        observed_benchmarks$random_pooled_rho[
          observed_benchmarks$analysis == "NO_OVERLAP_LOCKED22"
        ],
        digits = 16
      )
    ),
    "Random signatures generated: FALSE",
    "GSVA performed: FALSE",
    "Outcome used for matching: FALSE",
    paste0("Readiness status: ", readiness_status),
    "",
    "SCRIPT15A STATUS: COMPLETE",
    "============================================================"
  )
  writeLines(enc2utf8(report), files["report"], useBytes = TRUE)

  assert(all(file.exists(files)) && all(file.info(files)$size > 0),
         "At least one staged output is missing or empty.")

  b2 <- readRDS(files["bundle"])
  f2 <- readRDS(files["features_rds"])
  c2 <- readRDS(files["candidates_rds"])
  l2 <- readRDS(files["candidate_list"])

  assert(
    same_text(b2$readiness_status, "READY_FOR_SCRIPT15B") &&
      identical(f2, features) &&
      identical(c2, candidates) &&
      identical(l2, candidate_list) &&
      nrow(f2) == EXPECTED_COMMON_GENE_NUMBER &&
      nrow(c2) == length(LOCKED24) * NEIGHBOR_NUMBER,
    "Staged RDS save-read verification failed."
  )

  output_manifest <- file.path(
    stage, "audit", "Script15A_output_manifest_with_MD5.csv"
  )
  write_csv(make_manifest(files, stage), output_manifest)
  assert(manifest_ok(stage, output_manifest),
         "Staged output manifest verification failed.")

  renamed <- file.rename(stage, OUTPUT_ROOT)
  if (!renamed) {
    dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
    entries <- list.files(
      stage, full.names = TRUE, all.files = TRUE, no.. = TRUE
    )
    copied <- file.copy(
      entries, OUTPUT_ROOT, recursive = TRUE,
      copy.mode = TRUE, copy.date = TRUE
    )
    if (length(copied) != length(entries) || !all(copied)) {
      committed <- TRUE
      stopf("Final commit failed. Staging preserved at:\n%s", stage)
    }
    assert(
      manifest_ok(
        OUTPUT_ROOT,
        file.path(
          OUTPUT_ROOT, "audit",
          "Script15A_output_manifest_with_MD5.csv"
        )
      ),
      "Copied final output failed manifest verification."
    )
    unlink(stage, recursive = TRUE, force = TRUE)
  }

  committed <- TRUE
  assert(
    manifest_ok(
      OUTPUT_ROOT,
      file.path(
        OUTPUT_ROOT, "audit",
        "Script15A_output_manifest_with_MD5.csv"
      )
    ),
    "Post-commit manifest verification failed."
  )
  assert(existing_valid(OUTPUT_ROOT),
         "Post-commit completed-output validation failed.")

  cat("============================================================\n")
  cat("Script15A completed successfully.\n")
  cat("Cross-cohort matched candidate pools are locked.\n")
  cat("Random signatures generated: FALSE\n")
  cat("Readiness status: READY_FOR_SCRIPT15B\n")
  cat("Output: ", OUTPUT_ROOT, "\n", sep = "")
  cat("============================================================\n")
  cat("✅ 已完成\n")
  invisible(OUTPUT_ROOT)
}

result <- main()
